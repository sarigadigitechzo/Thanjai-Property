import{P as e,i as t,w as n}from"./toast-VL79DcQ1.js";import{a as r,i,l as a,s as o}from"./propertiesStore-CZ8TmvDn.js";var s=`thanjai_property_favorites`;function c(){try{let e=localStorage.getItem(s);return e?JSON.parse(e):[]}catch{return[]}}function l(e){return c().includes(e)}function u(e){let t=c(),n,r=!1;t.includes(e)?(n=t.filter(t=>t!==e),r=!1):(n=[...t,e],r=!0);try{localStorage.setItem(s,JSON.stringify(n))}catch(e){console.error(e)}return window.dispatchEvent(new CustomEvent(`favoritesUpdated`,{detail:{count:n.length,propertyId:e,isSavedNow:r}})),r}var d=`thanjai_blog_posts`,f=[{id:`cauvery-delta-farmlands`,slug:`cauvery-delta-farmlands`,title:`Agricultural Farmland Wealth: Cultivating Returns in Thanjavur Delta`,category:`Agricultural`,date:`28 Jul 2026`,author:`S. Vijayaraghavan`,authorRole:`Managing Director, Thanjai Property`,authorBio:`Leading strategic land acquisitions, premium gated communities, and NRI property concierge services across Tamil Nadu since 2009.`,authorSocial:`https://wa.me/919578311506`,authorAvatar:`https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=200&q=80`,image:`https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80`,excerpt:`Why premium Cauvery riverbed agricultural land in Thanjavur represents resilient generational wealth and high-yield organic agro-farming opportunities.`,metaTitle:`Agricultural Farmland Wealth in Thanjavur Delta | Thanjai Property`,metaDescription:`Why premium Cauvery riverbed agricultural land in Thanjavur represents resilient generational wealth and high-yield agro-farming opportunities.`,content:`<p class="blog-lead">The Cauvery delta region around Thanjavur, Kumbakonam, and Mannargudi has been revered for millennia as the rice bowl of Tamil Nadu, blessed with fertile alluvial soil and perennial river irrigation networks.</p>
<h2>1. Perennial Water Security & Soil Fertility</h2>
<p>Unlike seasonal rain-fed farm tracts, Cauvery delta agricultural parcels benefit from canal irrigation networks, ensuring multi-crop cycles annually (Kuruvai, Thaladi, and Samba).</p>
<h2>2. Tax-Free Agricultural Income & Land Wealth</h2>
<p>Agricultural revenue in India remains exempt from income tax, making managed farm estates an attractive legal tax-efficient investment vehicle for doctors, business leaders, and NRI investors.</p>`},{id:`contemporary-villas-architecture`,slug:`contemporary-villas-architecture`,title:`Modern Villa Architecture: Blending Dravidian Courtyards with Contemporary Luxury`,category:`Architecture`,date:`15 Jul 2026`,author:`Aishwarya R.`,authorRole:`Senior Legal & Patta Verification Specialist`,authorBio:`Over 12 years of hands-on expertise in Tamil Nadu revenue administration, 30-year parent document tracing, and DTCP layout sanctions across Thanjavur & Trichy.`,authorSocial:`https://wa.me/919578311506`,authorAvatar:`https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80`,image:`https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80`,excerpt:`Exploring modern luxury villas in Chennai and Thanjavur featuring open-air courtyards, VRV climate control, double-height ceilings, and lush tropical courtyards.`,metaTitle:`Modern Villa Architecture & Dravidian Courtyards | Thanjai Property`,metaDescription:`Exploring modern luxury villas in Chennai and Thanjavur featuring open-air courtyards, VRV climate control, and lush tropical courtyards.`,content:`<p class="blog-lead">Traditional South Indian courtyard architecture (Thinnai & Mutram) is experiencing a revival in high-end villa designs across Chennai, Trichy, and Thanjavur.</p>
<h2>1. Climate-Responsive Passive Cooling</h2>
<p>Central open sky courtyards pull hot air upwards while allowing cool breezes to circulate through living quarters naturally, reducing air conditioning energy load by up to 30%.</p>
<h2>2. Floor-to-Ceiling Thermal Glass</h2>
<p>Pairing traditional timber columns with double-glazed low-E glass walls creates seamless indoor-outdoor living while maintaining indoor thermal comfort during peak summer months.</p>`},{id:`central-tn-commercial-hubs`,slug:`central-tn-commercial-hubs`,title:`Investing in Central Tamil Nadu: Trichy & Thanjavur Commercial Corridors`,category:`Market Guide`,date:`30 Jun 2026`,author:`Kavitha S.`,authorRole:`Senior Investment & Capital Growth Analyst`,authorBio:`Specialist in central Tamil Nadu high-growth corridors, highway commercial plots, and real estate portfolio asset allocation.`,authorSocial:`https://wa.me/919578311506`,authorAvatar:`https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=200&q=80`,image:`https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80`,excerpt:`Commercial real estate growth analysis along Thanjavur New Bus Stand, Medical College Road, and Trichy Thillai Nagar high streets.`,metaTitle:`Investing in Central Tamil Nadu Commercial Corridors | Thanjai Property`,metaDescription:`Commercial real estate growth analysis along Thanjavur New Bus Stand, Medical College Road, and Trichy Thillai Nagar high streets.`,content:`<p class="blog-lead">Central Tamil Nadu cities like Trichy and Thanjavur are benefiting from infrastructure expansions including airport upgrades and NH highway widening, fueling 12-15% annual commercial property appreciation.</p>
<h2>1. Retail Showrooms & High Street Demand</h2>
<p>Key arterial roads such as Medical College Road in Thanjavur and Cantonment in Trichy report near 100% occupancy for banking hubs, healthcare clinics, and retail brand outlets.</p>`},{id:`nri-property-buying-guide`,slug:`nri-property-buying-guide`,title:`NRI Real Estate Guide: Purchasing Property in Tamil Nadu Seamlessly`,category:`NRI Guide`,date:`12 Jun 2026`,author:`S. Vijayaraghavan`,authorRole:`Managing Director, Thanjai Property`,authorBio:`Leading strategic land acquisitions, premium gated communities, and NRI property concierge services across Tamil Nadu since 2009.`,authorSocial:`https://wa.me/919578311506`,authorAvatar:`https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=200&q=80`,image:`https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=1200&q=80`,excerpt:`Essential checklist for non-resident Indians acquiring luxury villas, farm plots, and commercial assets in Tamil Nadu with remote legal execution.`,metaTitle:`NRI Real Estate Guide in Tamil Nadu | Thanjai Property`,metaDescription:`Essential checklist for non-resident Indians acquiring luxury villas, farm plots, and commercial assets in Tamil Nadu with remote legal execution.`,content:`<p class="blog-lead">Non-Resident Indians (NRIs) can freely acquire residential and commercial properties in India under RBI FEMA guidelines without requiring prior RBI permission.</p>
<h2>1. Power of Attorney (POA) Execution</h2>
<p>NRIs residing in US, UK, UAE, or Singapore can register a Specific Power of Attorney (POA) attested by the Indian Consulate to allow trusted family members to handle registration on their behalf.</p>`}],p=null;async function m(){try{let t=await e(`/blog`);if(t&&Array.isArray(t)&&t.length>0)return p=t,_(p),window.dispatchEvent(new CustomEvent(`blogPostsUpdated`)),p;if(t&&Array.isArray(t)&&t.length===0){let t=g(),n=t&&t.length>0?t:f;p=n,_(n);for(let t of n)e(`/blog`,{method:`POST`,body:JSON.stringify(t)}).catch(()=>{});return window.dispatchEvent(new CustomEvent(`blogPostsUpdated`)),p}}catch{}return p===null&&(p=g()),p}function h(){return p===null&&(p=g()),p||[]}function g(){try{let e=localStorage.getItem(d);if(e!==null){let t=JSON.parse(e);if(Array.isArray(t)&&t.length>0)return t}}catch(e){console.error(`Error reading blog posts from localStorage`,e)}return _(f),f}function _(e){try{localStorage.setItem(d,JSON.stringify(e)),p=e}catch(e){console.error(`Error saving blog posts to localStorage`,e)}}function v(e){return h().find(t=>t.id===e||t.slug===e||String(t.id).toLowerCase()===String(e).toLowerCase())}async function y(t){let r=h(),i=(t.slug||t.title||`post-${Date.now()}`).toLowerCase().trim().replace(/[^a-z0-9]+/g,`-`).replace(/(^-|-$)+/g,``),a=new Date().toLocaleDateString(`en-IN`,{day:`2-digit`,month:`short`,year:`numeric`}),o={id:t.id||`blog-${i}-${Date.now().toString().slice(-4)}`,slug:i,title:t.title||`Untitled Article`,category:t.category||`Market Guide`,date:t.date||a,readTime:t.readTime||`5 min read`,author:t.author||`Thanjai Editorial Desk`,authorRole:t.authorRole||``,authorBio:t.authorBio||``,authorSocial:t.authorSocial||``,authorAvatar:t.authorAvatar||`https://ui-avatars.com/api/?name=${encodeURIComponent(t.author||`Thanjai Desk`)}&background=2A1808&color=F8F4EC`,image:t.image||`https://images.unsplash.com/photo-1524813686514-a57563d77965?auto=format&fit=crop&w=1200&q=80`,excerpt:t.excerpt||`Article published on Thanjai Property Journal.`,metaTitle:t.metaTitle||(t.title?`${t.title} | Thanjai Property`:`Thanjai Property Legal Journal`),metaDescription:t.metaDescription||t.excerpt||`Expert real estate guides and market insights from Thanjai Property.`,content:t.content||`<p class="blog-lead">${t.excerpt||`Welcome to this article.`}</p>`};r.unshift(o),_(r),n({timestamp:new Date().toLocaleString(`en-IN`,{dateStyle:`medium`,timeStyle:`short`}),action:`Published Blog Article (${o.id})`,module:`Blog CMS`,details:`Published article "${o.title}" under ${o.category}.`}),window.dispatchEvent(new CustomEvent(`blogPostsUpdated`,{detail:{action:`add`,post:o}}));try{await e(`/blog`,{method:`POST`,body:JSON.stringify(o)})}catch(e){console.warn(`API sync for new blog post failed:`,e.message)}return o}async function b(t,r){let i=h(),a=i.findIndex(e=>e.id===t||e.slug===t);if(a===-1)return!1;let o=i[a],s={...o,...r,id:o.id,slug:r.slug||o.slug||o.id};i[a]=s,_(i),n({timestamp:new Date().toLocaleString(`en-IN`,{dateStyle:`medium`,timeStyle:`short`}),action:`Updated Blog Article (${o.id})`,module:`Blog CMS`,details:`Updated details for article "${s.title}".`}),window.dispatchEvent(new CustomEvent(`blogPostsUpdated`,{detail:{action:`update`,post:s}}));try{await e(`/blog/${o.id}`,{method:`PUT`,body:JSON.stringify(s)})}catch(e){console.error(`Failed to sync updated blog post to API`,e)}return s}async function x(t){let r=h(),i=r.find(e=>String(e.id)===String(t));if(!i)return!1;_(r.filter(e=>String(e.id)!==String(t))),n({timestamp:new Date().toLocaleString(`en-IN`,{dateStyle:`medium`,timeStyle:`short`}),action:`Deleted Blog Article (${t})`,module:`Blog CMS`,details:`Deleted article "${i.title}".`}),window.dispatchEvent(new CustomEvent(`blogPostsUpdated`,{detail:{action:`delete`,id:t}}));try{await e(`/blog/${t}`,{method:`DELETE`})}catch(e){console.error(`Failed to sync deleted blog post to API`,e)}return!0}function S(){_(f),e(`/blog/reset`,{method:`DELETE`}).catch(()=>{});for(let t of f)e(`/blog`,{method:`POST`,body:JSON.stringify(t)}).catch(()=>{});n({timestamp:new Date().toLocaleString(`en-IN`,{dateStyle:`medium`,timeStyle:`short`}),action:`Reset Blog CMS Catalog`,module:`Blog CMS`,details:`Restored factory seed blog articles in database and dashboard.`}),window.dispatchEvent(new CustomEvent(`blogPostsUpdated`,{detail:{action:`reset`}}))}var C=`eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY5NjYxNjVmODFhMDg2MTIzZWY5MWQ5MCIsIm5hbWUiOiJUaGFuamFpIFByb3BlcnR5IiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY5NjYxNjVmODFhMDg2MTIzZWY5MWQ4OSIsImFjdGl2ZVBsYW4iOiJQUk9fTU9OVEhMWSIsImlhdCI6MTc4NzcyNDczOX0.8SQSQDJdxrAivj8FAkWvjSk_qx4yE0dENDh70US75G0`;function w(){let e=typeof localStorage<`u`?localStorage.getItem(`thanjai_whatsapp_api_key`):``;return e&&e.trim().length>10?e.trim():C}async function T({campaignName:t,destination:n,userName:r,templateParams:i,media:a,messageText:o,leadId:s}){let c=`+91`+String(n||``).replace(/\D/g,``).slice(-10),l=w(),u=a||{url:`https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80`,filename:`thanjai-property.jpg`},d=(i||[]).map(e=>String(e)),f=!1;try{let n=await e(`/send_whatsapp`,{method:`POST`,body:JSON.stringify({campaignName:t,destination:c,userName:r||`Customer`,leadId:s,messageText:o,templateParams:d,media:u,apiKey:l})});n&&(n.success===!0||n.success===`true`)&&(f=!0)}catch(e){console.warn(`Backend relay notice:`,e)}if(!f)try{let e=await(await fetch(`https://backend.api-wa.co/campaign/smartping/api/v2`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({apiKey:l,campaignName:t,destination:c,userName:r||`Customer`,templateParams:d,media:u})})).json();(e.status===`success`||e.success===`true`||e.submitted_message_id)&&(f=!0)}catch{}return f}function E(e){if(!e)return``;let t=l(e.id),n=r(e.size),a=Array.isArray(e.specs)&&e.specs.length>0?[...e.specs]:[];!a.some(e=>e.label.toLowerCase()===`area`)&&n&&a.unshift({label:`Area`,value:n}),!a.some(e=>e.label.toLowerCase()===`facing`)&&(e.facing||e.address)&&a.push({label:`Facing`,value:e.facing||e.address}),e.approval&&a.push({label:`Approval Status`,value:e.approval}),e.road&&e.road!==`Other / Outside Road`&&a.push({label:`Road Corridor`,value:e.road}),e.taluk&&a.push({label:`Taluk`,value:e.taluk}),e.furnishing&&e.furnishing!==`Not specified`&&a.push({label:`Furnishing`,value:e.furnishing}),e.floor&&a.push({label:`Floor`,value:e.floor}),e.district&&a.push({label:`District`,value:e.district});let o=Array.isArray(e.images)?e.images.filter(Boolean):[],s=[...new Set(o)],c=s.length>0?s:[`/default-property.jpg`],u=[],d=e.videoUrl||e.videos;if(Array.isArray(d))u=d.filter(Boolean);else if(typeof d==`string`&&d.trim()){if(d.trim().startsWith(`[`)&&d.trim().endsWith(`]`))try{let e=JSON.parse(d);Array.isArray(e)&&(u=e)}catch{u=d.split(/[\n,]+/)}else u=d.split(/[\n,]+/)}return u=u.map(e=>typeof e==`string`?e.trim():``).filter(Boolean),`
    <div class="modal-overlay active" id="property-details-modal-overlay">
      <div class="property-modal-card">
        <!-- Close Button -->
        <button class="modal-close-btn" id="close-prop-modal-btn" title="Close Modal">
          <i class="ri-close-line"></i>
        </button>

        <!-- Cinematic Gallery -->
        <div class="modal-gallery-container">
          <div class="gallery-main-img-wrap" id="modal-gallery-media-viewport" style="position: relative;">
            <img src="${c[0]}" alt="${e.title}" class="gallery-main-img" id="modal-main-gallery-img" />
            <div style="position: absolute; bottom: 16px; left: 16px; display: flex; gap: 8px;">
              <span class="badge badge-dark">
                <i class="ri-image-line"></i> ${c.length} High-Res Photos
              </span>
              <span class="badge badge-orange">${e.tag||e.categoryLabel}</span>
            </div>

            <div style="position: absolute; top: 16px; right: 16px; display: flex; gap: 8px;">
              <button class="card-favorite-btn ${t?`saved`:``}" id="modal-save-fav-btn" title="Bookmark Property">
                <i class="${t?`ri-heart-fill`:`ri-heart-line`}"></i>
              </button>
              <button class="card-favorite-btn" id="modal-share-btn" title="Share Property">
                <i class="ri-share-line"></i>
              </button>
            </div>
          </div>

          <div class="gallery-thumbs-col">
            ${c.slice(0,4).map((e,t)=>`
              <img src="${e}" alt="Thumbnail ${t+1}" class="gallery-thumb-img modal-thumb" data-type="image" data-src="${e}" />
            `).join(``)}
            ${u.map((e,t)=>`
              <div class="gallery-thumb-img modal-thumb" data-type="video" data-src="${e}" style="display: flex; flex-direction: column; align-items: center; justify-content: center; background: #1a202c; color: #fff; cursor: pointer; border-radius: 8px;">
                <i class="ri-play-circle-fill" style="color: #eb5e28; font-size: 1.4rem;"></i>
                <span style="font-size: 0.6rem; font-weight: 800;">VIDEO ${u.length>1?t+1:``}</span>
              </div>
            `).join(``)}
          </div>
        </div>

        <!-- Modal Content Layout -->
        <div class="modal-body-layout">
          <!-- Main Left Details -->
          <div>
            <!-- Title & Price Header -->
            <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 20px; flex-wrap: wrap;">
              <div>
                <div style="font-size: 0.8125rem; font-weight: 800; letter-spacing: 0.1em; text-transform: uppercase; color: var(--color-orange); margin-bottom: 4px;">
                  PROPERTY ID: ${e.id} • ${e.categoryLabel}
                </div>
                <h2 class="font-serif" style="font-size: 2.25rem; color: var(--color-brown); line-height: 1.2;">
                  ${e.title}
                </h2>
                <div style="display: flex; align-items: center; gap: 8px; font-size: 0.9375rem; color: var(--color-text-muted); margin-top: 8px;">
                  <a href="${e.latitude&&e.longitude?`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(e.latitude)},${encodeURIComponent(e.longitude)}`:`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent([e.location,e.district,`Tamil Nadu`].filter(Boolean).join(`, `))}`}" target="_blank" rel="noopener noreferrer" style="color: var(--color-text-muted); text-decoration: none; display: inline-flex; align-items: center; gap: 6px; transition: color 0.2s ease;" onmouseover="this.style.color='var(--color-orange)'" onmouseout="this.style.color='var(--color-text-muted)'" title="Open Location on Google Maps">
                    <i class="ri-map-pin-2-line" style="color: var(--color-orange);"></i>
                    <span>${i(e.location,e.district)}</span>
                    <i class="ri-external-link-line" style="font-size: 0.85rem; color: #a0aec0;"></i>
                  </a>
                </div>
              </div>

              <div style="text-align: right;">
                <div class="font-serif" style="font-size: 2.5rem; color: var(--color-brown); font-weight: 700;">
                  ${e.priceFormatted}
                </div>
                ${e.priceSqft?`<div style="font-size: 0.8125rem; color: var(--color-text-muted);">${e.priceSqft}</div>`:``}
              </div>
            </div>

            <!-- Section 14: Editorial Property Facts -->
            <div class="facts-editorial-grid">
              ${n?`
                <div class="fact-block">
                  <div class="fact-value">${n}</div>
                  <div class="fact-label">TOTAL AREA</div>
                </div>
              `:``}
              ${e.facing||e.address?`
                <div class="fact-block">
                  <div class="fact-value">${e.facing||e.address}</div>
                  <div class="fact-label">FACING</div>
                </div>
              `:``}
              ${e.approval?`
                <div class="fact-block">
                  <div class="fact-value">${e.approval}</div>
                  <div class="fact-label">APPROVAL</div>
                </div>
              `:``}
              ${e.bedrooms?`
                <div class="fact-block">
                  <div class="fact-value">${e.bedrooms} BHK</div>
                  <div class="fact-label">BEDROOMS</div>
                </div>
              `:``}
              ${e.bathrooms?`
                <div class="fact-block">
                  <div class="fact-value">${e.bathrooms}</div>
                  <div class="fact-label">BATHROOMS</div>
                </div>
              `:``}
            </div>

            <!-- Description -->
            ${e.description?`
              <div style="margin-bottom: 40px;">
                <h3 class="font-serif" style="font-size: 1.5rem; color: var(--color-brown); margin-bottom: 12px;">Property Overview</h3>
                <p style="color: var(--color-text-main); font-size: 1rem; line-height: 1.7; white-space: pre-line;">
                  ${e.description}
                </p>
              </div>
            `:``}

            <!-- Key Specifications Table -->
            ${a.length>0?`
              <div style="margin-bottom: 40px;">
                <h3 class="font-serif" style="font-size: 1.5rem; color: var(--color-brown); margin-bottom: 16px;">Key Technical Specifications</h3>
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; background: var(--color-cream-light); padding: 24px; border-radius: var(--radius-md); border: 1px solid var(--color-border);">
                  ${a.map(e=>`
                    <div style="display: flex; flex-direction: column;">
                      <span style="font-size: 0.75rem; font-weight: 700; color: var(--color-text-muted); text-transform: uppercase;">${e.label}</span>
                      <span style="font-size: 0.9375rem; font-weight: 700; color: var(--color-brown);">${e.value}</span>
                    </div>
                  `).join(``)}
                </div>
              </div>
            `:``}

            <!-- Floor Plan Section -->
            <div style="margin-bottom: 32px;">
              <h3 class="font-serif" style="font-size: 1.5rem; color: var(--color-brown); margin-bottom: 16px;">Architectural Layout</h3>
              <div style="border-radius: var(--radius-md); overflow: hidden; border: 1px solid var(--color-border);">
                <img src="${e.floorPlan}" alt="Floor Plan" style="width: 100%; height: 260px; object-fit: cover;" />
              </div>
            </div>
          </div>

          <!-- Right Sticky Enquiry Panel (Section 15) -->
          <div>
            <div class="sticky-enquiry-card">
              ${(()=>{let t=String(e.adType||e.ad_type||e.adTier||e.listingPlan||``).toLowerCase().trim()===`paid`,n=t?e.ownerName||`Verified Owner`:`Thanjai Property`,r=t?e.ownerPhone||e.inquiryPhone||`8489996852`:e.inquiryPhone||`8489996852`,i=String(r).replace(/[^0-9]/g,``),a=i.length===10?`+91 ${i}`:i.startsWith(`91`)&&i.length===12?`+${i}`:`+91 ${r}`,o=i.startsWith(`91`)&&i.length===12?i:i.length===10?`91${i}`:`918489996852`;return`
                  <div style="display: flex; align-items: center; gap: 14px; margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid var(--color-border);">
                    <div style="width: 54px; height: 54px; border-radius: 50%; background: ${t?`#EBF8FF`:`#2A1808`}; color: ${t?`#3182CE`:`#eb5e28`}; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; font-weight: 800; border: 2px solid ${t?`#3182CE`:`#eb5e28`}; flex-shrink: 0;">
                      ${t?`<i class="ri-user-star-fill"></i>`:`TP`}
                    </div>
                    <div>
                      <h4 style="font-size: 1rem; font-weight: 800; color: var(--color-brown);">${n}</h4>
                      <div style="font-size: 0.75rem; color: ${t?`#38A169`:`var(--color-orange)`}; font-weight: 700;">
                        ${t?`👑 Direct Owner Listing • 0% Brokerage`:`🛡️ Executive Real Estate Advisory Desk`}
                      </div>
                    </div>
                  </div>

                  <h4 style="font-size: 1.125rem; font-weight: 800; color: var(--color-brown); margin-bottom: 16px;">Interested in this Property?</h4>

                  <div style="display: flex; flex-direction: column; gap: 10px; margin-bottom: 24px;">
                    <a href="tel:${a.replace(/\s+/g,``)}" class="btn btn-brown" style="width: 100%; display: inline-flex; align-items: center; justify-content: center; gap: 8px;">
                      <i class="ri-phone-fill"></i> ${t?`CALL OWNER (${a})`:`CALL SELLER (${a})`}
                    </a>
                    <a href="${t?`https://wa.me/${o}?text=Hi%20${encodeURIComponent(n)},%20I%20am%20interested%20in%20your%20property%20${encodeURIComponent(e.title)}%20(ID:%20${e.id})`:`https://wa.me/${o}?text=Hi%20Thanjai%20Property,%20I%20am%20interested%20in%20${encodeURIComponent(e.title)}%20(ID:%20${e.id})`}" target="_blank" class="btn btn-primary" style="width: 100%; display: inline-flex; align-items: center; justify-content: center; gap: 8px; background: #25D366; border-color: #25D366;">
                      <i class="ri-whatsapp-line" style="font-size: 1.2rem;"></i> ${t?`WHATSAPP OWNER`:`WHATSAPP CHAT`}
                    </a>
                    <a href="mailto:vijayaraghavan@thanjaiproperty.com?subject=Inquiry%20for%20${encodeURIComponent(e.title)}" class="btn btn-outline-dark" style="width: 100%; display: inline-flex; align-items: center; justify-content: center; gap: 8px;">
                      <i class="ri-mail-line" style="color: #eb5e28;"></i> EMAIL ADVISORY DESK
                    </a>
                    <button class="btn btn-outline-dark" id="modal-schedule-btn" style="width: 100%;">
                      <i class="ri-calendar-line"></i> SCHEDULE SITE VISIT
                    </button>
                  </div>
                `})()}

              <!-- Instant Direct Enquiry Form -->
              <form id="modal-enquiry-form" style="display: flex; flex-direction: column; gap: 12px; padding-top: 20px; border-top: 1px dashed var(--color-border);">
                <span style="font-size: 0.8125rem; font-weight: 800; color: var(--color-brown);">SEND QUICK INQUIRY</span>
                <input type="text" id="modal-enquiry-name" placeholder="Your Full Name" required class="search-input" style="background: var(--color-white); padding: 10px 14px; border: 1px solid var(--color-border); border-radius: var(--radius-sm);" />
                <input type="tel" id="modal-enquiry-phone" placeholder="Phone Number (+91)" required maxlength="15" class="search-input" style="background: var(--color-white); padding: 10px 14px; border: 1px solid var(--color-border); border-radius: var(--radius-sm);" />
                <button type="submit" id="modal-enquiry-submit-btn" class="btn btn-brown" style="padding: 10px; font-size: 0.875rem;">Submit Enquiry</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  `}function D(n,r){let i=document.getElementById(`property-details-modal-overlay`);document.getElementById(`close-prop-modal-btn`)?.addEventListener(`click`,()=>{i?.classList.remove(`active`),setTimeout(r,300)}),i?.addEventListener(`click`,e=>{e.target===i&&(i.classList.remove(`active`),setTimeout(r,300))});function o(e){if(!e)return``;let t=e.trim(),n=t.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/|youtube\.com\/shorts\/)([^"&?\/\s]{11})/i);return n&&n[1]?{type:`iframe`,url:`https://www.youtube.com/embed/${n[1]}?autoplay=1&rel=0`}:/facebook\.com|fb\.watch|fb\.com/i.test(t)?{type:`iframe`,url:`https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(t)}&show_text=0&width=560&autoplay=1`}:/\.(mp4|webm|ogg|mov)(\?.*)?$/i.test(t)||t.startsWith(`data:video/`)?{type:`video`,url:t}:{type:`iframe`,url:t}}document.querySelectorAll(`.modal-thumb`).forEach(e=>{e.addEventListener(`click`,()=>{let t=document.getElementById(`modal-gallery-media-viewport`);if(!t)return;let r=e.dataset.type||`image`,i=e.dataset.src;if(r===`image`)t.innerHTML=`
          <img src="${i}" alt="${n.title}" class="gallery-main-img" id="modal-main-gallery-img" style="width:100%; height:100%; object-fit:cover;" />
          <div style="position: absolute; bottom: 16px; left: 16px; display: flex; gap: 8px;">
            <span class="badge badge-dark">
              <i class="ri-image-line"></i> ${images.length} High-Res Photos
            </span>
            <span class="badge badge-orange">${n.tag||n.categoryLabel}</span>
          </div>
          <div style="position: absolute; top: 16px; right: 16px; display: flex; gap: 8px;">
            <button class="card-favorite-btn ${saved?`saved`:``}" id="modal-save-fav-btn" title="Bookmark Property">
              <i class="${saved?`ri-heart-fill`:`ri-heart-line`}"></i>
            </button>
            <button class="card-favorite-btn" id="modal-share-btn" title="Share Property">
              <i class="ri-share-line"></i>
            </button>
          </div>
        `;else{let e=o(i);t.innerHTML=`
          <div style="width:100%; height:100%; background:#000; display:flex; align-items:center; justify-content:center;">
            ${e.type===`video`?`
              <video src="${e.url}" controls autoplay style="width:100%; height:100%; object-fit:contain;"></video>
            `:`
              <iframe src="${e.url}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen style="width:100%; height:100%; border:0;"></iframe>
            `}
          </div>
          <div style="position: absolute; top: 16px; left: 16px;">
            <span class="badge badge-orange"><i class="ri-play-circle-fill"></i> Property Video Tour</span>
          </div>
        `}})}),document.getElementById(`modal-save-fav-btn`)?.addEventListener(`click`,()=>{let e=u(n.id);t(e?`Property saved to collection!`:`Property removed from collection`,`ri-heart-fill`)}),document.getElementById(`modal-share-btn`)?.addEventListener(`click`,()=>{navigator.clipboard&&(navigator.clipboard.writeText(window.location.href),t(`Property link copied to clipboard!`,`ri-file-copy-line`))}),document.getElementById(`modal-schedule-btn`)?.addEventListener(`click`,()=>{window.dispatchEvent(new CustomEvent(`openScheduleModal`,{detail:{propertyId:n.id,propertyTitle:n.title}}))}),document.getElementById(`modal-enquiry-form`)?.addEventListener(`submit`,async o=>{o.preventDefault();let s=document.getElementById(`modal-enquiry-name`),c=document.getElementById(`modal-enquiry-phone`),l=document.getElementById(`modal-enquiry-submit-btn`),u=s?.value.trim(),d=c?.value.trim();if(!u||!d)return;l&&(l.disabled=!0,l.innerHTML=`<i class="ri-loader-4-line ri-spin"></i> Submitting...`);let f=d.replace(/\D/g,``),p=f.length===10?`+91${f}`:d.startsWith(`+`)?d:`+${f}`,m=`L-${Date.now()}`,h=`Customer inquiry for property "${n.title}" (ID: ${n.id}) - Price: ${n.priceFormatted||`₹`+n.price}, Location: ${n.location||`Thanjavur`}`,g={id:m,name:u,phone:p,mobile:p,email:``,type:n.categoryLabel||n.type||`Residential`,location:n.location||n.district||`Thanjavur`,budget:n.priceFormatted||String(n.price),stage:`New Lead`,source:`Property Inquiry`,date:new Date().toISOString().split(`T`)[0],assignedTo:`Unassigned`,priority:`High`,propertyId:n.id,timeline:[{type:`whatsapp_incoming`,date:new Date().toISOString(),message:`📩 ${h}`,note:h},{type:`whatsapp`,date:new Date().toISOString(),message:`🤖 Auto-sent WhatsApp Welcome Intro to ${u} (${p})`,note:`Campaign: initial_contact_intro`}]};try{a(n.id)}catch{}try{let e=JSON.parse(localStorage.getItem(`thanjai_leads`))||[];e.unshift(g),localStorage.setItem(`thanjai_leads`,JSON.stringify(e)),window.dispatchEvent(new Event(`storage`))}catch{}try{await e(`/leads`,{method:`POST`,body:JSON.stringify(g)})}catch{}try{await e(`/whatsapp_incoming`,{method:`POST`,body:JSON.stringify({from_phone:p,from_name:u,message:`[Property Inquiry] ${n.title} (ID: ${n.id}) | Location: ${n.location||n.district||`Thanjavur`} | Price: ${n.priceFormatted||`₹`+n.price}`,message_type:`text`})}),await e(`/whatsapp_logs`,{method:`POST`,body:JSON.stringify({id:`WA-${Date.now()}`,leadId:m,phone:p,sender:`Super Admin`,recipientName:u,message:`Hello ${u}, Thank you for your interest in Thanjai Property! We have received your inquiry for "${n.title}". Our property advisors will assist you shortly. Official Desk: +91 84899 96852.`,type:`outbound`})})}catch{}try{let e=n.images&&n.images.length>0&&n.images[0].startsWith(`http`)?n.images[0]:`https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80`;await T({campaignName:`initial_contact_intro`,destination:p,userName:u,leadId:m,templateParams:[u,n.location||n.district||`Thanjavur`,n.title,`+91 84899 96852`],media:{url:e,filename:`property.jpg`}})}catch{}t(`Enquiry received! We've sent a WhatsApp confirmation to ${p}.`,`ri-checkbox-circle-fill`),i?.classList.remove(`active`),setTimeout(r,300)})}function O(n){if(!n)return;let r=document.getElementById(`global-inquiry-form-modal-container`);r||(r=document.createElement(`div`),r.id=`global-inquiry-form-modal-container`,document.body.appendChild(r)),r.innerHTML=`
    <div class="modal-overlay active" id="direct-prop-inquiry-modal-overlay" style="position: fixed; inset: 0; background: rgba(0,0,0,0.65); backdrop-filter: blur(5px); display: flex; align-items: center; justify-content: center; z-index: 99999; padding: 20px;">
      <div style="width: 100%; max-width: 500px; padding: 36px; border-radius: 20px; background: #ffffff; box-shadow: 0 20px 40px rgba(0,0,0,0.25); position: relative; animation: pageFadeIn 0.3s ease;">
        <button id="close-direct-inquiry-modal-btn" style="position: absolute; top: 18px; right: 18px; background: #f1f5f9; border: none; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.3rem; color: #475569; cursor: pointer;">
          <i class="ri-close-line"></i>
        </button>

        <div style="margin-bottom: 20px;">
          <span style="font-size: 0.75rem; font-weight: 800; color: #ea580c; text-transform: uppercase; letter-spacing: 0.08em; background: #fff7ed; padding: 4px 10px; border-radius: 8px; border: 1px solid #ffedd5;">PROPERTY INQUIRY FORM</span>
          <h2 class="font-serif" style="font-size: 1.5rem; color: #1e293b; margin-top: 10px; margin-bottom: 4px;">
            Inquire About Property
          </h2>
          <p style="font-size: 0.9rem; color: #ea580c; font-weight: 700; margin: 0; display: flex; align-items: center; gap: 6px;">
            <i class="ri-building-line"></i> ${n.title} (ID: ${n.id})
          </p>
        </div>

        <form id="direct-property-inquiry-form">
          <div style="display: flex; flex-direction: column; gap: 14px;">
            <div>
              <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #334155; margin-bottom: 6px;"><i class="ri-user-line" style="color: #ea580c;"></i> Full Name *</label>
              <input type="text" id="dpi-name" required placeholder="Enter your name" style="width: 100%; padding: 12px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 0.95rem; outline: none;" />
            </div>

            <div>
              <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #334155; margin-bottom: 6px;"><i class="ri-phone-line" style="color: #ea580c;"></i> Mobile Number *</label>
              <input type="tel" id="dpi-phone" required placeholder="10-digit mobile number" maxlength="10" pattern="[0-9]{10}" oninput="this.value = this.value.replace(/[^0-9]/g, '')" style="width: 100%; padding: 12px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 0.95rem; outline: none;" />
            </div>

            <div>
              <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #334155; margin-bottom: 6px;"><i class="ri-mail-line" style="color: #ea580c;"></i> Email Address (Optional)</label>
              <input type="email" id="dpi-email" placeholder="name@example.com" style="width: 100%; padding: 12px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 0.95rem; outline: none;" />
            </div>

            <div>
              <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #334155; margin-bottom: 6px;"><i class="ri-chat-3-line" style="color: #ea580c;"></i> Requirement / Question (Optional)</label>
              <textarea id="dpi-message" rows="3" placeholder="Tell us your preferences..." style="width: 100%; padding: 12px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 0.95rem; outline: none; resize: vertical;"></textarea>
            </div>

            <button type="submit" id="dpi-submit-btn" style="padding: 14px; font-size: 1rem; font-weight: 800; width: 100%; margin-top: 6px; background: #ea580c; color: #ffffff; border: none; border-radius: 10px; cursor: pointer; box-shadow: 0 4px 12px rgba(234,88,12,0.3);">
              <i class="ri-send-plane-fill"></i> SUBMIT PROPERTY INQUIRY
            </button>
          </div>
        </form>
      </div>
    </div>
  `;let i=document.getElementById(`close-direct-inquiry-modal-btn`),o=document.getElementById(`direct-prop-inquiry-modal-overlay`),s=document.getElementById(`direct-property-inquiry-form`),c=()=>{r&&(r.innerHTML=``)};i?.addEventListener(`click`,c),o?.addEventListener(`click`,e=>{e.target===o&&c()}),s?.addEventListener(`submit`,async r=>{r.preventDefault();let i=document.getElementById(`dpi-name`)?.value.trim(),o=document.getElementById(`dpi-phone`)?.value.trim(),s=document.getElementById(`dpi-email`)?.value.trim()||``,l=document.getElementById(`dpi-message`)?.value.trim()||``,u=document.getElementById(`dpi-submit-btn`);if(!i||!o)return;u&&(u.disabled=!0,u.innerHTML=`<i class="ri-loader-4-line ri-spin"></i> Submitting...`);let d=o.replace(/\D/g,``),f=d.length===10?`+91${d}`:`+${d}`,p=`L-${Date.now()}`,m=`Property Inquiry for "${n.title}" (ID: ${n.id}) - Price: ${n.priceFormatted||`₹`+n.price}. Note: ${l||`No additional note`}`,h={id:p,name:i,phone:f,mobile:f,email:s,type:n.categoryLabel||n.type||`Residential`,location:n.location||n.district||`Thanjavur`,budget:n.priceFormatted||String(n.price),stage:`New Lead`,source:`Property Inquiry`,date:new Date().toISOString().split(`T`)[0],assignedTo:`Unassigned`,priority:`High`,propertyId:n.id,propertyMatch:n.id,timeline:[{type:`whatsapp_incoming`,date:new Date().toISOString(),message:`📩 ${m}`,note:m},{type:`whatsapp`,date:new Date().toISOString(),message:`🤖 Auto-sent WhatsApp Welcome Intro to ${i} (${f})`,note:`Campaign: initial_contact_intro`}]};try{a(n.id)}catch{}try{let e=JSON.parse(localStorage.getItem(`thanjai_leads`))||[];e.unshift(h),localStorage.setItem(`thanjai_leads`,JSON.stringify(e)),window.dispatchEvent(new Event(`storage`))}catch{}try{await e(`/leads`,{method:`POST`,body:JSON.stringify(h)})}catch{}try{let e=n.images&&n.images.length>0&&n.images[0].startsWith(`http`)?n.images[0]:`https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80`;await T({campaignName:`initial_contact_intro`,destination:f,userName:i,leadId:p,templateParams:[i,n.location||n.district||`Thanjavur`,n.title,`+91 84899 96852`],media:{url:e,filename:`property.jpg`}})}catch{}t(`Inquiry received for Property ${n.id}! WhatsApp confirmation sent.`,`ri-checkbox-circle-fill`),c()})}function k(e){if(!e)return;let n=o(e);if(!n){t(`Property ${e} not found in current portfolio.`,`ri-error-warning-line`);return}let r=document.getElementById(`global-property-modal-container`);r||(r=document.createElement(`div`),r.id=`global-property-modal-container`,document.body.appendChild(r)),r.innerHTML=E(n),D(n,()=>{r.innerHTML=``})}document.addEventListener(`click`,e=>{let t=e.target.closest(`.prop-id-badge`);if(t){e.stopPropagation(),e.preventDefault();let n=t.getAttribute(`data-propid`);n&&k(n)}});var A=`thanjai_popups_store`,j=null;async function M(){try{let t=await e(`/popups`);if(t&&Array.isArray(t))return j=t.map(e=>({...e,highlights:typeof e.highlights==`string`?JSON.parse(e.highlights||`[]`):e.highlights||[]})),localStorage.setItem(A,JSON.stringify(j)),window.dispatchEvent(new CustomEvent(`popupsUpdated`)),j}catch(e){console.warn(`API error fetching popups, fallback to local cache`,e)}let t=localStorage.getItem(A);if(t)try{return j=JSON.parse(t),j}catch{}return j=[],localStorage.setItem(A,JSON.stringify(j)),j}function N(){if(Array.isArray(j))return j;let e=localStorage.getItem(A);if(e)try{return j=JSON.parse(e),j}catch{}return j=[],j}async function P(t){let r=N(),i={id:`POP-`+Date.now(),title:t.title||`New Announcement`,subtitle:t.subtitle||``,type:t.type||`festival`,badge:t.badge||`PROMOTIONAL`,image:t.image||``,highlights:Array.isArray(t.highlights)?t.highlights:[],ctaText:t.ctaText||`Claim Offer on WhatsApp`,ctaType:t.ctaType||`whatsapp`,ctaValue:t.ctaValue||`+91 84899 96852`,startDate:t.startDate||``,endDate:t.endDate||``,delaySeconds:parseInt(t.delaySeconds)||3,frequency:t.frequency||`once_session`,status:t.status||`Active`,createdAt:new Date().toISOString()};r.unshift(i),j=r,localStorage.setItem(A,JSON.stringify(r));try{await e(`/popups`,{method:`POST`,body:JSON.stringify(i)})}catch(e){console.error(`Failed to sync new popup to API:`,e)}return n({action:`Created Promotion Popup (${i.title})`,module:`Marketing Popups`,details:`Created new ${i.type} banner popup titled "${i.title}".`}),window.dispatchEvent(new CustomEvent(`popupsUpdated`)),i}async function F(t,r){let i=N(),a=i.findIndex(e=>e.id===t);if(a===-1)return null;i[a]={...i[a],...r},j=i,localStorage.setItem(A,JSON.stringify(i));try{await e(`/popups`,{method:`POST`,body:JSON.stringify(i[a])})}catch(e){console.error(`Failed to update popup in API:`,e)}return n({action:`Updated Promotion Popup (${i[a].title})`,module:`Marketing Popups`,details:`Updated popup "${i[a].title}" (Status: ${i[a].status}).`}),window.dispatchEvent(new CustomEvent(`popupsUpdated`)),i[a]}async function I(t){let r=N(),i=r.find(e=>e.id===t);r=r.filter(e=>e.id!==t),j=r,localStorage.setItem(A,JSON.stringify(r));try{await e(`/popups/${t}`,{method:`DELETE`})}catch(e){console.error(`Failed to delete popup from API:`,e)}return i&&n({action:`Deleted Promotion Popup (${i.title})`,module:`Marketing Popups`,details:`Removed popup "${i.title}" (ID: ${t}).`}),window.dispatchEvent(new CustomEvent(`popupsUpdated`)),!0}function L(){let e=N(),t=new Date;return e.filter(e=>{if(e.status!==`Active`)return!1;if(e.startDate){let n=new Date(e.startDate);if(t<n)return!1}if(e.endDate){let n=new Date(e.endDate);if(n.setHours(23,59,59,999),t>n)return!1}return!0})}export{m as _,M as a,c as b,O as c,C as d,T as f,h as g,v as h,N as i,k as l,x as m,I as n,F as o,y as p,L as r,D as s,P as t,E as u,S as v,b as y};