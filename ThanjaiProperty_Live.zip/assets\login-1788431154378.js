import{_ as e,d as t,l as n,m as r,p as i,s as a,t as o,u as s}from"./toast-1788431154378.js";o();function c(e=`signin`){let t=a(),n=t?t.email:`you@example.com`;return`
    <div class="login-wrapper">
      <div class="login-split-card">
        
        <!-- LEFT DARK SLATE VISUAL PANEL -->
        <div class="login-left-panel">
          <div class="login-left-content">
            <div class="login-brand-area" style="display: flex; align-items: center; justify-content: center; width: 100%; text-align: center; margin-bottom: 24px;">
              <div style="background: #ffffff; padding: 12px 24px; border-radius: 16px; box-shadow: 0 8px 24px rgba(0,0,0,0.3); display: flex; align-items: center; justify-content: center;">
                <img src="/thanjai-official-new.png" alt="Thanjai Property Logo" style="height: 68px; max-width: 100%; object-fit: contain; display: block;" />
              </div>
            </div>

            <div class="login-left-tagline" id="left-tagline" style="text-align: center;">
              ${e===`otp`?`Enter the 6-digit OTP sent to ${n} to complete verification.`:e===`credentials`?`Your account has been created. Use your one-time password to sign in.`:e===`register`?`Find your perfect home in Thanjavur & surrounding areas. Trusted listings, verified owners.`:`Welcome back! Sign in to continue exploring properties in Thanjavur & surrounding areas.`}
            </div>
          </div>
        </div>

        <!-- RIGHT FORM PANEL -->
        <div class="login-right-panel">

          <!-- SIGN IN FORM MODE -->
          <div class="auth-mode-container ${e===`signin`?`active-mode`:``}" id="mode-signin">
            <a href="/" id="signin-back-to-home" style="display: inline-flex; align-items: center; gap: 6px; font-size: 0.85rem; font-weight: 700; color: #718096; text-decoration: none; margin-bottom: 24px; transition: color 0.2s;" onmouseover="this.style.color='#2d3748'" onmouseout="this.style.color='#718096'">
              <i class="ri-arrow-left-line"></i> Back to Home
            </a>
            <h1 class="auth-heading">Sign in to your account</h1>

            <form class="auth-form" id="signin-form" onsubmit="return false;" autocomplete="off">
              <!-- Dummy inputs to prevent aggressive browser autofill -->
              <input type="email" style="display:none" name="fake_email" />
              <input type="password" style="display:none" name="fake_password" />

              <div class="auth-field">
                <label class="auth-label" for="signin-email">EMAIL ADDRESS</label>
                <div class="input-icon-wrap">
                  <i class="ri-mail-line field-icon"></i>
                  <input type="email" id="signin-email" name="email" placeholder="you@example.com" required class="auth-input" autocomplete="off" />
                </div>
              </div>

              <div class="auth-field">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                  <label class="auth-label" for="signin-password">PASSWORD</label>
                  <a href="#" class="forgot-link" id="forgot-password-link">Forgot password?</a>
                </div>
                <div class="input-icon-wrap">
                  <i class="ri-lock-2-line field-icon"></i>
                  <input type="password" id="signin-password" name="password" placeholder="Enter your password" required class="auth-input" autocomplete="new-password" />
                  <i class="ri-eye-line toggle-pw-icon" id="toggle-signin-pw" title="Toggle password visibility"></i>
                </div>
              </div>

              <div class="auth-checkbox-row">
                <label class="checkbox-label">
                  <input type="checkbox" id="remember-me" checked />
                  <span>Remember me</span>
                </label>
              </div>

              <button type="submit" class="auth-submit-btn" id="signin-btn">
                Sign in
              </button>

              <div class="auth-toggle-footer">
                Don't have an account? <a href="#" id="go-to-register" class="auth-link">Sign up for free</a>
              </div>
            </form>
          </div>

          <!-- CREATE ACCOUNT FORM MODE -->
          <div class="auth-mode-container ${e===`register`?`active-mode`:``}" id="mode-register">
            <a href="#" id="reg-back-to-signin" style="display: inline-flex; align-items: center; gap: 6px; font-size: 0.85rem; font-weight: 700; color: #718096; text-decoration: none; margin-bottom: 24px; transition: color 0.2s;" onmouseover="this.style.color='#2d3748'" onmouseout="this.style.color='#718096'">
              <i class="ri-arrow-left-line"></i> Back to Sign In
            </a>
            <h1 class="auth-heading">Create your Account</h1>

            <form class="auth-form" id="register-form" onsubmit="return false;">
              <div class="auth-field">
                <label class="auth-label" for="reg-fullname">FULL NAME</label>
                <div class="input-icon-wrap">
                  <i class="ri-user-3-line field-icon"></i>
                  <input type="text" id="reg-fullname" name="fullname" placeholder="Enter your full name" required class="auth-input" />
                </div>
              </div>

              <div class="auth-field">
                <label class="auth-label" for="reg-email">EMAIL ADDRESS (USERNAME)</label>
                <div class="input-icon-wrap">
                  <i class="ri-mail-line field-icon"></i>
                  <input type="email" id="reg-email" name="email" placeholder="you@example.com" required class="auth-input" />
                </div>
              </div>

              <div class="auth-field">
                <label class="auth-label" for="reg-phone">MOBILE NUMBER</label>
                <div class="input-icon-wrap">
                  <i class="ri-phone-line field-icon"></i>
                  <input type="tel" id="reg-phone" name="phone" placeholder="10-digit mobile number" maxlength="10" pattern="[0-9]{10}" required class="auth-input" oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
                </div>
              </div>

              <div class="auth-field">
                <label class="auth-label" for="reg-role">SELECT YOUR ROLE</label>
                <div class="input-icon-wrap">
                  <i class="ri-user-shared-line field-icon"></i>
                  <select id="reg-role" name="role" required class="auth-select">
                    <option value="">-- Select your role --</option>
                    <option value="individualowner" data-label="Individual Owner">Individual Owner</option>
                    <option value="agentbroker" data-label="Agent / Broker">Agent / Broker</option>
                    <option value="builderdeveloper" data-label="Builder / Developer">Builder / Developer</option>
                  </select>
                </div>
              </div>

              <!-- INTERACTIVE RECAPTCHA WIDGET -->
              <div class="recaptcha-widget" id="recaptcha-widget">
                <div class="recaptcha-checkbox-area" id="recaptcha-trigger">
                  <div class="recaptcha-checkbox" id="recaptcha-checkbox">
                    <div class="recaptcha-spinner" id="recaptcha-spinner"></div>
                    <i class="ri-check-line recaptcha-checkmark" id="recaptcha-checkmark"></i>
                  </div>
                  <span class="recaptcha-text" id="recaptcha-text">I'm not a robot</span>
                </div>
                <div class="recaptcha-brand">
                  <i class="ri-shield-check-fill" style="color: #1a73e8; font-size: 1.35rem;"></i>
                  <div style="font-size: 0.65rem; color: #555; font-weight: 700; line-height: 1.1;">reCAPTCHA<br><span style="font-weight: 400; color: #888;">Privacy - Terms</span></div>
                </div>
              </div>
              <div id="recaptcha-error-msg" style="color: #D92332; font-size: 0.8rem; font-weight: 700; display: none;">
                Please verify that you are not a robot before proceeding.
              </div>

              <div class="auth-checkbox-row">
                <label class="checkbox-label">
                  <input type="checkbox" id="reg-terms" required />
                  <span>I agree to the <a href="/privacy-policy" target="_blank" class="auth-link">privacy policy</a> and <a href="/terms-of-use" target="_blank" class="auth-link">terms of service</a></span>
                </label>
              </div>

              <button type="submit" class="auth-submit-btn" id="register-btn">
                Sign up with email
              </button>

              <div class="auth-toggle-footer">
                Already have an account? <a href="#" id="go-to-signin" class="auth-link">Sign In</a>
              </div>
            </form>
          </div>

          <!-- 6-DIGIT EMAIL OTP VERIFICATION SCREEN -->
          <div class="auth-mode-container ${e===`otp`?`active-mode`:``}" id="mode-otp">
            <div style="text-align: center; margin-bottom: 20px;">
              <div class="otp-icon-circle">
                <i class="ri-mail-check-line"></i>
              </div>
              <h1 class="auth-heading" style="margin-bottom: 6px; font-size: 1.6rem;">Email OTP Verification</h1>
              <p style="font-size: 0.88rem; color: #718096; line-height: 1.5; max-width: 340px; margin: 0 auto;">
                We have sent a 6-digit verification code to <strong id="otp-email-display" style="color: #1A202C;">${n}</strong>.
              </p>

              <!-- Email Dispatch Notification Banner -->
              <div class="email-dispatch-banner" id="email-dispatch-banner" style="margin-top: 14px; background: #EBF8FF; border: 1.5px solid #BEE3F8; border-radius: 14px; padding: 14px 18px; text-align: left; display: flex; align-items: flex-start; gap: 12px;">
                <i class="ri-mail-send-line" style="color: #3182CE; font-size: 1.4rem; margin-top: 2px;"></i>
                <div style="flex: 1;">
                  <div style="font-size: 0.88rem; font-weight: 700; color: #2D3748;">
                    Verification Code Sent to <span id="toast-email-span">${n}</span>
                  </div>
                  <div style="font-size: 0.82rem; color: #4A5568; margin-top: 4px; line-height: 1.45;">
                    Please check your email inbox (and spam/junk folder) for your 6-digit OTP verification code and enter it below.
                  </div>
                </div>
              </div>
            </div>

            <form class="auth-form" id="otp-form" onsubmit="return false;">
              <div class="otp-inputs-row">
                <input type="text" maxlength="1" class="otp-box" id="otp-1" autofocus pattern="[0-9]" />
                <input type="text" maxlength="1" class="otp-box" id="otp-2" pattern="[0-9]" />
                <input type="text" maxlength="1" class="otp-box" id="otp-3" pattern="[0-9]" />
                <input type="text" maxlength="1" class="otp-box" id="otp-4" pattern="[0-9]" />
                <input type="text" maxlength="1" class="otp-box" id="otp-5" pattern="[0-9]" />
                <input type="text" maxlength="1" class="otp-box" id="otp-6" pattern="[0-9]" />
              </div>

              <div id="otp-error-msg" style="color: #D92332; font-size: 0.82rem; font-weight: 700; text-align: center; display: none;"></div>

              <button type="submit" class="auth-submit-btn" id="verify-otp-btn" style="margin-top: 14px;">
                Verify OTP & Continue
              </button>

              <div class="auth-toggle-footer" style="margin-top: 14px;">
                Didn't receive code? <button type="button" id="resend-otp-btn" class="auth-link" style="background: none; border: none; cursor: pointer; padding: 0; font-size: 0.88rem;">Resend OTP (<span id="resend-countdown">45</span>s)</button> &nbsp;•&nbsp; <a href="#" id="otp-back-signin" class="auth-link">Back to Sign In</a>
              </div>
            </form>
          </div>

          <!-- ACCOUNT CREATED & CREDENTIALS SENT TO EMAIL SCREEN -->
          <div class="auth-mode-container ${e===`credentials`?`active-mode`:``}" id="mode-credentials">
            <div style="text-align: center; margin-bottom: 20px;">
              <div style="width: 68px; height: 68px; border-radius: 50%; background: #DEF7EC; color: #0E9F6E; display: flex; align-items: center; justify-content: center; font-size: 2.2rem; margin: 0 auto 16px;">
                <i class="ri-mail-check-line"></i>
              </div>
              <h1 class="auth-heading" style="margin-bottom: 8px; font-size: 1.65rem; color: #1A202C;">Account Created Successfully!</h1>
              <p style="font-size: 0.92rem; color: #718096; line-height: 1.5; max-width: 360px; margin: 0 auto;">
                Your account is verified. Your login credentials have been sent directly to your registered email address.
              </p>
            </div>

            <!-- Email Dispatched Notification Card -->
            <div style="background: #F8FAFC; border: 1.5px solid #E2E8F0; border-radius: 16px; padding: 22px; margin-bottom: 20px; text-align: center;">
              <div style="font-size: 0.75rem; font-weight: 800; color: #718096; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 6px;">
                LOGIN CREDENTIALS SENT TO
              </div>
              <div style="font-size: 1.02rem; font-weight: 800; color: #2B6CB0; background: #EBF8FF; border: 1px solid #BEE3F8; padding: 8px 16px; border-radius: 10px; display: inline-block; word-break: break-all; margin-bottom: 12px;" id="cred-username-display">
                you@example.com
              </div>

              <p style="font-size: 0.85rem; color: #4A5568; line-height: 1.5; margin: 0;">
                Please open your email inbox to retrieve your <strong>Username</strong> and <strong>One-Time Password</strong> for sign in.
              </p>
            </div>

            <div style="background: #FFFBEB; border: 1px solid #FDE68A; border-radius: 10px; padding: 10px 14px; font-size: 0.82rem; color: #92400E; margin-bottom: 20px; line-height: 1.4; display: flex; gap: 8px; align-items: flex-start;">
              <i class="ri-information-fill" style="font-size: 1.1rem; color: #D97706; margin-top: 1px;"></i>
              <span>You can change the one-time password to your personal permanent password anytime under <strong>Profile & Password</strong> in your dashboard.</span>
            </div>

            <button type="button" class="auth-submit-btn" id="proceed-to-dashboard-btn">
              Proceed to Sign In <i class="ri-arrow-right-line" style="margin-left: 6px;"></i>
            </button>
          </div>

        </div>

      </div>
    </div>
  `}async function l(){let o=document.getElementById(`login-app`);if(!o)return;await n().catch(()=>{});let l=window.location.pathname.toLowerCase(),u=window.location.hash.slice(1).toLowerCase(),d=`signin`;d=l.includes(`user-register`)||u.includes(`register`)||u.includes(`signup`)?`register`:l.includes(`otp`)||u.includes(`otp`)?`otp`:`signin`,o.innerHTML=c(d);let f=document.getElementById(`mode-signin`),p=document.getElementById(`mode-register`),m=document.getElementById(`mode-otp`),h=document.getElementById(`mode-credentials`),g=document.getElementById(`left-tagline`),_=!1,v=null,y=45;function b(e){try{window.history.replaceState(null,``,`/`+e)}catch{window.location.hash=e}}function x(e){if([f,p,m,h].forEach(e=>e?.classList.remove(`active-mode`)),e===`signin`)b(`user-login`),f?.classList.add(`active-mode`),g&&(g.textContent=`Welcome back! Sign in to continue exploring properties in Thanjavur & surrounding areas.`);else if(e===`register`)b(`user-register`),p?.classList.add(`active-mode`),g&&(g.textContent=`Find your perfect home in Thanjavur & surrounding areas. Trusted listings, verified owners.`);else if(e===`otp`){b(`otp`),m?.classList.add(`active-mode`);let e=a(),t=e?e.email:``,n=e?e.otpCode:`123456`,r=document.getElementById(`otp-email-display`);r&&(r.textContent=t);let i=document.getElementById(`toast-email-span`);i&&(i.textContent=t);let o=document.getElementById(`dispatched-otp-code`);o&&(o.textContent=n),g&&(g.textContent=`Enter the 6-digit OTP sent to ${t} to complete verification.`),S(),setTimeout(()=>document.getElementById(`otp-1`)?.focus(),100)}else e===`credentials`&&(b(`account-activated`),h?.classList.add(`active-mode`),g&&(g.textContent=`Your account has been created. Use your one-time password to sign in.`))}function S(){clearInterval(v),y=45;let e=document.getElementById(`resend-countdown`),t=document.getElementById(`resend-otp-btn`);t&&(t.disabled=!0),v=setInterval(()=>{y--,e&&(e.textContent=y),y<=0&&(clearInterval(v),t&&(t.disabled=!1,t.innerHTML=`Resend OTP Now`))},1e3)}document.getElementById(`go-to-register`)?.addEventListener(`click`,e=>{e.preventDefault(),x(`register`)}),document.getElementById(`go-to-signin`)?.addEventListener(`click`,e=>{e.preventDefault(),x(`signin`)}),document.getElementById(`reg-back-to-signin`)?.addEventListener(`click`,e=>{e.preventDefault(),x(`signin`)}),document.getElementById(`otp-back-signin`)?.addEventListener(`click`,e=>{e.preventDefault(),x(`signin`)});let C=document.getElementById(`recaptcha-trigger`),w=document.getElementById(`recaptcha-widget`),T=document.getElementById(`recaptcha-spinner`),E=document.getElementById(`recaptcha-checkmark`),D=document.getElementById(`recaptcha-error-msg`),O=document.getElementById(`recaptcha-checkbox`);C?.addEventListener(`click`,()=>{_||(T&&(T.style.display=`block`),O&&(O.style.borderColor=`#1a73e8`),setTimeout(()=>{_=!0,T&&(T.style.display=`none`),E&&(E.style.display=`block`),O&&(O.style.backgroundColor=`#1a73e8`,O.style.borderColor=`#1a73e8`),w&&(w.style.borderColor=`#34D399`,w.style.backgroundColor=`#F0FDF4`),D&&(D.style.display=`none`)},600))});let k=document.getElementById(`toggle-signin-pw`),A=document.getElementById(`signin-password`);k?.addEventListener(`click`,()=>{if(A){let e=A.type===`password`;A.type=e?`text`:`password`,k.className=e?`ri-eye-off-line toggle-pw-icon`:`ri-eye-line toggle-pw-icon`}});let j=document.getElementById(`signin-email`),M=document.getElementById(`signin-password`);document.getElementById(`signin-form`)?.addEventListener(`submit`,e=>{e.preventDefault();let n=document.getElementById(`signin-btn`),r=n?n.textContent:`Sign in`;n&&(n.textContent=`Signing in...`);let i=j?.value||``,a=M?.value||``;setTimeout(()=>{let e=t(i,a);e?e.roleCode&&(e.roleCode.includes(`admin`)||e.roleCode.includes(`manager`)||e.roleCode.includes(`executive`)||e.roleCode.includes(`staff`))?window.location.href=`/dashboard.html`:window.location.href=`/user-dashboard`:(n&&(n.textContent=r),alert(`Invalid email or password. Please check your credentials and try again.`))},600)}),document.getElementById(`register-form`)?.addEventListener(`submit`,e=>{if(e.preventDefault(),!_){D&&(D.style.display=`block`),w&&(w.style.borderColor=`#E52E3D`,w.style.backgroundColor=`#FFF5F5`);return}let t=document.getElementById(`reg-fullname`)?.value.trim(),n=document.getElementById(`reg-email`)?.value.trim(),r=document.getElementById(`reg-phone`)?.value.trim(),i=document.getElementById(`reg-role`),a=i?.value,o=i?.options[i.selectedIndex]?.dataset?.label||`Individual Owner`;s({fullName:t,email:n,phone:r,role:a,roleLabel:o}),x(`otp`)});let N=[document.getElementById(`otp-1`),document.getElementById(`otp-2`),document.getElementById(`otp-3`),document.getElementById(`otp-4`),document.getElementById(`otp-5`),document.getElementById(`otp-6`)];N.forEach((e,t)=>{e&&(e.addEventListener(`input`,e=>{e.target.value&&t<N.length-1&&N[t+1].focus()}),e.addEventListener(`keydown`,n=>{n.key===`Backspace`&&!e.value&&t>0&&N[t-1].focus()}),e.addEventListener(`paste`,e=>{e.preventDefault();let t=(e.clipboardData||window.clipboardData).getData(`text`).trim().replace(/[^0-9]/g,``);if(t){for(let e=0;e<N.length;e++)t[e]&&(N[e].value=t[e]);N[Math.min(t.length,N.length-1)].focus()}}))});let P=null;document.getElementById(`otp-form`)?.addEventListener(`submit`,async t=>{t.preventDefault();let n=N.map(e=>e?.value||``).join(``),r=document.getElementById(`otp-error-msg`),a=document.getElementById(`verify-otp-btn`);if(n.length<6){r&&(r.textContent=`Please enter all 6 digits of the OTP code.`,r.style.display=`block`);return}a&&(a.textContent=`Verifying Code...`);let o=await e(n);if(o.success){r&&(r.style.display=`none`),a&&(a.textContent=`Verified!`),P=o,i(o.user.email,o.user.fullName,o.tempPassword);let e=document.getElementById(`cred-username-display`);e&&(e.textContent=o.username||o.user.email),setTimeout(()=>{x(`credentials`)},400)}else a&&(a.textContent=`Verify OTP & Continue`),r&&(r.textContent=o.message,r.style.display=`block`)}),document.getElementById(`proceed-to-dashboard-btn`)?.addEventListener(`click`,()=>{P&&P.user&&(j&&(j.value=P.user.email),M&&(M.value=``,setTimeout(()=>M.focus(),150))),x(`signin`)}),document.getElementById(`resend-otp-btn`)?.addEventListener(`click`,e=>{e.preventDefault();let t=a();if(!t)return;let n=Math.floor(1e5+Math.random()*9e5).toString();t.otpCode=n,localStorage.setItem(`thanjai_pending_otp_user`,JSON.stringify(t)),r(t.email,t.fullName,n),S(),N.forEach(e=>{e&&(e.value=``)}),N[0]?.focus()})}document.addEventListener(`DOMContentLoaded`,l);