import{A as e,C as t,D as n,E as r,M as i,O as a,P as o,S as s,T as c,a as l,b as u,c as d,i as f,j as p,k as m,l as h,n as g,o as _,r as v,t as y,v as b,w as x,x as S,y as C}from"./toast-CBEj-iOa.js";import{a as w,c as T,d as E,l as D,n as O,o as k,r as A,t as j,u as ee}from"./propertiesStore-CTW7P7ko.js";import{c as te,i as ne,l as re,n as M,o as ie,r as ae,s as oe,t as se}from"./whatsapp-CbaHFD0k.js";import{marked as ce}from"https://cdn.jsdelivr.net/npm/marked/lib/marked.esm.js";function le(){let e=k().length,t=d(),n=JSON.parse(localStorage.getItem(`thanjai_leads`))||[],r=n.length,i=new Date().toISOString().split(`T`)[0],a=n.filter(e=>e.date===i&&e.status===`new`).length,o=n.filter(e=>e.status?.toLowerCase()===`new`).length,s=n.filter(e=>[`contacted`,`property shared`,`follow up`].includes(e.status?.toLowerCase())).length,c=n.filter(e=>[`interested`].includes(e.status?.toLowerCase())).length,l=n.filter(e=>[`negotiation`,`converted`].includes(e.status?.toLowerCase())).length,u=o+s+c+l||1,f=Math.round(o/u*100),p=Math.round(s/u*100),m=Math.round(c/u*100),h=Math.round(l/u*100),g=Math.max(f,10),_=Math.max(p,10),v=Math.max(m,10),y=Math.max(h,10),b=JSON.parse(localStorage.getItem(`thanjai_active_user`))||{fullName:`Admin`};return`
    <div class="view-enter">
      <!-- Luxury Hero -->
      <div class="os-hero">
        <div class="hero-text">
          <h1>Good Morning,<br/>${(b.fullName||b.name||`Admin`).split(` `)[0]}</h1>
          <p>Here's what's happening across your business today.</p>
        </div>
        
        <div class="hero-ai-summary">
          <div class="ai-summary-title">
            <i class="ri-sparkling-line"></i> AI Morning Brief
          </div>
          <ul class="ai-summary-list">
            <li><i class="ri-fire-fill"></i> ${s} high-priority follow-ups due</li>
            <li><i class="ri-time-line"></i> ${l} registrations pending signatures</li>
            <li><i class="ri-vip-crown-line"></i> ${c} hot lead ready for site visit</li>
          </ul>
        </div>
      </div>

      <!-- 8 KPI Grid (2x4) Matching Reference Design -->
      <div class="kpi-grid">
        <!-- 1. TOTAL LEADS -->
        <div class="kpi-card clickable-kpi" data-route="#leads" title="Open CRM Pipeline">
          <div class="kpi-header">
            <span class="kpi-title">TOTAL LEADS</span>
            <div class="kpi-icon" style="background: #ebf8ff; color: #3182ce;"><i class="ri-user-line"></i></div>
          </div>
          <div class="kpi-value count-up">${r}</div>
          <div class="kpi-trend up"><i class="ri-arrow-up-line"></i> Live count</div>
        </div>

        <!-- 2. NEW TODAY -->
        <div class="kpi-card clickable-kpi" data-route="#leads" title="Open CRM Pipeline">
          <div class="kpi-header">
            <span class="kpi-title">NEW TODAY</span>
            <div class="kpi-icon" style="background: #e6fffa; color: #319795;"><i class="ri-sparkling-fill"></i></div>
          </div>
          <div class="kpi-value count-up">${a}</div>
          <div class="kpi-trend neutral"><i class="ri-subtract-line"></i> Just arrived</div>
        </div>

        <!-- 3. FOLLOW-UPS DUE -->
        <div class="kpi-card clickable-kpi" data-route="#visits" title="Open Site Visits & Appointments">
          <div class="kpi-header">
            <span class="kpi-title">FOLLOW-UPS DUE</span>
            <div class="kpi-icon" style="background: #feebc8; color: #dd6b20;"><i class="ri-calendar-event-line"></i></div>
          </div>
          <div class="kpi-value count-up">${s}</div>
          <div class="kpi-trend neutral"><i class="ri-time-line"></i> today</div>
        </div>

        <!-- 4. CONVERSION RATE -->
        <div class="kpi-card clickable-kpi" data-route="#reports" title="Open Reports & Analytics">
          <div class="kpi-header">
            <span class="kpi-title">CONVERSION RATE</span>
            <div class="kpi-icon" style="background: #faf5ff; color: #805ad5;"><i class="ri-pie-chart-line"></i></div>
          </div>
          <div class="kpi-value">${r>0?Math.round(l/r*100):0}%</div>
          <div class="kpi-trend up"><i class="ri-arrow-up-line"></i> based on data</div>
        </div>

        <!-- 5. PROPERTIES AVAILABLE -->
        <div class="kpi-card clickable-kpi" data-route="#properties" title="Open Properties Inventory">
          <div class="kpi-header">
            <span class="kpi-title">PROPERTIES AVAILABLE</span>
            <div class="kpi-icon" style="background: #e6fffa; color: #00a3c4;"><i class="ri-building-line"></i></div>
          </div>
          <div class="kpi-value count-up">${e}</div>
          <div class="kpi-trend up"><i class="ri-checkbox-circle-line"></i> Active inventory</div>
        </div>

        <!-- 6. SHARED TODAY -->
        <div class="kpi-card clickable-kpi" data-route="#whatsapp" title="Open WhatsApp Log">
          <div class="kpi-header">
            <span class="kpi-title">SHARED TODAY</span>
            <div class="kpi-icon" style="background: #ebf8ff; color: #4299e1;"><i class="ri-send-plane-line"></i></div>
          </div>
          <div class="kpi-value count-up">0</div>
          <div class="kpi-trend neutral"><i class="ri-whatsapp-line"></i> via WhatsApp</div>
        </div>

        <!-- 7. WHATSAPP SENT TODAY -->
        <div class="kpi-card clickable-kpi" data-route="#whatsapp" title="Open WhatsApp Log">
          <div class="kpi-header">
            <span class="kpi-title">WHATSAPP SENT TODAY</span>
            <div class="kpi-icon" style="background: #f0fff4; color: #38a169;"><i class="ri-whatsapp-line"></i></div>
          </div>
          <div class="kpi-value count-up">0</div>
          <div class="kpi-trend neutral"><i class="ri-chat-3-line"></i> Client logs</div>
        </div>

        <!-- 8. PARTNER-SHARED LEADS -->
        <div class="kpi-card clickable-kpi" data-route="#partners" title="Open Partner Network">
          <div class="kpi-header">
            <span class="kpi-title">PARTNER-SHARED LEADS</span>
            <div class="kpi-icon" style="background: #fff5f5; color: #d53f8c;"><i class="ri-briefcase-4-line"></i></div>
          </div>
          <div class="kpi-value count-up">0</div>
          <div class="kpi-trend neutral"><i class="ri-user-shared-line"></i> Partner network</div>
        </div>
      </div>

      <!-- Mixed Layout: AI Insight + Charts -->
      <div class="dashboard-mixed-layout">
        
        <!-- Pipeline Graph Flow -->
        <div class="os-chart-card pipeline-card">
          <div class="os-chart-header">
            <i class="ri-node-tree"></i> Pipeline Distribution
          </div>
          <p class="chart-subtext">Total active leads across all stages.</p>
          
          <div class="pipeline-graph-wrapper">
            <div class="graph-grid"></div>
            
            <svg class="pipeline-connectors" preserveAspectRatio="none">
              <line x1="0" y1="50%" x2="100%" y2="50%" class="connector-base" />
              <line x1="0" y1="50%" x2="100%" y2="50%" class="connector-glow" />
            </svg>

            <div class="pipeline-stages">
              <div class="pg-stage" style="flex: ${g};" data-tooltip="New Leads • ${f}%">
                <div class="pg-val count-up">${o}</div>
                <div class="pg-node" style="border-color: var(--os-charcoal);"><div class="pg-inner" style="background: var(--os-charcoal);"></div></div>
                <div class="pg-label">New</div>
              </div>

              <div class="pg-stage ${p>0?`pulse-highest`:``}" style="flex: ${_};" data-tooltip="Follow Up Pending • ${p}%">
                <div class="pg-val count-up">${s}</div>
                <div class="pg-node" style="border-color: var(--os-deep-brown);"><div class="pg-inner" style="background: var(--os-deep-brown);"></div></div>
                <div class="pg-label">Follow Up</div>
              </div>

              <div class="pg-stage" style="flex: ${v};" data-tooltip="Site Visit Scheduled • ${m}%">
                <div class="pg-val count-up">${c}</div>
                <div class="pg-node" style="border-color: var(--os-luxury-orange);"><div class="pg-inner" style="background: var(--os-luxury-orange);"></div></div>
                <div class="pg-label">Site Visit</div>
              </div>

              <div class="pg-stage" style="flex: ${y};" data-tooltip="Registration • ${h}%">
                <div class="pg-val count-up">${l}</div>
                <div class="pg-node" style="border-color: var(--os-rich-red);"><div class="pg-inner" style="background: var(--os-rich-red);"></div></div>
                <div class="pg-label">Register</div>
              </div>
            </div>
          </div>
        </div>

        <!-- AI Insight -->
        <div class="ai-insight-card magnetic-hover">
          <div class="ai-amber-glow"></div>
          <h3 class="floating-text"><i class="ri-brain-line"></i> AI Business Intelligence</h3>
          <p class="fade-quote">"3 leads are showing high buying signals and are likely to convert this week. Suggest scheduling site visits immediately."</p>
          <button class="magnetic-btn">Take Action</button>
        </div>
      </div>
      
      <!-- Bottom Section: Leads by Source Split Layout -->
      <div class="os-chart-card">
        <div class="os-chart-header">
          <i class="ri-pie-chart-2-fill"></i> Leads by Source (Acquisition)
        </div>
        
        <div class="source-split-layout">
          <!-- LEFT: 3D Donut Chart -->
          <div class="source-left">
            <div class="donut-svg-wrapper">
              <svg viewBox="0 0 100 100" class="premium-donut">
                <circle cx="50" cy="50" r="40" fill="none" stroke="rgba(0,0,0,0.03)" stroke-width="12"></circle>
                <circle class="donut-slice" cx="50" cy="50" r="40" fill="none" stroke="var(--os-deep-brown)" stroke-width="12" stroke-dasharray="153.2 251.2" stroke-dashoffset="0" data-tooltip="Manual: 11 (61%)" data-source="manual"></circle>
                <circle class="donut-slice" cx="50" cy="50" r="40" fill="none" stroke="var(--os-luxury-orange)" stroke-width="12" stroke-dasharray="42.7 251.2" stroke-dashoffset="-153.2" data-tooltip="WhatsApp: 3 (17%)" data-source="whatsapp"></circle>
                <circle class="donut-slice" cx="50" cy="50" r="40" fill="none" stroke="var(--os-gold)" stroke-width="12" stroke-dasharray="42.7 251.2" stroke-dashoffset="-195.9" data-tooltip="Website: 3 (17%)" data-source="website"></circle>
                <circle class="donut-slice" cx="50" cy="50" r="40" fill="none" stroke="var(--os-rich-red)" stroke-width="12" stroke-dasharray="12.6 251.2" stroke-dashoffset="-238.6" data-tooltip="Referral: 1 (5%)" data-source="referral"></circle>
              </svg>
              <div class="donut-center-info">
                <span class="dc-total count-up">18</span>
                <span class="dc-lbl">Total Leads</span>
              </div>
            </div>
          </div>

          <!-- RIGHT: Premium Glass Cards -->
          <div class="source-right">
            
            <div class="source-glass-card hover-lift" data-source="manual">
              <div class="sgc-header">
                <div class="sgc-title"><span class="sgc-dot" style="background: var(--os-deep-brown);"></span> Manual Entry</div>
                <div class="sgc-badge"><span class="count-up">11</span> Leads</div>
              </div>
              <div class="sgc-perc count-up">61%</div>
              <div class="sgc-track">
                <div class="sgc-fill" style="width: 61%; background: var(--os-deep-brown);"></div>
              </div>
            </div>

            <div class="source-glass-card hover-lift" data-source="whatsapp">
              <div class="sgc-header">
                <div class="sgc-title"><span class="sgc-dot" style="background: var(--os-luxury-orange);"></span> WhatsApp</div>
                <div class="sgc-badge"><span class="count-up">3</span> Leads</div>
              </div>
              <div class="sgc-perc count-up">17%</div>
              <div class="sgc-track">
                <div class="sgc-fill" style="width: 17%; background: var(--os-luxury-orange);"></div>
              </div>
            </div>

            <div class="source-glass-card hover-lift" data-source="website">
              <div class="sgc-header">
                <div class="sgc-title"><span class="sgc-dot" style="background: var(--os-gold);"></span> Website Form</div>
                <div class="sgc-badge"><span class="count-up">3</span> Leads</div>
              </div>
              <div class="sgc-perc count-up">17%</div>
              <div class="sgc-track">
                <div class="sgc-fill" style="width: 17%; background: var(--os-gold);"></div>
              </div>
            </div>

            <div class="source-glass-card hover-lift" data-source="referral">
              <div class="sgc-header">
                <div class="sgc-title"><span class="sgc-dot" style="background: var(--os-rich-red);"></span> Referral</div>
                <div class="sgc-badge"><span class="count-up">1</span> Leads</div>
              </div>
              <div class="sgc-perc count-up">5%</div>
              <div class="sgc-track">
                <div class="sgc-fill" style="width: 5%; background: var(--os-rich-red);"></div>
              </div>
            </div>

          </div>
        </div>
      </div>

      <!-- Registered Portal Users & Client Logins Table -->
      <div class="os-chart-card" style="margin-top: 32px;">
        <div class="os-chart-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span><i class="ri-user-shared-line"></i> Registered Portal Users & Active Logins (${t.length})</span>
          <span style="font-size: 0.78rem; background: rgba(235,94,40,0.15); color: #eb5e28; padding: 4px 12px; border-radius: 20px; font-weight: 800;">
            Client Portal Synchronized
          </span>
        </div>
        
        <div class="table-responsive" style="margin-top: 16px;">
          <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 0.88rem;">
            <thead>
              <tr style="border-bottom: 1px solid rgba(0,0,0,0.08); text-transform: uppercase; font-size: 0.75rem; color: var(--os-gray-400);">
                <th style="padding: 12px 16px;">User ID</th>
                <th style="padding: 12px 16px;">Full Name</th>
                <th style="padding: 12px 16px;">Email Address</th>
                <th style="padding: 12px 16px;">Mobile Phone</th>
                <th style="padding: 12px 16px;">Account Role</th>
                <th style="padding: 12px 16px;">Listed Props</th>
                <th style="padding: 12px 16px;">OTP Verification</th>
              </tr>
            </thead>
            <tbody>
              ${t.map(e=>`
                <tr style="border-bottom: 1px solid rgba(0,0,0,0.04);">
                  <td style="padding: 12px 16px; font-weight: 700; color: var(--os-luxury-orange);">${e.id}</td>
                  <td style="padding: 12px 16px; font-weight: 700;">${e.fullName}</td>
                  <td style="padding: 12px 16px;">${e.email}</td>
                  <td style="padding: 12px 16px;">${e.phone||`N/A`}</td>
                  <td style="padding: 12px 16px;"><span class="os-badge" style="background: rgba(49,130,206,0.12); color: #3182ce; font-weight: 700; padding: 2px 8px; border-radius: 6px;">${e.role}</span></td>
                  <td style="padding: 12px 16px; font-weight: 700;">${e.propertiesCount||0}</td>
                  <td style="padding: 12px 16px;"><span style="color: #38a169; font-weight: 800;"><i class="ri-checkbox-circle-fill"></i> ${e.status||`Active`}</span></td>
                </tr>
              `).join(``)}
            </tbody>
          </table>
        </div>
      </div>

      <script>
        setTimeout(() => {
          // Number Counter Animation
          document.querySelectorAll('.count-up').forEach(el => {
            const target = parseInt(el.innerText, 10);
            let count = 0;
            const speed = target / 30; // 30 frames
            const update = () => {
              count += speed;
              if(count < target) {
                el.innerText = Math.ceil(count);
                requestAnimationFrame(update);
              } else {
                el.innerText = target;
              }
            };
            update();
          });

          // SVG Donut Hover - Bring to Front & Link Cards
          const donutWrapper = document.querySelector('.premium-donut');
          const slices = document.querySelectorAll('.donut-slice');
          const cards = document.querySelectorAll('.source-glass-card');
          
          slices.forEach(slice => {
            slice.addEventListener('mouseenter', function() {
              this.parentNode.appendChild(this);
              donutWrapper.classList.add('has-active');
              this.classList.add('is-active');
              const source = this.getAttribute('data-source');
              const card = document.querySelector('.source-glass-card[data-source="' + source + '"]');
              if (card) card.classList.add('is-active');
            });
            slice.addEventListener('mouseleave', function() {
              donutWrapper.classList.remove('has-active');
              this.classList.remove('is-active');
              const source = this.getAttribute('data-source');
              const card = document.querySelector('.source-glass-card[data-source="' + source + '"]');
              if (card) card.classList.remove('is-active');
            });
          });

          cards.forEach(card => {
            card.addEventListener('mouseenter', function() {
              const source = this.getAttribute('data-source');
              const slice = document.querySelector('.donut-slice[data-source="' + source + '"]');
              if (slice) {
                slice.parentNode.appendChild(slice);
                slice.classList.add('is-active');
                donutWrapper.classList.add('has-active');
              }
              this.classList.add('is-active');
            });
            card.addEventListener('mouseleave', function() {
              const source = this.getAttribute('data-source');
              const slice = document.querySelector('.donut-slice[data-source="' + source + '"]');
              if (slice) slice.classList.remove('is-active');
              donutWrapper.classList.remove('has-active');
              this.classList.remove('is-active');
            });
          });
        }, 500);
      <\/script>
    </div>
  `}function ue(){document.querySelectorAll(`.clickable-kpi`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault();let n=e.dataset.route;n&&(window.location.hash=n)})})}function de(){return`
    <div class="view-enter">
      <div class="view-header-flex" style="margin-bottom: 24px;">
        <div style="display: flex; align-items: center; gap: 16px;">
          <div style="width: 48px; height: 48px; background: rgba(247,147,26,0.1); border-radius: var(--os-radius-md); display: flex; align-items: center; justify-content: center; color: var(--os-luxury-orange); font-size: 1.5rem;">
            <i class="ri-team-line"></i>
          </div>
          <div>
            <h1 class="view-title">CRM Pipeline</h1>
            <p class="view-subtitle">Track leads from first contact through to conversion</p>
          </div>
        </div>
        <div class="header-actions-right">
          <button class="os-btn-secondary" id="btn-import-csv"><i class="ri-upload-cloud-2-line"></i> Import CSV</button>
          <button class="os-btn-secondary" id="btn-sample-csv" style="border: none; background: transparent;"><i class="ri-download-line"></i> Sample CSV</button>
          <button class="os-btn-secondary" id="btn-export-csv"><i class="ri-download-cloud-2-line"></i> Export CSV</button>
          <button class="os-btn-primary" id="open-new-lead-btn" style="background: var(--os-luxury-orange); border-color: var(--os-luxury-orange);"><i class="ri-add-line"></i> New lead</button>
        </div>
      </div>

      <!-- Filters -->
      <div class="os-filter-bar" style="background: transparent; padding: 0; box-shadow: none; border: none; margin-bottom: 24px; display: flex; gap: 16px; flex-wrap: nowrap;">
        <div class="search-box" style="flex: 1; max-width: 300px; background: var(--os-white); border: var(--os-border-thin); border-radius: var(--os-radius-sm);">
          <i class="ri-search-line"></i>
          <input type="text" id="filter-search" placeholder="Search name / phone / email..." style="background: transparent;" />
        </div>
        
        <!-- Custom Selects -->
        <div class="os-custom-select" id="filter-status">
          <div class="select-value">All statuses</div>
          <i class="ri-arrow-down-s-line"></i>
          <div class="select-dropdown">
            <div class="select-option selected">All statuses</div>
            <div class="select-option">New</div>
            <div class="select-option">Contacted</div>
            <div class="select-option">Property Shared</div>
            <div class="select-option">Follow Up</div>
            <div class="select-option">Interested</div>
            <div class="select-option">Negotiation</div>
            <div class="select-option">Converted</div>
          </div>
        </div>

        <div class="os-custom-select" id="filter-source">
          <div class="select-value">All sources</div>
          <i class="ri-arrow-down-s-line"></i>
          <div class="select-dropdown">
            <div class="select-option selected">All sources</div>
            <div class="select-option">Visa Form</div>
            <div class="select-option">Website Form</div>
            <div class="select-option">Manual</div>
            <div class="select-option">Referral</div>
            <div class="select-option">Whatsapp</div>
            <div class="select-option">Import</div>
            <div class="select-option">Partner</div>
            <div class="select-option">Meta Ads</div>
          </div>
        </div>

        <div class="os-custom-select" id="filter-type">
          <div class="select-value">All property types</div>
          <i class="ri-arrow-down-s-line"></i>
          <div class="select-dropdown">
            <div class="select-option selected">All property types</div>
            <div class="select-option">Apartment</div>
            <div class="select-option">Villa</div>
            <div class="select-option">Townhouse</div>
            <div class="select-option">Penthouse</div>
            <div class="select-option">Studio</div>
            <div class="select-option">Plot</div>
            <div class="select-option">Office</div>
            <div class="select-option">Retail</div>
            <div class="select-option">Warehouse</div>
            <div class="select-option">Other</div>
          </div>
        </div>

        <div class="os-custom-select" id="filter-staff">
          <div class="select-value">All staff</div>
          <i class="ri-arrow-down-s-line"></i>
          <div class="select-dropdown">
            <div class="select-option selected">All staff</div>
${(()=>{let e=JSON.parse(localStorage.getItem(`thanjai_admin_users`))||[],t=``;return e.length>0?e.filter(e=>e.status===`Active`).forEach(e=>{t+=`<div class="select-option">${e.fullName}</div>`}):t+=`<div class="select-option" style="color:var(--os-gray-400);">No staff found</div>`,t})()}
          </div>
        </div>

        <label class="filter-toggle" style="background: var(--os-white); border: var(--os-border-thin); padding: 0 16px; border-radius: var(--os-radius-sm); height: 42px; display: flex; align-items: center; cursor: pointer;">
          <input type="checkbox" id="filter-due" style="accent-color: var(--os-luxury-orange);" /> <span style="margin-left: 8px; font-size: 0.9rem; font-weight: 500; color: var(--os-gray-600);">Due</span>
        </label>
      </div>

      <!-- Table View -->
      <div class="os-table-container" style="background: var(--os-white); border: var(--os-border-thin); border-radius: var(--os-radius-xl); box-shadow: var(--os-shadow-soft); overflow-x: auto;">
        <table class="os-table" style="width: 100%; border-collapse: collapse; min-width: 900px;">
          <thead>
            <tr>
              <th>LEAD</th>
              <th>REQUIREMENT</th>
              <th>BUDGET</th>
              <th>SOURCE</th>
              <th>STATUS</th>
              <th>ASSIGNED</th>
              <th>FOLLOW-UP</th>
              <th style="text-align: right;">ACTIONS</th>
            </tr>
          </thead>
          <tbody id="leads-table-body">
            <!-- Dynamic Content -->
          </tbody>
        </table>
      </div>

      <!-- Pagination Footer -->
      <div class="os-pagination-bar" style="display: flex; align-items: center; justify-content: space-between; margin-top: 16px; padding: 12px 20px; background: var(--os-white); border: var(--os-border-thin); border-radius: var(--os-radius-lg); font-size: 0.9rem; color: var(--os-gray-600); flex-wrap: wrap; gap: 12px;">
        <div id="leads-pagination-info" style="font-weight: 500;">Showing 0 of 0 leads</div>
        <div style="display: flex; align-items: center; gap: 8px;">
          <button id="leads-prev-btn" class="os-btn-secondary" style="padding: 6px 14px; font-size: 0.85rem; cursor: pointer;"><i class="ri-arrow-left-s-line"></i> Prev</button>
          <span id="leads-page-indicator" style="font-weight: 600; padding: 0 4px;">Page 1 of 1</span>
          <button id="leads-next-btn" class="os-btn-secondary" style="padding: 6px 14px; font-size: 0.85rem; cursor: pointer;">Next <i class="ri-arrow-right-s-line"></i></button>
          <select id="leads-page-size" style="margin-left: 8px; padding: 6px 10px; border: var(--os-border-thin); border-radius: var(--os-radius-sm); background: var(--os-white); font-family: inherit; font-size: 0.85rem; color: var(--os-gray-600); cursor: pointer;">
            <option value="25" selected>25 / page</option>
            <option value="50">50 / page</option>
            <option value="100">100 / page</option>
            <option value="500">500 / page</option>
          </select>
        </div>
      </div>

    </div>
    
    <!-- New Lead / Edit Lead Modal -->
    <div class="os-modal-overlay" id="new-lead-modal">
      <div class="os-modal-card">
        <div class="os-modal-header">
          <h2 id="modal-title">New lead</h2>
          <button class="os-modal-close" id="close-new-lead-modal"><i class="ri-close-line"></i></button>
        </div>
        <div class="os-modal-body">
          <form id="new-lead-form">
            <input type="hidden" id="lead-id" />
            <!-- CONTACT -->
            <div class="form-section-title">CONTACT</div>
            <div class="form-row">
              <div class="form-group">
                <label>Full name *</label>
                <input type="text" id="lead-name" required />
              </div>
              <div class="form-group">
                <label>Mobile *</label>
                <input type="text" id="lead-mobile" placeholder="10-digit number" required maxlength="10" pattern="[0-9]{10}" oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>WhatsApp number</label>
                <input type="text" id="lead-whatsapp" placeholder="defaults to mobile" maxlength="10" pattern="[0-9]{10}" oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
              </div>
              <div class="form-group">
                <label>Email</label>
                <input type="email" id="lead-email" />
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Country</label>
                <input type="text" id="lead-country" />
              </div>
              <div class="form-group">
                <label>City</label>
                <input type="text" id="lead-city" />
              </div>
            </div>

            <!-- REQUIREMENT -->
            <div class="form-section-title">REQUIREMENT</div>
            <div class="form-row">
              <div class="form-group">
                <label>Preferred area</label>
                <input type="text" id="lead-area" />
              </div>
              <div class="form-group">
                <label>Property type</label>
                <div class="os-custom-select modal-select" id="lead-type-select">
                  <div class="select-value">Any</div>
                  <i class="ri-arrow-down-s-line"></i>
                  <div class="select-dropdown">
                    <div class="select-option selected">Any</div>
                    <div class="select-option">Apartment</div>
                    <div class="select-option">Villa</div>
                    <div class="select-option">Townhouse</div>
                    <div class="select-option">Penthouse</div>
                    <div class="select-option">Studio</div>
                    <div class="select-option">Plot</div>
                    <div class="select-option">Office</div>
                    <div class="select-option">Retail</div>
                    <div class="select-option">Warehouse</div>
                    <div class="select-option">Other</div>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Budget min</label>
                <input type="text" id="lead-budget-min" />
              </div>
              <div class="form-group">
                <label>Budget max</label>
                <input type="text" id="lead-budget-max" />
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Currency</label>
                <div class="os-custom-select modal-select" id="lead-currency-select">
                  <div class="select-value">INR</div>
                  <i class="ri-arrow-down-s-line"></i>
                  <div class="select-dropdown">
                    <div class="select-option selected">INR</div>
                    <div class="select-option">USD</div>
                    <div class="select-option">EUR</div>
                  </div>
                </div>
              </div>
              <div class="form-group">
                <label>Bedrooms</label>
                <input type="text" id="lead-bedrooms" />
              </div>
            </div>

            <!-- TRACKING -->
            <div class="form-section-title">TRACKING</div>
            <div class="form-row">
              <div class="form-group">
                <label>Source</label>
                <input type="text" id="lead-source" placeholder="e.g. Manual, Walk-in, Referral, Instagram, Meta Ads..." value="Manual" />
              </div>
              <div class="form-group">
                <label>Priority</label>
                <div class="os-custom-select modal-select" id="lead-priority-select">
                  <div class="select-value">Medium</div>
                  <i class="ri-arrow-down-s-line"></i>
                  <div class="select-dropdown">
                    <div class="select-option">High</div>
                    <div class="select-option selected">Medium</div>
                    <div class="select-option">Low</div>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Assign to</label>
                <div class="os-custom-select modal-select" id="lead-assign-select">
                  <div class="select-value">Unassigned</div>
                  <i class="ri-arrow-down-s-line"></i>
                  <div class="select-dropdown">
                    <div class="select-option selected">Unassigned</div>
${(()=>{let e=JSON.parse(localStorage.getItem(`thanjai_admin_users`))||[],t=``;return e.length>0?e.filter(e=>e.status===`Active`).forEach(e=>{t+=`<div class="select-option">${e.fullName}</div>`}):t+=`<div class="select-option" style="color:var(--os-gray-400);">No staff found</div>`,t})()}
                  </div>
                </div>
              </div>
              <div class="form-group">
                <label>Follow-up Date</label>
                <input type="date" id="lead-followup" style="color: var(--os-gray-600);" />
              </div>
            </div>
            <div class="form-row">
              <div class="form-group" style="width: 100%;">
                <label>Requirement notes</label>
                <textarea id="lead-notes" rows="3" style="width: 100%; border: var(--os-border-thin); border-radius: var(--os-radius-sm); padding: 12px; font-family: inherit; resize: vertical;"></textarea>
              </div>
            </div>
          </form>
        </div>
        <div class="os-modal-footer">
          <button class="os-btn-secondary" id="cancel-new-lead-btn">Cancel</button>
          <button class="os-btn-primary" id="btn-save-lead" style="background: var(--os-luxury-orange); border-color: var(--os-luxury-orange);">Create lead</button>
        </div>
        </div>
      </div>
    </div>
  `}var N=[],P=1,F=25;function fe(e){let t=e.phone||e.mobile||``,n=e.budget||e.budgetMax||``,r=e.requirement||e.propertyType||e.type||`Residential Plot`,i=e.location||e.city||`Thanjavur`,a=i.split(`,`).map(e=>e.trim());return{id:e.id,name:e.name||`Unnamed Lead`,mobile:t,phone:t,whatsapp:e.whatsapp||t,email:e.email||``,country:e.country||(a.length>=3?a[a.length-1]:`India`),city:a.length>=2?a[a.length-2]:a[0]||e.city||`Thanjavur`,area:a[0]||i,location:i,budgetMin:e.budgetMin||``,budgetMax:n,budget:n,bedrooms:e.bedrooms||``,notes:e.notes?typeof e.notes==`string`&&e.notes.startsWith(`[`)&&pe(e.notes)||e.notes:``,type:r,propertyType:r,requirement:r,source:e.source||`MANUAL`,assignTo:e.assignedTo||e.assignTo||`Unassigned`,assignedTo:e.assignedTo||e.assignTo||`Unassigned`,status:e.status||`New Lead`,followup:e.followup||`—`,createdAt:e.createdAt?new Date(e.createdAt).getTime():Date.now(),timeline:e.timeline?typeof e.timeline==`string`&&e.timeline.startsWith(`[`)?pe(e.timeline)||[]:Array.isArray(e.timeline)?e.timeline:[]:[]}}function pe(e){try{return JSON.parse(e)}catch{return null}}async function me(){try{let e=await o(`/leads`);e&&Array.isArray(e)&&(N=e.map(fe),he(N))}catch(e){console.error(`API Error:`,e),N=JSON.parse(localStorage.getItem(`thanjai_leads`))||[]}_e(),R()}function I(){return N}function he(e){N=e;try{localStorage.setItem(`thanjai_leads`,JSON.stringify(e.slice(0,100)))}catch(e){console.warn(`LocalStorage quota notice:`,e)}}function ge(e){if(!e)return`—`;if(typeof e==`string`&&(e.includes(`Lakh`)||e.includes(`Crore`)||e.includes(`-`)||e.includes(`₹`)))return e.startsWith(`₹`)?e:`₹ `+e;let t=parseFloat(String(e).replace(/[^0-9.]/g,``));return isNaN(t)||t<=0?typeof e==`string`&&e.trim()?e:`—`:t>=1e7?`₹ `+(t/1e7).toFixed(2).replace(/\.00$/,``)+` Crore`:t>=1e5?`₹ `+(t/1e5).toFixed(2).replace(/\.00$/,``)+` Lakhs`:`₹ `+t.toLocaleString(`en-IN`)}function R(){let e=document.getElementById(`leads-table-body`);if(!e)return;let t=I(),n=document.getElementById(`filter-search`),r=document.getElementById(`filter-status`),i=document.getElementById(`filter-source`),a=document.getElementById(`filter-type`),o=document.getElementById(`filter-staff`),s=document.getElementById(`filter-due`);if(n&&r){let e=n.value.toLowerCase(),c=r.querySelector(`.select-value`).textContent,l=i.querySelector(`.select-value`).textContent,u=a.querySelector(`.select-value`).textContent,d=o.querySelector(`.select-value`).textContent,f=s.checked;t=t.filter(t=>!(e&&!`${t.name||``} ${t.mobile||``} ${t.email||``} ${t.type||``} ${t.area||``} ${t.source||``} ${t.status||``} ${t.assignTo||``}`.toLowerCase().includes(e)||c!==`All statuses`&&t.status!==c||l!==`All sources`&&t.source!==l||u!==`All property types`&&t.type!==u||d!==`All staff`&&t.assignTo!==d||f&&(!t.followup||t.followup===`—`)))}let c=t.length,l=Math.max(1,Math.ceil(c/F));P>l&&(P=l),P<1&&(P=1);let u=(P-1)*F,d=Math.min(u+F,c),f=t.slice(u,d),p=document.getElementById(`leads-pagination-info`),m=document.getElementById(`leads-page-indicator`),h=document.getElementById(`leads-prev-btn`),g=document.getElementById(`leads-next-btn`);if(p&&(p.innerHTML=c>0?`Showing <strong>${u+1}</strong> - <strong>${d}</strong> of <strong>${c.toLocaleString()}</strong> leads`:`No leads found`),m&&(m.textContent=`Page ${P} of ${l.toLocaleString()}`),h&&(h.disabled=P<=1),g&&(g.disabled=P>=l),f.length===0){e.innerHTML=`<tr><td colspan="8" style="text-align: center; padding: 40px; color: var(--os-gray-400);">No matching leads found</td></tr>`;return}e.innerHTML=f.map(e=>{let t=e.type||e.propertyType||e.requirement||`—`;(t===`undefined`||t===`null`)&&(t=`—`);let n=`<div style="font-weight: 500; color: var(--os-gray-600);">${t===`Any`?`—`:t}</div>`;(e.area||e.location)&&(n+=`<div style="font-size: 0.85rem; color: var(--os-gray-400);">${e.area||e.location}</div>`);let r=`—`;e.budgetMax||e.budget?r=ge(e.budgetMax||e.budget):e.budgetMin&&(r=`Min ${ge(e.budgetMin)}`);let i=`badge-gray`,a=e.status?e.status.toUpperCase():`NEW`;a.includes(`CONTACTED`)?i=`badge-cyan`:a.includes(`FOLLOW UP`)?i=`badge-yellow`:a.includes(`NEGOTIATION`)?i=`badge-orange`:a.includes(`CONVERTED`)&&(i=`badge-cyan`);let o=e.source?e.source.toUpperCase():`MANUAL`,s=`<td style="color: var(--os-gray-400);">—</td>`;if(e.assignTo&&e.assignTo!==`Unassigned`){let t=e.assignTo.split(` `);s=`<td>
         <div style="font-weight: 500; color: var(--os-gray-600);">${t[0]}</div>
         <div style="font-size: 0.85rem; color: var(--os-gray-400);">${t[1]||``}</div>
       </td>`}return`
      <tr data-id="${e.id}">
        <td>
          <div class="action-view" style="font-weight: 600; color: var(--os-luxury-orange); cursor: pointer;">${e.name}</div>
          <div style="font-size: 0.85rem; color: var(--os-gray-400);">${e.mobile||e.phone||`—`}</div>
        </td>
        <td>
          ${n}
        </td>
        <td style="color: var(--os-gray-600); font-weight: 500;">${r}</td>
        <td><span class="os-badge badge-gray">${o}</span></td>
        <td><span class="os-badge ${i}">${a}</span></td>
        ${s}
        <td style="color: var(--os-gray-400);">${e.followup||`—`}</td>
        <td style="text-align: right;">
          <div class="action-icons">
            <i class="ri-eye-line action-view"></i>
            <i class="ri-pencil-line action-edit"></i>
            <i class="ri-delete-bin-line action-delete"></i>
          </div>
        </td>
      </tr>
    `}).join(``)}function _e(){let e=document.querySelectorAll(`.os-custom-select`);e.forEach(t=>{t.addEventListener(`click`,n=>{n.stopPropagation(),e.forEach(e=>{e!==t&&e.classList.remove(`open`)}),t.classList.toggle(`open`)});let n=t.querySelectorAll(`.select-option`),r=t.querySelector(`.select-value`);n.forEach(e=>{e.addEventListener(`click`,i=>{i.stopPropagation(),r.textContent=e.textContent,n.forEach(e=>e.classList.remove(`selected`)),e.classList.add(`selected`),t.classList.remove(`open`),t.id&&t.id.startsWith(`filter-`)&&(P=1,R())})})}),document.addEventListener(`click`,()=>{e.forEach(e=>e.classList.remove(`open`))});let t=document.getElementById(`filter-search`);t&&t.addEventListener(`input`,()=>{P=1,R()});let n=document.getElementById(`filter-due`);n&&n.addEventListener(`change`,()=>{P=1,R()});let r=document.getElementById(`leads-prev-btn`),i=document.getElementById(`leads-next-btn`),a=document.getElementById(`leads-page-size`);r&&r.addEventListener(`click`,()=>{P>1&&(P--,R())}),i&&i.addEventListener(`click`,()=>{P++,R()}),a&&a.addEventListener(`change`,e=>{F=parseInt(e.target.value)||25,P=1,R()});let s=document.getElementById(`new-lead-modal`),c=document.getElementById(`open-new-lead-btn`),l=document.getElementById(`close-new-lead-modal`),u=document.getElementById(`cancel-new-lead-btn`),d=document.getElementById(`btn-save-lead`),p=document.getElementById(`new-lead-form`),m=document.getElementById(`modal-title`);function h(e=!1){if(!e){p.reset(),document.getElementById(`lead-id`).value=``,document.getElementById(`lead-followup`).value=``;let e=document.getElementById(`lead-source`);e&&(e.value=`Manual`),m.textContent=`New lead`,d.textContent=`Create lead`,document.querySelectorAll(`.modal-select`).forEach(e=>{let t=e.querySelector(`.select-option`);e.querySelector(`.select-value`).textContent=t.textContent,e.querySelectorAll(`.select-option`).forEach(e=>e.classList.remove(`selected`)),t.classList.add(`selected`)})}s.classList.add(`show`)}let _=()=>s.classList.remove(`show`);c&&c.addEventListener(`click`,()=>h(!1)),l&&l.addEventListener(`click`,_),u&&u.addEventListener(`click`,_),s&&s.addEventListener(`click`,e=>{e.target===s&&_()}),d&&d.addEventListener(`click`,async()=>{let e=document.getElementById(`lead-name`).value.trim(),t=document.getElementById(`lead-mobile`).value.trim();if(!e||!t){g({title:`Missing Required Fields`,message:`Please enter both the <strong>Lead Name</strong> and <strong>Mobile Phone Number</strong> to proceed.`,type:`warning`});return}let n=document.getElementById(`lead-id`).value,r=I(),i=n?r.find(e=>e.id==n):null,a=document.getElementById(`lead-type-select`).querySelector(`.select-value`).textContent,s=document.getElementById(`lead-source`),c=(s?s.value.trim():``)||`Manual`,l=document.getElementById(`lead-assign-select`).querySelector(`.select-value`).textContent,u=document.getElementById(`lead-area`).value,d=document.getElementById(`lead-city`).value,p=document.getElementById(`lead-country`).value,m=[u,d,p].filter(Boolean).join(`, `),h=document.getElementById(`lead-bedrooms`).value,v=h?`${a} - ${h} Beds`:a,y=document.getElementById(`lead-budget-min`).value,b=document.getElementById(`lead-budget-max`).value,S=y&&b?`${y} - ${b}`:b||y||``,C=(()=>{try{let e=JSON.parse(localStorage.getItem(`thanjai_active_user`)||`{}`);return e.fullName||e.name||`System`}catch{return`System`}})(),w={id:n||`L-`+Math.floor(1e3+Math.random()*9e3),name:e,phone:t,email:document.getElementById(`lead-email`).value,source:c,status:n&&i?i.status:`New Lead`,budget:S,requirement:v,location:m,timeline:n?i?typeof i.timeline==`string`?i.timeline:JSON.stringify(i.timeline||[]):`[]`:JSON.stringify([{type:`pipeline`,message:`Lead created`,author:C,date:new Date().toISOString()}]),followup:document.getElementById(`lead-followup`).value||`—`,assignedTo:l,notes:n?i?typeof i.notes==`string`?i.notes:JSON.stringify(i.notes||[]):`[]`:document.getElementById(`lead-notes`).value,mobile:t,whatsapp:document.getElementById(`lead-whatsapp`).value,country:p,city:d,area:u,budgetMin:y,budgetMax:b,bedrooms:h,type:a,assignTo:l,createdAt:n&&i?i.createdAt:Date.now()},T=I();if(n){let e=T.findIndex(e=>String(e.id)===String(n));e!==-1&&(T[e]={...T[e],...w})}else T.unshift(w);he(T),x({action:n?`Updated Lead (${e})`:`Added New Lead (${e})`,module:`CRM Pipeline`,details:n?`Updated lead requirements for ${e} (${t}) to ${v} in ${m}.`:`Created new lead ${e} (${t}) with requirement ${v} in ${m}.`}),R(),_(),f(n?`Lead "${e}" updated!`:`New lead "${e}" added!`,`ri-checkbox-circle-fill`);let E=n?`/leads/`+n:`/leads`;o(E,{method:n?`PUT`:`POST`,body:JSON.stringify(w)}).then(async()=>{let e=await o(`/leads`);e&&Array.isArray(e)&&he(e.map(fe))}).catch(e=>{console.warn(`DB sync failed, saved locally only:`,e)})});let y=document.getElementById(`btn-import-csv`),b=document.getElementById(`btn-sample-csv`),S=document.getElementById(`btn-export-csv`),C=document.getElementById(`csv-file-input`);C||(C=document.createElement(`input`),C.type=`file`,C.id=`csv-file-input`,C.accept=`.csv`,C.style.display=`none`,document.body.appendChild(C)),y&&y.addEventListener(`click`,()=>{C.click()}),C.addEventListener(`change`,async e=>{let t=e.target.files[0];if(!t)return;let n=new FileReader;n.onload=async function(e){let t=e.target.result.split(`
`).map(e=>e.trim()).filter(Boolean);if(t.length<2){g({title:`Empty or Invalid CSV`,message:`The selected CSV file appears to be empty or missing property data rows.`,type:`error`});return}let n=t[0].split(`,`).map(e=>e.replace(/^["']|["']$/g,``).trim().toLowerCase()),r=e=>{for(let t of e){let e=n.findIndex(e=>e.includes(t));if(e!==-1)return e}return-1},i=r([`name`,`lead`,`client`]),a=r([`mobile`,`phone`,`contact`,`whatsapp`]),s=r([`email`,`mail`]),c=r([`propertytype`,`type`,`requirement`,`property`]),l=r([`budget`,`budgetmax`,`amount`,`price`]),u=r([`location`,`area`,`city`]),d=r([`source`,`lead source`]),p=r([`status`]),m=r([`notes`,`note`,`desc`,`remarks`]),h=[];for(let e=1;e<t.length;e++){let n=t[e].match(/(".*?"|[^",]+)(?=\s*,|\s*$)/g),r=n?n.map(e=>e.replace(/^"|"$/g,``).trim()):t[e].split(`,`).map(e=>e.replace(/^"|"$/g,``).trim()),f=(e,t=``)=>e!==-1&&r[e]!==void 0?r[e]:t,g=f(i===-1?0:i);if(g&&g.toLowerCase()!==`name`){let t=f(a===-1?1:a,`9585777772`),n=f(s===-1?2:s,``),r=f(c===-1?3:c,`Residential Plot`),i=f(l===-1?4:l,`₹ 25 - 50 Lakhs`),_=f(u===-1?5:u,`Thanjavur`),v=f(d===-1?6:d,`Website Form`),y=f(p===-1?7:p,`New Lead`),b=f(m===-1?8:m,`Imported from CSV template.`),x={id:`L-${Date.now()}-${e}`,name:g,mobile:t,phone:t,whatsapp:t,email:n,country:`India`,city:`Thanjavur`,area:_,location:_,budgetMin:``,budgetMax:i,budget:i,bedrooms:``,notes:b,type:r,propertyType:r,requirement:r,source:v,assignTo:`Unassigned`,status:y,followup:`—`,createdAt:Date.now(),timeline:[{action:`Imported from CSV file`,date:new Date().toLocaleDateString(`en-IN`),by:`System`}]};h.push(x);try{o(`/leads`,{method:`POST`,body:JSON.stringify(x)}).catch(e=>console.warn(e))}catch{}}}if(h.length>0){let e=I();he([...h,...e]),R(),x({action:`Bulk Imported Leads (${h.length})`,module:`CRM Pipeline`,details:`Imported ${h.length} new leads via CSV batch upload.`}),f(`${h.length} leads imported successfully into CRM!`,`ri-checkbox-circle-fill`)}else g({title:`No Valid Records`,message:`No valid lead rows could be extracted from the uploaded CSV.`,type:`warning`})},n.readAsText(t),e.target.value=``}),b&&b.addEventListener(`click`,()=>{let e=new Blob([`Name,Mobile,Email,PropertyType,Budget,Location,Source,Status,Notes
"Arun Kumar","9842154321","arun.kumar@gmail.com","Luxury Villa","12500000","Medical College Road, Thanjavur","Website Form","New Lead","Looking for 3 or 4 BHK independent luxury villa near Medical College Road with car parking."
"Priya Raman","9443219876","priya.raman@yahoo.com","Residential Plot","3500000","Trichy Road, Thanjavur","Phone Call","Contacted","Interested in DTCP approved East-facing corner plot near New Bus Stand bypass."`],{type:`text/csv;charset=utf-8;`}),t=document.createElement(`a`),n=URL.createObjectURL(e);t.setAttribute(`href`,n),t.setAttribute(`download`,`Thanjai_CRM_Leads_Sample_Template.csv`),t.style.visibility=`hidden`,document.body.appendChild(t),t.click(),document.body.removeChild(t)}),S&&S.addEventListener(`click`,()=>{let e=I();if(e.length===0){g({title:`Export Notice`,message:`There are currently no active leads available to export.`,type:`info`});return}let t=`Name,Mobile,Email,PropertyType,BudgetMax,Source,Status,AssignedTo
`;e.forEach(e=>{t+=`${e.name||``},${e.mobile||``},${e.email||``},${e.type||``},${e.budgetMax||``},${e.source||``},${e.status||``},${e.assignTo||``}\n`});let n=new Blob([t],{type:`text/csv;charset=utf-8;`}),r=document.createElement(`a`),i=URL.createObjectURL(n);r.setAttribute(`href`,i),r.setAttribute(`download`,`exported_leads.csv`),r.style.visibility=`hidden`,document.body.appendChild(r),r.click(),document.body.removeChild(r)});let w=document.querySelector(`.os-table-container`);w&&w.addEventListener(`click`,e=>{let t=e.target.closest(`tr`);if(!t)return;let n=t.getAttribute(`data-id`),r=I(),i=r.find(e=>e.id==n);if(i){if(e.target.closest(`.action-view`))window.location.hash=`lead/`+n;else if(e.target.closest(`.action-edit`)){let e=document.getElementById(`lead-notes`);e&&(e.value=``,e.disabled=!1),h(!0),m.textContent=`Edit lead`,d.textContent=`Save Changes`,document.getElementById(`lead-id`).value=i.id,document.getElementById(`lead-name`).value=i.name||``,document.getElementById(`lead-mobile`).value=i.mobile||``,document.getElementById(`lead-whatsapp`).value=i.whatsapp||``,document.getElementById(`lead-email`).value=i.email||``,document.getElementById(`lead-country`).value=i.country||``,document.getElementById(`lead-city`).value=i.city||``,document.getElementById(`lead-area`).value=i.area||``,document.getElementById(`lead-budget-min`).value=i.budgetMin||``,document.getElementById(`lead-budget-max`).value=i.budgetMax||``,document.getElementById(`lead-bedrooms`).value=i.bedrooms||``,e&&(e.value=`Notes are managed in the Lead Details page.`,e.disabled=!0),document.getElementById(`lead-followup`).value=i.followup&&i.followup!==`—`?i.followup:``;let t=document.getElementById(`lead-type-select`);t&&(t.querySelector(`.select-value`).textContent=i.type||`Any`);let n=document.getElementById(`lead-source`);n&&(n.value=i.source||`Manual`);let r=document.getElementById(`lead-assign-select`);r&&(r.querySelector(`.select-value`).textContent=i.assignTo||`Unassigned`)}else e.target.closest(`.action-delete`)&&v({title:`Delete Lead`,message:`Are you sure you want to permanently delete lead <strong>${i.name}</strong> from the CRM Pipeline? This will remove all linked timeline and notes.`,confirmText:`Delete Lead`,cancelText:`Keep Lead`,confirmIcon:`ri-delete-bin-line`,isDanger:!0,onConfirm:()=>{he(r.filter(e=>String(e.id)!==String(n))),R(),x({action:`Deleted Lead (${i.name})`,module:`CRM Pipeline`,details:`Permanently removed lead record ${i.name} (${i.phone||i.mobile||`No Phone`}) from CRM pipeline.`}),f(`Lead "${i.name}" deleted`,`ri-checkbox-circle-fill`),o(`/leads/`+n,{method:`DELETE`}).catch(e=>console.warn(`DB delete sync failed:`,e))}})}})}var ve=``,z=`all`,B=`all`,V=`all`,H=`all`,U=`list`,W=null,G=null,K=0;function ye(){U=`list`,W=null,G=null,K=0}function be(e){ve=e}var q=[],J=[``],xe=[],Y=null,Se=null;function Ce(e,t=1e3,n=800,r=.75){return new Promise(i=>{if(!e||!e.type.startsWith(`image/`)){i(null);return}let a=new FileReader;a.onload=e=>{let a=new Image;a.onload=()=>{let e=a.width,o=a.height;e>t&&(o=Math.round(o*t/e),e=t),o>n&&(e=Math.round(e*n/o),o=n);let s=document.createElement(`canvas`);s.width=e,s.height=o,s.getContext(`2d`).drawImage(a,0,0,e,o),i(s.toDataURL(`image/jpeg`,r))},a.onerror=()=>i(e.target.result),a.src=e.target.result},a.onerror=()=>i(null),a.readAsDataURL(e)})}function we(){try{let e=k()||[];if(U===`form`)return De(W?e.find(e=>e&&e.id===W):null);let t=ke(e);return`
    <div class="view-enter properties-view-container" style="padding-bottom: 40px; position: relative;">
      
      <!-- Top Header Matching Reference Image 2 -->
      <div class="os-module-header" style="
        display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px; margin-bottom: 24px;
      ">
        <div style="display: flex; align-items: center; gap: 14px;">
          <div style="
            width: 46px; height: 46px; border-radius: 12px; background: rgba(235,94,40,0.12);
            color: var(--color-orange, #eb5e28); display: flex; align-items: center; justify-content: center; font-size: 1.4rem;
          ">
            <i class="ri-building-4-fill"></i>
          </div>
          <div>
            <a href="#users" style="display: inline-flex; align-items: center; gap: 4px; font-size: 0.82rem; color: #718096; text-decoration: none; font-weight: 700; margin-bottom: 6px; transition: color 0.2s;" onmouseover="this.style.color='#1a202c'" onmouseout="this.style.color='#718096'">
              <i class="ri-arrow-left-line"></i> Back to Registered Users
            </a>
            <h1 style="font-size: 1.5rem; font-weight: 700; color: #1a202c; margin: 0; line-height: 1.2;">Properties Inventory</h1>
            <p style="font-size: 0.88rem; color: #718096; margin: 2px 0 0 0;">Browse, list, and manage your property catalog</p>
          </div>
        </div>

        <!-- Top Right Actions: Import CSV, Export CSV and + Add Property -->
        <div style="display: flex; align-items: center; gap: 12px;">
          <input type="file" id="import-props-csv-file" accept=".csv" style="display: none;" />

          <button class="os-btn-secondary" id="import-props-csv-btn" title="Import properties from CSV file" style="display: inline-flex; align-items: center; gap: 6px; padding: 10px 18px; font-size: 0.88rem; border-radius: 10px; border: 1px solid #cbd5e0; background: #ffffff; color: #4a5568; font-weight: 600; cursor: pointer;">
            <i class="ri-upload-cloud-line" style="font-size: 1.1rem; color: #3182ce;"></i>
            <span>Import CSV</span>
          </button>

          <button class="os-btn-secondary" id="export-props-csv-btn" title="Export currently listed properties to CSV" style="display: inline-flex; align-items: center; gap: 6px; padding: 10px 18px; font-size: 0.88rem; border-radius: 10px; border: 1px solid #cbd5e0; background: #ffffff; color: #4a5568; font-weight: 600; cursor: pointer;">
            <i class="ri-download-cloud-line" style="font-size: 1.1rem; color: var(--color-orange, #eb5e28);"></i>
            <span>Export CSV</span>
          </button>

          <button class="os-btn-secondary" id="download-sample-csv-btn" title="Download official sample CSV template" style="display: inline-flex; align-items: center; gap: 6px; padding: 10px 18px; font-size: 0.88rem; border-radius: 10px; border: 1px solid #cbd5e0; background: #ffffff; color: #4a5568; font-weight: 600; cursor: pointer;">
            <i class="ri-file-text-line" style="font-size: 1.1rem; color: #38a169;"></i>
            <span>Sample CSV</span>
          </button>

          <button class="os-btn-primary" id="open-add-property-form-btn" style="
            display: inline-flex; align-items: center; gap: 6px; padding: 10px 22px; font-size: 0.9rem; font-weight: 700;
            border-radius: 10px; background: var(--color-orange, #eb5e28); color: #ffffff; border: none; cursor: pointer;
            box-shadow: 0 4px 12px rgba(235,94,40,0.25);
          ">
            <i class="ri-add-line" style="font-size: 1.15rem;"></i>
            <span>Add property</span>
          </button>
        </div>
      </div>

      <!-- Filter Bar -->
      <div style="
        background: #ffffff; border-radius: 16px; padding: 14px 18px; border: 1px solid #e2e8f0;
        box-shadow: 0 2px 8px rgba(0,0,0,0.03); margin-bottom: 28px; display: flex; flex-wrap: wrap; gap: 12px; align-items: center;
      ">
        <div style="position: relative; flex: 1; min-width: 240px;">
          <i class="ri-search-line" style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #a0aec0; font-size: 1rem;"></i>
          <input type="text" id="props-search-input" value="${ve}" placeholder="Search title / location..." style="
            width: 100%; padding: 8px 12px 8px 36px; border-radius: 8px; border: 1px solid #cbd5e0; font-size: 0.88rem; outline: none;
          " />
        </div>

        <select id="props-type-filter" style="padding: 8px 14px; border-radius: 8px; border: 1px solid #cbd5e0; background: #fff; font-size: 0.88rem; color: #4a5568;">
          <option value="all" ${z===`all`?`selected`:``}>All types</option>
          <option value="Apartment" ${z===`Apartment`?`selected`:``}>Apartment</option>
          <option value="Villa" ${z===`Villa`?`selected`:``}>Villa</option>
          <option value="Townhouse" ${z===`Townhouse`?`selected`:``}>Townhouse</option>
          <option value="Penthouse" ${z===`Penthouse`?`selected`:``}>Penthouse</option>
          <option value="Studio" ${z===`Studio`?`selected`:``}>Studio</option>
          <option value="Plot" ${z===`Plot`?`selected`:``}>Plot</option>
          <option value="Office" ${z===`Office`?`selected`:``}>Office</option>
          <option value="Retail" ${z===`Retail`?`selected`:``}>Retail</option>
          <option value="Warehouse" ${z===`Warehouse`?`selected`:``}>Warehouse</option>
          <option value="Other" ${z===`Other`?`selected`:``}>Other</option>
        </select>

        <select id="props-category-filter" style="padding: 8px 14px; border-radius: 8px; border: 1px solid #cbd5e0; background: #fff; font-size: 0.88rem; color: #4a5568;">
          <option value="all" ${B===`all`?`selected`:``}>All categories</option>
          <option value="Sale" ${B===`Sale`?`selected`:``}>Sale</option>
          <option value="Rent" ${B===`Rent`?`selected`:``}>Rent</option>
          <option value="Lease" ${B===`Lease`?`selected`:``}>Lease</option>
          <option value="Commercial" ${B===`Commercial`?`selected`:``}>Commercial</option>
          <option value="Residential" ${B===`Residential`?`selected`:``}>Residential</option>
        </select>

        <select id="props-status-filter" style="padding: 8px 14px; border-radius: 8px; border: 1px solid #cbd5e0; background: #fff; font-size: 0.88rem; color: #4a5568;">
          <option value="all" ${V===`all`?`selected`:``}>All statuses</option>
          <option value="Available" ${V===`Available`?`selected`:``}>Available</option>
          <option value="Booked" ${V===`Booked`?`selected`:``}>Booked</option>
          <option value="Sold" ${V===`Sold`?`selected`:``}>Sold</option>
          <option value="Rented" ${V===`Rented`?`selected`:``}>Rented</option>
          <option value="Inactive" ${V===`Inactive`?`selected`:``}>Inactive</option>
        </select>

        <select id="props-maxprice-filter" style="padding: 8px 14px; border-radius: 8px; border: 1px solid #cbd5e0; background: #fff; font-size: 0.88rem; color: #4a5568;">
          <option value="all" ${H===`all`?`selected`:``}>Max price</option>
          <option value="5000000" ${H===`5000000`?`selected`:``}>₹ 50 Lakhs</option>
          <option value="15000000" ${H===`15000000`?`selected`:``}>₹ 1.5 Crore</option>
          <option value="30000000" ${H===`30000000`?`selected`:``}>₹ 3 Crore</option>
          <option value="50000000" ${H===`50000000`?`selected`:``}>₹ 5 Crore+</option>
        </select>
      </div>

      <!-- Properties Grid -->
      ${t.length===0?`
        <div style="
          background: #ffffff; border-radius: 16px; padding: 60px 20px; text-align: center; border: 1px solid #e2e8f0;
        ">
          <i class="ri-building-line" style="font-size: 3rem; color: #a0aec0; margin-bottom: 12px; display: block;"></i>
          <h3 style="font-size: 1.1rem; color: #2d3748; margin-bottom: 6px;">No Properties Match Your Filters</h3>
          <p style="font-size: 0.88rem; color: #718096; margin-bottom: 16px;">Try adjusting your search term, category, status, or price parameters.</p>
          <button class="os-btn-primary" id="empty-add-prop-btn" style="padding: 10px 20px; font-size: 0.88rem; border-radius: 8px; background: var(--color-orange, #eb5e28); color: #fff; border: none; font-weight: 700; cursor: pointer;">
            + Add New Property Listing
          </button>
        </div>
      `:`
        <div style="
          display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 24px;
        ">
          ${t.map(e=>Te(e)).join(``)}
        </div>
      `}

    </div>
  `}catch(e){return console.error(`Error rendering properties view:`,e),`
      <div class="view-enter" style="padding: 40px; text-align: center;">
        <h2 style="color: var(--os-charcoal);">Properties Inventory</h2>
        <p style="color: #e53e3e;">Unable to load property inventory. Please refresh the page.</p>
      </div>
    `}}function Te(e){if(!e)return``;let t=e.status||e.availability||`Available`,n=e.approvalStatus||(t===`Pending Approval`?`Pending Approval`:`Approved`),r=t.toLowerCase(),i=r===`available`?`#e6fffa`:r===`sold`?`#fed7d7`:r===`booked`?`#feebc8`:r===`rented`?`#ebf8ff`:`#fff5f5`,a=r===`available`?`#234e52`:r===`sold`?`#9b2c2c`:r===`booked`?`#7b341e`:r===`rented`?`#2b6cb0`:`#742a2a`,o=e.images&&e.images[0]?e.images[0]:`/default-property.jpg`,s=[];return e.bedrooms&&s.push(`${e.bedrooms} bed`),e.bathrooms&&s.push(`${e.bathrooms} bath`),e.size&&s.push(w(e.size)),e.facing&&s.push(e.facing),e.approval&&s.push(e.approval),`
    <div class="crm-ref-prop-card" data-id="${e.id}" style="
      background: #ffffff; border-radius: 16px; overflow: hidden; border: 1px solid #e2e8f0;
      box-shadow: 0 4px 16px rgba(0,0,0,0.03); display: flex; flex-direction: column; transition: transform 0.2s ease, box-shadow 0.2s ease;
    ">
      <!-- Card Image Header -->
      <div style="height: 200px; position: relative; overflow: hidden; background: #f0f4f8;">
        <img src="${o}" alt="${e.title}" style="
          width: 100%; height: 100%; object-fit: cover; object-position: center; display: block;
        " />
        
        <!-- Ad Type Interactive Select Dropdown Top Left -->
        <div style="position: absolute; top: 12px; left: 12px; z-index: 2;" title="Change Listing Plan">
          <select class="quick-adtype-select" data-id="${e.id}" style="
            padding: 4px 8px; border-radius: 6px; font-size: 0.72rem; font-weight: 800;
            letter-spacing: 0.04em; text-transform: uppercase; cursor: pointer; outline: none;
            background: ${e.adType===`paid`?`#EBF8FF`:`#FFF5EB`};
            color: ${e.adType===`paid`?`#2B6CB0`:`#C05621`};
            border: 1px solid ${e.adType===`paid`?`#BEE3F8`:`#FBD38D`};
            box-shadow: 0 2px 6px rgba(0,0,0,0.12);
          ">
            <option value="free" ${e.adType===`paid`?``:`selected`}>🛡️ FREE AD</option>
            <option value="paid" ${e.adType===`paid`?`selected`:``}>👑 PAID AD</option>
          </select>
        </div>

        <!-- Status Badge Top Right -->
        <span style="
          position: absolute; top: 12px; right: 12px; padding: 4px 10px; border-radius: 6px;
          font-size: 0.72rem; font-weight: 800; letter-spacing: 0.05em; text-transform: uppercase;
          background: ${i}; color: ${a}; box-shadow: 0 2px 6px rgba(0,0,0,0.08);
        ">
          ${t}
        </span>
      </div>

      <!-- Card Body matching Image 2 -->
      <div style="padding: 18px 20px; display: flex; flex-direction: column; flex: 1;">
        
        <!-- Title -->
        <h3 style="font-size: 1.05rem; font-weight: 700; color: #1a202c; margin: 0 0 4px 0; line-height: 1.35; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
          ${e.title}
        </h3>

        <!-- Location & Type Info Line -->
        <p style="font-size: 0.82rem; color: #718096; margin: 0 0 6px 0;">
          ${e.location||e.district} • Property • ${e.categoryRaw||e.type||`Sale`}
        </p>

        <!-- Owner Badge -->
        <div style="font-size: 0.8rem; font-weight: 700; color: #4A5568; margin-bottom: 8px; display: flex; align-items: center; gap: 6px;">
          <i class="${e.adType===`paid`?`ri-user-star-fill`:`ri-shield-user-fill`}" style="color: ${e.adType===`paid`?`#3182CE`:`#eb5e28`};"></i>
          <span>${e.adType===`paid`?`Direct Owner`:`Listing Desk`}: ${e.adType===`paid`?e.ownerName||`Verified Owner`:`Thanjai Property`} ${e.adType===`paid`?e.ownerPhone?`(${e.ownerPhone})`:``:`(8489996852)`}</span>
        </div>

        <!-- Bold Price -->
        <div style="font-size: 1.35rem; font-weight: 800; color: var(--color-orange, #eb5e28); margin-bottom: 8px;">
          ${e.priceFormatted||`₹ ${e.price}`}
        </div>

        <!-- Specs Line -->
        <div style="font-size: 0.82rem; color: #718096; margin-bottom: 18px;">
          ${s.length>0?s.join(` • `):e.size||`Prime Property`}
        </div>

        <!-- Bottom Action Bar Matching Image 2 -->
        <div style="
          margin-top: auto; padding-top: 14px; border-top: 1px solid #edf2f7;
          display: flex; justify-content: space-between; align-items: center; gap: 8px; flex-wrap: wrap;
        ">
          <!-- Status Dropdown with "Update availability" Tooltip -->
          <div style="position: relative;" title="Update availability">
            <select class="quick-status-select" data-id="${e.id}" style="
              padding: 6px 12px; font-size: 0.8rem; font-weight: 700; border-radius: 8px; border: 1px solid #cbd5e0;
              background: #ffffff; color: #2d3748; cursor: pointer; outline: none;
            ">
              <option value="Available" ${t===`Available`?`selected`:``}>Available</option>
              <option value="Pending Approval" ${t===`Pending Approval`?`selected`:``}>Pending Approval</option>
              <option value="Booked" ${t===`Booked`?`selected`:``}>Booked</option>
              <option value="Sold" ${t===`Sold`?`selected`:``}>Sold</option>
              <option value="Rented" ${t===`Rented`?`selected`:``}>Rented</option>
              <option value="Inactive" ${t===`Inactive`?`selected`:``}>Inactive</option>
            </select>
          </div>

          <!-- Icon & Approval Action Buttons -->
          <div style="display: flex; align-items: center; gap: 6px;">
            ${n===`Pending Approval`||t===`Pending Approval`?`
              <button class="quick-approve-prop-btn" data-id="${e.id}" title="Approve & Publish Live" style="
                padding: 6px 10px; border-radius: 8px; border: none; background: #38A169;
                color: #ffffff; font-weight: 700; font-size: 0.78rem; display: flex; align-items: center; gap: 4px; cursor: pointer;
              ">
                <i class="ri-checkbox-circle-fill"></i> Approve
              </button>
            `:``}

            <button class="view-website-prop-btn" data-id="${e.id}" title="Preview property details" style="
              width: 32px; height: 32px; border-radius: 8px; border: 1px solid #e2e8f0; background: #ffffff;
              color: #718096; display: flex; align-items: center; justify-content: center; cursor: pointer;
            ">
              <i class="ri-eye-line"></i>
            </button>

            <button class="edit-prop-btn" data-id="${e.id}" title="Edit property details" style="
              width: 32px; height: 32px; border-radius: 8px; border: 1px solid #ebf8ff; background: #ebf8ff;
              color: #3182ce; display: flex; align-items: center; justify-content: center; cursor: pointer;
            ">
              <i class="ri-pencil-line"></i>
            </button>

            <button class="delete-prop-btn" data-id="${e.id}" title="Delete property listing" style="
              width: 32px; height: 32px; border-radius: 8px; border: 1px solid #fff5f5; background: #fff5f5;
              color: #e53e3e; display: flex; align-items: center; justify-content: center; cursor: pointer;
            ">
              <i class="ri-delete-bin-line"></i>
            </button>
          </div>
        </div>

      </div>
    </div>
  `}function Ee(e){if(!e)return``;let t=Array.isArray(e.images)?e.images.filter(Boolean):[],n=[...new Set(t)],r=n.length>0?n:[`/default-property.jpg`],i=e.status||e.availability||`Available`,a=D(e.videoUrl);a.forEach((e,t)=>{let n=!1,i=e;if(e.includes(`youtube.com`)||e.includes(`youtu.be`)){let t=e.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([\w-]{11})/);t&&t[1]&&(i=`https://www.youtube.com/embed/${t[1]}?autoplay=0`,n=!0)}else(e.includes(`facebook.com`)||e.includes(`fb.watch`)||e.includes(`fb.com`))&&(i=`https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(e)}&show_text=0&width=560&autoplay=0`,n=!0);allMediaItems.push({type:`video`,url:i,rawUrl:e,isEmbeddable:n,title:a.length>1?`Property Video Tour ${t+1}`:`Property Video Tour`,thumb:r[0]})}),r.forEach((e,t)=>{allMediaItems.push({type:`image`,url:e,title:`Photo ${t+1}`,thumb:e})});let o=allMediaItems.length;K>=o&&(K=0);let s=allMediaItems[K]||allMediaItems[0],c=``;return c=s.type===`video`?s.isEmbeddable?`<iframe src="${s.url}" style="width: 100%; height: 100%; border: none;" allowfullscreen></iframe>`:`<video src="${s.rawUrl}" controls autoplay style="width: 100%; height: 100%; object-fit: contain; background: #000;"></video>`:`<img src="${s.url}" alt="${e.title}" style="width: 100%; height: 100%; object-fit: cover; transition: opacity 0.3s ease;" />`,`
    <div id="admin-prop-modal-overlay" style="
      position: fixed !important; top: 0 !important; left: 0 !important; right: 0 !important; bottom: 0 !important;
      width: 100vw !important; height: 100vh !important; z-index: 999999 !important;
      background: rgba(15, 23, 42, 0.82) !important; backdrop-filter: blur(8px) !important;
      display: flex !important; align-items: center !important; justify-content: center !important;
      padding: 24px !important; box-sizing: border-box !important; margin: 0 !important;
    ">
      <div style="
        background: #ffffff; width: 100%; max-width: 920px; max-height: 90vh; border-radius: 24px;
        overflow: hidden; box-shadow: 0 25px 60px rgba(0,0,0,0.5); border: 1px solid #e2e8f0; display: flex; flex-direction: column;
      ">
        
        <!-- Modal Fixed Top Bar -->
        <div style="padding: 18px 28px; background: #faf8f5; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; flex-shrink: 0;">
          <div>
            <span style="font-size: 0.75rem; font-weight: 800; color: #eb5e28; letter-spacing: 0.08em; text-transform: uppercase;">
              ADMIN PROPERTY PREVIEW • ID: ${e.id}
            </span>
            <h3 style="font-size: 1.3rem; font-weight: 800; color: #1a202c; margin: 2px 0 0 0;">${e.title}</h3>
          </div>

          <button id="close-admin-prop-preview-btn" style="background: #ffffff; border: 1px solid #cbd5e0; color: #4a5568; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; cursor: pointer; transition: transform 0.2s ease;">
            <i class="ri-close-line"></i>
          </button>
        </div>

        <!-- Scrollable Modal Body -->
        <div style="padding: 24px 28px; overflow-y: auto; display: flex; flex-direction: column; gap: 24px; flex: 1;">
          
          <!-- LUXURY HERO MEDIA VIEWPORT WITH OVERLAY ARROWS & CAROUSEL (REFERENCE IMAGE 2) -->
          <div style="width: 100%;">
            
            <!-- Main Hero Viewport (380px) -->
            <div style="width: 100%; height: 380px; border-radius: 16px; overflow: hidden; background: #f0f4f8; position: relative; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
              ${c}

              <!-- Overlay Top Media Counter Badge -->
              <div style="position: absolute; top: 16px; left: 16px; background: rgba(0,0,0,0.75); color: #ffffff; font-size: 0.8rem; font-weight: 700; padding: 6px 14px; border-radius: 20px; backdrop-filter: blur(4px); display: flex; align-items: center; gap: 6px; z-index: 10;">
                <i class="${s.type===`video`?`ri-video-line`:`ri-image-line`}" style="color: #eb5e28;"></i>
                <span>${s.type===`video`?`Video Tour`:`Photo ${K+ +!e.videoUrl} of ${o-+!!e.videoUrl}`}</span>
              </div>

              <!-- Overlay Status Badge Top Right -->
              <span style="position: absolute; top: 16px; right: 16px; background: #eb5e28; color: #fff; font-size: 0.78rem; font-weight: 800; padding: 6px 14px; border-radius: 20px; z-index: 10; box-shadow: 0 4px 12px rgba(0,0,0,0.25);">
                ${i.toUpperCase()}
              </span>

              <!-- Left & Right Carousel Arrow Overlay Buttons (Screen 2 Style) -->
              ${o>1?`
                <button id="prev-preview-media-btn" title="Previous photo/video" style="
                  position: absolute; left: 16px; top: 50%; transform: translateY(-50%); width: 44px; height: 44px; border-radius: 50%;
                  background: rgba(0,0,0,0.65); color: #ffffff; border: 1px solid rgba(255,255,255,0.3); font-size: 1.4rem;
                  display: flex; align-items: center; justify-content: center; cursor: pointer; backdrop-filter: blur(6px);
                  box-shadow: 0 4px 14px rgba(0,0,0,0.4); z-index: 10; transition: background 0.2s ease, transform 0.2s ease;
                ">
                  <i class="ri-arrow-left-s-line"></i>
                </button>

                <button id="next-preview-media-btn" title="Next photo/video" style="
                  position: absolute; right: 16px; top: 50%; transform: translateY(-50%); width: 44px; height: 44px; border-radius: 50%;
                  background: rgba(0,0,0,0.65); color: #ffffff; border: 1px solid rgba(255,255,255,0.3); font-size: 1.4rem;
                  display: flex; align-items: center; justify-content: center; cursor: pointer; backdrop-filter: blur(6px);
                  box-shadow: 0 4px 14px rgba(0,0,0,0.4); z-index: 10; transition: background 0.2s ease, transform 0.2s ease;
                ">
                  <i class="ri-arrow-right-s-line"></i>
                </button>
              `:``}
            </div>

            <!-- INTERACTIVE HORIZONTAL CAROUSEL THUMBNAIL BAR (REFERENCE IMAGE 2) -->
            ${o>1?`
              <div style="
                display: flex; gap: 12px; overflow-x: auto; padding: 14px 4px 6px 4px; scroll-behavior: smooth;
                margin-top: 12px; scrollbar-width: thin; scrollbar-color: #eb5e28 #edf2f7;
              ">
                ${allMediaItems.map((t,n)=>{let r=n===K;return`
                    <div class="preview-thumb-card" data-index="${n}" style="
                      position: relative; flex-shrink: 0; width: 110px; height: 74px; border-radius: 10px; overflow: hidden;
                      cursor: pointer; transition: all 0.25s ease; border: ${r?`3px solid #eb5e28`:`2px solid #e2e8f0`};
                      box-shadow: ${r?`0 4px 14px rgba(235,94,40,0.35)`:`0 2px 6px rgba(0,0,0,0.06)`};
                      opacity: ${r?`1`:`0.75`}; transform: ${r?`scale(1.02)`:`scale(1)`};
                    ">
                      <img src="${t.thumb}" style="width: 100%; height: 100%; object-fit: cover;" />
                      ${t.type===`video`?`
                        <div style="position: absolute; inset: 0; background: rgba(0,0,0,0.45); display: flex; align-items: center; justify-content: center; color: #fff; font-size: 1.5rem;">
                          <i class="ri-play-circle-fill" style="color: #eb5e28;"></i>
                        </div>
                      `:``}
                      <div style="position: absolute; bottom: 4px; left: 4px; font-size: 0.65rem; background: rgba(0,0,0,0.7); color: #fff; padding: 1px 6px; border-radius: 4px; font-weight: 700;">
                        ${t.type===`video`?`Video`:`Photo ${n+ +!e.videoUrl}`}
                      </div>
                    </div>
                  `}).join(``)}
              </div>
            `:``}

          </div>

          <!-- Key Specs Grid -->
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; background: #faf8f5; padding: 20px; border-radius: 14px; border: 1px solid #e2e8f0;">
            <div>
              <span style="font-size: 0.75rem; font-weight: 800; color: #718096; display: block;">EXPECTED PRICE</span>
              <div style="font-size: 1.3rem; font-weight: 800; color: #eb5e28;">${e.priceFormatted||`₹ `+(e.price||0).toLocaleString(`en-IN`)}</div>
            </div>
            <div>
              <span style="font-size: 0.75rem; font-weight: 800; color: #718096; display: block;">TYPE & CATEGORY</span>
              <div style="font-size: 0.95rem; font-weight: 700; color: #1a202c;">${e.type||`Property`} • ${e.categoryRaw||`Sale`}</div>
            </div>
            <div>
              <span style="font-size: 0.75rem; font-weight: 800; color: #718096; display: block;">LOCATION / DISTRICT</span>
              <div style="font-size: 0.95rem; font-weight: 700; color: #1a202c;">${e.location||e.district}</div>
            </div>
            <div>
              <span style="font-size: 0.75rem; font-weight: 800; color: #718096; display: block;">AREA SIZE</span>
              <div style="font-size: 0.95rem; font-weight: 700; color: #1a202c;">${e.size||`N/A`}</div>
            </div>
            ${e.bedrooms?`
              <div>
                <span style="font-size: 0.75rem; font-weight: 800; color: #718096; display: block;">BEDROOMS / BATHROOMS</span>
                <div style="font-size: 0.95rem; font-weight: 700; color: #1a202c;">${e.bedrooms} Bed • ${e.bathrooms||0} Bath</div>
              </div>
            `:``}
            ${e.floor?`
              <div>
                <span style="font-size: 0.75rem; font-weight: 800; color: #718096; display: block;">FLOOR NUMBER</span>
                <div style="font-size: 0.95rem; font-weight: 700; color: #1a202c;">${e.floor}</div>
              </div>
            `:``}
            <div>
              <span style="font-size: 0.75rem; font-weight: 800; color: #718096; display: block;">FURNISHING STATUS</span>
              <div style="font-size: 0.95rem; font-weight: 700; color: #1a202c;">${e.furnishing||`Not specified`}</div>
            </div>
          </div>

          <!-- Owner Information Box -->
          <div style="background: #FFF; border: 1px solid #E2E8F0; padding: 20px; border-radius: 14px;">
            <h4 style="font-size: 0.85rem; font-weight: 800; color: #4A5568; text-transform: uppercase; margin-bottom: 12px;">OWNER & CONTACT DETAILS</h4>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 14px; font-size: 0.9rem;">
              <div><strong>Owner Name:</strong> ${e.ownerName||`Thanjai Property Owner`}</div>
              <div><strong>Contact Phone:</strong> ${e.ownerPhone||`+91 95857 77772`}</div>
              <div><strong>Listed By:</strong> ${e.listedBy||`Aishwarya Raman`}</div>
              <div><strong>Patta Verification:</strong> <span style="color: #38A169; font-weight: 700;">Verified Legal Title</span></div>
            </div>
          </div>

          <!-- Detailed Description & Features -->
          <div>
            <h4 style="font-size: 0.85rem; font-weight: 800; color: #4A5568; text-transform: uppercase; margin-bottom: 8px;">PROPERTY DESCRIPTION</h4>
            <p style="font-size: 0.92rem; color: #4A5568; line-height: 1.6;">${e.description||`${e.title} located at ${e.location}.`}</p>
          </div>

          <!-- Features List -->
          <div>
            <h4 style="font-size: 0.85rem; font-weight: 800; color: #4A5568; text-transform: uppercase; margin-bottom: 10px;">AMENITIES & HIGHLIGHTS</h4>
            <div style="display: flex; gap: 8px; flex-wrap: wrap;">
              ${(e.features||[`Patta Title Verified`,`24/7 Security`]).map(e=>`
                <span style="background: #EDF2F7; color: #2D3748; font-size: 0.82rem; font-weight: 700; padding: 6px 12px; border-radius: 20px; display: inline-flex; align-items: center; gap: 4px;">
                  <i class="ri-checkbox-circle-fill" style="color: #eb5e28;"></i> ${e}
                </span>
              `).join(``)}
            </div>
          </div>

        </div>

        <!-- Modal Fixed Bottom Action Bar -->
        <div style="padding: 18px 28px; background: #faf8f5; border-top: 1px solid #e2e8f0; display: flex; justify-content: flex-end; gap: 12px; flex-shrink: 0; flex-wrap: wrap;">
          <button id="modal-share-wa-btn" data-id="${e.id}" style="background: #25D366; color: #fff; border: none; padding: 10px 24px; border-radius: 10px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 6px; box-shadow: 0 4px 12px rgba(37, 211, 102, 0.2);">
            <i class="ri-whatsapp-line"></i> Share via WhatsApp
          </button>
          <button id="modal-edit-prop-btn" data-id="${e.id}" style="background: #3182CE; color: #fff; border: none; padding: 10px 24px; border-radius: 10px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 6px;">
            <i class="ri-pencil-line"></i> Edit Property Details
          </button>
          <button id="modal-close-prop-btn" style="background: #ffffff; border: 1px solid #cbd5e0; color: #4a5568; padding: 10px 24px; border-radius: 10px; font-weight: 700; cursor: pointer;">
            Close Preview
          </button>
        </div>

        </div>

        <!-- WhatsApp Share Lead Selector Overlay (Hidden by default) -->
        <div id="wa-share-lead-overlay" style="display: none; position: absolute; inset: 0; background: rgba(255,255,255,0.95); z-index: 100; flex-direction: column; align-items: center; justify-content: center; padding: 32px; text-align: center; backdrop-filter: blur(4px); border-radius: 20px;">
          <div style="background: #fff; padding: 24px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); width: 100%; max-width: 400px; border: 1px solid #e2e8f0;">
            <i class="ri-whatsapp-line" style="font-size: 2.5rem; color: #25D366; margin-bottom: 12px; display: block;"></i>
            <h3 style="margin: 0 0 8px 0; font-size: 1.2rem; color: #1a202c;">Share via CRM</h3>
            <p style="margin: 0 0 20px 0; font-size: 0.9rem; color: #4a5568;">Select a lead to send this property directly via WhatsApp.</p>
            
            <select id="wa-share-lead-select" style="width: 100%; padding: 12px; border: 1px solid #cbd5e0; border-radius: 8px; margin-bottom: 16px; font-size: 0.95rem; outline: none;"></select>
            
            <div style="display: flex; gap: 12px;">
              <button id="wa-share-cancel-btn" style="flex: 1; padding: 10px; background: #edf2f7; color: #4a5568; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">Cancel</button>
              <button id="wa-share-confirm-btn" style="flex: 1; padding: 10px; background: #25D366; color: #fff; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px;">
                <i class="ri-send-plane-fill"></i> Send
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  `}function De(e){let t=!!e;t&&e?.images?q=[...e.images]:t||(q=[]);let n=e?.type||``,r=n.toLowerCase(),i=[`house`,`villa`,`apartment`,`home`,`flat`,`duplex`,`townhouse`,`penthouse`,`building`,`room`].some(e=>r.includes(e))||n===`Villa`;return`
    <div class="view-enter full-page-property-form-container" style="padding-bottom: 60px;">
      
      <!-- Form Navigation Header Bar -->
      <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px;">
        <button id="back-to-props-list-btn" style="
          display: inline-flex; align-items: center; gap: 8px; padding: 10px 18px; border-radius: 10px;
          background: #ffffff; border: 1px solid #cbd5e0; color: #2d3748; font-weight: 600; font-size: 0.9rem; cursor: pointer;
        ">
          <i class="ri-arrow-left-line"></i>
          <span>Back to Properties Inventory</span>
        </button>

        <span style="font-size: 0.85rem; color: #718096; font-weight: 600;">
          ${t?`Editing Property ID: ${e.id}`:`Creating New Property Listing`}
        </span>
      </div>

      <!-- Main Form Container -->
      <div style="background: #ffffff; border-radius: 20px; border: 1px solid #e2e8f0; box-shadow: 0 6px 24px rgba(0,0,0,0.04); overflow: hidden;">
        
        <!-- Header Title Banner -->
        <div style="padding: 24px 32px; background: #faf8f5; border-bottom: 1px solid #e2e8f0;">
          <span style="font-size: 0.75rem; font-weight: 800; text-transform: uppercase; color: var(--color-orange, #eb5e28); letter-spacing: 0.08em;">
            PROPERTIES INVENTORY FORM
          </span>
          <h2 style="font-size: 1.6rem; font-weight: 700; color: #1a1a1a; margin: 4px 0 0 0;">
            ${t?`Edit Property (${e.id})`:`Add Property`}
          </h2>
          <p style="font-size: 0.88rem; color: #718096; margin: 4px 0 0 0;">
            ${t?`Update property details, photos, video, and map location below`:`New listing — enter title, category, price, photos, and location details`}
          </p>
        </div>

        <!-- Inline Form -->
        <form id="prop-admin-form" style="padding: 32px; display: flex; flex-direction: column; gap: 32px;">
          
          <!-- SECTION 1: BASICS -->
          <div>
            <h4 style="font-size: 0.85rem; font-weight: 800; text-transform: uppercase; color: #4a5568; letter-spacing: 0.08em; margin-bottom: 18px;">
              BASICS
            </h4>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 18px;">
              <div style="grid-column: span 2;">
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Title *</label>
                <input type="text" id="form-prop-title" required value="${t&&e?.title||``}" placeholder="e.g. Premium Villa in Anna Nagar" style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; box-sizing: border-box;" />
              </div>

              <!-- Type Text Input -->
              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Type (Text Input) *</label>
                <input type="text" id="form-prop-type" required value="${t&&e?.type||``}" placeholder="e.g. Villa, House, Apartment, Land, Plot..." style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; box-sizing: border-box;" />
              </div>

              <!-- Category Dropdown -->
              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Category *</label>
                <select id="form-prop-category" required style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; background: #fff; box-sizing: border-box;">
                  <option value="Sale" ${t&&(e?.categoryRaw===`Sale`||e?.category===`Sale`||e?.purpose===`buy`)?`selected`:``}>Sale</option>
                  <option value="Rent" ${t&&(e?.categoryRaw===`Rent`||e?.category===`Rent`||e?.purpose===`rent`)?`selected`:``}>Rent</option>
                  <option value="Lease" ${t&&e?.categoryRaw===`Lease`?`selected`:``}>Lease</option>
                  <option value="Commercial" ${t&&e?.categoryRaw===`Commercial`?`selected`:``}>Commercial</option>
                  <option value="Residential" ${t&&e?.categoryRaw===`Residential`?`selected`:``}>Residential</option>
                </select>
              </div>

              <!-- Location -->
              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Location *</label>
                <input type="text" id="form-prop-location" required value="${t&&e?.location||``}" placeholder="e.g. Anna Nagar, Chennai" style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; box-sizing: border-box;" />
              </div>

              <!-- Facing -->
              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Facing</label>
                <input type="text" id="form-prop-facing" value="${t&&(e?.facing||e?.address)||``}" placeholder="e.g. North, East, South-East, North-Facing" style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; box-sizing: border-box;" />
              </div>

              <!-- Area (sqft) -->
              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Area (sqft)</label>
                <input type="text" id="form-prop-size" value="${t&&e?.size||``}" placeholder="e.g. 2400 or 2,400 sqft or 6.5 Acres" style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; box-sizing: border-box;" />
              </div>

              <!-- Approval Status (Optional) -->
              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Approval Status (Optional)</label>
                <input type="text" id="form-prop-approval" value="${t&&e?.approval||``}" placeholder="e.g. DTCP Approved, RERA Approved (Optional)" style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; box-sizing: border-box;" />
              </div>
            </div>

            <!-- DYNAMIC RESIDENTIAL STRUCTURE FIELDS -->
            <div id="residential-specs-section" style="
              margin-top: 20px; display: ${i?`grid`:`none`}; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px;
              background: #fdfbf7; padding: 20px; border-radius: 14px; border: 1px dashed #cbd5e0;
            ">
              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Bedrooms</label>
                <input type="number" id="form-prop-bedrooms" value="${t&&e?.bedrooms||``}" placeholder="e.g. 4" style="width: 100%; padding: 10px 14px; font-size: 0.9rem; border-radius: 8px; border: 1px solid #cbd5e0; box-sizing: border-box;" />
              </div>

              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Bathrooms</label>
                <input type="number" id="form-prop-bathrooms" value="${t&&e?.bathrooms||``}" placeholder="e.g. 4" style="width: 100%; padding: 10px 14px; font-size: 0.9rem; border-radius: 8px; border: 1px solid #cbd5e0; box-sizing: border-box;" />
              </div>

              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Floor Number (Optional)</label>
                <input type="text" id="form-prop-floor" value="${t&&e?.floor||``}" placeholder="e.g. 2nd Floor (Optional)" style="width: 100%; padding: 10px 14px; font-size: 0.9rem; border-radius: 8px; border: 1px solid #cbd5e0; box-sizing: border-box;" />
              </div>

              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Furnishing</label>
                <select id="form-prop-furnishing" style="width: 100%; padding: 10px 14px; font-size: 0.9rem; border-radius: 8px; border: 1px solid #cbd5e0; background: #fff; box-sizing: border-box;">
                  <option value="Not specified" ${t&&e?.furnishing===`Not specified`?`selected`:``}>Not specified</option>
                  <option value="Fully Furnished" ${t&&e?.furnishing===`Fully Furnished`?`selected`:``}>Fully Furnished</option>
                  <option value="Semi-Furnished" ${t&&e?.furnishing===`Semi-Furnished`?`selected`:``}>Semi-Furnished</option>
                  <option value="Unfurnished" ${t&&e?.furnishing===`Unfurnished`?`selected`:``}>Unfurnished</option>
                </select>
              </div>
            </div>

          </div>

          <!-- SECTION 2: PRICING & AVAILABILITY -->
          <div style="border-top: 1px solid #e2e8f0; padding-top: 24px;">
            <h4 style="font-size: 0.85rem; font-weight: 800; text-transform: uppercase; color: #4a5568; letter-spacing: 0.08em; margin-bottom: 18px;">
              PRICING & AVAILABILITY
            </h4>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 18px;">
              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Price *</label>
                <input type="number" id="form-prop-price-num" required value="${t&&e?.price||``}" placeholder="e.g. 13500000" style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; box-sizing: border-box;" />
              </div>

              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Currency</label>
                <select id="form-prop-currency" style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; background: #fff; box-sizing: border-box;">
                  <option value="INR" selected>INR</option>
                  <option value="USD">USD</option>
                </select>
              </div>

              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Availability *</label>
                <select id="form-prop-availability" required style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; background: #fff; box-sizing: border-box;">
                  <option value="Available" ${!t||e?.availability===`Available`||e?.status===`Available`?`selected`:``}>Available</option>
                  <option value="Booked" ${t&&(e?.availability===`Booked`||e?.status===`Booked`)?`selected`:``}>Booked</option>
                  <option value="Sold" ${t&&(e?.availability===`Sold`||e?.status===`Sold`)?`selected`:``}>Sold</option>
                  <option value="Rented" ${t&&(e?.availability===`Rented`||e?.status===`Rented`)?`selected`:``}>Rented</option>
                  <option value="Inactive" ${t&&(e?.availability===`Inactive`||e?.status===`Inactive`)?`selected`:``}>Inactive</option>
                </select>
              </div>
            </div>
          </div>

          <!-- SECTION 3: OWNER & CONTACT -->
          <div style="border-top: 1px solid #e2e8f0; padding-top: 24px;">
            <h4 style="font-size: 0.85rem; font-weight: 800; text-transform: uppercase; color: #4a5568; letter-spacing: 0.08em; margin-bottom: 18px;">
              OWNER & CONTACT
            </h4>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 18px;">
              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Listing Plan (Ad Type)</label>
                <select id="form-prop-ad-type" style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; box-sizing: border-box; background: #fff;">
                  <option value="free" ${t&&e?.adType===`paid`?``:`selected`}>🛡️ Free Ad (Thanjai Property Desk +91 84899 96852)</option>
                  <option value="paid" ${t&&e?.adType===`paid`?`selected`:``}>👑 Paid Ad (Direct Owner Contact & Call Enabled)</option>
                </select>
              </div>

              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Owner / Company Name</label>
                <input type="text" id="form-prop-owner-company" value="${t&&e?.ownerName||``}" placeholder="e.g. Arun / Thanjai Property" style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; box-sizing: border-box;" />
              </div>

              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Contact / Listed By</label>
                <input type="text" id="form-prop-contact-name" value="${t&&e?.listedBy||``}" placeholder="e.g. Aishwarya Raman" style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; box-sizing: border-box;" />
              </div>

              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Owner Direct Phone</label>
                <input type="tel" id="form-prop-contact-phone" value="${t&&e?.ownerPhone||``}" placeholder="10-digit number" maxlength="10" pattern="[0-9]{10}" oninput="this.value = this.value.replace(/[^0-9]/g, '')" style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; box-sizing: border-box;" />
              </div>
            </div>
          </div>

          <!-- SECTION 4: DETAILS -->
          <div style="border-top: 1px solid #e2e8f0; padding-top: 24px;">
            <h4 style="font-size: 0.85rem; font-weight: 800; text-transform: uppercase; color: #4a5568; letter-spacing: 0.08em; margin-bottom: 18px;">
              DETAILS
            </h4>

            <div style="display: flex; flex-direction: column; gap: 18px;">
              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Amenities (comma separated)</label>
                <input type="text" id="form-prop-features" value="${t&&e?.features?e.features.join(`, `):``}" placeholder="e.g. Pool, Gym, Parking, Clear Patta Title" style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; box-sizing: border-box;" />
              </div>

              <div>
                <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Description</label>
                <textarea id="form-prop-desc" rows="4" style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; box-sizing: border-box;" placeholder="Enter detailed property description...">${t&&e?.description||``}</textarea>
              </div>
            </div>
          </div>

          <!-- SECTION 5: MEDIA & LOCATION -->
          <div style="border-top: 1px solid #e2e8f0; padding-top: 24px;">
            <h4 style="font-size: 0.85rem; font-weight: 800; text-transform: uppercase; color: #4a5568; letter-spacing: 0.08em; margin-bottom: 18px;">
              MEDIA & LOCATION
            </h4>

            <div style="display: flex; flex-direction: column; gap: 20px;">
              
              <!-- Multiple Video Links Section -->
              <div style="background: #faf8f5; border: 1px solid #e2e8f0; border-radius: 12px; padding: 18px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; flex-wrap: wrap; gap: 8px;">
                  <div>
                    <label style="font-size: 0.85rem; font-weight: 800; color: #2d3748; display: block;">YouTube & Facebook Video Links</label>
                    <span style="font-size: 0.78rem; color: #718096;">Add one or multiple video links (YouTube, Facebook Video, Vimeo, etc.)</span>
                  </div>
                  <button type="button" id="add-video-link-row-btn" style="
                    display: inline-flex; align-items: center; gap: 6px; padding: 6px 14px; border-radius: 8px;
                    background: #eb5e28; color: #ffffff; border: none; font-size: 0.82rem; font-weight: 700; cursor: pointer;
                  ">
                    <i class="ri-add-line"></i> Add Another Video Link
                  </button>
                </div>

                <div id="video-links-container" style="display: flex; flex-direction: column; gap: 10px;">
                  ${J.map((e,t)=>`
                    <div class="video-link-row" style="display: flex; gap: 8px; align-items: center;">
                      <input type="url" class="form-prop-videolink-input" value="${e||``}" placeholder="e.g. https://youtube.com/watch?v=... or https://facebook.com/.../videos/..." style="flex: 1; padding: 10px 14px; font-size: 0.9rem; border-radius: 8px; border: 1px solid #cbd5e0; background: #fff; box-sizing: border-box;" />
                      ${J.length>1?`
                        <button type="button" class="remove-video-link-row-btn" data-index="${t}" style="background: #fed7d7; color: #c53030; border: none; border-radius: 8px; padding: 10px 12px; cursor: pointer; font-size: 0.9rem;" title="Remove this video link">
                          <i class="ri-delete-bin-line"></i>
                        </button>
                      `:``}
                    </div>
                  `).join(``)}
                </div>
              </div>

              <!-- Upload Video Files Section -->
              <div style="background: #faf8f5; border: 1px solid #e2e8f0; border-radius: 12px; padding: 18px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; flex-wrap: wrap; gap: 8px;">
                  <div>
                    <label style="font-size: 0.85rem; font-weight: 800; color: #2d3748; display: block;">Upload Video Files (.mp4 / .mov)</label>
                    <span style="font-size: 0.78rem; color: #718096;">Upload one or multiple property tour video files</span>
                  </div>
                  <label style="
                    display: inline-flex; align-items: center; gap: 6px; padding: 8px 16px; border-radius: 8px;
                    background: #ffffff; border: 1px dashed #cbd5e0; color: #2d3748; font-weight: 700; font-size: 0.82rem; cursor: pointer;
                  ">
                    <i class="ri-video-upload-line" style="color: #eb5e28; font-size: 1.1rem;"></i>
                    <span>Browse Video Files</span>
                    <input type="file" id="form-prop-video-file-input" accept="video/*" multiple style="display: none;" />
                  </label>
                </div>
                
                <div id="video-files-preview-container" style="display: flex; flex-wrap: wrap; gap: 8px;">
                  ${xe.map((e,t)=>`
                    <span style="display: inline-flex; align-items: center; gap: 6px; background: #EDF2F7; border: 1px solid #CBD5E0; padding: 6px 12px; border-radius: 20px; font-size: 0.82rem; font-weight: 700; color: #2D3748;">
                      <i class="ri-movie-fill" style="color: #eb5e28;"></i>
                      <span>${e.name||`Video ${t+1}`}</span>
                      <button type="button" class="delete-uploaded-video-file-btn" data-index="${t}" style="background: none; border: none; color: #E53E3E; cursor: pointer; padding: 0; margin-left: 4px;" title="Remove video">
                        <i class="ri-close-circle-fill"></i>
                      </button>
                    </span>
                  `).join(``)}
                </div>
              </div>

              <!-- Coordinates Grid -->
              <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 18px;">
                <div>
                  <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Latitude</label>
                  <input type="text" id="form-prop-latitude" value="${t&&e?.latitude||``}" placeholder="e.g. 10.786999" style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; box-sizing: border-box;" />
                </div>

                <div>
                  <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Longitude</label>
                  <input type="text" id="form-prop-longitude" value="${t&&e?.longitude||``}" placeholder="e.g. 79.137827" style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; box-sizing: border-box;" />
                </div>
              </div>

              <!-- Location Buttons -->
              <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                <button type="button" id="use-my-location-btn" style="
                  display: inline-flex; align-items: center; gap: 8px; padding: 10px 18px; border-radius: 10px;
                  background: #ffffff; border: 1px solid #cbd5e0; color: #2d3748; font-weight: 600; font-size: 0.88rem; cursor: pointer;
                  box-shadow: 0 2px 6px rgba(0,0,0,0.04);
                ">
                  <i class="ri-map-pin-user-fill" style="color: var(--color-orange, #eb5e28); font-size: 1.1rem;"></i>
                  <span>Use my current location</span>
                </button>

                <button type="button" id="select-location-map-btn" style="
                  display: inline-flex; align-items: center; gap: 8px; padding: 10px 18px; border-radius: 10px;
                  background: #ffffff; border: 1px solid #cbd5e0; color: #2d3748; font-weight: 600; font-size: 0.88rem; cursor: pointer;
                  box-shadow: 0 2px 6px rgba(0,0,0,0.04);
                ">
                  <i class="ri-compass-3-fill" style="color: #3182ce; font-size: 1.1rem;"></i>
                  <span>Select Location on Interactive Map</span>
                </button>
              </div>

              <!-- Interactive Leaflet Map Widget Container -->
              <div id="map-picker-container" style="display: none; border-radius: 14px; overflow: hidden; border: 1px solid #cbd5e0; background: #fff; margin-top: 10px;">
                <div style="padding: 12px 18px; background: #faf8f5; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center;">
                  <span style="font-size: 0.85rem; font-weight: 700; color: #2d3748; display: flex; align-items: center; gap: 6px;">
                    <i class="ri-map-2-line" style="color: var(--color-orange, #eb5e28);"></i>
                    Click or drag marker pin to capture exact property location
                  </span>
                  <button type="button" id="close-map-picker-btn" style="background: none; border: none; font-size: 1rem; color: #a0aec0; cursor: pointer;">
                    <i class="ri-close-line"></i>
                  </button>
                </div>
                <div id="leaflet-interactive-map" style="width: 100%; height: 320px; z-index: 1;"></div>
              </div>

              <!-- Image URL & Gallery Uploader -->
              <div style="border-top: 1px solid #f0f4f8; padding-top: 18px; display: flex; flex-direction: column; gap: 14px;">
                <div>
                  <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Primary Image URL</label>
                  <input type="url" id="form-prop-img-main" value="${t&&e?.images&&e.images[0]?e.images[0]:``}" placeholder="https://images.unsplash.com/photo-..." style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #cbd5e0; box-sizing: border-box;" />
                </div>

                <div>
                  <label style="font-size: 0.82rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">Upload Gallery Photos</label>
                  <label style="
                    display: flex; align-items: center; justify-content: center; gap: 10px; padding: 16px; border-radius: 12px;
                    background: #FAF8F5; border: 2px dashed #cbd5e0; color: #4a5568; font-weight: 700; font-size: 0.9rem; cursor: pointer;
                  ">
                    <i class="ri-image-add-line" style="color: var(--color-orange, #eb5e28); font-size: 1.4rem;"></i>
                    <span>Click to Upload Property Images (.png / .jpg)</span>
                    <input type="file" id="form-prop-gallery-file-input" accept="image/*" multiple style="display: none;" />
                  </label>
                </div>

                <!-- Preview Grid for Uploaded Gallery Images -->
                <div id="uploaded-images-preview-grid" style="display: flex; gap: 14px; flex-wrap: wrap; margin-top: 8px;">
                  ${Oe()}
                </div>
              </div>

            </div>
          </div>

          <!-- SUBMIT BUTTON BAR -->
          <div style="border-top: 1px solid #e2e8f0; padding-top: 24px; display: flex; justify-content: flex-end; gap: 14px;">
            <button type="button" id="cancel-prop-form-btn" style="
              padding: 12px 24px; border-radius: 10px; background: #ffffff; border: 1px solid #cbd5e0;
              color: #4a5568; font-weight: 700; font-size: 0.92rem; cursor: pointer;
            ">
              Cancel
            </button>

            <button type="submit" id="save-prop-form-btn" style="
              padding: 12px 32px; border-radius: 10px; background: var(--color-orange, #eb5e28); border: none;
              color: #ffffff; font-weight: 700; font-size: 0.92rem; cursor: pointer; box-shadow: 0 4px 14px rgba(235,94,40,0.3);
            ">
              <i class="ri-save-line"></i> ${t?`Save Property`:`Create Property`}
            </button>
          </div>

        </form>
      </div>
    </div>
  `}function Oe(){return!q||q.length===0?``:q.map((e,t)=>`
    <div class="img-preview-thumb-item" style="
      position: relative; width: 130px; height: 105px; border-radius: 14px; overflow: hidden; border: 1px solid #cbd5e0; background: #111; flex-shrink: 0;
    ">
      <img src="${e}" style="width: 100%; height: 100%; object-fit: cover;" />
      
      <!-- Red Delete Button -->
      <button type="button" class="delete-uploaded-img-btn" data-index="${t}" title="Remove photo" style="
        position: absolute; top: 6px; right: 6px; width: 26px; height: 26px; border-radius: 50%;
        background: rgba(229, 62, 62, 0.9); color: #ffffff; border: none; font-size: 0.9rem;
        display: flex; align-items: center; justify-content: center; cursor: pointer; box-shadow: 0 2px 6px rgba(0,0,0,0.3);
      ">
        <i class="ri-close-line"></i>
      </button>
    </div>
  `).join(``)}function ke(e){return Array.isArray(e)?e.filter(e=>{if(!e)return!1;let t=ve?ve.toLowerCase().trim():``,n=t.replace(/[^a-z0-9]/gi,``),r=String(e.id||``).toLowerCase(),i=r.replace(/[^a-z0-9]/gi,``),a=t.length>0&&(r.includes(t)||n.length>0&&i.includes(n));if(!a&&(e.approvalStatus===`Pending Approval`||e.status===`Pending Approval`))return!1;if(ve){let n=(e.title||``).toLowerCase().includes(t),r=(e.location||``).toLowerCase().includes(t),i=(e.district||``).toLowerCase().includes(t),o=(e.address||``).toLowerCase().includes(t),s=(e.type||``).toLowerCase().includes(t),c=(e.ownerName||``).toLowerCase().includes(t)||(e.ownerPhone||``).includes(t),l=(e.status||e.availability||``).toLowerCase().includes(t);if(!a&&!n&&!r&&!i&&!o&&!s&&!c&&!l)return!1}if(z&&z!==`all`){let t=(e.type||``).toLowerCase(),n=(e.categoryLabel||``).toLowerCase(),r=(e.category||``).toLowerCase(),i=z.toLowerCase(),a=!1;if(a=i===`apartment`?t.includes(`apartment`)||n.includes(`apartment`)||r.includes(`apartment`):i===`villa`?t.includes(`villa`)||n.includes(`villa`)||r.includes(`villa`):i===`townhouse`?t.includes(`townhouse`)||n.includes(`townhouse`):i===`penthouse`?t.includes(`penthouse`)||n.includes(`penthouse`):i===`studio`?t.includes(`studio`)||n.includes(`studio`):i===`plot`?t.includes(`plot`)||t.includes(`land`)||n.includes(`plot`)||r.includes(`plot`)||r.includes(`agricultural`):i===`office`?t.includes(`office`)||n.includes(`office`)||r.includes(`commercial`):i===`retail`?t.includes(`retail`)||n.includes(`retail`):i===`warehouse`?t.includes(`warehouse`)||n.includes(`warehouse`):t.includes(i),!a)return!1}if(B&&B!==`all`){let t=(e.categoryRaw||e.category||``).toLowerCase(),n=(e.purpose||``).toLowerCase(),r=B.toLowerCase();if(r===`sale`&&t!==`sale`&&n!==`buy`||r===`rent`&&t!==`rent`&&n!==`rent`||r===`lease`&&t!==`lease`||r===`commercial`&&t!==`commercial`||r===`residential`&&t!==`residential`)return!1}if(V&&V!==`all`&&(e.status||e.availability||`Available`).toLowerCase()!==V.toLowerCase())return!1;if(H&&H!==`all`){let t=parseFloat(H);if((e.price||0)>t)return!1}return!0}):[]}function Ae(){let e=document.getElementById(`close-admin-prop-preview-btn`),t=document.getElementById(`modal-close-prop-btn`),n=document.getElementById(`modal-edit-prop-btn`),r=document.getElementById(`modal-share-wa-btn`),i=document.getElementById(`wa-share-lead-overlay`),a=document.getElementById(`wa-share-cancel-btn`),o=document.getElementById(`wa-share-confirm-btn`),s=document.getElementById(`wa-share-lead-select`),c=document.getElementById(`prev-preview-media-btn`),l=document.getElementById(`next-preview-media-btn`),u=()=>{G=null,K=0,document.getElementById(`admin-prop-modal-overlay`)?.remove(),X()};e?.addEventListener(`click`,u),t?.addEventListener(`click`,u),r?.addEventListener(`click`,()=>{let e=JSON.parse(localStorage.getItem(`thanjai_leads`))||[];s.innerHTML=e.map(e=>`<option value="${e.id}">${e.name} (${e.mobile||e.whatsapp||`No Phone`})</option>`).join(``),e.length===0?(s.innerHTML=`<option value="">No leads available</option>`,o.disabled=!0):o.disabled=!1,i.style.display=`flex`}),a?.addEventListener(`click`,()=>{i.style.display=`none`}),o?.addEventListener(`click`,async()=>{let e=s.value;if(!e)return;let t=r.dataset.id,n=k().find(e=>e.id===t);if(!n)return;let a=JSON.parse(localStorage.getItem(`thanjai_leads`))||[],c=a.find(t=>t.id===e);if(!c)return;let l=c.whatsapp||c.mobile;if(!l){alert(`This lead has no phone number.`);return}let u=l.replace(/\D/g,``);u.length===10&&(u=`91`+u);let d=localStorage.getItem(`thanjai_wa_provider`)||`aisensy`,f=d===`smartping`?`https://backend.api-wa.co/campaign/smartping/api/v2`:`https://backend.aisensy.com/campaign/t1/api/v2`;d===`smartping`&&!u.startsWith(`+`)&&(u=`+`+u);let p=localStorage.getItem(`thanjai_whatsapp_api_key`);if(!p){alert(`Please go to Settings > Integrations and paste your WhatsApp API Key first.`);return}let m=o.innerHTML;o.innerHTML=`<i class="ri-loader-4-line ri-spin"></i>`,o.disabled=!0;try{let e={apiKey:p,campaignName:`initial_contact_intro`,destination:u,userName:c.name||`Client`,templateParams:[c.name||`Client`,n.title,n.location,n.priceFormatted||n.price]},t=n.images&&n.images.length>0?n.images[0]:`https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80`;e.media={url:t,filename:`property.jpg`},e.mediaUrl=t;let r=await fetch(f,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(e)}),o=await r.json();if(!r.ok)throw Error(`[${d.toUpperCase()}] ${o.message||o.error||JSON.stringify(o)}`);c.timeline||=[],c.timeline.unshift({type:`whatsapp`,message:`WhatsApp sent: Property - ${n.title}`,author:localStorage.getItem(`thanjai_active_user`)?JSON.parse(localStorage.getItem(`thanjai_active_user`)).fullName:`System`,date:new Date().toISOString()}),localStorage.setItem(`thanjai_leads`,JSON.stringify(a)),window.dispatchEvent(new CustomEvent(`leadsUpdated`)),window.showToast&&window.showToast(`Property shared via WhatsApp successfully!`,`success`),i.style.display=`none`}catch(e){console.error(e),alert(`Failed to send WhatsApp message: `+e.message)}finally{o.innerHTML=m,o.disabled=!1}}),n?.addEventListener(`click`,()=>{let e=n.dataset.id;G=null,K=0,document.getElementById(`admin-prop-modal-overlay`)?.remove(),e&&(W=e,U=`form`,X())}),c?.addEventListener(`click`,e=>{e.stopPropagation();let t=k().find(e=>e.id===G),n=(t?.images?.length||1)+ +!!t?.videoUrl;K=(K-1+n)%n,X()}),l?.addEventListener(`click`,e=>{e.stopPropagation();let t=k().find(e=>e.id===G),n=(t?.images?.length||1)+ +!!t?.videoUrl;K=(K+1)%n,X()}),document.querySelectorAll(`.preview-thumb-card`).forEach(e=>{e.addEventListener(`click`,()=>{let t=parseInt(e.dataset.index,10);isNaN(t)||(K=t,X())})})}function je(){if(U===`form`){Me();return}G&&Ae(),document.getElementById(`props-search-input`)?.addEventListener(`input`,e=>{ve=e.target.value,X()}),document.getElementById(`props-type-filter`)?.addEventListener(`change`,e=>{z=e.target.value,X()}),document.getElementById(`props-category-filter`)?.addEventListener(`change`,e=>{B=e.target.value,X()}),document.getElementById(`props-status-filter`)?.addEventListener(`change`,e=>{V=e.target.value,X()}),document.getElementById(`props-maxprice-filter`)?.addEventListener(`change`,e=>{H=e.target.value,X()}),[document.getElementById(`open-add-property-form-btn`),document.getElementById(`empty-add-prop-btn`)].forEach(e=>{e?.addEventListener(`click`,()=>{W=null,G=null,K=0,q=[],formVideoFileUrl=``,U=`form`,X()})});let e=document.getElementById(`import-props-csv-btn`),t=document.getElementById(`import-props-csv-file`);e?.addEventListener(`click`,()=>{t?.click()}),t?.addEventListener(`change`,e=>{let t=e.target.files[0];if(t){let e=new FileReader;e.onload=e=>{let t=e.target.result.split(`
`).map(e=>e.trim()).filter(Boolean);if(t.length>1){let e=t[0].split(`,`).map(e=>e.replace(/^["']|["']$/g,``).trim().toLowerCase()),n=t=>{for(let n of t){let t=e.findIndex(e=>e.includes(n));if(t!==-1)return t}return-1},r=n([`title`,`property name`,`name`]),i=n([`type`,`property type`]),a=n([`category`]),o=n([`price`,`amount`,`cost`]),s=n([`location`,`area`,`corridor`]),c=n([`district`,`city`]),l=n([`address`,`street`]),u=n([`size`,`area size`,`sqft`]),d=n([`bedroom`,`beds`,`bhk`]),p=n([`bathroom`,`baths`]),m=n([`furnish`]),h=n([`status`,`availab`]),g=n([`owner name`,`owner`,`contact name`]),_=n([`owner phone`,`phone`,`mobile`]),v=n([`desc`,`about`,`details`]),y=0;for(let e=1;e<t.length;e++){let n=t[e].match(/(".*?"|[^",]+)(?=\s*,|\s*$)/g),f=n?n.map(e=>e.replace(/^"|"$/g,``).trim()):t[e].split(`,`).map(e=>e.replace(/^"|"$/g,``).trim()),b=(e,t=``)=>e!==-1&&f[e]!==void 0?f[e]:t,x=b(r===-1?0:r);if(x&&x.toLowerCase()!==`title`){let e=b(i===-1?1:i,`Villa`),t=b(a===-1?2:a,`villas`).toLowerCase(),n=parseFloat(b(o===-1?3:o,`5000000`).replace(/[^0-9.]/g,``))||5e6,r=b(s===-1?4:s,`Medical College Road, Thanjavur`),f=b(c===-1?5:c,`Thanjavur`),S=b(l===-1?6:l,r),C=b(u===-1?7:u,`2,400 Sq.Ft`),w=parseInt(b(d===-1?8:d,``))||null,T=parseInt(b(p===-1?9:p,``))||null,E=b(m===-1?10:m,`Unfurnished`),D=b(h===-1?11:h,`Available`),O=b(g===-1?12:g,`Owner`),k=b(_===-1?13:_,`8489996852`),A=b(v===-1?14:v,`Verified property in ${r}`);j({title:x,type:e,category:t.includes(`villa`)?`villas`:t.includes(`house`)?`houses`:t.includes(`apart`)?`apartments`:t.includes(`plot`)?`plots`:t.includes(`agri`)||t.includes(`farm`)?`agricultural`:t.includes(`comm`)?`commercial`:`villas`,categoryRaw:t,price:n,location:r,district:f,address:S,size:C,bedrooms:w,bathrooms:T,furnishing:E,status:D,availability:D,approvalStatus:`Approved`,ownerName:O,ownerPhone:k,description:A}),y++}}x({action:`IMPORT_PROPERTIES_CSV`,details:`Imported ${y} properties from CSV file.`}),f(`Successfully imported ${y} property listings!`,`ri-upload-cloud-line`),X()}},e.readAsText(t)}}),document.getElementById(`export-props-csv-btn`)?.addEventListener(`click`,Re),document.getElementById(`download-sample-csv-btn`)?.addEventListener(`click`,ze),document.querySelectorAll(`.edit-prop-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.id;t&&(G=null,K=0,W=t,U=`form`,X())})}),document.querySelectorAll(`.view-website-prop-btn`).forEach(e=>{e.setAttribute(`title`,`Preview property details`),e.addEventListener(`click`,()=>{let t=e.dataset.id;t&&(G=t,K=0,X())})}),document.querySelectorAll(`.delete-prop-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.id;Be(t,k().find(e=>e.id===t)?.title||``,()=>{G===t&&(G=null),K=0,A(t),f(`Property ${t} deleted from inventory.`,`ri-delete-bin-line`),X()})})}),document.querySelectorAll(`.quick-approve-prop-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.stopPropagation();let n=e.dataset.id;n&&(E(n,{status:`Available`,availability:`Available`,approvalStatus:`Approved`}),f(`Property ${n} approved & published live to website!`,`ri-checkbox-circle-fill`),X())})}),document.querySelectorAll(`.quick-status-select`).forEach(e=>{e.addEventListener(`change`,t=>{let n=e.dataset.id,r=t.target.value;n&&r&&(r===`Available`?(E(n,{status:`Available`,availability:`Available`,approvalStatus:`Approved`}),f(`Property ${n} approved & published live!`,`ri-checkbox-circle-fill`)):r===`Pending Approval`?(E(n,{status:`Pending Approval`,availability:`Pending Approval`,approvalStatus:`Pending Approval`}),f(`Property ${n} set to Pending Approval.`,`ri-time-line`)):(E(n,{status:r,availability:r}),f(`Property ${n} status updated to ${r}`,`ri-checkbox-circle-fill`)),X())})}),document.querySelectorAll(`.quick-adtype-select`).forEach(e=>{e.addEventListener(`change`,t=>{let n=e.dataset.id,r=t.target.value;n&&r&&(E(n,{adType:r}),r===`paid`?f(`Property ${n} updated to Paid Ad! Direct Owner details & call links enabled.`,`ri-vip-crown-fill`):f(`Property ${n} updated to Free Ad (Thanjai Property Desk +91 84899 96852).`,`ri-shield-user-fill`),X())})})}function Me(){[document.getElementById(`back-to-props-list-btn`),document.getElementById(`cancel-prop-form-btn`)].forEach(e=>{e?.addEventListener(`click`,()=>{U=`list`,X()})});let e=document.getElementById(`form-prop-type`),t=document.getElementById(`residential-specs-section`);e?.addEventListener(`input`,()=>{let n=(e.value||``).toLowerCase().trim(),r=[`house`,`villa`,`apartment`,`home`,`flat`,`duplex`,`townhouse`,`penthouse`,`building`,`room`,`bhk`,`residence`,`cottage`,`bungalow`,`rowhouse`,`manor`,`studio`].some(e=>n.includes(e));t&&(t.style.display=r?`grid`:`none`)}),document.getElementById(`use-my-location-btn`)?.addEventListener(`click`,()=>{`geolocation`in navigator?(f(`Fetching current GPS coordinates...`,`ri-compass-line`),navigator.geolocation.getCurrentPosition(e=>{let t=e.coords.latitude.toFixed(6),n=e.coords.longitude.toFixed(6),r=document.getElementById(`form-prop-latitude`),i=document.getElementById(`form-prop-longitude`);r&&(r.value=t),i&&(i.value=n),Y&&Se&&(Se.setLatLng([t,n]),Y.setView([t,n],15)),f(`GPS set to Lat: ${t}, Lng: ${n}`,`ri-map-pin-user-fill`)},e=>{console.warn(`Geolocation error:`,e),f(`Could not fetch GPS location. Please check browser permissions.`,`ri-error-warning-line`)},{enableHighAccuracy:!0,timeout:1e4,maximumAge:0})):f(`Geolocation is not supported by your browser.`,`ri-error-warning-line`)});let n=document.getElementById(`select-location-map-btn`),r=document.getElementById(`map-picker-container`),i=document.getElementById(`close-map-picker-btn`);n?.addEventListener(`click`,()=>{if(!r)return;let e=r.style.display===`none`;r.style.display=e?`block`:`none`,e&&Pe()}),i?.addEventListener(`click`,()=>{r&&(r.style.display=`none`)});let a=document.getElementById(`form-prop-img-main`);a?.addEventListener(`input`,()=>{let e=a.value.trim();e&&!q.includes(e)&&(q.unshift(e),q=[...new Set(q)],Ie())}),document.getElementById(`form-prop-gallery-file-input`)?.addEventListener(`change`,async e=>{let t=Array.from(e.target.files);if(!t||t.length===0)return;f(`Compressing ${t.length} photo(s)...`,`ri-loader-4-line`);let n=0;for(let e of t){let t=await Ce(e,1e3,800,.75);t&&(q.push(t),n++)}q=[...new Set(q)],n>0&&(Ie(),f(`${n} HD photo(s) added to property!`,`ri-image-add-line`))});let o=document.getElementById(`add-video-link-row-btn`),s=document.getElementById(`video-links-container`);function c(){s&&(s.innerHTML=J.map((e,t)=>`
      <div class="video-link-row" style="display: flex; gap: 8px; align-items: center;">
        <input type="url" class="form-prop-videolink-input" data-index="${t}" value="${e||``}" placeholder="e.g. https://youtube.com/watch?v=... or https://facebook.com/.../videos/..." style="flex: 1; padding: 10px 14px; font-size: 0.9rem; border-radius: 8px; border: 1px solid #cbd5e0; background: #fff; box-sizing: border-box;" />
        ${J.length>1?`
          <button type="button" class="remove-video-link-row-btn" data-index="${t}" style="background: #fed7d7; color: #c53030; border: none; border-radius: 8px; padding: 10px 12px; cursor: pointer; font-size: 0.9rem;" title="Remove this video link">
            <i class="ri-delete-bin-line"></i>
          </button>
        `:``}
      </div>
    `).join(``),s.querySelectorAll(`.remove-video-link-row-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=parseInt(e.dataset.index,10);!isNaN(t)&&J.length>1&&(J.splice(t,1),c())})}),s.querySelectorAll(`.form-prop-videolink-input`).forEach(e=>{e.addEventListener(`input`,()=>{let t=parseInt(e.dataset.index,10);isNaN(t)||(J[t]=e.value)})}))}o?.addEventListener(`click`,()=>{J.push(``),c()}),c();let l=document.getElementById(`form-prop-video-file-input`),u=document.getElementById(`video-files-preview-container`);function d(){u&&(u.innerHTML=xe.map((e,t)=>`
      <span style="display: inline-flex; align-items: center; gap: 6px; background: #EDF2F7; border: 1px solid #CBD5E0; padding: 6px 12px; border-radius: 20px; font-size: 0.82rem; font-weight: 700; color: #2D3748;">
        <i class="ri-movie-fill" style="color: #eb5e28;"></i>
        <span>${e.name||`Video ${t+1}`}</span>
        <button type="button" class="delete-uploaded-video-file-btn" data-index="${t}" style="background: none; border: none; color: #E53E3E; cursor: pointer; padding: 0; margin-left: 4px;" title="Remove video">
          <i class="ri-close-circle-fill"></i>
        </button>
      </span>
    `).join(``),u.querySelectorAll(`.delete-uploaded-video-file-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=parseInt(e.dataset.index,10);isNaN(t)||(xe.splice(t,1),d(),f(`Video removed`,`ri-delete-bin-line`))})}))}l?.addEventListener(`change`,e=>{let t=Array.from(e.target.files);!t||t.length===0||(f(`Loading ${t.length} video(s)...`,`ri-loader-4-line`),t.forEach(e=>{let t=new FileReader;t.onload=t=>{xe.push({name:e.name,dataUrl:t.target.result}),d(),f(`Video "${e.name}" attached!`,`ri-video-upload-line`)},t.readAsDataURL(e)}))}),d(),Le(),document.getElementById(`prop-admin-form`)?.addEventListener(`submit`,e=>{e.preventDefault();let t=document.getElementById(`form-prop-title`)?.value.trim(),n=document.getElementById(`form-prop-type`)?.value,r=document.getElementById(`form-prop-category`)?.value,i=document.getElementById(`form-prop-price`)?.value,a=document.getElementById(`form-prop-location`)?.value.trim(),o=document.getElementById(`form-prop-facing`)?.value.trim(),s=document.getElementById(`form-prop-size`)?.value.trim(),c=document.getElementById(`form-prop-bedrooms`)?.value,l=document.getElementById(`form-prop-bathrooms`)?.value,u=document.getElementById(`form-prop-furnishing`)?.value,d=document.getElementById(`form-prop-status`)?.value,p=document.getElementById(`form-prop-approval`)?.value.trim(),m=document.getElementById(`form-prop-features`)?.value.trim(),h=document.getElementById(`form-prop-desc`)?.value.trim(),g=Array.from(document.querySelectorAll(`.form-prop-videolink-input`)).map(e=>e.value.trim()).filter(Boolean),_=xe.map(e=>e.dataUrl).filter(Boolean),v=[...new Set([...g,..._])],y=v.length===1?v[0]:v.length>1?JSON.stringify(v):``,b=document.getElementById(`form-prop-latitude`)?.value.trim(),x=document.getElementById(`form-prop-longitude`)?.value.trim(),S=b?String(Ne(b,b)):``,C=x?String(Ne(x,x)):``,T=document.getElementById(`form-prop-img-main`)?.value.trim(),D=[...q];T&&!D.includes(T)&&D.unshift(T),D=[...new Set(D.filter(Boolean))],D.length===0&&D.push(`/default-property.jpg`);let O=m?m.split(`,`).map(e=>e.trim()).filter(Boolean):[],k=a||``,A=`Thanjavur`,ee=[`Thanjavur`,`Trichy`,`Tiruchirappalli`,`Madurai`,`Chennai`,`Coimbatore`,`Kumbakonam`,`Pudukkottai`,`Tiruvarur`,`Nagapattinam`,`Salem`,`Dindigul`,`Karur`,`Perambalur`,`Ariyalur`,`Mayiladuthurai`];if(k.includes(`,`)){let e=k.split(`,`).map(e=>e.trim());A=ee.find(t=>e.some(e=>e.toLowerCase()===t.toLowerCase()))||e[e.length-1]||`Thanjavur`}else A=ee.find(e=>k.toLowerCase().includes(e.toLowerCase()))||`Thanjavur`;let te=(n||``).toLowerCase(),ne=[`house`,`villa`,`apartment`,`home`,`flat`,`duplex`,`townhouse`,`penthouse`,`building`,`room`].some(e=>te.includes(e)),re={title:t||`Untitled Property`,type:n||`Villa`,category:r||`Sale`,price:parseFloat(i)||0,location:a||`Thanjavur`,district:A,facing:o||``,size:s?w(s):``,bedrooms:ne&&c?parseInt(c,10):null,bathrooms:ne&&l?parseInt(l,10):null,furnishing:ne&&u||`Not specified`,status:d||`Available`,availability:d||`Available`,approval:p||``,latitude:S,longitude:C,videoUrl:y,images:D,features:O,description:h||``,ownerName:document.getElementById(`form-prop-owner-name`)?.value.trim()||`Aishwarya Raman`,ownerPhone:document.getElementById(`form-prop-owner-phone`)?.value.trim()||`8489996852`,listedBy:`Aishwarya Raman`};W?(E(W,re),f(`Property ${W} updated successfully!`,`ri-checkbox-circle-fill`)):(j(re),f(`New property listing published!`,`ri-checkbox-circle-fill`)),U=`list`,W=null,q=[],J=[``],xe=[],X()})}function Ne(e,t){if(!e||typeof e!=`string`)return t;let n=e.trim();if(!n)return t;let r=parseFloat(n);if(!isNaN(r)&&!n.includes(`°`)&&!n.includes(`'`)&&!n.includes(`"`))return r;let i=n.match(/(\d+)[°\s]+(\d+)[`'\s]+([\d.]+)(?:["\s]*([NSEWnsew])?)?/);if(i){let e=parseFloat(i[1])||0,t=parseFloat(i[2])||0,n=parseFloat(i[3])||0,r=i[4]?i[4].toUpperCase():``,a=e+t/60+n/3600;return(r===`S`||r===`W`)&&(a=-a),parseFloat(a.toFixed(6))}return isNaN(r)?t:r}function Pe(){if(document.getElementById(`leaflet-interactive-map`)){if(window.L)Fe();else{let e=document.createElement(`link`);e.rel=`stylesheet`,e.href=`https://unpkg.com/leaflet@1.9.4/dist/leaflet.css`,document.head.appendChild(e);let t=document.createElement(`script`);t.src=`https://unpkg.com/leaflet@1.9.4/dist/leaflet.js`,t.onload=()=>Fe(),document.head.appendChild(t)}}}function Fe(){let e=document.getElementById(`form-prop-latitude`),t=document.getElementById(`form-prop-longitude`),n=Ne(e?.value,10.786999),r=Ne(t?.value,79.137827);Y&&=(Y.remove(),null),Y=L.map(`leaflet-interactive-map`).setView([n,r],14),L.tileLayer(`https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png`,{maxZoom:19,attribution:`© OpenStreetMap contributors`}).addTo(Y),Se=L.marker([n,r],{draggable:!0}).addTo(Y),Se.on(`dragend`,n=>{let r=n.target.getLatLng();e&&(e.value=r.lat.toFixed(6)),t&&(t.value=r.lng.toFixed(6)),f(`Pinpoint updated: ${r.lat.toFixed(6)}, ${r.lng.toFixed(6)}`,`ri-map-pin-2-fill`)}),Y.on(`click`,n=>{let{lat:r,lng:i}=n.latlng;Se.setLatLng([r,i]),e&&(e.value=r.toFixed(6)),t&&(t.value=i.toFixed(6)),f(`Pinpoint moved to clicked location: ${r.toFixed(6)}, ${i.toFixed(6)}`,`ri-map-pin-2-fill`)}),setTimeout(()=>{Y&&Y.invalidateSize()},200)}function Ie(){let e=document.getElementById(`uploaded-images-preview-grid`);e&&(e.innerHTML=Oe(),Le())}function Le(){document.querySelectorAll(`.delete-uploaded-img-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault();let n=parseInt(e.dataset.index,10);!isNaN(n)&&n>=0&&n<q.length&&(q.splice(n,1),Ie(),f(`Photo removed from upload queue`,`ri-delete-bin-line`))})})}function Re(){let e=ke(k());if(e.length===0){f(`No properties available to export under current filters.`,`ri-error-warning-line`);return}let t=[[`Property ID`,`Title`,`Type`,`Category`,`Price (INR)`,`Location`,`District`,`Address`,`Area Size`,`Bedrooms`,`Bathrooms`,`Furnishing`,`Status`,`Owner Name`,`Owner Phone`,`Created At`].join(`,`)];e.forEach(e=>{let n=[`"${e.id||``}"`,`"${(e.title||``).replace(/"/g,`""`)}"`,`"${e.type||``}"`,`"${e.categoryRaw||e.category||``}"`,`"${e.price||0}"`,`"${(e.location||``).replace(/"/g,`""`)}"`,`"${(e.district||``).replace(/"/g,`""`)}"`,`"${(e.address||``).replace(/"/g,`""`)}"`,`"${(e.size||``).replace(/"/g,`""`)}"`,`"${e.bedrooms||``}"`,`"${e.bathrooms||``}"`,`"${e.furnishing||``}"`,`"${e.status||e.availability||``}"`,`"${(e.ownerName||``).replace(/"/g,`""`)}"`,`"${e.ownerPhone||``}"`,`"${e.createdAt||``}"`];t.push(n.join(`,`))});let n=t.join(`
`),r=new Blob([n],{type:`text/csv;charset=utf-8;`}),i=URL.createObjectURL(r),a=document.createElement(`a`);a.setAttribute(`href`,i),a.setAttribute(`download`,`Thanjai_Properties_Export_${new Date().toISOString().slice(0,10)}.csv`),document.body.appendChild(a),a.click(),document.body.removeChild(a),x({action:`EXPORT_PROPERTIES_CSV`,details:`Exported ${e.length} property listings matching current filters to CSV file.`}),f(`Exported ${e.length} filtered property records to CSV`,`ri-file-download-line`)}function ze(){let e=[[`Title`,`Type`,`Category`,`Price (INR)`,`Location`,`District`,`Address`,`Area Size`,`Bedrooms`,`Bathrooms`,`Furnishing`,`Status`,`Owner Name`,`Owner Phone`,`Description`].join(`,`),...[[`"4 BHK Luxury Courtyard Villa - Medical College Road"`,`"Villa"`,`"villas"`,`"13500000"`,`"Medical College Road, Thanjavur"`,`"Thanjavur"`,`"Plot 42, Green Avenue, Medical College Road"`,`"2,600 Sq.Ft"`,`"4"`,`"4"`,`"Fully Furnished"`,`"Available"`,`"R. Sundaram"`,`"9585777772"`,`"Brand new luxury courtyard villa with DTCP approval, modular kitchen, and private borewell."`],[`"DTCP Approved Corner Plot - Trichy Highway"`,`"Plot"`,`"plots"`,`"2800000"`,`"Trichy Road, Thanjavur"`,`"Thanjavur"`,`"Near New Bus Stand Bypass, Trichy Road"`,`"1,800 Sq.Ft"`,`""`,`""`,`""`,`"Available"`,`"K. Mohan"`,`"9842412345"`,`"Prime corner residential plot with 40ft blacktop road, clear Patta, and instant bank loan approval."`],[`"5 Acres Fertile Kaveri Delta Coconut Farmland"`,`"Other"`,`"agricultural"`,`"7500000"`,`"Pattukottai Bypass, Thanjavur"`,`"Thanjavur"`,`"Pattukkottai Main Road, Thanjavur District"`,`"5.0 Acres"`,`""`,`""`,`""`,`"Available"`,`"M. Radhakrishnan"`,`"9443198765"`,`"Fertile agricultural farmland with 350 yield coconut trees, Kaveri canal water connectivity, and EB service."`]].map(e=>e.join(`,`))].join(`
`),t=new Blob([e],{type:`text/csv;charset=utf-8;`}),n=URL.createObjectURL(t),r=document.createElement(`a`);r.setAttribute(`href`,n),r.setAttribute(`download`,`Thanjai_Properties_Sample_Template.csv`),document.body.appendChild(r),r.click(),document.body.removeChild(r),f(`Downloaded sample CSV template successfully!`,`ri-file-download-line`)}function X(){document.getElementById(`admin-prop-modal-overlay`)?.remove();let e=document.getElementById(`os-content`);if(e&&(e.innerHTML=we(),je(),G)){let e=k().find(e=>e.id===G);if(e){let t=document.createElement(`div`);t.innerHTML=Ee(e);let n=t.firstElementChild;n&&(document.body.appendChild(n),Ae())}}}function Be(e,t,n){document.getElementById(`admin-custom-confirm-overlay`)?.remove();let r=document.createElement(`div`);r.id=`admin-custom-confirm-overlay`,r.style.cssText=`
    position: fixed !important; top: 0 !important; left: 0 !important; right: 0 !important; bottom: 0 !important;
    width: 100vw !important; height: 100vh !important; z-index: 999999 !important;
    background: rgba(15, 23, 42, 0.75) !important; backdrop-filter: blur(6px) !important;
    display: flex !important; align-items: center !important; justify-content: center !important;
    padding: 20px !important; box-sizing: border-box !important; margin: 0 !important;
  `,r.innerHTML=`
    <div style="
      background: #ffffff; width: 100%; max-width: 440px; border-radius: 20px;
      padding: 32px 28px 24px; box-shadow: 0 20px 40px rgba(0,0,0,0.3); text-align: center;
      box-sizing: border-box; border: 1px solid #E2E8F0;
    ">
      <div style="
        width: 60px; height: 60px; border-radius: 50%; background: #FFF5F5;
        border: 2px solid #FED7D7; color: #E52E3D; display: flex; align-items: center;
        justify-content: center; font-size: 1.8rem; margin: 0 auto 20px;
      ">
        <i class="ri-delete-bin-line"></i>
      </div>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #1A202C; margin: 0 0 8px 0;">Delete Property Listing?</h3>
      
      <p style="font-size: 0.9rem; color: #718096; line-height: 1.5; margin: 0 0 20px 0;">
        Are you sure you want to permanently delete <strong style="color: #E52E3D;">${e}</strong> (${t||`this listing`})? This action cannot be undone.
      </p>

      <div style="display: flex; gap: 12px; justify-content: center;">
        <button id="cancel-admin-delete-btn" style="
          flex: 1; padding: 12px 18px; border-radius: 12px; border: 1px solid #CBD5E0;
          background: #EDF2F7; color: #4A5568; font-weight: 700; font-size: 0.9rem; cursor: pointer;
        ">Cancel</button>
        <button id="confirm-admin-delete-btn" style="
          flex: 1; padding: 12px 18px; border-radius: 12px; border: none;
          background: #E52E3D; color: #ffffff; font-weight: 700; font-size: 0.9rem; cursor: pointer;
          box-shadow: 0 4px 12px rgba(229, 46, 61, 0.3);
        ">Yes, Delete</button>
      </div>
    </div>
  `,document.body.appendChild(r);let i=()=>r.remove();document.getElementById(`cancel-admin-delete-btn`)?.addEventListener(`click`,i),document.getElementById(`confirm-admin-delete-btn`)?.addEventListener(`click`,()=>{i(),n()}),r.addEventListener(`click`,e=>{e.target===r&&i()})}function Ve(){return`
    <div class="view-enter">
      <div class="view-header-flex">
        <div>
          <h1 class="view-title">Site Visits Planner</h1>
          <p class="view-subtitle">Coordinate property tours and client meetings.</p>
        </div>
        <div class="header-actions-right">
          <button class="os-btn-primary"><i class="ri-add-line"></i> Schedule Visit</button>
        </div>
      </div>

      <div class="visits-layout">
        <!-- Calendar Side -->
        <div class="calendar-side">
          <div class="cal-card">
            <div class="cal-header">
              <button class="cal-nav" id="cal-prev-btn"><i class="ri-arrow-left-s-line"></i></button>
              <div class="cal-month" id="cal-month-display">August 2026</div>
              <button class="cal-nav" id="cal-next-btn"><i class="ri-arrow-right-s-line"></i></button>
            </div>
            <div class="cal-grid" id="cal-grid-container">
              <!-- Rendered by JS -->
            </div>
          </div>
        </div>

        <!-- Agenda Side -->
        <div class="agenda-side" id="agenda-side-container">
          <!-- Dynamic Content -->
        </div>
      </div>
    </div>

    <!-- Modals -->
    <div class="os-modal-overlay" id="site-visits-schedule-modal">
      <div class="os-modal-card" style="max-width: 450px;">
        <div class="os-modal-header">
          <h2>Schedule site visit</h2>
          <button class="os-modal-close" id="close-sv-modal"><i class="ri-close-line"></i></button>
        </div>
        <div class="os-modal-body">
          <div class="form-group" style="margin-bottom: 16px;">
            <label>Client name / Lead *</label>
            <input type="text" id="sv-client-name" class="os-input" placeholder="Search leads..." style="width: 100%;" />
          </div>
          <div class="form-group" style="margin-bottom: 16px;">
            <label>Property *</label>
            <input type="text" id="sv-property" class="os-input" placeholder="e.g. Premium Villa, Anna Nagar" style="width: 100%;" />
          </div>
          <div class="form-group">
            <label>Visit date & time *</label>
            <input type="datetime-local" id="sv-datetime" class="os-input" style="width: 100%;" />
          </div>
          <p style="font-size: 0.85rem; color: var(--os-gray-500); margin-top: 16px;">A confirmation WhatsApp will be sent to the client.</p>
        </div>
        <div class="os-modal-footer">
          <button class="os-btn-secondary" id="cancel-sv-modal">Cancel</button>
          <button class="os-btn-primary" id="confirm-sv-modal" style="background: #fdba74; border-color: #fdba74; color: #fff;">Confirm & send</button>
        </div>
      </div>
    </div>
    </div>
  `}async function He(){let e=[];try{let t=await o(`/site_visits`);t&&Array.isArray(t)&&(e=t.map(e=>{let t=new Date(e.visitDate),n=t.getHours(),r=t.getMinutes().toString().padStart(2,`0`),i=n>=12?`PM`:`AM`,a=n%12||12,o=[`Jan`,`Feb`,`Mar`,`Apr`,`May`,`Jun`,`Jul`,`Aug`,`Sep`,`Oct`,`Nov`,`Dec`],s=e.leadId,c=e.propertyId;try{if(e.notes){let t=JSON.parse(e.notes);s=t.clientName||s,c=t.property||c}}catch{}return{id:e.id,date:t.getDate().toString(),month:o[t.getMonth()],hours:a.toString().padStart(2,`0`),mins:r,ampm:i,clientName:s,phone:``,property:c,status:e.status}}))}catch(t){console.error(`API Error:`,t),e=JSON.parse(localStorage.getItem(`thanjai_visits`))||[]}let t=new Date,n=t.getMonth(),r=t.getFullYear(),i=t.getDate(),a=[`Jan`,`Feb`,`Mar`,`Apr`,`May`,`Jun`,`Jul`,`Aug`,`Sep`,`Oct`,`Nov`,`Dec`],s=[`January`,`February`,`March`,`April`,`May`,`June`,`July`,`August`,`September`,`October`,`November`,`December`],c=()=>{let e=document.getElementById(`cal-month-display`),t=document.getElementById(`cal-grid-container`);if(!e||!t)return;e.textContent=`${s[n]} ${r}`;let a=`
      <div class="cal-day-name">Su</div><div class="cal-day-name">Mo</div><div class="cal-day-name">Tu</div>
      <div class="cal-day-name">We</div><div class="cal-day-name">Th</div><div class="cal-day-name">Fr</div><div class="cal-day-name">Sa</div>
    `,o=new Date(r,n,1).getDay(),c=new Date(r,n+1,0).getDate(),l=new Date(r,n,0).getDate();for(let e=o-1;e>=0;e--)a+=`<div class="cal-day muted">${l-e}</div>`;for(let e=1;e<=c;e++)a+=`<div class="cal-day ${e===i?`active`:``}" data-day="${e}">${e}</div>`;let u=42-(o+c);for(let e=1;e<=u;e++)a+=`<div class="cal-day muted">${e}</div>`;t.innerHTML=a,t.querySelectorAll(`.cal-day:not(.muted)`).forEach(e=>{e.addEventListener(`click`,()=>{t.querySelectorAll(`.cal-day`).forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`),i=parseInt(e.dataset.day),m(i.toString())})}),p()},l=document.getElementById(`cal-prev-btn`),u=document.getElementById(`cal-next-btn`);l&&l.addEventListener(`click`,()=>{n--,n<0&&(n=11,r--),c(),m(i.toString())}),u&&u.addEventListener(`click`,()=>{n++,n>11&&(n=0,r++),c(),m(i.toString())});let d=document.getElementById(`agenda-side-container`),p=()=>{document.querySelectorAll(`.cal-day:not(.muted)`).forEach(t=>{let r=t.dataset.day,i=a[n];e.some(e=>parseInt(e.date)===parseInt(r)&&e.month===i)?t.classList.add(`has-event`):t.classList.remove(`has-event`)})},m=async t=>{if(!d)return;let r=a[n],i=e.filter(e=>parseInt(e.date)===parseInt(t)&&e.month===r),s=`<h2 class="agenda-title">Visits for <span>${t} ${r}</span></h2>`;i.length===0?s+=`<p style="color: var(--os-gray-500); padding: 20px 0;">No visits scheduled for this date.</p>`:i.forEach(e=>{s+=`
          <div class="visit-card hover-lift">
            <div class="v-time">
              <div class="v-hour">${e.hours}:${e.mins}</div>
              <div class="v-ampm">${e.ampm}</div>
            </div>
            <div class="v-details">
              <div class="v-client">
                <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(e.clientName)}&background=random" class="v-avatar" />
                <div>
                  <div class="v-name">${e.clientName}</div>
                  <div class="v-phone">${e.phone}</div>
                </div>
              </div>
              <div class="v-prop">
                <i class="ri-building-4-line"></i> ${e.property}
              </div>
            </div>
            <div class="v-actions">
              <button class="v-btn whatsapp"><i class="ri-whatsapp-line"></i> Message</button>
              <button class="v-btn map"><i class="ri-map-pin-line"></i> Directions</button>
              <button class="v-btn delete-btn" data-id="${e.id}" style="color: var(--os-error); border-color: #fee2e2; background: #fef2f2;"><i class="ri-delete-bin-line"></i> Delete</button>
            </div>
          </div>
        `}),d.innerHTML=s,d.querySelectorAll(`.v-btn.whatsapp`).forEach(e=>{e.addEventListener(`click`,()=>alert(`Opening WhatsApp...`))}),d.querySelectorAll(`.v-btn.map`).forEach(e=>{e.addEventListener(`click`,()=>window.open(`https://maps.google.com`,`_blank`))}),d.querySelectorAll(`.v-btn.delete-btn`).forEach(n=>{n.addEventListener(`click`,async n=>{let r=n.currentTarget.getAttribute(`data-id`);if(confirm(`Are you sure you want to delete this site visit?`))try{await o(`/site_visits/`+r,{method:`DELETE`}),e=e.filter(e=>e.id!=r),p(),m(t)}catch(e){console.error(`Failed to delete visit`,e),alert(`Failed to delete visit`)}})})};c(),m(i.toString());let h=document.querySelector(`.view-header-flex .os-btn-primary`),_=document.getElementById(`site-visits-schedule-modal`),v=document.getElementById(`close-sv-modal`),y=document.getElementById(`cancel-sv-modal`),b=document.getElementById(`confirm-sv-modal`);h&&_&&h.addEventListener(`click`,()=>{_.classList.add(`show`)});let S=()=>{_&&_.classList.remove(`show`)};v&&v.addEventListener(`click`,S),y&&y.addEventListener(`click`,S),b&&b.addEventListener(`click`,()=>{let t=document.getElementById(`sv-client-name`).value.trim(),s=document.getElementById(`sv-property`).value.trim(),l=document.getElementById(`sv-datetime`).value;if(!t||!l){g({title:`Missing Details`,message:`Please enter both the <strong>Client Name</strong> and the <strong>Visit Date & Time</strong>.`,type:`warning`});return}let u=new Date(l),d=u.getDate().toString(),p=u.getHours(),h=p>=12?`PM`:`AM`;p=p%12||12;let _=u.getMinutes().toString().padStart(2,`0`),v={id:`SV-${Date.now()}`,leadId:t,propertyId:s||`TBD`,visitDate:l.replace(`T`,` `)+`:00`,status:`Scheduled`,assignedTo:`Aishwarya R.`,notes:JSON.stringify({clientName:t,property:s})};o(`/site_visits`,{method:`POST`,body:JSON.stringify(v)}).catch(e=>{console.error(`API Error`,e),f(`Saved locally (network offline)`,`ri-information-line`)}),e.push({id:v.id,date:d,month:a[u.getMonth()],hours:p.toString(),mins:_,ampm:h,clientName:t,phone:`New Visit`,property:s||`TBD`,isNew:!0}),x({action:`Scheduled Site Visit (${t})`,module:`Site Visits`,details:`Scheduled property tour for ${t} at ${s||`Property`} on ${d} ${a[u.getMonth()]} ${u.getFullYear()} at ${p}:${_} ${h}.`}),f(`Site visit scheduled for ${t}!`,`ri-checkbox-circle-fill`),document.getElementById(`sv-client-name`).value=``,document.getElementById(`sv-property`).value=``,document.getElementById(`sv-datetime`).value=``,S(),i=parseInt(d),n=u.getMonth(),r=u.getFullYear(),c(),m(i.toString())}),window.addEventListener(`click`,e=>{e.target===_&&S()})}function Ue(){return`
    <div class="view-enter" style="height: 100%; display: flex; flex-direction: column;">
      <div class="view-header-flex" style="margin-bottom: 24px;">
        <div style="display: flex; align-items: center; gap: 16px;">
          <div style="width: 48px; height: 48px; background: rgba(247,147,26,0.1); border-radius: var(--os-radius-md); display: flex; align-items: center; justify-content: center; color: var(--os-luxury-orange); font-size: 1.5rem;">
            <i class="ri-kanban-view"></i>
          </div>
          <div>
            <h1 class="view-title">Pipeline Board</h1>
            <p class="view-subtitle">Drag cards between stages — some stages (marked <i class="ri-mail-line"></i> in the mobile select) send an automated WhatsApp to the client</p>
          </div>
        </div>
      </div>

      <div class="pipeline-board-container" id="pipeline-board">
        <!-- Columns rendered by JS -->
      </div>
    </div>
  `}var We=[{id:`New Lead`,name:`NEW LEAD`,emailIcon:!1},{id:`Initial Contact`,name:`INITIAL CONTACT`,emailIcon:!0},{id:`Requirement Analysis`,name:`REQUIREMENT ANALYSIS`,emailIcon:!1},{id:`Property Matching`,name:`PROPERTY MATCHING`,emailIcon:!1},{id:`Shared To Partner (use Share to partner)`,name:`SHARED TO PARTNER`,emailIcon:!1},{id:`Property Shared`,name:`PROPERTY SHARED`,emailIcon:!1},{id:`Follow Up Pending`,name:`FOLLOW UP PENDING`,emailIcon:!0},{id:`Site Visit Scheduled`,name:`SITE VISIT SCHEDULED`,emailIcon:!0},{id:`Site Visit Completed`,name:`SITE VISIT COMPLETED`,emailIcon:!0},{id:`Negotiation`,name:`NEGOTIATION`,emailIcon:!0},{id:`Bank Loan`,name:`BANK LOAN`,emailIcon:!0},{id:`Registration`,name:`REGISTRATION`,emailIcon:!0},{id:`Lost Closed`,name:`LOST CLOSED`,emailIcon:!1}];function Ge(){return JSON.parse(localStorage.getItem(`thanjai_leads`))||[]}function Ke(e){localStorage.setItem(`thanjai_leads`,JSON.stringify(e))}function qe(e){if(!e)return`—`;let t=parseInt(e.replace(/[^0-9]/g,``));return isNaN(t)?`—`:`₹`+t.toLocaleString(`en-IN`)}function Je(){let e=document.getElementById(`pipeline-board`);if(!e)return;let t=Ge();t.forEach(e=>{We.find(t=>t.id===e.status)||(e.status=e.status===`New`?`New Lead`:e.status===`Contacted`?`Initial Contact`:e.status===`Follow Up`?`Follow Up Pending`:e.status===`Interested`?`Requirement Analysis`:e.status===`Converted`?`Registration`:`New Lead`)});function n(){e.innerHTML=``,We.forEach(n=>{let i=t.filter(e=>e.status===n.id),a=document.createElement(`div`);a.className=`pipeline-col`,a.dataset.stage=n.id,a.innerHTML=`
        <div class="pipeline-col-header">
          <span>${n.name}</span>
          <span class="pipeline-col-count">${i.length}</span>
        </div>
        <div class="pipeline-col-cards" data-stage="${n.id}">
          ${i.map(e=>r(e)).join(``)}
        </div>
      `,e.appendChild(a)}),i()}function r(e){let t=`—`;e.budgetMax?t=qe(e.budgetMax):e.budgetMin&&(t=`Min ${qe(e.budgetMin)}`);let n=(e.priority||`Medium`).toLowerCase()===`high`?`high`:``,r=e.priority?e.priority.toUpperCase():`MEDIUM`,i=e.source?e.source.toUpperCase():`MANUAL`,a=[];e.type&&e.type!==`Any`&&a.push(e.type),e.bedrooms&&a.push(e.bedrooms+`BR`),e.area&&a.push(e.area);let o=a.length>0?a.join(` · `):`—`,s=We.map(t=>{let n=t.id+(t.emailIcon?` <i class="ri-mail-line" style="margin-left:4px; font-size:0.8rem;"></i>`:``);return`<div class="custom-option ${t.id===e.status?`selected`:``}" data-val="${t.id}">${n}</div>`}).join(``),c=We.find(t=>t.id===e.status)||We[0],l=c.id+(c.emailIcon?` <i class="ri-mail-line" style="margin-left:4px; font-size:0.8rem;"></i>`:``);return`
      <div class="pipeline-card" draggable="true" data-id="${e.id}" data-priority="${n||`medium`}">
        <div class="pipeline-card-header">
          <div class="pipeline-card-title">${e.name}</div>
          <div class="pipeline-card-priority ${n}">${r}</div>
        </div>
        <div class="pipeline-card-details">${o}</div>
        <div class="pipeline-card-budget">${t}</div>
        <div class="pipeline-card-meta">
          <div class="pipeline-card-assigned">${e.assignTo||`Unassigned`}</div>
          <div class="pipeline-card-source">${i}</div>
        </div>
        <div class="pipeline-card-action">
          <div class="custom-dropdown-wrap" data-lead="${e.id}">
            <div class="custom-dropdown-selected" tabindex="0">
              <span style="display:flex; align-items:center;">${l}</span> <i class="ri-arrow-down-s-line"></i>
            </div>
            <div class="custom-dropdown-options">
              ${s}
            </div>
          </div>
        </div>
      </div>
    `}function i(){e.querySelectorAll(`.custom-dropdown-wrap`).forEach(e=>{let t=e.querySelector(`.custom-dropdown-selected`);e.querySelectorAll(`.custom-option`);let n=e.dataset.lead;t.addEventListener(`mousedown`,e=>{e.stopPropagation()}),t.addEventListener(`click`,t=>{if(t.stopPropagation(),document.querySelectorAll(`.custom-dropdown-wrap.open`).forEach(t=>{t!==e&&t.classList.remove(`open`)}),document.querySelectorAll(`body > .custom-dropdown-options`).forEach(t=>{let n=document.querySelector(`.custom-dropdown-wrap[data-lead="${t.dataset.wrapId}"]`);n&&n!==e&&(n.appendChild(t),t.style.position=``,t.style.display=``)}),e.classList.contains(`open`)){e.classList.remove(`open`);let t=document.querySelector(`body > .custom-dropdown-options[data-wrap-id="${n}"]`);t&&(e.appendChild(t),t.style.position=``,t.style.display=``)}else{e.classList.add(`open`);let t=e.querySelector(`.custom-dropdown-options`);document.body.appendChild(t);let r=e.getBoundingClientRect();t.style.position=`fixed`,t.style.display=`block`,window.innerHeight-r.bottom<280&&r.top>280?(t.style.top=`auto`,t.style.bottom=window.innerHeight-r.top+4+`px`):(t.style.bottom=`auto`,t.style.top=r.bottom+4+`px`),t.style.left=r.left+`px`,t.style.width=r.width+`px`,t.style.zIndex=`999999`,t.dataset.wrapId=n}}),document.addEventListener(`click`,t=>{if(t.target.closest(`.custom-option`)){let r=t.target.closest(`.custom-option`),i=r.closest(`.custom-dropdown-options`);if(i&&i.dataset.wrapId===n){let t=r.dataset.val;e.appendChild(i),i.style.position=``,i.style.display=``,e.classList.remove(`open`),a(n,t)}}})}),document.addEventListener(`click`,e=>{!e.target.closest(`.custom-dropdown-wrap`)&&!e.target.closest(`.custom-dropdown-options`)&&(document.querySelectorAll(`.custom-dropdown-wrap.open`).forEach(e=>{e.classList.remove(`open`)}),document.querySelectorAll(`body > .custom-dropdown-options`).forEach(e=>{let t=document.querySelector(`.custom-dropdown-wrap[data-lead="${e.dataset.wrapId}"]`);t?(t.appendChild(e),e.style.position=``,e.style.display=``):e.remove()}))});let t=e.querySelectorAll(`.pipeline-card`),n=e.querySelectorAll(`.pipeline-col-cards`);t.forEach(e=>{e.addEventListener(`dragstart`,t=>{e.classList.add(`dragging`),t.dataTransfer.setData(`text/plain`,e.dataset.id),t.dataTransfer.effectAllowed=`move`}),e.addEventListener(`dragend`,()=>{e.classList.remove(`dragging`),n.forEach(e=>e.parentElement.classList.remove(`drag-over`))})}),n.forEach(e=>{e.addEventListener(`dragover`,t=>{t.preventDefault(),t.dataTransfer.dropEffect=`move`,e.parentElement.classList.add(`drag-over`)}),e.addEventListener(`dragleave`,()=>{e.parentElement.classList.remove(`drag-over`)}),e.addEventListener(`drop`,t=>{t.preventDefault(),e.parentElement.classList.remove(`drag-over`);let n=t.dataTransfer.getData(`text/plain`),r=e.dataset.stage;n&&r&&a(n,r)})})}function a(e,r){let i=t.findIndex(t=>String(t.id)===String(e));if(i!==-1){if(t[i].status===r)return;let e=t[i].status||`New Lead`;t[i].status=r,t[i].timeline||(t[i].timeline=[]),t[i].timeline.unshift({type:`pipeline`,message:`Moved from ${e.toUpperCase().replace(/\s+/g,`_`)} to ${r.toUpperCase().replace(/\s+/g,`_`)}`,author:localStorage.getItem(`thanjai_active_user`)||`Aishwarya Raman`,date:new Date().toISOString()}),Ke(t),n()}}n()}function Ye(){return`
    <div class="view-enter">
      <div class="view-header-flex">
        <div>
          <h1 class="view-title">Partner Network</h1>
          <p class="view-subtitle">Manage channel partners, real estate brokers, and track shared lead referrals</p>
        </div>
        <div class="header-actions-right">
          <button class="os-btn-primary" id="btn-add-partner" style="background: var(--os-luxury-orange); border-color: var(--os-luxury-orange);">
            <i class="ri-add-line"></i> Add partner
          </button>
        </div>
      </div>

      <div class="pn-container">
        <!-- Left Sidebar: Partner List -->
        <div class="pn-sidebar" id="pn-sidebar-list">
          <!-- Populated by JS -->
        </div>

        <!-- Right Content: Shared Leads -->
        <div class="pn-content" style="display: flex; flex-direction: column;">
          <div class="pn-content-header" style="display: flex; justify-content: space-between; align-items: center; padding: 16px 20px; border-bottom: 1px solid var(--os-border-thin);">
            <div id="pn-content-title" style="font-size: 1.15rem; font-weight: 700; color: var(--os-dark);">
              Select a partner
            </div>
            <button class="os-btn-primary" id="btn-share-lead-modal" style="background: var(--os-luxury-orange); border-color: var(--os-luxury-orange); display: none; padding: 6px 14px; font-size: 0.85rem;">
              <i class="ri-user-shared-line"></i> Share Lead
            </button>
          </div>

          <!-- Partner Info Card -->
          <div id="pn-partner-info-card" style="display: none; padding: 16px 20px; background: #fdfaf6; border-bottom: 1px solid var(--os-border-thin); font-size: 0.9rem;">
            <!-- Populated by JS -->
          </div>

          <!-- Shared Leads List -->
          <div class="pn-leads-list" id="pn-leads-container" style="flex: 1; padding: 20px; overflow-y: auto;">
            <!-- Populated by JS -->
          </div>
        </div>
      </div>
    </div>

    <!-- Add/Edit Partner Modal -->
    <div class="os-modal-overlay" id="add-partner-modal">
      <div class="os-modal-card" style="max-width: 650px; width: 90%; background: #ffffff; border-radius: 12px; padding: 24px; box-shadow: 0 10px 30px rgba(0,0,0,0.2);">
      <!-- MAIN LAYOUT -->
      <div class="pn-layout">
        <!-- SIDEBAR -->
        <div class="pn-sidebar">
          <div class="pn-sidebar-header">
            <span>Registered Partners</span>
          </div>
          <div class="pn-sidebar-list" id="pn-sidebar-list">
            <!-- Dynamic Partner List -->
          </div>
        </div>

        <!-- MAIN CONTENT AREA -->
        <div class="pn-content">
          <div class="pn-content-header" id="pn-content-title">
            <h2>Select a partner to view details</h2>
          </div>
          <div id="pn-partner-info-card" style="display: none;"></div>
          
          <div id="pn-leads-container" style="display: none; margin-top: 24px;">
            <!-- Leads shared with this partner -->
          </div>
        </div>
      </div>

      <!-- ADD PARTNER MODAL -->
      <div class="os-modal-overlay" id="add-partner-modal">
        <div class="os-modal" style="max-width: 500px;">
          <div class="os-modal-header" style="border-bottom: 1px solid rgba(0,0,0,0.06); padding-bottom: 16px; margin-bottom: 20px;">
            <h3 style="font-family: var(--font-sans); font-size: 1.3rem; font-weight: 800; color: #1A202C;">Register New Partner</h3>
            <button class="os-modal-close" id="close-add-partner-modal"><i class="ri-close-line"></i></button>
          </div>
          <div class="os-modal-body">
            <div class="form-group">
              <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #475569; margin-bottom: 6px;">Company / Agency Name <span style="color: #e53e3e;">*</span></label>
              <input type="text" id="add-partner-company" placeholder="e.g. Royal Realtors" style="width: 100%; padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.9rem;" required />
            </div>
            <div class="form-group">
              <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #475569; margin-bottom: 6px;">Contact Person <span style="color: #e53e3e;">*</span></label>
              <input type="text" id="add-partner-contact" placeholder="e.g. Ramesh K." style="width: 100%; padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.9rem;" required />
            </div>
            <div class="form-group">
              <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #475569; margin-bottom: 6px;">Official Phone Number <span style="color: #e53e3e;">*</span></label>
              <input type="tel" id="add-partner-phone" placeholder="10-digit mobile number" style="width: 100%; padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.9rem;" required />
            </div>
            <div class="form-group">
              <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #475569; margin-bottom: 6px;">WhatsApp Number</label>
              <input type="tel" id="add-partner-whatsapp" placeholder="Same as phone if left blank" style="width: 100%; padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.9rem;" />
            </div>
            <div class="form-group" style="display: flex; gap: 16px;">
              <div style="flex: 1;">
                <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #475569; margin-bottom: 6px;">Operating City</label>
                <input type="text" id="add-partner-city" placeholder="e.g. Trichy" style="width: 100%; padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.9rem;" />
              </div>
              <div style="flex: 1;">
                <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #475569; margin-bottom: 6px;">Status</label>
                <select id="add-partner-status" style="width: 100%; padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.9rem;">
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                </select>
              </div>
            </div>
          </div>
          <div class="os-modal-footer" style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 20px;">
            <button class="os-btn-secondary" id="cancel-add-partner-modal" style="padding: 8px 18px;">Cancel</button>
            <button class="os-btn-primary" id="save-add-partner-btn" style="background: #e27c3e; border-color: #e27c3e; padding: 8px 22px;">Save Partner</button>
          </div>
        </div>
      </div>

      <!-- SHARE LEAD MODAL -->
      <div class="os-modal-overlay" id="share-lead-modal">
        <div class="os-modal" style="max-width: 550px;">
          <div class="os-modal-header" style="border-bottom: 1px solid rgba(0,0,0,0.06); padding-bottom: 16px; margin-bottom: 20px;">
            <h3 style="font-family: var(--font-sans); font-size: 1.3rem; font-weight: 800; color: #1A202C;">Manually Add Shared Lead</h3>
            <button class="os-modal-close" id="close-share-lead-modal"><i class="ri-close-line"></i></button>
          </div>
          <div class="os-modal-body">
            <p style="font-size: 0.85rem; color: #64748b; margin-bottom: 16px;">Record a lead requirement that you are sharing with this partner.</p>
            
            <div class="form-group">
              <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #475569; margin-bottom: 6px;">Client Name (Alias optional) <span style="color: #e53e3e;">*</span></label>
              <input type="text" id="sl-name" placeholder="e.g. Ramesh (Buyer)" style="width: 100%; padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.9rem;" required />
            </div>
            <div class="form-group">
              <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #475569; margin-bottom: 6px;">Contact Phone (Optional - to protect data)</label>
              <input type="tel" id="sl-phone" placeholder="e.g. 9876543210 or leave blank" style="width: 100%; padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.9rem;" />
            </div>
            <div class="form-group" style="display: flex; gap: 16px;">
              <div style="flex: 1;">
                <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #475569; margin-bottom: 6px;">Property Type</label>
                <input type="text" id="sl-type" placeholder="e.g. 3BHK Villa" style="width: 100%; padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.9rem;" />
              </div>
              <div style="flex: 1;">
                <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #475569; margin-bottom: 6px;">Location Preference</label>
                <input type="text" id="sl-location" placeholder="e.g. Vilar Road" style="width: 100%; padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.9rem;" />
              </div>
            </div>
            <div class="form-group">
              <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #475569; margin-bottom: 6px;">Budget Range</label>
              <input type="text" id="sl-budget" placeholder="e.g. ₹ 25 - 50 Lakhs" style="width: 100%; padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 0.9rem;" />
            </div>
            <div class="form-group" style="margin-bottom: 0;">
              <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #475569; margin-bottom: 6px;">Handover Notes</label>
              <textarea id="sl-notes" placeholder="Requirement specifics, preferred timeline, or client instructions..." style="width: 100%; min-height: 70px; border: 1px solid #cbd5e1; border-radius: 6px; padding: 10px 12px; font-size: 0.9rem;"></textarea>
            </div>
          </div>
          <div class="os-modal-footer" style="display: flex; justify-content: flex-end; gap: 12px; margin-top: 20px;">
            <button class="os-btn-secondary" id="cancel-share-lead-modal" style="padding: 8px 18px;">Cancel</button>
            <button class="os-btn-primary" id="save-share-lead-btn" style="background: #e27c3e; border-color: #e27c3e; padding: 8px 22px;">Share Lead</button>
          </div>
        </div>
      </div>
    </div>
  `}async function Xe(){let e=[];try{let t=localStorage.getItem(`thanjai_partners`);t&&t!==`undefined`&&(e=JSON.parse(t)),Array.isArray(e)||(e=[])}catch(t){console.warn(`Failed to parse partners data:`,t),e=[]}let t={};try{let e=await o(`/shared_leads`);e&&Array.isArray(e)&&e.forEach(e=>{t[e.partnerId]||(t[e.partnerId]=[]),t[e.partnerId].push(e)})}catch(e){console.error(`Failed to fetch shared leads from DB:`,e)}let n=e.length>0?e[0].id:null,r=document.getElementById(`pn-sidebar-list`),i=document.getElementById(`pn-content-title`),a=document.getElementById(`pn-partner-info-card`),s=document.getElementById(`pn-leads-container`),c=document.getElementById(`btn-share-lead-modal`),l=()=>{if(!r)return;if(e.length===0){r.innerHTML=`<div style="padding: 24px; text-align: center; color: var(--os-gray-500);">No partner companies found. Click "+ Add partner" above.</div>`;return}let i=``;e.forEach(e=>{let r=String(e.id)===String(n)?`active`:``,a=e.city?` · ${e.city}`:``,o=(t[e.id]||[]).length,s=(e.status||`Active`).toLowerCase()===`active`?`active`:`inactive`;i+=`
        <div class="pn-partner-item ${r}" data-id="${e.id}">
          <div class="pn-partner-header">
            <div class="pn-partner-name" style="font-weight: 700;">${e.company||e.name}</div>
            <div class="pn-badge ${s}">${(e.status||`Active`).toUpperCase()}</div>
          </div>
          <div class="pn-partner-meta">
            ${e.contact||e.contactPerson||`Direct`} ${a} · <strong>${o} leads</strong>
          </div>
          <div class="pn-actions" style="margin-top: 8px; display: flex; gap: 8px;">
            <button class="pn-edit-btn os-btn-secondary" style="padding: 4px 10px; font-size: 0.75rem;"><i class="ri-edit-line"></i> Edit</button>
            <button class="pn-delete-btn os-btn-secondary" style="padding: 4px 10px; font-size: 0.75rem; color: #ef4444;"><i class="ri-delete-bin-line"></i> Delete</button>
          </div>
        </div>
      `}),r.innerHTML=i,r.querySelectorAll(`.pn-partner-item`).forEach(r=>{let i=r.dataset.id;r.addEventListener(`click`,r=>{if(r.target.closest(`.pn-edit-btn`)){r.stopPropagation(),p(i);return}if(r.target.closest(`.pn-delete-btn`)){r.stopPropagation();let a=e.find(e=>String(e.id)===String(i)),s=a?.company||a?.name||`Partner`;v({title:`Delete Partner`,message:`Are you sure you want to delete channel partner <strong>${s}</strong>? All shared lead referrals for this partner will be unlinked.`,confirmText:`Delete Partner`,cancelText:`Keep Partner`,confirmIcon:`ri-delete-bin-line`,isDanger:!0,onConfirm:()=>{e=e.filter(e=>String(e.id)!==String(i)),delete t[i],localStorage.setItem(`thanjai_partners`,JSON.stringify(e)),localStorage.setItem(`thanjai_shared_leads`,JSON.stringify(t)),o(`/partners/${i}`,{method:`DELETE`}).catch(e=>console.warn(e)),String(n)===String(i)&&(n=e.length>0?e[0].id:null),l(),u(),f(`Partner "${s}" deleted`,`ri-checkbox-circle-fill`)}});return}n=i,l(),u()})})},u=()=>{if(!i||!s)return;if(!n||e.length===0){i.textContent=`Select a partner`,a&&(a.style.display=`none`),s.innerHTML=`<div style="color: var(--os-gray-500); text-align: center; margin-top: 40px;">Select a partner from the sidebar to view shared leads and details.</div>`,c&&(c.style.display=`none`);return}let r=e.find(e=>String(e.id)===String(n));if(!r)return;i.textContent=r.company||r.name||`Partner Details`,c&&(c.style.display=`block`),a&&(a.style.display=`block`,a.innerHTML=`
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
          <div><strong>Contact:</strong> ${r.contact||r.contactPerson||`—`}</div>
          <div><strong>Phone:</strong> ${r.phone||`—`}</div>
          <div><strong>WhatsApp:</strong> ${r.whatsapp||r.phone||`—`}</div>
          <div><strong>Email:</strong> ${r.email||`—`}</div>
          <div><strong>Location:</strong> ${r.city||`—`}, ${r.country||`India`}</div>
          <div style="grid-column: span 2;"><strong>Notes:</strong> ${r.notes||`—`}</div>
        </div>
      `);let o=t[n]||[];if(o.length===0){s.innerHTML=`<div style="color: var(--os-gray-500); text-align: center; margin-top: 40px;">No leads shared with this partner yet.</div>`;return}let l=`<div style="display: grid; gap: 16px;">`;o.forEach(e=>{let t=(e.status||`Shared`).toLowerCase()===`shared`?`background: #e0e7ff; color: #4338ca;`:`background: #dcfce7; color: #15803d;`;l+=`
        <div style="padding: 16px; border: 1px solid var(--os-border-thin); border-radius: 8px; background: #fff;">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px;">
            <div style="font-weight: 700; font-size: 1.05rem;">${e.name}</div>
            <div style="padding: 4px 10px; border-radius: 4px; font-size: 0.75rem; font-weight: 600; ${t}">${(e.status||`Shared`).toUpperCase()}</div>
          </div>
          <div style="font-size: 0.85rem; color: var(--os-gray-600); margin-bottom: 12px;">
            <i class="ri-phone-line"></i> ${e.phone} &nbsp;|&nbsp; 
            <i class="ri-map-pin-line"></i> ${e.location} &nbsp;|&nbsp; 
            <i class="ri-home-4-line"></i> ${e.propertyType}
          </div>
          <div style="font-size: 0.85rem; color: var(--os-gray-600); margin-bottom: 12px;">
            <strong>Budget:</strong> ${e.budget||`—`} <br/>
            <strong>Shared by:</strong> ${e.sharedBy} on ${e.sharedDate}
          </div>
          <div style="font-size: 0.85rem; padding: 10px; background: #f8fafc; border-radius: 6px;">
            <strong>Handover Notes:</strong> ${e.notes||`No notes provided.`}
          </div>
        </div>
      `}),l+=`</div>`,s.innerHTML=l},d=()=>{let e=document.getElementById(`ap-edit-id`),t=document.getElementById(`ap-company`),n=document.getElementById(`ap-contact`),r=document.getElementById(`ap-phone`),i=document.getElementById(`ap-whatsapp`),a=document.getElementById(`ap-email`),o=document.getElementById(`ap-city`),s=document.getElementById(`ap-country`),c=document.getElementById(`ap-status`),l=document.getElementById(`ap-notes`),u=document.getElementById(`partner-modal-title`),d=document.getElementById(`save-partner-modal`),f=document.getElementById(`add-partner-modal`);e&&(e.value=``),t&&(t.value=``),n&&(n.value=``),r&&(r.value=``),i&&(i.value=``),a&&(a.value=``),o&&(o.value=`Thanjavur`),s&&(s.value=`India`),c&&(c.value=`Active`),l&&(l.value=``),u&&(u.textContent=`Add partner company`),d&&(d.textContent=`Save Partner`),f&&f.classList.add(`show`)},p=t=>{let n=e.find(e=>String(e.id)===String(t));if(!n)return;let r=document.getElementById(`ap-edit-id`),i=document.getElementById(`ap-company`),a=document.getElementById(`ap-contact`),o=document.getElementById(`ap-phone`),s=document.getElementById(`ap-whatsapp`),c=document.getElementById(`ap-email`),l=document.getElementById(`ap-city`),u=document.getElementById(`ap-country`),d=document.getElementById(`ap-status`),f=document.getElementById(`ap-notes`),p=document.getElementById(`partner-modal-title`),m=document.getElementById(`save-partner-modal`),h=document.getElementById(`add-partner-modal`);r&&(r.value=n.id),i&&(i.value=n.company||n.name||``),a&&(a.value=n.contact||n.contactPerson||``),o&&(o.value=n.phone||``),s&&(s.value=n.whatsapp||n.phone||``),c&&(c.value=n.email||``),l&&(l.value=n.city||`Thanjavur`),u&&(u.value=n.country||`India`),d&&(d.value=n.status||`Active`),f&&(f.value=n.notes||``),p&&(p.textContent=`Edit partner company`),m&&(m.textContent=`Update Partner`),h&&h.classList.add(`show`)},m=()=>{let e=document.getElementById(`add-partner-modal`);e&&e.classList.remove(`show`)},h=document.getElementById(`btn-add-partner`);h&&h.addEventListener(`click`,d);let _=document.getElementById(`close-partner-modal`);_&&_.addEventListener(`click`,m);let y=document.getElementById(`cancel-partner-modal`);y&&y.addEventListener(`click`,m);let b=document.getElementById(`add-partner-modal`);b&&b.addEventListener(`click`,e=>{e.target===b&&m()});let S=document.getElementById(`save-partner-modal`);S&&S.addEventListener(`click`,async()=>{let t=document.getElementById(`ap-edit-id`)?.value.trim(),r=document.getElementById(`ap-company`)?.value.trim(),i=document.getElementById(`ap-contact`)?.value.trim(),a=document.getElementById(`ap-phone`)?.value.trim(),s=document.getElementById(`ap-whatsapp`)?.value.trim(),c=document.getElementById(`ap-email`)?.value.trim(),d=document.getElementById(`ap-city`)?.value.trim()||`Thanjavur`,p=document.getElementById(`ap-country`)?.value.trim()||`India`,h=document.getElementById(`ap-status`)?.value||`Active`,_=document.getElementById(`ap-notes`)?.value.trim();if(!r){g({title:`Missing Company Name`,message:`Please enter a <strong>Company or Agency Name</strong> for this partner.`,type:`warning`});return}if(t){let n=e.findIndex(e=>String(e.id)===String(t));n!==-1&&(e[n]={...e[n],name:r,company:r,type:i,contact:i,contactPerson:i,phone:a,whatsapp:s||a,email:c,city:d,country:p,status:h,notes:_},o(`/partners/${t}`,{method:`PUT`,body:JSON.stringify(e[n])}).catch(e=>console.warn(e)),x({action:`Updated Partner (${r})`,module:`Partners Network`,details:`Updated channel partner details for ${r} (${d}).`}))}else{let t=`PN-${Date.now()}`,l={id:t,name:r,company:r,type:i,contact:i,contactPerson:i,phone:a,whatsapp:s||a,email:c,city:d,country:p,status:h,notes:_,leads:0};e.unshift(l),n=t,o(`/partners`,{method:`POST`,body:JSON.stringify(l)}).catch(e=>console.warn(e)),x({action:`Added Partner (${r})`,module:`Partners Network`,details:`Registered new channel partner "${r}" (${i} - ${a}) in ${d}.`})}localStorage.setItem(`thanjai_partners`,JSON.stringify(e)),m(),l(),u(),f(t?`Partner updated successfully!`:`New partner registered!`,`ri-checkbox-circle-fill`)});let C=document.getElementById(`share-lead-modal`),w=document.getElementById(`close-share-lead-modal`),T=document.getElementById(`cancel-share-lead-modal`),E=document.getElementById(`save-share-lead-btn`),D=document.getElementById(`sl-lead-select`),O=()=>{if(!n){g({title:`No Partner Selected`,message:`Please select a channel partner from the left sidebar first.`,type:`warning`});return}let e=JSON.parse(localStorage.getItem(`thanjai_leads`))||[];if(D){let t=`<option value="">-- Choose Existing Lead --</option>`;e.forEach(e=>{let n=e.phone||e.mobile||``;t+=`<option value="${e.id}" data-name="${e.name||``}" data-phone="${n}" data-loc="${e.location||e.city||``}" data-type="${e.requirement||e.type||``}" data-budget="${e.budget||``}">${e.name||`Unnamed`} (${n||`No Phone`})</option>`}),D.innerHTML=t}document.getElementById(`sl-name`).value=``,document.getElementById(`sl-phone`).value=``,document.getElementById(`sl-location`).value=`Thanjavur`,document.getElementById(`sl-type`).value=`Plot`,document.getElementById(`sl-budget`).value=`₹ 25 - 50 Lakhs`,document.getElementById(`sl-notes`).value=``,C&&C.classList.add(`show`)},k=()=>{C&&C.classList.remove(`show`)};c&&c.addEventListener(`click`,O),w&&w.addEventListener(`click`,k),T&&T.addEventListener(`click`,k),C&&C.addEventListener(`click`,e=>{e.target===C&&k()}),D?.addEventListener(`change`,e=>{let t=e.target.options[e.target.selectedIndex];t&&t.value&&(document.getElementById(`sl-name`).value=t.dataset.name||``,document.getElementById(`sl-phone`).value=t.dataset.phone||``,document.getElementById(`sl-location`).value=t.dataset.loc||`Thanjavur`,document.getElementById(`sl-type`).value=t.dataset.type||`Plot`,document.getElementById(`sl-budget`).value=t.dataset.budget||`Contact for Budget`)}),E&&E.addEventListener(`click`,async()=>{if(!n)return;let r=document.getElementById(`sl-lead-select`)?.value,i=document.getElementById(`sl-name`).value.trim(),a=document.getElementById(`sl-phone`).value.trim(),s=document.getElementById(`sl-location`).value.trim(),c=document.getElementById(`sl-type`).value.trim(),d=document.getElementById(`sl-budget`).value.trim(),p=document.getElementById(`sl-notes`).value.trim();if(!i){f(`Please enter client name.`,`ri-error-warning-fill`);return}let m=JSON.parse(sessionStorage.getItem(`thanjai_active_user`))||{fullName:`Admin`},h=new Date,g=h.toLocaleDateString(`en-IN`,{day:`numeric`,month:`short`,year:`numeric`})+`, `+h.toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`}),_={id:`SL-${Date.now()}`,partnerId:String(n),leadId:r||null,name:i,phone:a,location:s,propertyType:c,budget:d,sharedBy:m.fullName||`Admin`,sharedDate:g,status:`Shared`,notes:p};try{await o(`/shared_leads`,{method:`POST`,body:JSON.stringify(_)}),t[n]||(t[n]=[]),t[n].unshift(_)}catch(e){console.error(`Failed to save shared lead to DB:`,e)}let v=e.findIndex(e=>String(e.id)===String(n)),y=`Partner`;if(v!==-1){let r=e[v];y=r.name||r.company||`Partner`,e[v].leads=t[n].length,localStorage.setItem(`thanjai_partners`,JSON.stringify(e));let l=(r.whatsapp||r.phone||``).replace(/\D/g,``);if(l){l.length===10?l=`+91`+l:l.length===12&&l.startsWith(`91`)?l=`+`+l:l.startsWith(`+`)||(l=`+`+l);let e=p||`Requirement from CRM`,t=`Hello ${y},\n\nA new qualified buyer requirement has been assigned to you from Thanjai Property:\n\n👤 Client Name: ${i}\n📍 Preferred Location: ${s}\n🏡 Requirement: ${c}\n💰 Budget Range: ${d}\n\n📝 Notes: ${e}\n\nFor client coordination, please connect through our official desk: +91 84899 96852.\n\nWarm regards,\nThanjai Property Partner Network`;o(`/whatsapp_logs`,{method:`POST`,body:JSON.stringify({id:`WA-${Date.now()}`,phone:l,sender:`Super Admin`,recipientName:y,message:t,type:`outbound`})}).catch(()=>{});let n=localStorage.getItem(`thanjai_whatsapp_api_key`);if(n){let t={apiKey:n,campaignName:`partner_lead_assignment`,destination:l,userName:y,templateParams:[y,i,s,c,d,e]};fetch(`https://backend.api-wa.co/campaign/smartping/api/v2`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(t)}).then(e=>e.json()).then(e=>{e.status===`error`?f(`SmartPing: ${e.message||e.error||`Dispatch error`}`,`ri-alert-line`):f(`WhatsApp sent to partner ${y}!`,`ri-checkbox-circle-fill`)}).catch(()=>{o(`/send_whatsapp`,{method:`POST`,body:JSON.stringify(t)}).catch(()=>{})})}}let u=(a||``).replace(/\D/g,``);if(u){u.length===10?u=`+91`+u:u.length===12&&u.startsWith(`91`)?u=`+`+u:u.startsWith(`+`)||(u=`+`+u);let e=`Hello ${i},\n\nYour property requirement in ${s} has been assigned to our senior partner specialist ${y}.\n\nOur team and specialist will assist you with exclusive listings, verified Patta documents, and on-site visits.\n\nFor any direct assistance, contact our official desk at +91 84899 96852.\n\nBest regards,\nThanjai Property`;o(`/whatsapp_logs`,{method:`POST`,body:JSON.stringify({id:`WA-${Date.now()}-client`,phone:u,sender:`Super Admin`,recipientName:i,message:e,type:`outbound`})}).catch(()=>{});let t=localStorage.getItem(`thanjai_whatsapp_api_key`);if(t){let e={apiKey:t,campaignName:`partner_transfer_notification`,destination:u,userName:i,templateParams:[i,s,y,`+91 84899 96852`]};fetch(`https://backend.api-wa.co/campaign/smartping/api/v2`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(e)}).catch(()=>{o(`/send_whatsapp`,{method:`POST`,body:JSON.stringify(e)}).catch(()=>{})})}}}x({action:`Shared Lead to Partner (${y})`,module:`Partners Network`,details:`Shared lead ${i} (${a}) for ${c} in ${s} with partner ${y}.`}),k(),l(),u(),f(`Lead shared with ${y} & WhatsApp notification sent!`,`ri-checkbox-circle-fill`)}),l(),u(),o(`/partners`).then(t=>{t&&Array.isArray(t)&&t.length>0?(e=t.map(e=>({id:e.id,name:e.name||e.company||`Partner Company`,company:e.name||e.company||`Partner Company`,contact:e.contactPerson||e.type||e.contact||`Contact Person`,contactPerson:e.contactPerson||e.type||e.contact||`Contact Person`,city:e.city||`Thanjavur`,phone:e.phone||``,whatsapp:e.whatsapp||e.phone||``,email:e.email||``,country:e.country||`India`,notes:e.notes||``,leads:e.leads||0,status:e.status||`Active`})),localStorage.setItem(`thanjai_partners`,JSON.stringify(e)),n=e.length>0?e[0].id:null,l(),u()):e.length>0&&e.forEach(e=>{o(`/partners`,{method:`POST`,body:JSON.stringify(e)}).catch(()=>{})})}).catch(e=>{console.warn(`API sync warning:`,e)})}function Ze(){return`
    <div class="view-enter ai-agent-view">
      
      <div class="ai-chat-container">
        
        <!-- Empty State / Welcome -->
        <div class="ai-welcome">
          <div class="ai-logo-large">
            <i class="ri-magic-line"></i>
          </div>
          <h2>How can I help you today?</h2>
          <p>I am your Thanjai Property AI Operating Agent. Ask me anything about your leads, properties, or schedule.</p>

          <div class="ai-suggestions">
            <button class="ai-sug-card hover-lift">
              <i class="ri-bar-chart-box-line"></i>
              <span>Summarize this week's sales performance</span>
            </button>
            <button class="ai-sug-card hover-lift">
              <i class="ri-user-search-line"></i>
              <span>Find properties matching Rajesh's budget (₹1.4Cr)</span>
            </button>
            <button class="ai-sug-card hover-lift">
              <i class="ri-calendar-check-line"></i>
              <span>What is my schedule looking like for tomorrow?</span>
            </button>
            <button class="ai-sug-card hover-lift">
              <i class="ri-mail-send-line"></i>
              <span>Draft a follow-up email for Suresh Menon</span>
            </button>
          </div>
        </div>

        <!-- Chat History (Hidden initially) -->
        <div class="ai-history" style="display:none;" id="ai-chat-history">
        </div>

      </div>

      <!-- Input Area -->
      <div class="ai-input-area">
        <div class="ai-input-box">
          <button class="ai-attach-btn"><i class="ri-attachment-2"></i></button>
          <input type="text" id="ai-user-input" placeholder="Message AI Agent..." />
          <button class="ai-send-btn" id="ai-send-button"><i class="ri-arrow-up-line"></i></button>
        </div>
        <div class="ai-disclaimer">AI can make mistakes. Verify important information.</div>
      </div>
    </div>
  `}function Qe(){let e=document.getElementById(`ai-send-button`),t=document.getElementById(`ai-user-input`),n=document.querySelectorAll(`.ai-sug-card`),r=document.querySelector(`.ai-welcome`),i=document.getElementById(`ai-chat-history`);function a(e,t){let n=e===`user`,r=document.createElement(`div`);r.className=`ai-msg ${n?`user`:`system`}`;let a=``;n||(a+=`<div class="ai-avatar"><i class="ri-magic-line"></i></div>`);let o=n?t:ce.parse(t);a+=`
      <div class="ai-msg-bubble">
        ${n?t:o}
      </div>
    `,r.innerHTML=a,i.appendChild(r),i.scrollTop=i.scrollHeight}async function s(e){if(!e.trim())return;r.style.display=`none`,i.style.display=`flex`,i.style.flexDirection=`column`,i.style.gap=`16px`,t.value=``,a(`user`,e);let n=`loading-`+Date.now(),s=document.createElement(`div`);s.className=`ai-msg system`,s.id=n,s.innerHTML=`
      <div class="ai-avatar"><i class="ri-magic-line"></i></div>
      <div class="ai-msg-bubble" style="color: var(--os-gray-400);">Thinking...</div>
    `,i.appendChild(s),i.scrollTop=i.scrollHeight;try{let t=JSON.parse(localStorage.getItem(`thanjai_properties`))||[],r=JSON.parse(localStorage.getItem(`thanjai_leads`))||[];await new Promise(e=>setTimeout(e,1200));let i=``,s=e.toLowerCase();if(s.includes(`summarize`)&&(s.includes(`performance`)||s.includes(`sales`))){let e=r.length,t=r.filter(e=>e.status===`new`).length;i=`**Weekly Sales Performance Summary:**\n\n- **Total Active Leads:** ${e}\n- **New Inquiries:** ${t}\n\n*Overall pipeline is looking healthy. Focus on converting the ${t} new leads in your queue.*`}else if(s.includes(`rajesh`)||s.includes(`budget`)||s.includes(`1.4cr`)){let e=t.filter(e=>e.price<=14e6&&e.price>=1e7);i=`I found **${e.length} properties** matching Rajesh's budget of ₹1.4Cr:\n\n`+e.slice(0,3).map(e=>`- **${e.title}** (${e.location}) - ${e.priceFormatted}`).join(`
`)+`

*Should I draft an email to Rajesh with these options?*`}else i=s.includes(`schedule`)||s.includes(`tomorrow`)?`**Your Schedule for Tomorrow:**

- **10:00 AM:** Site visit at Kaveri Riverfront Villas with Mr. Karthik.
- **02:30 PM:** Follow-up call with Suresh Menon.
- **04:00 PM:** Partner meeting with Chennai Prime Realty.

*Would you like me to set reminders for these?*`:s.includes(`suresh`)?`**Draft Email for Suresh Menon:**

Subject: Follow-up regarding your property inquiry

Dear Suresh,

I hope this email finds you well. I wanted to follow up on our previous conversation regarding the luxury apartments in Thanjavur. Please let me know if you are available for a quick site visit this weekend.

Best regards,
S. Vijayaraghavan

*(You can edit this draft before sending)*`:`I am your AI Operating Agent simulator. I see you have **${t.length} properties** and **${r.length} leads** in your CRM database.\n\nSince this is a simulated demo environment, I can respond to specific queries like:\n- Summarize this week's sales performance\n- Find properties matching Rajesh's budget (₹1.4Cr)\n- What is my schedule looking like for tomorrow?\n- Draft a follow-up email for Suresh Menon`;let c=document.getElementById(n);c&&c.remove(),a(`system`,i);let l=_(),u=l?l.email||l.username||`admin`:`system`;o(`/ai_logs`,{method:`POST`,body:JSON.stringify({id:`AI-${Date.now()}`,user_id:u,prompt:e,response:i})}).catch(e=>console.warn(`Failed to log AI conversation`,e))}catch(e){console.error(`Error in AI simulator:`,e);let t=document.getElementById(n);t&&t.remove(),a(`system`,`Sorry, an error occurred in the AI simulator.`)}}e&&t&&(e.addEventListener(`click`,()=>s(t.value)),t.addEventListener(`keypress`,e=>{e.key===`Enter`&&s(t.value)})),n.forEach(e=>{e.addEventListener(`click`,()=>{let t=e.querySelector(`span`).textContent;s(t)})})}function $e(){return`
    <div class="view-enter whatsapp-view" style="display: flex; height: calc(100vh - 110px); max-height: calc(100vh - 110px); min-height: 550px; background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.05); border: 1px solid #e2e8f0; position: relative;">
      
      <!-- Left: Conversation List -->
      <div class="wa-sidebar" style="width: 350px; min-width: 350px; border-right: 1px solid #e2e8f0; display: flex; flex-direction: column; background: #ffffff;">
        <div class="wa-header" style="padding: 16px 20px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; background: #f8fafc;">
          <h2 style="margin: 0; font-size: 1.15rem; font-weight: 800; color: #1e293b; display: flex; align-items: center; gap: 8px;">
            <i class="ri-whatsapp-fill" style="color: #25D366; font-size: 1.3rem;"></i> WhatsApp Log
          </h2>
          <div style="display: flex; gap: 6px;">
            <button id="wa-refresh-leads" class="os-btn-secondary" title="Refresh conversations" style="padding: 6px 12px; font-size: 0.85rem;"><i class="ri-refresh-line"></i></button>
          </div>
        </div>
        
        <div class="os-filter-bar" style="margin: 0; box-shadow: none; border-radius: 0; border: none; border-bottom: 1px solid #e2e8f0; padding: 10px 16px; background: #ffffff;">
          <div class="search-box" style="width: 100%;">
            <i class="ri-search-line"></i>
            <input type="text" id="wa-search-leads" placeholder="Search contacts by name or phone..." style="font-size: 0.85rem; width: 100%; border: none; outline: none;" />
          </div>
        </div>

        <div id="wa-chat-list" class="wa-chat-list" style="flex: 1; overflow-y: auto;">
          <!-- Conversations injected dynamically -->
        </div>
      </div>

      <!-- Right: Chat Panel -->
      <div class="wa-main" style="flex: 1; display: flex; flex-direction: column; background: #efeae2; overflow: hidden; height: 100%;">
        <!-- Empty State -->
        <div id="wa-empty-state" style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; color: var(--os-gray-500);">
          <i class="ri-whatsapp-line" style="font-size: 4rem; color: #25d366; margin-bottom: 16px;"></i>
          <h2 style="margin: 0 0 8px 0; color: #1e293b;">WhatsApp Live Chat</h2>
          <p style="margin: 0; font-size: 0.9rem;">Select a conversation from the left to view live messages or reply.</p>
        </div>

        <!-- Chat Container (Hidden by default) -->
        <div id="wa-chat-container" style="display: none; flex-direction: column; height: 100%; width: 100%; overflow: hidden;">
          <!-- Top Bar Header (Sticky) -->
          <div class="wa-chat-header" style="padding: 12px 20px; background: #f0f2f5; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #d1d7db; min-height: 64px; flex-shrink: 0; z-index: 10;">
            <div class="wa-chat-title" style="display: flex; align-items: center; gap: 12px;">
              <div id="wa-active-avatar" style="width: 42px; height: 42px; min-width: 42px; border-radius: 50%; background: #25d366; color: white; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 1.1rem; box-shadow: 0 2px 5px rgba(0,0,0,0.1);"></div>
              <div>
                <h3 id="wa-active-name" style="margin: 0; font-size: 1.05rem; font-weight: 700; color: #111b21;"></h3>
                <p id="wa-active-phone" style="margin: 2px 0 0 0; font-size: 0.82rem; color: #667781; font-weight: 500;"></p>
                <div id="wa-active-property-badge" style="display: none; align-items: center; gap: 6px; font-size: 0.76rem; font-weight: 700; color: #9a3412; background: #ffedd5; padding: 2px 10px; border-radius: 12px; margin-top: 4px; border: 1px solid #fed7aa; max-width: 420px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"></div>
              </div>
            </div>
            <div style="display: flex; align-items: center; gap: 10px;">
              <span style="display: inline-flex; align-items: center; gap: 6px; font-size: 0.75rem; font-weight: 700; color: #059669; background: #ecfdf5; padding: 4px 12px; border-radius: 20px; border: 1px solid #a7f3d0;">
                <span style="width: 8px; height: 8px; border-radius: 50%; background: #10b981; display: inline-block;"></span> Live SmartPing Webhook
              </span>
            </div>
          </div>

          <!-- Chat Stream History -->
          <div id="wa-chat-history" class="wa-chat-history" style="flex: 1; overflow-y: auto; padding: 20px 24px; display: flex; flex-direction: column; gap: 12px;">
            <!-- Messages injected here -->
          </div>

          <!-- Input Area (Bottom) -->
          <div class="wa-input-area" style="padding: 12px 20px; background: #f0f2f5; display: flex; gap: 12px; align-items: center; border-top: 1px solid #d1d7db; flex-shrink: 0;">
            <input type="text" id="wa-msg-input" placeholder="Type a message to reply on WhatsApp..." style="flex: 1; padding: 12px 18px; border: 1px solid #e2e8f0; border-radius: 24px; outline: none; font-size: 0.95rem; background: #ffffff; box-shadow: 0 1px 3px rgba(0,0,0,0.05);" />
            <button id="wa-btn-send" class="wa-send" title="Send WhatsApp Message" style="background: #25d366; border: none; width: 44px; height: 44px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.25rem; color: #ffffff; cursor: pointer; box-shadow: 0 2px 6px rgba(37,211,102,0.4); flex-shrink: 0;"><i class="ri-send-plane-fill"></i></button>
          </div>
        </div>
      </div>
    </div>
  `}function et(e){return e?String(e).replace(/\D/g,``).slice(-10):``}function tt(e){let t=String(e||``);if(t.startsWith(`+`))return t;let n=t.replace(/\D/g,``);return n.length===10?`+91 ${n}`:n.length>10?`+${n}`:t}function nt(e){if(!e||isNaN(e.getTime())||e.getTime()===0)return``;let t=new Date;return e.toDateString()===t.toDateString()?e.toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`}):new Date(t.setDate(t.getDate()-1)).toDateString()===e.toDateString()?`Yesterday`:e.toLocaleDateString([],{day:`numeric`,month:`short`})}function rt(e){if(!e||isNaN(e.getTime()))return``;let t=new Date,n=e.toDateString()===t.toDateString(),r=e.toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`});return n?r:`${e.toLocaleDateString([],{day:`numeric`,month:`short`})}, ${r}`}function it(e,t=`Client`){if(!e)return``;let n=String(e).trim();return n===`bank_loan_assist`||n===`bank_loan_assistance`?`Hello ${t}, Thanjai Property offers complete bank loan facilitation with leading nationalized and private banks (SBI, HDFC, ICICI, Indian Bank) at competitive interest rates with instant Patta verification support. Desk: +91 84899 96852.`:n===`property_follow_up`||n===`follow_up_nurture`?`Hello ${t}, We are following up regarding your property requirement in Thanjavur. Our advisors have new verified listings that match your criteria. Let us know when you'd like to review.`:n===`welcome_message`?`Hello ${t}, Welcome to Thanjai Property! What type of property or location are you looking for in Thanjavur? Let us know your requirement and our property advisory desk will assist you.`:n===`initial_contact_intro`?`Hello ${t}, Thank you for your interest in Thanjai Property! We have received your requirement. Our property advisors will assist you shortly with verified documents, prime locations, and direct builder coordination. Official Desk: +91 84899 96852.`:n===`stage_requirement_analysis`?`Hello ${t}, We are currently analyzing your property requirement. Our team is shortlisting legal-verified properties matching your exact criteria. Advisory Desk: +91 84899 96852.`:n===`stage_lead_qualified`?`Hello ${t}, Your property requirement has been successfully qualified and matched with verified inventory. Our specialist will coordinate the legal Patta documents.`:n===`stage_site_visit_scheduled`?`Hello ${t}, Your site visit has been scheduled. Our field manager will assist you with plot boundaries, layout review, and Patta verification. Location coordinator: +91 84899 96852.`:n===`stage_negotiation_stage`?`Hello ${t}, We have initiated price negotiation and legal terms discussion with the property owner on your behalf. We will update you with the approved terms shortly.`:n===`stage_booking_in_progress`?`Hello ${t}, Your property booking token documentation is now in progress with legal stamp verification. Our registration desk will guide you on the next milestone.`:n===`stage_deal_won_registration`?`Congratulations ${t}! Your property registration has been completed successfully at the Sub-Registrar Office. Thank you for choosing Thanjai Property!`:n===`partner_transfer_notification`?`Hello ${t}, Your property requirement has been assigned to our verified Area Specialist Partner for dedicated on-ground coordination.`:n===`partner_lead_assignment`?`New Lead Assigned: Please coordinate with client ${t} for property inspection and advisory.`:n===`stage_closed_lost_archive`?`Hello ${t}, Thank you for connecting with Thanjai Property. Your requirement file has been archived. We are always here whenever you plan your next real estate journey.`:n}async function at(){let e=document.getElementById(`wa-chat-list`),t=document.getElementById(`wa-search-leads`),n=document.getElementById(`wa-empty-state`),r=document.getElementById(`wa-chat-container`),i=document.getElementById(`wa-btn-send`),a=document.getElementById(`wa-msg-input`),s=null,c=new Map;async function l(){let e=[];try{let t=await o(`/leads`);t&&Array.isArray(t)&&(e=t)}catch{}e.length===0&&(e=JSON.parse(localStorage.getItem(`thanjai_leads`))||[]);let n=[];try{let e=await o(`/whatsapp_messages`);e&&Array.isArray(e)&&(n=e)}catch{}let r=new Map;e.forEach(e=>{let t=e.phone||e.mobile||e.whatsapp||``,n=et(t);n&&r.set(n,{id:e.id||`C-${n}`,name:e.name||`Client (+91 ${n})`,phone:tt(t),phone10:n,messages:[],lastTime:``,lastDate:new Date(0),lastMessage:`No messages yet`})}),n.forEach(e=>{let t=e.message||``,n=e.customer_phone||``,i=et(n);if(!i)return;r.has(i)||r.set(i,{id:`WA-${i}`,name:e.customer_name||`WhatsApp (+91 ${i})`,phone:tt(n),phone10:i,messages:[],lastTime:``,lastDate:new Date(0),lastMessage:``});let a=r.get(i);e.customer_name&&a.name.startsWith(`Client (`)&&(a.name=e.customer_name);let o=(e.direction||`inbound`).toLowerCase()===`outbound`?`out`:`in`,s=new Date(e.createdAt||Date.now()),c=it(t,a.name);a.messages.some(e=>e.direction===o&&e.message===c&&Math.abs(e.date-s)<5e3)||a.messages.push({direction:o,message:c,date:s,source:e.source})}),r.forEach(e=>{if(e.messages.sort((e,t)=>e.date-t.date),e.messages.length>0){let t=e.messages[e.messages.length-1];e.lastDate=t.date,e.lastMessage=t.message,e.lastTime=nt(t.date)}}),c=r,u(t?.value||``),s&&m(s,!0)}function u(t=``){let n=t.toLowerCase(),r=Array.from(c.values()).sort((e,t)=>t.lastDate-e.lastDate).filter(e=>e.name.toLowerCase().includes(n)||e.phone.toLowerCase().includes(n)||e.phone10.includes(n));if(r.length===0){e.innerHTML=`<div style="padding: 24px; text-align: center; color: #64748b; font-size: 0.9rem;">No WhatsApp chats found.</div>`;return}let i=``;r.forEach(e=>{let t=(e.name||`W`).substring(0,2).toUpperCase(),n=e.phone10===s?`#e2e8f0`:`transparent`,r=e.lastMessage||`Start conversation`;i+=`
        <div class="wa-chat-item hover-lift" data-phone10="${e.phone10}" style="padding: 14px 16px; display: flex; gap: 12px; cursor: pointer; border-bottom: 1px solid #f1f5f9; background: ${n}; transition: background 0.2s;">
          <div style="width: 44px; height: 44px; min-width: 44px; border-radius: 50%; background: #25D366; display: flex; align-items: center; justify-content: center; font-weight: 800; color: #ffffff; font-size: 0.95rem; box-shadow: 0 2px 5px rgba(37,211,102,0.3);">
            ${t}
          </div>
          <div style="flex: 1; overflow: hidden;">
            <div style="display: flex; justify-content: space-between; align-items: baseline;">
              <strong style="color: #1e293b; font-size: 0.95rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${e.name}</strong>
              <span style="font-size: 0.72rem; color: #94a3b8; font-weight: 600;">${e.lastTime}</span>
            </div>
            <div style="font-size: 0.8rem; color: #64748b; margin-top: 2px;">
              ${e.phone}
            </div>
            <div style="font-size: 0.8rem; color: #475569; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 4px; font-weight: 500;">
              ${r}
            </div>
          </div>
        </div>
      `}),e.innerHTML=i,e.querySelectorAll(`.wa-chat-item`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.phone10;d(t)})})}function d(e){s=e;let i=c.get(e);if(!i)return;n.style.display=`none`,r.style.display=`flex`,document.getElementById(`wa-active-name`).textContent=i.name,document.getElementById(`wa-active-phone`).textContent=i.phone,document.getElementById(`wa-active-avatar`).textContent=(i.name||`W`).substring(0,2).toUpperCase();let a=document.getElementById(`wa-active-property-badge`),o=(i.messages||[]).find(e=>e.message&&e.message.includes(`[Property Inquiry]`));if(o&&a){let e=o.message.replace(`[Property Inquiry]`,``).trim();a.style.display=`inline-flex`,a.innerHTML=`<i class="ri-home-4-line" style="color: #eb5e28;"></i> <span title="${e}">${e}</span>`}else a&&(a.style.display=`none`);u(t?.value||``),m(e,!1)}function p(e){return e?e.replace(`WhatsApp sent: `,``).replace(`Customer replied: `,``).replace(/\n/g,`<br/>`):``}function m(e,t=!1){let n=document.getElementById(`wa-chat-history`);if(!n)return;let r=c.get(e);if(!r)return;if(r.messages.length===0){n.innerHTML=`<div style="text-align: center; color: #667781; margin-top: 30px; font-size: 0.9rem;">Start of conversation. Type a message below to send via WhatsApp.</div>`;return}let i=n.scrollHeight-n.scrollTop<=n.clientHeight+60,a=``;r.messages.forEach(e=>{let t=rt(e.date);e.direction===`out`?a+=`
          <div style="align-self: flex-end; background: #d9fdd3; padding: 10px 14px; border-radius: 12px 12px 0 12px; max-width: 75%; min-width: 160px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border: 1px solid #c7f2c0;">
            <div style="font-size: 0.92rem; color: #111b21; margin-bottom: 6px; word-wrap: break-word; line-height: 1.4;">
              ${p(e.message)}
            </div>
            <div style="font-size: 0.7rem; color: #667781; text-align: right; display: flex; align-items: center; justify-content: flex-end; gap: 4px; margin-top: 4px;">
              <span>${t}</span>
              <i class="ri-check-double-line" style="color: #53bdeb; font-size: 1rem;"></i>
            </div>
          </div>
        `:a+=`
          <div style="align-self: flex-start; background: #ffffff; padding: 10px 14px; border-radius: 12px 12px 12px 0; max-width: 75%; min-width: 160px; box-shadow: 0 1px 3px rgba(0,0,0,0.12); border: 1px solid #e2e8f0;">
            <div style="font-size: 0.75rem; font-weight: 800; color: #06c167; margin-bottom: 4px; display: flex; align-items: center; gap: 4px;">
              <i class="ri-user-smile-fill"></i> Customer Reply
            </div>
            <div style="font-size: 0.95rem; color: #111b21; margin-bottom: 6px; word-wrap: break-word; font-weight: 500;">
              ${p(e.message)}
            </div>
            <div style="font-size: 0.7rem; color: #667781; text-align: left; margin-top: 2px;">${t}</div>
          </div>
        `}),n.innerHTML=a,(!t||i)&&(n.scrollTop=n.scrollHeight)}async function h(){if(!s)return;let e=c.get(s);if(!e)return;let n=a.value.trim();if(!n)return;let r=i.innerHTML;i.innerHTML=`<i class="ri-loader-4-line ri-spin"></i>`,i.disabled=!0;try{let r=`+91`+e.phone10;await M({campaignName:`property_follow_up`,destination:r,userName:e.name,messageText:n,templateParams:[e.name,`Thanjavur`,n],media:{url:`https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80`,filename:`property.jpg`}});let i={direction:`out`,message:n,date:new Date};e.messages.push(i),e.lastDate=new Date,e.lastMessage=n,e.lastTime=new Date().toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`}),x({action:`Sent WhatsApp to ${e.name}`,module:`WhatsApp Log`,details:`Sent message to ${e.phone}: "${n.length>50?n.slice(0,48)+`...`:n}"`}),a.value=``,u(t?.value||``),m(s,!1),f(`Message sent on WhatsApp!`,`ri-checkbox-circle-fill`)}catch{f(`Message logged to conversation`,`ri-information-line`)}finally{i.innerHTML=r,i.disabled=!1}}i?.addEventListener(`click`,h),a?.addEventListener(`keydown`,e=>{e.key===`Enter`&&(e.preventDefault(),h())}),t?.addEventListener(`input`,e=>u(e.target.value)),document.getElementById(`wa-refresh-leads`)?.addEventListener(`click`,()=>{l(),f(`WhatsApp Log refreshed!`,`ri-refresh-line`)}),await l();let g=c.keys().next().value;g&&d(g),window.waLivePollTimer&&clearInterval(window.waLivePollTimer),window.waLivePollTimer=setInterval(()=>{document.getElementById(`wa-chat-history`)?l():clearInterval(window.waLivePollTimer)},3e3)}function ot(){let e=r(),t=Object.values(e),n=Array.from(new Set(t.map(e=>e.category))).filter(Boolean);return`
    <div class="view-enter website-images-view">
      <!-- Header -->
      <div class="view-header-flex" style="margin-bottom: 24px;">
        <div>
          <div style="margin-bottom: 8px;">
            <span style="
              display: inline-flex; align-items: center; gap: 6px;
              font-size: 0.8rem; font-weight: 800; color: var(--os-luxury-orange);
              text-transform: uppercase; letter-spacing: 0.1em;
            ">
              <i class="ri-image-edit-line"></i> SITE ASSETS & BANNER MANAGEMENT
            </span>
          </div>
          <h1 class="view-title">Website Front-End Images</h1>
          <p class="view-subtitle">Customize and replace all static banners, cards, and section images displayed across the website.</p>
        </div>

        <div class="header-actions-right" style="gap: 12px;">
          <a href="/index.html" target="_blank" class="os-btn-secondary" style="display: inline-flex; align-items: center; gap: 8px; text-decoration: none;">
            <i class="ri-external-link-line"></i> View Live Website
          </a>
          <button class="os-btn-secondary" id="reset-all-site-images-btn" style="color: #e53e3e; border-color: rgba(229, 62, 62, 0.3);">
            <i class="ri-refresh-line"></i> Reset All Defaults
          </button>
        </div>
      </div>

      <!-- Info Banner Box explaining Pixel & Size info -->
      <div class="pixel-guidelines-banner" style="
        background: linear-gradient(135deg, rgba(235, 94, 40, 0.08) 0%, rgba(255, 255, 255, 0.9) 100%);
        border: 1px solid rgba(235, 94, 40, 0.25);
        border-radius: 16px;
        padding: 20px 24px;
        margin-bottom: 28px;
        display: flex;
        align-items: flex-start;
        gap: 18px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.03);
      ">
        <div style="
          width: 44px; height: 44px; border-radius: 12px; background: var(--color-orange, #eb5e28);
          color: white; display: flex; align-items: center; justify-content: center; font-size: 1.4rem; flex-shrink: 0;
        ">
          <i class="ri-ruler-2-line"></i>
        </div>
        <div style="flex: 1;">
          <h3 style="font-size: 1.05rem; font-weight: 700; color: #1a1a1a; margin-bottom: 6px; display: flex; align-items: center; gap: 8px;">
            Image Resolution & Aspect Ratio Guidelines
          </h3>
          <p style="font-size: 0.9rem; color: #555; line-height: 1.5; margin: 0;">
            To maintain crisp luxury visual quality on high-DPI retina displays and mobile phones, upload images matching the 
            <strong>recommended pixel dimensions (Width × Height)</strong> listed on each card. Uploaded local images or image URLs will automatically update the front-end homepage instantly!
          </p>
        </div>
      </div>
      <!-- Filter Controls & Category Dropdown -->
      <div class="os-filter-bar" style="margin-bottom: 28px; display: flex; gap: 16px;">
        <div class="search-box" style="flex: 1;">
          <i class="ri-search-line"></i>
          <input type="text" id="img-search-input" placeholder="Search by section, banner name, category..." style="width: 100%; border: none; background: transparent; outline: none;" />
        </div>

        <div style="width: 280px;">
          <select id="img-category-dropdown" style="width: 100%; height: 100%; padding: 10px 14px; border-radius: 8px; border: 1px solid var(--os-border); background: var(--os-gray-100); color: var(--os-text); font-size: 0.85rem; font-weight: 600; cursor: pointer; outline: none; appearance: none;">
            <option value="all">All Front-End Images (${t.length})</option>
            ${n.map(e=>`<option value="${e}">${e} (${t.filter(t=>t.category===e).length})</option>`).join(``)}
          </select>
        </div>
      </div>

      <!-- Website Images Grid -->
      <div class="website-images-grid" id="website-images-grid" style="
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(360px, 1fr));
        gap: 24px;
      ">
        ${t.map(e=>st(e)).join(``)}
      </div>
    </div>
  `}function st(e){return`
    <div class="site-img-card ${e.isCustom?`custom-active`:``}" data-id="${e.id}" data-category="${e.category}" style="
      background: #ffffff;
      border: 1px solid rgba(0,0,0,0.08);
      border-radius: 16px;
      overflow: hidden;
      display: flex;
      flex-direction: column;
      box-shadow: 0 4px 14px rgba(0,0,0,0.04);
      transition: all 0.25s ease;
    ">
      <!-- Card Top Info Header -->
      <div style="padding: 16px 20px 12px 20px; border-bottom: 1px solid rgba(0,0,0,0.05); display: flex; justify-content: space-between; align-items: flex-start;">
        <div>
          <span style="
            font-size: 0.72rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: var(--color-orange, #eb5e28);
          ">${e.category}</span>
          <h3 style="font-size: 1.05rem; font-weight: 700; color: #222; margin-top: 2px;">${e.title}</h3>
        </div>
        <span class="status-pill ${e.isCustom?`custom`:`default`}" style="
          font-size: 0.75rem; font-weight: 600; padding: 4px 10px; border-radius: 20px;
          background: ${e.isCustom?`#e6fffa`:`#f7fafc`};
          color: ${e.isCustom?`#234e52`:`#718096`};
          border: 1px solid ${e.isCustom?`#b2f5ea`:`#e2e8f0`};
          display: inline-flex; align-items: center; gap: 4px;
        ">
          <i class="${e.isCustom?`ri-edit-line`:`ri-check-line`}"></i>
          ${e.isCustom?`Custom Image`:`Default`}
        </span>
      </div>

      <!-- Preview Image Frame -->
      <div class="preview-img-container" style="
        position: relative; width: 100%; height: 190px; background: #1a1a1a; overflow: hidden;
      ">
        <img 
          src="${e.currentUrl}" 
          alt="${e.title}" 
          id="preview-img-${e.id}"
          style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.3s ease;"
          onerror="this.src='https://via.placeholder.com/800x450?text=Invalid+Image+URL';"
        />

        <!-- Overlay Badge for Dimensions -->
        <div style="
          position: absolute; bottom: 10px; right: 10px;
          background: rgba(0,0,0,0.75); backdrop-filter: blur(8px);
          color: #ffffff; font-size: 0.78rem; font-weight: 600; padding: 4px 10px;
          border-radius: 6px; display: flex; align-items: center; gap: 6px;
        ">
          <i class="ri-aspect-ratio-line" style="color: #ff9f1c;"></i>
          <span>${e.recommendedWidth} × ${e.recommendedHeight} px (${e.aspectRatio})</span>
        </div>
      </div>

      <!-- Specifications Box (Required Info of Size / Pixels) -->
      <div style="padding: 14px 20px; background: #fdfbf7; border-bottom: 1px solid rgba(0,0,0,0.05);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 0.82rem;">
          <div>
            <span style="color: #777; display: block; font-size: 0.72rem; text-transform: uppercase;">Pixel Size</span>
            <strong style="color: #222; font-weight: 700;">${e.recommendedWidth} × ${e.recommendedHeight} px</strong>
          </div>
          <div>
            <span style="color: #777; display: block; font-size: 0.72rem; text-transform: uppercase;">Aspect Ratio</span>
            <strong style="color: #222; font-weight: 700;">${e.aspectRatio}</strong>
          </div>
          <div>
            <span style="color: #777; display: block; font-size: 0.72rem; text-transform: uppercase;">Format</span>
            <strong style="color: #222; font-weight: 600;">${e.format}</strong>
          </div>
          <div>
            <span style="color: #777; display: block; font-size: 0.72rem; text-transform: uppercase;">Max File Size</span>
            <strong style="color: #222; font-weight: 600;">${e.maxSize}</strong>
          </div>
        </div>
        <p style="font-size: 0.8rem; color: #666; margin-top: 10px; margin-bottom: 0; line-height: 1.4;">
          ${e.description}
        </p>
      </div>

      <!-- Controls Form Area -->
      <div style="padding: 16px 20px; display: flex; flex-direction: column; gap: 12px; margin-top: auto;">
        
        <!-- URL Input -->
        <div>
          <label style="font-size: 0.78rem; font-weight: 700; color: #444; margin-bottom: 4px; display: block;">
            Image URL
          </label>
          <input 
            type="url" 
            id="input-url-${e.id}" 
            value="${e.currentUrl}" 
            placeholder="https://example.com/image.jpg"
            style="
              width: 100%; padding: 8px 12px; font-size: 0.85rem; border-radius: 8px;
              border: 1px solid #cbd5e0; background: #ffffff; outline: none; transition: border-color 0.2s;
            "
          />
        </div>

        <!-- File Upload Button & Action Controls -->
        <div style="display: flex; gap: 8px; align-items: center;">
          <!-- Custom File Input -->
          <label style="
            flex: 1; cursor: pointer; padding: 8px 12px; border-radius: 8px;
            background: #f7fafc; border: 1px dashed #cbd5e0; color: #4a5568;
            font-size: 0.82rem; font-weight: 600; display: inline-flex; align-items: center; justify-content: center; gap: 6px;
            transition: background 0.2s;
          " class="file-upload-label" title="Upload image file from your computer">
            <i class="ri-upload-cloud-2-line" style="font-size: 1.05rem; color: var(--color-orange, #eb5e28);"></i>
            <span>Upload File</span>
            <input type="file" id="file-input-${e.id}" accept="image/*" style="display: none;" class="site-img-file-input" data-id="${e.id}" />
          </label>

          <!-- Apply / Save Button -->
          <button 
            class="os-btn-primary save-img-btn" 
            data-id="${e.id}"
            style="padding: 8px 16px; font-size: 0.85rem; height: 36px;"
          >
            <i class="ri-save-line"></i> Save
          </button>

          <!-- Reset Button -->
          ${e.isCustom?`
            <button 
              class="reset-img-btn" 
              data-id="${e.id}"
              title="Reset to default image"
              style="
                width: 36px; height: 36px; border-radius: 8px; border: 1px solid #e2e8f0;
                background: #ffffff; color: #e53e3e; display: flex; align-items: center; justify-content: center;
                cursor: pointer; transition: all 0.2s;
              "
            >
              <i class="ri-refresh-line"></i>
            </button>
          `:``}
        </div>

      </div>
    </div>
  `}function ct(){let t=document.getElementById(`img-search-input`),n=document.getElementById(`img-category-dropdown`);function r(){let e=(t?.value||``).toLowerCase().trim(),r=n?.value||`all`;document.querySelectorAll(`.site-img-card`).forEach(t=>{let n=t.textContent.toLowerCase(),i=t.dataset.category;(e===``||n.includes(e))&&(r===`all`||i===r)?t.style.display=`flex`:t.style.display=`none`})}t?.addEventListener(`input`,r),n?.addEventListener(`change`,r),document.querySelectorAll(`.site-img-file-input`).forEach(e=>{e.addEventListener(`change`,t=>{let n=t.target.files[0],r=e.dataset.id;if(!n||!r)return;if(n.size>5242880){lt(`Image file size exceeds 5MB limit. Please upload a smaller image.`,`ri-error-warning-line`);return}let i=new FileReader;i.onload=function(e){let t=e.target.result,n=document.getElementById(`input-url-${r}`),i=document.getElementById(`preview-img-${r}`);n&&(n.value=t),i&&(i.src=t),lt(`Image loaded from file. Click 'Save' to apply changes.`,`ri-check-line`)},i.readAsDataURL(n)})}),document.querySelectorAll(`.save-img-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.id,n=document.getElementById(`input-url-${t}`);if(!t||!n)return;let r=n.value.trim();if(!r){lt(`Please provide a valid image URL or upload a file.`,`ri-alert-line`);return}if(i(t,r)){lt(`Website image updated successfully!`,`ri-checkbox-circle-fill`);let e=document.getElementById(`os-content`);e&&(e.innerHTML=ot(),ct())}})}),document.querySelectorAll(`.reset-img-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.id;if(t&&p(t)){lt(`Image restored to default!`,`ri-refresh-line`);let e=document.getElementById(`os-content`);e&&(e.innerHTML=ot(),ct())}})}),document.getElementById(`reset-all-site-images-btn`)?.addEventListener(`click`,()=>{v({title:`Reset All Website Images`,message:`Are you sure you want to reset <strong>ALL custom website images</strong> back to factory defaults? Any custom uploaded banners will be replaced.`,confirmText:`Reset Defaults`,cancelText:`Keep Current`,confirmIcon:`ri-refresh-line`,isDanger:!0,onConfirm:()=>{e(),lt(`All website images restored to factory defaults.`,`ri-refresh-line`);let t=document.getElementById(`os-content`);t&&(t.innerHTML=ot(),ct())}})})}function lt(e,t=`ri-notification-line`){let n=document.getElementById(`os-toast-container`);n||(n=document.createElement(`div`),n.id=`os-toast-container`,n.style.cssText=`
      position: fixed; bottom: 24px; right: 24px; z-index: 9999;
      display: flex; flex-direction: column; gap: 10px; pointer-events: none;
    `,document.body.appendChild(n));let r=document.createElement(`div`);r.style.cssText=`
    background: #1a1a1a; color: #ffffff; padding: 12px 20px; border-radius: 10px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.25); font-size: 0.9rem; font-weight: 500;
    display: flex; align-items: center; gap: 10px; pointer-events: auto;
    animation: slideUp 0.3s cubic-bezier(0.16, 1, 0.3, 1);
  `,r.innerHTML=`<i class="${t}" style="color: var(--color-orange, #eb5e28); font-size: 1.15rem;"></i> <span>${e}</span>`,n.appendChild(r),setTimeout(()=>{r.style.opacity=`0`,r.style.transform=`translateY(10px)`,r.style.transition=`all 0.3s ease`,setTimeout(()=>r.remove(),300)},3500)}function ut(){let e=n(),t=e=>{let t=(e||``).toLowerCase();return t.includes(`image`)?{bg:`rgba(235, 94, 40, 0.1)`,color:`#eb5e28`,icon:`ri-image-line`}:t.includes(`prop`)?{bg:`#FEF3C7`,color:`#B45309`,icon:`ri-building-line`}:t.includes(`crm`)||t.includes(`lead`)||t.includes(`pipeline`)?{bg:`#DBEAFE`,color:`#1D4ED8`,icon:`ri-user-shared-line`}:t.includes(`blog`)||t.includes(`cms`)?{bg:`#F3E8FF`,color:`#7E22CE`,icon:`ri-article-line`}:t.includes(`whatsapp`)||t.includes(`chat`)?{bg:`#DCFCE7`,color:`#15803D`,icon:`ri-whatsapp-line`}:t.includes(`visit`)?{bg:`#CFFAFE`,color:`#0E7490`,icon:`ri-calendar-check-line`}:t.includes(`partner`)?{bg:`#E0E7FF`,color:`#4338CA`,icon:`ri-team-line`}:t.includes(`user`)||t.includes(`staff`)||t.includes(`admin`)?{bg:`#FFE4E6`,color:`#BE123C`,icon:`ri-shield-user-line`}:{bg:`#F1F5F9`,color:`#475569`,icon:`ri-settings-4-line`}};return`
    <div class="view-enter audit-log-view">
      <style>
        .audit-filter-btn {
          padding: 6px 14px;
          border-radius: 20px;
          border: 1px solid #e2e8f0;
          background: #fff;
          color: #4a5568;
          font-size: 0.82rem;
          font-weight: 700;
          cursor: pointer;
          transition: all 0.2s;
        }
        .audit-filter-btn:hover {
          background: #f7fafc;
          border-color: #cbd5e0;
        }
        .audit-filter-btn.active {
          background: #1a202c;
          color: #fff;
          border-color: #1a202c;
        }
      </style>
      <div style="display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 16px; margin-bottom: 24px;">
        <div>
          <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px;">
            <span class="badge badge-dark" style="font-size: 0.75rem;">
              <i class="ri-history-line"></i> SECURITY & SYSTEM AUDIT TRAIL
            </span>
          </div>
          <h1 class="view-title" style="margin: 4px 0;">Audit Log</h1>
          <p class="view-subtitle" style="margin: 0;">Track all administrative activities, CRM lead actions, WhatsApp dispatches, property updates, and system changes.</p>
        </div>

        <div style="display: flex; gap: 12px; align-items: center;">
          <button class="os-btn-secondary" id="clear-audit-btn" style="display: inline-flex; align-items: center; gap: 6px; color: #E53E3E; border-color: #FED7D7; background: #FFF5F5;">
            <i class="ri-delete-bin-line"></i> Clear Logs
          </button>
          <button class="os-btn-secondary" id="export-audit-btn" style="display: inline-flex; align-items: center; gap: 6px;">
            <i class="ri-download-2-line"></i> Export Audit Log
          </button>
        </div>
      </div>

      <!-- Filter Controls -->
      <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px; margin-bottom: 24px;">
        <div class="search-box" style="flex: 1; min-width: 280px; max-width: 380px; display: flex; align-items: center; gap: 8px; background: #fff; padding: 8px 14px; border: 1px solid var(--os-border); border-radius: 8px;">
          <i class="ri-search-line" style="color: var(--os-gray-400);"></i>
          <input type="text" id="audit-search-input" placeholder="Search logs by action, user, or module..." style="border: none; outline: none; width: 100%; font-size: 0.85rem;" />
        </div>
        
        <div style="display: flex; gap: 6px; flex-wrap: wrap;">
          <button class="audit-filter-btn active" data-module="all">All Modules (${e.length})</button>
          <button class="audit-filter-btn" data-module="CRM Pipeline">CRM Pipeline</button>
          <button class="audit-filter-btn" data-module="WhatsApp Log">WhatsApp</button>
          <button class="audit-filter-btn" data-module="Properties Inventory">Properties</button>
          <button class="audit-filter-btn" data-module="Blog CMS">Blog CMS</button>
          <button class="audit-filter-btn" data-module="Site Visits">Site Visits</button>
          <button class="audit-filter-btn" data-module="Partners Network">Partners</button>
          <button class="audit-filter-btn" data-module="Portal Users">Users & Access</button>
          <button class="audit-filter-btn" data-module="Website Images">Website Images</button>
        </div>
      </div>

      <!-- Audit Logs Table -->
      <div style="
        background: #ffffff;
        border-radius: 16px;
        border: 1px solid rgba(0,0,0,0.08);
        overflow-x: auto;
        overflow-y: hidden;
        box-shadow: 0 4px 16px rgba(0,0,0,0.03);
      ">
        <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 0.9rem;">
          <thead>
            <tr style="background: #fdfbf7; border-bottom: 1px solid rgba(0,0,0,0.06); font-size: 0.8rem; text-transform: uppercase; color: #666; letter-spacing: 0.05em;">
              <th style="padding: 16px 20px;">Timestamp</th>
              <th style="padding: 16px 20px;">Admin User</th>
              <th style="padding: 16px 20px;">Action</th>
              <th style="padding: 16px 20px;">Module</th>
              <th style="padding: 16px 20px;">Details & Changes</th>
            </tr>
          </thead>
          <tbody id="audit-log-rows">
            ${e.length===0?`
              <tr>
                <td colspan="5" style="padding: 40px 20px; text-align: center; color: #888;">
                  <i class="ri-history-line" style="font-size: 2.5rem; color: #ccc; display: block; margin-bottom: 8px;"></i>
                  <p style="font-weight: 600;">No audit logs recorded yet.</p>
                </td>
              </tr>
            `:e.map(e=>{let n=t(e.module);return`
                <tr class="audit-row" data-module="${e.module||``}" style="border-bottom: 1px solid rgba(0,0,0,0.04); transition: background 0.15s;">
                  <td style="padding: 16px 20px; white-space: nowrap; color: #555; font-size: 0.85rem; font-weight: 500;">
                    <i class="ri-time-line" style="color: #999; margin-right: 4px;"></i>
                    ${e.timestamp||`Just now`}
                  </td>
                  <td style="padding: 16px 20px; font-weight: 600; color: #222; white-space: nowrap;">
                    <div style="display: flex; align-items: center; gap: 8px;">
                      <div style="
                        width: 28px; height: 28px; border-radius: 50%; background: #2A1808; color: #F8F4EC;
                        font-size: 0.72rem; font-weight: 700; display: flex; align-items: center; justify-content: center; flex-shrink: 0;
                      ">${(e.user||`AD`).slice(0,2).toUpperCase()}</div>
                      <span>${e.user||`Admin`}</span>
                    </div>
                  </td>
                  <td style="padding: 16px 20px; font-weight: 700; color: #1a1a1a;">
                    ${e.action||`System Action`}
                  </td>
                  <td style="padding: 16px 20px;">
                    <span style="
                      font-size: 0.75rem; font-weight: 700; padding: 4px 10px; border-radius: 12px;
                      display: inline-flex; align-items: center; gap: 4px; white-space: nowrap;
                      background: ${n.bg};
                      color: ${n.color};
                    "><i class="${n.icon}"></i> ${e.module||`System`}</span>
                  </td>
                  <td style="padding: 16px 20px; color: #555; font-size: 0.88rem; max-width: 380px;">
                    ${e.details||``}
                  </td>
                </tr>
              `}).join(``)}
          </tbody>
        </table>
      </div>
    </div>
  `}function dt(){document.getElementById(`audit-search-input`)?.addEventListener(`input`,e=>{let t=e.target.value.toLowerCase().trim();document.querySelectorAll(`.audit-row`).forEach(e=>{e.textContent.toLowerCase().includes(t)?e.style.display=``:e.style.display=`none`})});let e=document.querySelectorAll(`.audit-filter-btn`);e.forEach(t=>{t.addEventListener(`click`,()=>{e.forEach(e=>e.classList.remove(`active`)),t.classList.add(`active`);let n=(t.dataset.module||`all`).toLowerCase();document.querySelectorAll(`.audit-row`).forEach(e=>{let t=(e.dataset.module||``).toLowerCase();n===`all`||t.includes(n)||n===`portal users`&&(t.includes(`user`)||t.includes(`staff`))?e.style.display=``:e.style.display=`none`})})}),document.getElementById(`export-audit-btn`)?.addEventListener(`click`,()=>{let e=n();if(!e||e.length===0){f(`No audit logs available to export.`,`ri-information-line`);return}let t=`Timestamp,User,Action,Module,Details
`;e.forEach(e=>{let n=`"${(e.timestamp||``).replace(/"/g,`""`)}"`,r=`"${(e.user||``).replace(/"/g,`""`)}"`,i=`"${(e.action||``).replace(/"/g,`""`)}"`,a=`"${(e.module||``).replace(/"/g,`""`)}"`,o=`"${(e.details||``).replace(/"/g,`""`)}"`;t+=`${n},${r},${i},${a},${o}\n`});let r=new Blob([t],{type:`text/csv;charset=utf-8;`}),i=document.createElement(`a`);i.href=URL.createObjectURL(r),i.download=`Thanjai_Property_Audit_Log_${new Date().toISOString().slice(0,10)}.csv`,i.click(),f(`Audit Log CSV exported successfully!`,`ri-download-2-line`)});let t=document.getElementById(`clear-audit-btn`);t&&t.addEventListener(`click`,()=>{v({title:`Clear All Audit Logs`,message:`Are you sure you want to delete <strong>all administrative audit logs</strong>? This action cannot be undone.`,confirmText:`Clear All Logs`,isDestructive:!0,onConfirm:()=>{c(),f(`Audit logs cleared`,`ri-checkbox-circle-fill`);let e=document.getElementById(`audit-log-rows`);e&&(e.innerHTML=`
              <tr>
                <td colspan="5" style="padding: 40px 20px; text-align: center; color: #888;">
                  <i class="ri-history-line" style="font-size: 2.5rem; color: #ccc; display: block; margin-bottom: 8px;"></i>
                  <p style="font-weight: 600;">No audit logs recorded yet.</p>
                </td>
              </tr>
            `)}})})}var ft=`modulepreload`,pt=function(e){return`/`+e},mt={},ht=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}function s(e){return import.meta.resolve?import.meta.resolve(e):new URL(e,import.meta.url).href}r=o(t.map(t=>{if(t=pt(t,n),t=s(t),t in mt)return;mt[t]=!0;let r=t.endsWith(`.css`);for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}let i=document.createElement(`link`);if(i.rel=r?`stylesheet`:ft,r||(i.as=`script`),i.crossOrigin=``,i.href=t,a&&i.setAttribute(`nonce`,a),document.head.appendChild(i),r)return new Promise((e,n)=>{i.addEventListener(`load`,e),i.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})};function gt(e){let t=JSON.parse(localStorage.getItem(`thanjai_leads`))||[],n=t.find(t=>t.id==e);if(!n)return`
      <div style="padding: 40px; text-align: center;">
        <h2>Lead not found</h2>
        <button class="os-btn-secondary" onclick="window.location.hash='leads'">Back to Leads</button>
      </div>
    `;let r=!1;if(typeof n.notes==`string`){if(n.notes.trim()!==``)try{let e=JSON.parse(n.notes);n.notes=Array.isArray(e)?e:[{text:n.notes,date:n.createdAt||new Date().toISOString()}]}catch{n.notes=[{text:n.notes,date:n.createdAt||new Date().toISOString()}]}else n.notes=[];r=!0}if(typeof n.timeline==`string`){if(n.timeline.trim()!==``&&n.timeline!==`—`)try{let e=JSON.parse(n.timeline);n.timeline=Array.isArray(e)?e:[{type:`pipeline`,message:`Follow-up: `+n.timeline,author:n.assignTo||`System`,date:n.createdAt||new Date().toISOString()}]}catch{n.timeline=[{type:`pipeline`,message:`Follow-up: `+n.timeline,author:n.assignTo||`System`,date:n.createdAt||new Date().toISOString()}]}else n.timeline=[];r=!0}r&&Z(t,e);let i=e=>e?`₹`+parseInt(e).toLocaleString(`en-IN`):`—`,a=[{label:`New Lead`,wa:!1},{label:`Initial Contact`,wa:!0},{label:`Requirement Analysis`,wa:!1},{label:`Property Matching`,wa:!1},{label:`Shared To Partner (use Share to partner below)`,val:`Shared To Partner`,wa:!1,style:`color: var(--os-gray-400);`},{label:`Property Shared`,wa:!1},{label:`Follow Up Pending`,wa:!0},{label:`Site Visit Scheduled`,wa:!0},{label:`Site Visit Completed`,wa:!0},{label:`Negotiation`,wa:!0},{label:`Bank Loan`,wa:!0},{label:`Registration`,wa:!0},{label:`Lost Closed`,wa:!1}],o=``,s=n.status||`Requirement Analysis`;return a.forEach(e=>{let t=(e.val||e.label)===s?`selected`:``,n=e.style||``,r=t?`style="background: #2563eb; color: #fff;"`:n?`style="${n}"`:``,i=e.wa?` <i class="ri-mail-line" style="font-size: 0.8rem; vertical-align: middle;"></i> sends WhatsApp`:``;o+=`          <div class="select-option ${t}" ${r}>${e.label}${i}</div>\n`}),`
    <div class="lead-detail-page">
      <div class="ld-back-nav" style="margin-bottom: 24px;">
        <a href="#leads" style="color: var(--os-gray-500); text-decoration: none; font-weight: 500; display: inline-flex; align-items: center; gap: 8px;">
          <i class="ri-arrow-left-line"></i> Back to leads
        </a>
      </div>

      <div class="ld-header" style="margin-bottom: 24px;">
        <h1 style="font-size: 1.8rem; font-weight: 700; color: var(--os-dark); margin-bottom: 8px;">${n.name}</h1>
        <div class="ld-badges" style="display: flex; gap: 12px; align-items: center;">
          <span style="border: 1px solid #14b8a6; color: #14b8a6; padding: 2px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 600; text-transform: uppercase;">${n.status||`Contacted`}</span>
          <span style="color: var(--os-gray-500); font-size: 0.9rem;">Stage: Requirement Analysis</span>
        </div>
      </div>

      <div class="ld-stage-selector os-custom-select" style="width: 100%; padding: 0; border: var(--os-border-thin); border-radius: var(--os-radius-sm); margin-bottom: 24px;">
        <div class="select-value" style="padding: 12px 16px; font-weight: 500; color: var(--os-dark);">${n.status||`Requirement Analysis`}</div>
        <i class="ri-arrow-down-s-line" style="position: absolute; right: 16px; top: 14px; color: var(--os-gray-500);"></i>
        <div class="select-dropdown" style="top: 100%; left: 0; right: 0; border-radius: 0 0 8px 8px; border: 1px solid var(--os-luxury-orange); margin-top: -1px; box-shadow: var(--os-shadow-md);">
${o}        </div>
      </div>

      <div class="ld-action-toolbar" style="display: flex; gap: 12px; margin-bottom: 32px; flex-wrap: wrap;">
        <div class="os-custom-select" id="ld-assign-dropdown" style="min-width: 150px; background: var(--os-white);">
          <div class="select-value">${n.assignTo&&n.assignTo!==`Unassigned`?n.assignTo:`Assign to...`}</div>
          <i class="ri-arrow-down-s-line"></i>
          <div class="select-dropdown">
${(()=>{let e=JSON.parse(localStorage.getItem(`thanjai_admin_users`))||[],t=`<div class="select-option ${!n.assignTo||n.assignTo===`Unassigned`?`selected`:``}">Assign to...</div>`;return e.length>0?e.filter(e=>e.status===`Active`).forEach(e=>{t+=`<div class="select-option ${n.assignTo===e.fullName?`selected`:``}">${e.fullName}</div>`}):t+=`<div class="select-option" style="color:var(--os-gray-400);">No staff found</div>`,t})()}
          </div>
        </div>
        <button class="os-btn-primary" id="btn-send-whatsapp" style="background: #f97316; border-color: #f97316; display: flex; align-items: center; gap: 8px;">
          <i class="ri-send-plane-fill"></i> Send WhatsApp
        </button>
        <button class="os-btn-secondary" id="btn-schedule-visit" style="background: var(--os-white); display: flex; align-items: center; gap: 8px;">
          <i class="ri-calendar-event-line"></i> Schedule visit
        </button>
        <button class="os-btn-secondary" id="btn-edit-lead" style="background: var(--os-white);">
          Edit
        </button>
        <button class="os-btn-secondary" id="btn-share-partner" style="background: var(--os-white);">
          Share to partner
        </button>
      </div>

      <div class="ld-content-grid" style="display: grid; grid-template-columns: 350px 1fr; gap: 24px; align-items: start;">
        
        <div class="ld-left-col" style="display: flex; flex-direction: column; gap: 24px;">
          <div class="os-card" style="padding: 24px; background: var(--os-white); border-radius: var(--os-radius-xl); box-shadow: var(--os-shadow-soft);">
            <h3 style="font-size: 1rem; font-weight: 600; color: var(--os-dark); margin-bottom: 20px;">Lead details</h3>
            <table class="ld-details-table" style="width: 100%; border-collapse: collapse; font-size: 0.9rem;">
              <tbody>
                <tr><td style="padding: 8px 0; color: var(--os-gray-500);">Mobile</td><td style="padding: 8px 0; text-align: right; font-weight: 500;">${n.mobile||`—`}</td></tr>
                <tr><td style="padding: 8px 0; color: var(--os-gray-500);">WhatsApp</td><td style="padding: 8px 0; text-align: right; font-weight: 500;">${n.whatsapp||n.mobile||`—`}</td></tr>
                <tr><td style="padding: 8px 0; color: var(--os-gray-500);">Email</td><td style="padding: 8px 0; text-align: right; font-weight: 500;">${n.email||`—`}</td></tr>
                <tr><td style="padding: 8px 0; color: var(--os-gray-500);">Country</td><td style="padding: 8px 0; text-align: right; font-weight: 500;">${n.country||`—`}</td></tr>
                <tr><td style="padding: 8px 0; color: var(--os-gray-500);">City / area</td><td style="padding: 8px 0; text-align: right; font-weight: 500;">${n.city||n.area||`—`}</td></tr>
                <tr><td style="padding: 8px 0; color: var(--os-gray-500);">Budget</td><td style="padding: 8px 0; text-align: right; font-weight: 500;">${i(n.budgetMax)}</td></tr>
                <tr><td style="padding: 8px 0; color: var(--os-gray-500);">Property type</td><td style="padding: 8px 0; text-align: right; font-weight: 500;">${n.type||`—`}</td></tr>
                <tr><td style="padding: 8px 0; color: var(--os-gray-500);">Source</td><td style="padding: 8px 0; text-align: right; font-weight: 500;"><span style="border: 1px solid var(--os-gray-300); color: var(--os-gray-600); padding: 2px 6px; border-radius: 4px; font-size: 0.7rem; text-transform: uppercase;">${n.source||`MANUAL`}</span></td></tr>
                <tr><td style="padding: 8px 0; color: var(--os-gray-500);">Priority</td><td style="padding: 8px 0; text-align: right; font-weight: 500;"><span style="border: 1px solid #3b82f6; color: #3b82f6; padding: 2px 6px; border-radius: 4px; font-size: 0.7rem; text-transform: uppercase;">MEDIUM</span></td></tr>
                <tr><td style="padding: 8px 0; color: var(--os-gray-500);">Assigned to</td><td style="padding: 8px 0; text-align: right; font-weight: 500;">${n.assignTo||`Unassigned`}</td></tr>
                <tr><td style="padding: 8px 0; color: var(--os-gray-500);">Created</td><td style="padding: 8px 0; text-align: right; font-weight: 500;">12 Aug 2026, 12:08</td></tr>
              </tbody>
            </table>
          </div>

          <div class="os-card" style="padding: 24px; background: var(--os-white); border-radius: var(--os-radius-xl); box-shadow: var(--os-shadow-soft);">
            <h3 style="font-size: 1rem; font-weight: 600; color: var(--os-dark); margin-bottom: 16px;">Set follow-up</h3>
            <div style="display: flex; gap: 12px;">
              <input type="datetime-local" id="follow-up-datetime" class="os-input" style="flex: 1;" />
              <button id="btn-set-follow-up" class="os-btn-secondary" style="background: #fcd34d; border-color: #fcd34d; color: #92400e;">Set</button>
            </div>
          </div>

          <div class="os-card" style="padding: 24px; background: var(--os-white); border-radius: var(--os-radius-xl); box-shadow: var(--os-shadow-soft);">
            <h3 style="font-size: 1rem; font-weight: 600; color: var(--os-dark); margin-bottom: 16px;">Notes</h3>
            <textarea id="ld-note-input" class="os-input" rows="3" placeholder="Add an internal note..." style="width: 100%; margin-bottom: 12px; resize: vertical;"></textarea>
            <button id="ld-add-note-btn" class="os-btn-secondary" style="background: #fed7aa; border-color: #fed7aa; color: #9a3412;">Add note</button>
            <div id="ld-notes-list" style="margin-top: 16px; max-height: 300px; overflow-y: auto;">
              ${Array.isArray(n.notes)&&n.notes.length>0?n.notes.map((e,t)=>`
                    <div style="background: #f8fafc; padding: 12px; border-radius: 6px; margin-bottom: 8px; border-left: 3px solid #fed7aa; position: relative;">
                      <p style="font-size: 0.9rem; color: var(--os-dark); margin-bottom: 8px; padding-right: 40px;">${typeof e==`string`?e:e.text}</p>
                      <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-size: 0.75rem; color: var(--os-gray-400);"><i class="ri-calendar-line"></i> ${e.date?new Date(e.date).toLocaleString([],{year:`numeric`,month:`short`,day:`numeric`,hour:`2-digit`,minute:`2-digit`}):`Just now`}</span>
                        <div style="display: flex; gap: 8px;">
                          <button class="note-action-btn" data-action="edit" data-index="${t}" style="background: none; border: none; cursor: pointer; color: var(--os-gray-500); padding: 2px;" title="Edit Note"><i class="ri-edit-line"></i></button>
                          <button class="note-action-btn" data-action="delete" data-index="${t}" style="background: none; border: none; cursor: pointer; color: var(--os-error); padding: 2px;" title="Delete Note"><i class="ri-delete-bin-line"></i></button>
                        </div>
                      </div>
                    </div>
                  `).join(``):typeof n.notes==`string`&&n.notes.trim()!==``?`
                    <div style="background: #f8fafc; padding: 12px; border-radius: 6px; margin-bottom: 8px; border-left: 3px solid #fed7aa; position: relative;">
                      <p style="font-size: 0.9rem; color: var(--os-dark); margin-bottom: 8px; padding-right: 40px;">${n.notes}</p>
                    </div>
                  `:`<p style="font-size: 0.85rem; color: var(--os-gray-400);">No notes yet.</p>`}
            </div>
          </div>
        </div>

        <div class="ld-right-col" style="display: flex; flex-direction: column; gap: 24px;">
          
          <div class="os-card" style="padding: 24px; background: var(--os-white); border-radius: var(--os-radius-xl); box-shadow: var(--os-shadow-soft);">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
              <h3 style="font-size: 1rem; font-weight: 600; color: var(--os-dark);">Matching properties</h3>
              <button class="os-btn-secondary" id="btn-find-matches" style="font-size: 0.85rem; padding: 4px 12px; height: auto;"><i class="ri-search-line"></i> Find matches</button>
            </div>
            <div style="display: flex; gap: 12px; margin-bottom: 16px;">
              <input type="text" class="os-input" id="matching-properties-search" placeholder="Search properties by title, location or description..." style="flex: 1;" />
              <button class="os-btn-secondary" id="btn-search-matches">Search</button>
            </div>
            <div id="matching-properties-results">
              <p style="font-size: 0.9rem; color: var(--os-gray-500); line-height: 1.5;">Click "Find matches" to score current inventory against this lead's requirements, or search properties manually above.</p>
            </div>
          </div>

          <div class="os-card" style="background: var(--os-white); border-radius: var(--os-radius-xl); box-shadow: var(--os-shadow-soft); overflow: hidden;">
            <div class="ld-tabs" style="display: flex; border-bottom: 1px solid var(--os-gray-200); padding: 0 16px;">
              <div class="ld-tab active" data-target="pane-timeline" style="padding: 16px; font-size: 0.9rem; font-weight: 500; color: #ea580c; border-bottom: 2px solid #ea580c; cursor: pointer;">Activity timeline</div>
              <div class="ld-tab" data-target="pane-whatsapp" style="padding: 16px; font-size: 0.9rem; font-weight: 500; color: var(--os-gray-500); cursor: pointer;">WhatsApp (${n.timeline&&n.timeline.filter(e=>e.type===`whatsapp`).length||0})</div>
              <div class="ld-tab" data-target="pane-partner" style="padding: 16px; font-size: 0.9rem; font-weight: 500; color: var(--os-gray-500); cursor: pointer;">Partner shares (0)</div>
              <div class="ld-tab" data-target="pane-pipeline" style="padding: 16px; font-size: 0.9rem; font-weight: 500; color: var(--os-gray-500); cursor: pointer;">Pipeline history</div>
            </div>
            
            <div class="ld-tab-content" style="padding: 24px;">
              
              <div class="ld-tab-pane" id="pane-timeline" style="display: block;">
                ${!n.timeline||n.timeline.length===0?`<p style="color: var(--os-gray-400); font-size: 0.9rem;">No activity recorded yet.</p>`:`
                <div class="timeline" style="position: relative; padding-left: 20px;">
                  <div style="position: absolute; left: 6px; top: 8px; bottom: 0; width: 2px; background: #fed7aa;"></div>
                  ${n.timeline.map(e=>`
                    <div class="timeline-item" style="position: relative; margin-bottom: 24px;">
                      <div style="position: absolute; left: -20px; top: 4px; width: 10px; height: 10px; border-radius: 50%; background: ${e.type===`whatsapp`?`#16a34a`:`#ea580c`}; border: 2px solid var(--os-white);"></div>
                      <div style="font-weight: 500; color: ${e.type===`whatsapp`?`#16a34a`:`var(--os-dark)`}; font-size: 0.95rem; margin-bottom: 4px;">${e.message}</div>
                      <div style="font-size: 0.8rem; color: var(--os-gray-400);">${e.author} - ${new Date(e.date).toLocaleString([],{year:`numeric`,month:`short`,day:`numeric`,hour:`2-digit`,minute:`2-digit`})}</div>
                    </div>
                  `).join(``)}
                </div>
                `}
              </div>

              <!-- WhatsApp Tab -->
              <div class="ld-tab-pane" id="pane-whatsapp" style="display: none; background: #eae6df; padding: 20px; border-radius: 8px;">
                ${!n.timeline||!n.timeline.find(e=>e.type===`whatsapp`)?`<p style="text-align: center; color: #555; font-size: 0.9rem;">No WhatsApp history.</p>`:`
                <div style="text-align: center; margin-bottom: 16px;">
                  <span style="background: #fff; padding: 4px 12px; border-radius: 12px; font-size: 0.8rem; color: #555;">Logs</span>
                </div>
                ${n.timeline.filter(e=>e.type===`whatsapp`).map(e=>`
                  <div style="background: #dcf8c6; padding: 12px; border-radius: 8px; margin-bottom: 16px; position: relative;">
                    <div style="font-size: 0.8rem; color: #16a34a; margin-bottom: 4px;">Sent by ${e.author}</div>
                    <div style="font-size: 0.95rem; color: #1f2937; line-height: 1.4;">${e.message}</div>
                    <div style="text-align: right; font-size: 0.75rem; color: #6b7280; margin-top: 4px;">${new Date(e.date).toLocaleString([],{year:`numeric`,month:`short`,day:`numeric`,hour:`2-digit`,minute:`2-digit`})} <span style="color: #16a34a; font-weight: bold; margin-left: 4px;">✓</span></div>
                  </div>
                `).join(``)}
                `}
              </div>

              <!-- Pipeline History Tab -->
              <div class="ld-tab-pane" id="pane-pipeline" style="display: none;">
                ${!n.timeline||!n.timeline.find(e=>e.type===`pipeline`)?`<p style="color: var(--os-gray-400); font-size: 0.9rem;">No pipeline history.</p>`:`
                  ${n.timeline.filter(e=>e.type===`pipeline`).map(e=>{let t=e.message.replace(`Moved from `,``).split(` to `);return`
                     <div style="margin-bottom: 16px;">
                       <span style="color: var(--os-gray-500);">${t[0]||``} <i class="ri-arrow-right-line" style="vertical-align: middle;"></i></span> <span style="color: var(--os-dark); font-weight: 500;">${t[1]||``}</span>
                       <span style="color: var(--os-gray-400); font-size: 0.85rem; margin-left: 8px;">${e.author} · ${new Date(e.date).toLocaleString([],{year:`numeric`,month:`short`,day:`numeric`,hour:`2-digit`,minute:`2-digit`})}</span>
                     </div>
                     `}).join(``)}
                `}
              </div>

              <!-- Partner shares Tab -->
              <div class="ld-tab-pane" id="pane-partner" style="display: none;">
                 <p style="color: var(--os-gray-400); font-size: 0.9rem;">No partner shares yet.</p>
              </div>

            </div>
          </div>

        </div>
      </div>
    </div>

    <!-- Modals for Lead Detail -->
    <!-- Edit Lead Modal -->
    <div class="os-modal-overlay" id="edit-lead-modal">
      <div class="os-modal-card">
        <div class="os-modal-header">
          <h2>Edit lead</h2>
          <button class="os-modal-close" id="close-edit-modal"><i class="ri-close-line"></i></button>
        </div>
        <div class="os-modal-body">
          <form id="edit-lead-form">
            <input type="hidden" id="edit-lead-id" value="${n.id}" />
            <div class="form-section-title">CONTACT</div>
            <div class="form-row">
              <div class="form-group">
                <label>Full name *</label>
                <input type="text" id="edit-lead-name" required value="${n.name||``}" />
              </div>
              <div class="form-group">
                <label>Mobile *</label>
                <input type="text" id="edit-lead-mobile" required value="${n.mobile||``}" maxlength="10" pattern="[0-9]{10}" oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>WhatsApp number</label>
                <input type="text" id="edit-lead-whatsapp" value="${n.whatsapp||``}" />
              </div>
              <div class="form-group">
                <label>Email</label>
                <input type="email" id="edit-lead-email" value="${n.email||``}" />
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Country</label>
                <input type="text" id="edit-lead-country" value="${n.country||``}" />
              </div>
              <div class="form-group">
                <label>City / area</label>
                <input type="text" id="edit-lead-city" value="${n.city||n.area||``}" />
              </div>
            </div>

            <div class="form-section-title">REQUIREMENT</div>
            <div class="form-row">
              <div class="form-group">
                <label>Property type</label>
                <input type="text" id="edit-lead-type" value="${n.type||``}" />
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Budget min</label>
                <input type="text" id="edit-lead-budget-min" value="${n.budgetMin||``}" />
              </div>
              <div class="form-group">
                <label>Budget max</label>
                <input type="text" id="edit-lead-budget-max" value="${n.budgetMax||``}" />
              </div>
            </div>

            <div class="form-section-title">TRACKING</div>
            <div class="form-row">
              <div class="form-group">
                <label>Source</label>
                <input type="text" id="edit-lead-source" value="${n.source||``}" />
              </div>
              <div class="form-group">
                <label>Assign to</label>
                <input type="text" id="edit-lead-assign" value="${n.assignTo||``}" />
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Follow-up Date</label>
                <input type="date" id="edit-lead-followup" value="${n.followup&&n.followup!==`—`?n.followup:``}" style="color: var(--os-gray-600);" />
              </div>
            </div>
            <div class="form-row">
              <div class="form-group" style="width: 100%;">
                <label>Requirement notes</label>
                <textarea id="edit-lead-notes" rows="3" style="width: 100%; border: var(--os-border-thin); border-radius: var(--os-radius-sm); padding: 12px; font-family: inherit; resize: vertical;">${n.notes||``}</textarea>
              </div>
            </div>
          </form>
        </div>
        <div class="os-modal-footer">
          <button class="os-btn-secondary" id="cancel-edit-btn">Cancel</button>
          <button class="os-btn-primary" id="btn-save-edit" style="background: var(--os-luxury-orange); border-color: var(--os-luxury-orange);">Save Changes</button>
        </div>
      </div>
    </div>
    <div class="os-modal-overlay" id="schedule-visit-modal">
      <div class="os-modal-card" style="max-width: 450px;">
        <div class="os-modal-header">
          <h2>Schedule site visit</h2>
          <button class="os-modal-close" id="close-schedule-modal"><i class="ri-close-line"></i></button>
        </div>
        <div class="os-modal-body">
          <div class="form-group">
            <label>Visit date & time *</label>
            <input type="datetime-local" id="crm-sv-datetime" class="os-input" style="width: 100%;" />
          </div>
          <p style="font-size: 0.85rem; color: var(--os-gray-500); margin-top: 16px;">This sends the site visit confirmation WhatsApp to the client with this date/time.</p>
        </div>
        <div class="os-modal-footer">
          <button class="os-btn-secondary" id="cancel-schedule-modal">Cancel</button>
          <button class="os-btn-primary" id="confirm-schedule-modal" style="background: #fdba74; border-color: #fdba74; color: #fff;">Confirm & send</button>
        </div>
      </div>
    </div>

    <div class="os-modal-overlay" id="share-partner-modal">
      <div class="os-modal-card" style="max-width: 500px;">
        <div class="os-modal-header">
          <h2>Share lead with partner company</h2>
          <button class="os-modal-close" id="close-share-modal"><i class="ri-close-line"></i></button>
        </div>
        <div class="os-modal-body">
          <div class="form-group">
            <label>Partner company</label>
            <div class="os-custom-select" style="width: 100%;" id="partner-share-dropdown">
              <div class="select-value">Broadcast to All Partners</div>
              <i class="ri-arrow-down-s-line"></i>
              <div class="select-dropdown" id="partner-share-options">
                <!-- Dynamically populated -->
              </div>
            </div>
          </div>
          <div class="form-group" style="margin-top: 16px;">
            <label>Notes to share</label>
            <textarea id="share-partner-notes" class="os-input" rows="3" placeholder="Context for the partner team..." style="width: 100%; resize: vertical;"></textarea>
          </div>
          <label style="display: flex; align-items: start; gap: 8px; margin-top: 16px; cursor: pointer;">
            <input type="checkbox" id="share-partner-wa" checked style="margin-top: 4px;" />
            <span style="font-size: 0.9rem; color: var(--os-gray-600); line-height: 1.4;">Send requirement & shortlisted properties to the partner on WhatsApp</span>
          </label>
        </div>
        <div class="os-modal-footer">
          <button class="os-btn-secondary" id="cancel-share-modal">Cancel</button>
          <button class="os-btn-primary" id="confirm-share-modal" style="background: var(--os-luxury-orange); border-color: var(--os-luxury-orange); color: #fff;">Share lead</button>
        </div>
      </div>
    </div>

    <!-- Send WhatsApp Modal -->
    <div class="os-modal-overlay" id="send-whatsapp-modal">
      <div class="os-modal-card" style="max-width: 500px;">
        <div class="os-modal-header">
          <h2>Send WhatsApp</h2>
          <button class="os-modal-close" id="close-whatsapp-modal"><i class="ri-close-line"></i></button>
        </div>
        <div class="os-modal-body" style="padding-top: 16px;">
          <div style="font-size: 0.9rem; color: var(--os-gray-600); margin-bottom: 20px;">
            To <span style="font-weight: 500; color: var(--os-dark);">${n.whatsapp||n.mobile||`9566321457`}</span>
          </div>
          
          <div class="wa-tab-group" style="display: flex; background: var(--os-white); border: 1px solid var(--os-gray-200); border-radius: 8px; margin-bottom: 24px; overflow: hidden;">
            <button class="wa-tab-btn active" data-tab="template" style="flex: 1; padding: 12px; border: none; background: #e27c3e; color: #fff; font-weight: 500; cursor: pointer; transition: all 0.2s ease;">Use a template</button>
            <button class="wa-tab-btn" data-tab="custom" style="flex: 1; padding: 12px; border: none; background: transparent; color: var(--os-gray-600); font-weight: 500; cursor: pointer; transition: all 0.2s ease;">Write custom message</button>
          </div>

          <!-- Template Tab -->
          <div class="wa-tab-content active" id="wa-tab-template">
            <div class="form-group">
              <label>Template</label>
              <div class="os-custom-select" style="width: 100%;">
                <div class="select-value">Welcome message</div>
                <i class="ri-arrow-down-s-line"></i>
                <div class="select-dropdown">
                  <div class="select-option selected">Welcome message</div>
                  <div class="select-option">No template (auto message)</div>
                  <div class="select-option">Bank loan assistance (auto)</div>
                  <div class="select-option">Follow-up message</div>
                  <div class="select-option">Initial contact intro (auto)</div>
                  <div class="select-option">Negotiation check-in (auto)</div>
                  <div class="select-option">Partner transfer notification</div>
                  <div class="select-option">Registration testimonial & referral (auto)</div>
                  <div class="select-option">Site visit confirmation (auto)</div>
                  <div class="select-option">Site visit feedback request (auto)</div>
                  <div class="select-option">Site visit reminder</div>
                </div>
              </div>
            </div>
            
            <div class="form-group" style="margin-top: 16px;">
              <label>Language</label>
              <div class="os-custom-select" style="width: 100%;">
                <div class="select-value">English</div>
                <i class="ri-arrow-down-s-line"></i>
                <div class="select-dropdown">
                  <div class="select-option selected">English</div>
                  <div class="select-option">Tamil · தமிழ்</div>
                  <div class="select-option">Hindi · हिन्दी</div>
                  <div class="select-option">Telugu · తెలుగు</div>
                  <div class="select-option">Kannada · ಕನ್ನಡ</div>
                  <div class="select-option">Malayalam · മലയാളം</div>
                </div>
              </div>
            </div>

            <!-- Dynamic Template Parameter Customizer -->
            <div id="wa-template-params-container" style="margin-top: 16px; background: #faf8f5; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px;">
              <div style="font-size: 0.8rem; font-weight: 700; color: #4a5568; margin-bottom: 8px; display: flex; align-items: center; gap: 6px;">
                <i class="ri-equalizer-line" style="color: #e27c3e;"></i> Template Parameters (Editable)
              </div>
              <div id="wa-params-fields" style="display: flex; flex-direction: column; gap: 10px;">
                <!-- Injected dynamically -->
              </div>
            </div>
          </div>

          <!-- Custom Tab -->
          <div class="wa-tab-content" id="wa-tab-custom" style="display: none;">
            <div class="form-group">
              <label>Message</label>
              <textarea class="os-input" rows="5" placeholder="Type your message..." style="width: 100%; resize: vertical;"></textarea>
            </div>
            <div class="form-group" style="margin-top: 16px;">
              <label>Language</label>
              <div class="os-custom-select" style="width: 100%;">
                <div class="select-value">English</div>
                <i class="ri-arrow-down-s-line"></i>
                <div class="select-dropdown">
                  <div class="select-option selected">English</div>
                  <div class="select-option">Tamil · தமிழ்</div>
                  <div class="select-option">Hindi · हिन्दी</div>
                  <div class="select-option">Telugu · తెలుగు</div>
                  <div class="select-option">Kannada · ಕನ್ನಡ</div>
                  <div class="select-option">Malayalam · മലയാളം</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="os-modal-footer">
          <button class="os-btn-secondary" id="cancel-whatsapp-modal" style="border: 1px solid var(--os-gray-200); padding: 8px 16px; border-radius: 8px; font-weight: 500; cursor: pointer; color: var(--os-gray-700); background: #fff;">Cancel</button>
          <button class="os-btn-primary" id="confirm-whatsapp-modal" style="background: #e27c3e; border: none; border-radius: 8px; padding: 8px 16px; color: #fff; font-weight: 500; cursor: pointer; display: flex; align-items: center; gap: 8px;">
            <i class="ri-send-plane-fill"></i> Send
          </button>
        </div>
      </div>
    </div>
  `}function _t(e){let t=document.getElementById(`partner-share-dropdown`),n=document.getElementById(`partner-share-options`);if(t&&n){let e=JSON.parse(localStorage.getItem(`thanjai_partners`))||[],r=`<div class="select-option selected" data-id="ALL">Broadcast to All Partners <i class="ri-broadcast-line" style="margin-left:8px; color:var(--os-luxury-orange);"></i></div>`;e.forEach(e=>{(e.status||`Active`).toLowerCase()===`active`&&(r+=`<div class="select-option" data-id="${e.id}">${e.company||e.name}</div>`)}),n.innerHTML=r;let i=t.querySelector(`.select-value`);i.dataset.id=`ALL`,i.addEventListener(`click`,e=>{e.stopPropagation(),t.classList.toggle(`open`)}),n.querySelectorAll(`.select-option`).forEach(e=>{e.addEventListener(`click`,r=>{r.stopPropagation(),n.querySelectorAll(`.select-option`).forEach(e=>e.classList.remove(`selected`)),e.classList.add(`selected`),i.innerHTML=e.innerHTML,i.dataset.id=e.dataset.id,t.classList.remove(`open`)})}),window.addEventListener(`click`,e=>{t.contains(e.target)||t.classList.remove(`open`)})}let r=document.getElementById(`schedule-visit-modal`),i=document.getElementById(`btn-schedule-visit`),a=document.getElementById(`close-schedule-modal`),s=document.getElementById(`cancel-schedule-modal`),c=document.getElementById(`confirm-schedule-modal`);i&&i.addEventListener(`click`,()=>r.classList.add(`show`)),a&&a.addEventListener(`click`,()=>r.classList.remove(`show`)),s&&s.addEventListener(`click`,()=>r.classList.remove(`show`)),c&&c.addEventListener(`click`,()=>{let t=document.getElementById(`crm-sv-datetime`).value;if(!t){alert(`Please select a date and time.`);return}let n=(JSON.parse(localStorage.getItem(`thanjai_leads`))||[]).find(t=>t.id==e);if(!n)return;let i=new Date(t),a=i.getDate().toString(),o=i.getHours(),s=o>=12?`PM`:`AM`;o=o%12||12;let c=i.getMinutes().toString().padStart(2,`0`),l=(n.area||``)+` `+(n.type||``),u={id:`SV-`+Date.now(),leadId:n.name,propertyId:l.trim()||`TBD`,visitDate:t.replace(`T`,` `)+`:00`,status:`Scheduled`,assignedTo:n.assignTo||`Unassigned`,notes:JSON.stringify({clientName:n.name,property:l.trim()||`TBD`,phone:n.mobile})};ht(async()=>{let{fetchFromAPI:e}=await import(`./toast-CBEj-iOa.js`).then(e=>e.N);return{fetchFromAPI:e}},[]).then(({fetchFromAPI:e})=>{e(`/site_visits`,{method:`POST`,body:JSON.stringify(u)}).then(()=>{r.classList.remove(`show`),alert(`Visit scheduled successfully! You can view it in the Site Visits Planner.`);let e=JSON.parse(localStorage.getItem(`thanjai_visits`))||[];e.push({id:u.id,date:a,month:[`Jan`,`Feb`,`Mar`,`Apr`,`May`,`Jun`,`Jul`,`Aug`,`Sep`,`Oct`,`Nov`,`Dec`][i.getMonth()],hours:o.toString(),mins:c,ampm:s,clientName:n.name,phone:n.mobile||`New Visit`,property:l.trim()||`TBD`,isNew:!0}),localStorage.setItem(`thanjai_visits`,JSON.stringify(e))}).catch(e=>{console.error(`Failed to schedule visit`,e),alert(`Failed to schedule visit: `+e.message)})})});let l=document.getElementById(`share-partner-modal`),u=document.getElementById(`btn-share-partner`),d=document.getElementById(`close-share-modal`),p=document.getElementById(`cancel-share-modal`),m=document.getElementById(`confirm-share-modal`);u&&u.addEventListener(`click`,()=>l.classList.add(`show`)),d&&d.addEventListener(`click`,()=>l.classList.remove(`show`)),p&&p.addEventListener(`click`,()=>l.classList.remove(`show`)),m&&m.addEventListener(`click`,async()=>{let t=JSON.parse(localStorage.getItem(`thanjai_partners`))||[],n=document.querySelector(`#partner-share-dropdown .select-value`),r=n?n.dataset.id:null,i=(n?n.innerText||n.textContent:``).trim();if(!r||r===`ALL`){if(i.toLowerCase().includes(`broadcast`))r=`ALL`;else{let e=t.find(e=>(e.company||e.name||``).trim().toLowerCase()===i.toLowerCase());e&&(r=e.id)}}if(!r&&t.length>0){let e=t.find(e=>i.toLowerCase().includes((e.company||e.name||``).toLowerCase()));r=e?e.id:t[0].id}let a=document.getElementById(`share-partner-notes`)?.value||``,s=document.getElementById(`share-partner-wa`)?.checked??!0,c=JSON.parse(localStorage.getItem(`thanjai_leads`))||[],u=c.find(t=>String(t.id)===String(e));if(!u)return;JSON.parse(localStorage.getItem(`thanjai_shared_leads`));let d=JSON.parse(localStorage.getItem(`thanjai_active_user`))||{fullName:`Aishwarya Raman`},p=new Date,m=p.toLocaleDateString(`en-IN`,{day:`numeric`,month:`short`,year:`numeric`})+`, `+p.toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`}),h=u.location||u.city||u.area||`Thanjavur`,g=u.requirement||u.type||`Residential Plot / Villa`,_=u.budget||(u.budgetMax?`₹ `+u.budgetMax:`₹ 25 - 50 Lakhs`),v={id:`SL-${Date.now()}`,name:u.name||`Client`,phone:`Protected by Desk (+91 84899 96852)`,location:h,propertyType:g,budget:_,sharedBy:d.fullName||`Admin`,sharedDate:m,notes:a,status:`Shared`},y=async e=>{let t=(e.phone||e.whatsapp||``).replace(/\D/g,``);if(!t)return;t.length===10?t=`+91`+t:t.length===12&&t.startsWith(`91`)?t=`+`+t:t.startsWith(`+`)||(t=`+`+t);let n=e.company||e.name||e.contact||`Partner`,r=u.name||`Client`,i=h||`Thanjavur`,s=g||`Residential Plot / Villa`,c=_||`Contact for Budget`,l=a||`Requirement from CRM`,d=`Hello ${n},\n\nA new qualified buyer requirement has been assigned to you from Thanjai Property:\n\n👤 Client Name: ${r}\n📍 Preferred Location: ${i}\n🏡 Requirement: ${s}\n💰 Budget Range: ${c}\n\n📝 Notes: ${l}\n\nFor client coordination, please connect through our official desk: +91 84899 96852.\n\nWarm regards,\nThanjai Property Partner Network`;o(`/whatsapp_logs`,{method:`POST`,body:JSON.stringify({id:`WA-${Date.now()}`,leadId:u.id,phone:t,sender:`Super Admin`,recipientName:n,message:d,type:`outbound`})}).catch(()=>{}),addAuditLog({action:`Assigned Lead to Partner (${n})`,module:`WhatsApp Log`,details:`Sent partner_lead_assignment template to ${n} (${t}) for client ${r}.`});let p=localStorage.getItem(`thanjai_whatsapp_api_key`);if(!p){f(`Please configure your SmartPing API Key in Settings > Integrations.`,`ri-alert-line`);return}let m={apiKey:p,campaignName:`partner_lead_assignment`,destination:t,userName:n,templateParams:[n,r,i,s,c,l]};try{let e=await fetch(`https://backend.api-wa.co/campaign/smartping/api/v2`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(m)}),t=await e.json();e.ok&&t.status!==`error`?f(`WhatsApp sent to partner ${n}!`,`ri-checkbox-circle-fill`):(console.warn(`SmartPing partner dispatch error:`,t),f(`SmartPing: ${t.message||t.error||`Check campaign name/status in SmartPing`}`,`ri-alert-line`))}catch(e){console.warn(`Direct SmartPing dispatch warning, calling server relay:`,e),o(`/send_whatsapp`,{method:`POST`,body:JSON.stringify(m)}).catch(()=>{})}},b=async e=>{let t=(u.whatsapp||u.mobile||u.phone||``).replace(/\D/g,``);if(!t)return;t.length===10?t=`+91`+t:t.length===12&&t.startsWith(`91`)?t=`+`+t:t.startsWith(`+`)||(t=`+`+t);let n=e&&(e.company||e.name||e.contact)||`our specialist partner`,r=u.name||`Client`,i=h||`Thanjavur`,a=`Hello ${r},\n\nYour property requirement in ${i} has been assigned to our senior partner specialist ${n}.\n\nOur team and specialist will assist you with exclusive listings, verified Patta documents, and on-site visits.\n\nFor any direct assistance, contact our official desk at +91 84899 96852.\n\nBest regards,\nThanjai Property`;o(`/whatsapp_logs`,{method:`POST`,body:JSON.stringify({id:`WA-${Date.now()}-client`,leadId:u.id,phone:t,sender:`Super Admin`,recipientName:r,message:a,type:`outbound`})}).catch(()=>{}),addAuditLog({action:`Notified Client on Partner Transfer (${r})`,module:`WhatsApp Log`,details:`Sent partner_transfer_notification to client ${r} (${t}) assigned to ${n}.`});let s=localStorage.getItem(`thanjai_whatsapp_api_key`);if(!s)return;let c={apiKey:s,campaignName:`partner_transfer_notification`,destination:t,userName:r,templateParams:[r,i,n,`+91 84899 96852`]};try{let e=await fetch(`https://backend.api-wa.co/campaign/smartping/api/v2`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(c)}),t=await e.json();e.ok&&t.status!==`error`?f(`WhatsApp notification sent to client ${r}!`,`ri-checkbox-circle-fill`):console.warn(`SmartPing client dispatch error:`,t)}catch{o(`/send_whatsapp`,{method:`POST`,body:JSON.stringify(c)}).catch(()=>{})}};if(r===`ALL`){let n=t.filter(e=>(e.status||`Active`).toLowerCase()===`active`);for(let e of n){let t={...v,id:`SL-${Date.now()}-${Math.random().toString(36).substr(2,5)}`,partnerId:String(e.id)};try{await o(`/shared_leads`,{method:`POST`,body:JSON.stringify(t)}),e.leads=(e.leads||0)+1,s&&y(e)}catch(e){console.error(`Failed to save shared lead to DB:`,e)}}s&&b(null),localStorage.setItem(`thanjai_partners`,JSON.stringify(t)),u.timeline||=[],u.timeline.unshift({action:`Broadcasted requirement to ALL channel partners (Client contact protected)`,date:m,by:d.fullName||`Admin`}),Z(c,e),l.classList.remove(`show`),f(`Lead requirement broadcasted to ${n.length} partners via official WhatsApp (+91 84899 96852).`,`ri-checkbox-circle-fill`);let r=document.getElementById(`os-content`);r&&(r.innerHTML=gt(e),_t(e))}else if(r){v.partnerId=String(r);try{await o(`/shared_leads`,{method:`POST`,body:JSON.stringify(v)})}catch(e){console.error(`Failed to save shared lead to DB:`,e)}let n=t.findIndex(e=>String(e.id)===String(r)),i=`Partner`;n!==-1&&(i=t[n].company||t[n].name,t[n].leads=(t[n].leads||0)+1,localStorage.setItem(`thanjai_partners`,JSON.stringify(t)),s&&(await y(t[n]),await b(t[n]))),u.timeline||=[],u.timeline.unshift({action:`Shared requirement with partner "${i}" (Client contact protected)`,date:m,by:d.fullName||`Admin`}),Z(c,e),l.classList.remove(`show`),f(`Lead requirement for "${u.name}" shared with ${i} via official WhatsApp!`,`ri-checkbox-circle-fill`);let a=document.getElementById(`os-content`);a&&(a.innerHTML=gt(e),_t(e))}else f(`Please select a partner company or Broadcast option.`,`ri-alert-line`)}),window.addEventListener(`click`,e=>{let t=document.getElementById(`edit-lead-modal`),n=document.getElementById(`send-whatsapp-modal`);e.target===r&&r.classList.remove(`show`),e.target===l&&l.classList.remove(`show`),t&&e.target===t&&t.classList.remove(`show`),n&&e.target===n&&n.classList.remove(`show`)});let h=document.getElementById(`send-whatsapp-modal`),g=document.getElementById(`btn-send-whatsapp`),_=document.getElementById(`close-whatsapp-modal`),y=document.getElementById(`cancel-whatsapp-modal`),b=document.getElementById(`confirm-whatsapp-modal`),x=document.querySelectorAll(`.wa-tab-btn`),S=document.querySelectorAll(`.wa-tab-content`);function C(e){return{"Welcome message":`welcome_message`,"No template (auto message)":`general_property_update`,"Bank loan assistance (auto)":`bank_loan_assistance`,"Follow-up message":`property_follow_up`,"Initial contact intro (auto)":`initial_contact_intro`,"Negotiation check-in (auto)":`negotiation_check_in`,"Partner lead assignment":`partner_lead_assignment`,"Partner transfer notification":`partner_transfer_notification`,"Registration testimonial & referral (auto)":`registration_testimonial_referral`,"Site visit confirmation (auto)":`site_visit_confirmation`,"Site visit feedback request (auto)":`site_visit_feedback`,"Site visit reminder":`site_visit_reminder`}[e]||e.replace(`(auto)`,``).trim().toLowerCase().replace(/[\s-]/g,`_`)}function w(e,t){let n=document.getElementById(`wa-params-fields`);if(!n)return;let r=JSON.parse(localStorage.getItem(`thanjai_properties`))||[],i=r.find(e=>e.title===t.propertyMatch)||r[0]||{},a=t.name||`Client`,o=t.propertyMatch||i.title||t.type||`DTCP Approved Plot - Trichy Road`,s=i.location||t.city||`Medical College Road, Thanjavur`,c=i.priceFormatted||`₹ 25 Lakhs`,l=`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(s+` Thanjavur`)}`,u=``;switch(e){case`property_shortlist`:u=`
          <div>
            <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{1}} Client Name</label>
            <input type="text" id="wa-p1" class="os-input" value="${a}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
          </div>
          <div style="margin-top: 10px;">
            <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:flex; justify-content:space-between; margin-bottom:6px;">
              <span><i class="ri-checkbox-multiple-line" style="color:#e27c3e;"></i> Select 3 Properties from Inventory</span>
              <span id="wa-shortlist-count" style="color:#e27c3e; font-weight:800;">3/3 selected</span>
            </label>
            <div id="wa-shortlist-picker" style="max-height: 180px; overflow-y: auto; background: #ffffff; border: 1px solid #cbd5e0; border-radius: 6px; padding: 6px; display: flex; flex-direction: column; gap: 6px;">
              ${r.map((e,t)=>`
                <label style="display: flex; align-items: flex-start; gap: 8px; font-size: 0.8rem; cursor: pointer; padding: 6px; border-radius: 4px; background: #f8fafc; border: 1px solid #e2e8f0;">
                  <input type="checkbox" class="wa-prop-checkbox" data-title="${e.title}" data-price="${e.priceFormatted||`Price on request`}" data-loc="${e.location||`Thanjavur`}" ${t<3?`checked`:``} style="margin-top: 2px; accent-color: #e27c3e;" />
                  <div style="flex: 1;">
                    <div style="font-weight: 700; color: #1e293b;">${e.title}</div>
                    <div style="color: #64748b; font-size: 0.73rem;">📍 ${e.location||`Thanjavur`} • 💰 <strong style="color:#e27c3e;">${e.priceFormatted||``}</strong></div>
                  </div>
                </label>
              `).join(``)}
            </div>
          </div>
        `;break;case`welcome_message`:u=`
          <div>
            <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{1}} Client Name</label>
            <input type="text" id="wa-p1" class="os-input" value="${a}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
          </div>
        `;break;case`initial_contact_intro`:u=`
          <div style="margin-bottom: 8px;">
            <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">
              <i class="ri-building-line" style="color:#e27c3e;"></i> Choose Property from Inventory (Auto-fills Title, Location & Price)
            </label>
            <select id="wa-quick-prop-select" class="os-input" style="width: 100%; padding: 6px 10px; font-size: 0.85rem; background: #ffffff;">
              ${r.map(e=>`
                <option value="${e.id}" data-title="${e.title}" data-loc="${e.location||`Thanjavur`}" data-price="${e.priceFormatted||`₹ 25 Lakhs`}" ${e.title===o?`selected`:``}>
                  ${e.title} (${e.location||`Thanjavur`} - ${e.priceFormatted||``})
                </option>
              `).join(``)}
            </select>
          </div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{1}} Client Name</label>
              <input type="text" id="wa-p1" class="os-input" value="${a}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{2}} Property Title</label>
              <input type="text" id="wa-p2" class="os-input" value="${o}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
          </div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{3}} Location</label>
              <input type="text" id="wa-p3" class="os-input" value="${s}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{4}} Price</label>
              <input type="text" id="wa-p4" class="os-input" value="${c}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
          </div>
        `;break;case`site_visit_confirmation`:u=`
          <div style="margin-bottom: 8px;">
            <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">
              <i class="ri-building-line" style="color:#e27c3e;"></i> Choose Property from Inventory (Auto-fills Title, Location & Map Link)
            </label>
            <select id="wa-quick-prop-select" class="os-input" style="width: 100%; padding: 6px 10px; font-size: 0.85rem; background: #ffffff;">
              ${r.map(e=>`
                <option value="${e.id}" data-title="${e.title}" data-loc="${e.location||`Thanjavur`}" data-price="${e.priceFormatted||``}" ${e.title===o?`selected`:``}>
                  ${e.title} (${e.location||`Thanjavur`})
                </option>
              `).join(``)}
            </select>
          </div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{1}} Client Name</label>
              <input type="text" id="wa-p1" class="os-input" value="${a}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{2}} Property Title</label>
              <input type="text" id="wa-p2" class="os-input" value="${o}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
          </div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{3}} Date & Time</label>
              <input type="text" id="wa-p3" class="os-input" value="Tomorrow at 10:30 AM" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{4}} Location</label>
              <input type="text" id="wa-p4" class="os-input" value="${s}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
          </div>
          <div>
            <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{5}} Google Map Link (Direct URL)</label>
            <input type="url" id="wa-p5" class="os-input" value="${l}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
          </div>
        `;break;case`site_visit_reminder`:u=`
          <div style="margin-bottom: 8px;">
            <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">
              <i class="ri-building-line" style="color:#e27c3e;"></i> Choose Property from Inventory
            </label>
            <select id="wa-quick-prop-select" class="os-input" style="width: 100%; padding: 6px 10px; font-size: 0.85rem; background: #ffffff;">
              ${r.map(e=>`
                <option value="${e.id}" data-title="${e.title}" data-loc="${e.location||`Thanjavur`}" ${e.title===o?`selected`:``}>
                  ${e.title} (${e.location||`Thanjavur`})
                </option>
              `).join(``)}
            </select>
          </div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{1}} Client Name</label>
              <input type="text" id="wa-p1" class="os-input" value="${a}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{2}} Property Title</label>
              <input type="text" id="wa-p2" class="os-input" value="${o}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
          </div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{3}} Time</label>
              <input type="text" id="wa-p3" class="os-input" value="11:00 AM" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{4}} Meeting Point</label>
              <input type="text" id="wa-p4" class="os-input" value="${s}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
          </div>
        `;break;case`site_visit_feedback`:case`bank_loan_assistance`:u=`
          <div style="margin-bottom: 8px;">
            <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">
              <i class="ri-building-line" style="color:#e27c3e;"></i> Choose Property from Inventory
            </label>
            <select id="wa-quick-prop-select" class="os-input" style="width: 100%; padding: 6px 10px; font-size: 0.85rem; background: #ffffff;">
              ${r.map(e=>`
                <option value="${e.id}" data-title="${e.title}" data-loc="${e.location||`Thanjavur`}" ${e.title===o?`selected`:``}>
                  ${e.title}
                </option>
              `).join(``)}
            </select>
          </div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{1}} Client Name</label>
              <input type="text" id="wa-p1" class="os-input" value="${a}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{2}} Property Title</label>
              <input type="text" id="wa-p2" class="os-input" value="${o}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
          </div>
        `;break;case`property_follow_up`:u=`
          <div style="margin-bottom: 8px;">
            <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">
              <i class="ri-building-line" style="color:#e27c3e;"></i> Choose Property from Inventory
            </label>
            <select id="wa-quick-prop-select" class="os-input" style="width: 100%; padding: 6px 10px; font-size: 0.85rem; background: #ffffff;">
              ${r.map(e=>`
                <option value="${e.id}" data-title="${e.title}" data-loc="${e.location||`Thanjavur`}" ${e.title===o?`selected`:``}>
                  ${e.title} (${e.location||`Thanjavur`})
                </option>
              `).join(``)}
            </select>
          </div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{1}} Client Name</label>
              <input type="text" id="wa-p1" class="os-input" value="${a}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{2}} Property Title</label>
              <input type="text" id="wa-p2" class="os-input" value="${o}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
          </div>
          <div>
            <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{3}} Location</label>
            <input type="text" id="wa-p3" class="os-input" value="${s}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
          </div>
        `;break;case`negotiation_check_in`:u=`
          <div style="margin-bottom: 8px;">
            <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">
              <i class="ri-building-line" style="color:#e27c3e;"></i> Choose Property from Inventory
            </label>
            <select id="wa-quick-prop-select" class="os-input" style="width: 100%; padding: 6px 10px; font-size: 0.85rem; background: #ffffff;">
              ${r.map(e=>`
                <option value="${e.id}" data-title="${e.title}" data-loc="${e.location||`Thanjavur`}" ${e.title===o?`selected`:``}>
                  ${e.title}
                </option>
              `).join(``)}
            </select>
          </div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{1}} Client Name</label>
              <input type="text" id="wa-p1" class="os-input" value="${a}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{2}} Property Title</label>
              <input type="text" id="wa-p2" class="os-input" value="${o}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
          </div>
          <div>
            <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{3}} Suggested Meeting Time</label>
            <input type="text" id="wa-p3" class="os-input" value="Tomorrow at 4:00 PM" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
          </div>
        `;break;case`partner_lead_assignment`:u=`
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{1}} Partner Name</label>
              <input type="text" id="wa-p1" class="os-input" value="Partner" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{2}} Client Name</label>
              <input type="text" id="wa-p2" class="os-input" value="${a}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
          </div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{3}} Preferred Location</label>
              <input type="text" id="wa-p3" class="os-input" value="${t.city||t.location||`Thanjavur`}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{4}} Requirement</label>
              <input type="text" id="wa-p4" class="os-input" value="${t.requirement||t.type||`Plot`}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
          </div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{5}} Budget Range</label>
              <input type="text" id="wa-p5" class="os-input" value="${t.budget||`₹ 25 - 50 Lakhs`}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{6}} Notes</label>
              <input type="text" id="wa-p6" class="os-input" value="${t.notes||`Immediate buyer requirement.`}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
          </div>
        `;break;case`partner_transfer_notification`:u=`
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{1}} Client Name</label>
              <input type="text" id="wa-p1" class="os-input" value="${a}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{2}} City Name</label>
              <input type="text" id="wa-p2" class="os-input" value="${t.city||`Thanjavur`}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
          </div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{3}} Executive Name</label>
              <input type="text" id="wa-p3" class="os-input" value="${t.assignTo||`S. Vijayaraghavan`}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{4}} Executive Mobile</label>
              <input type="text" id="wa-p4" class="os-input" value="+91 95783 11506" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
          </div>
        `;break;case`registration_testimonial_referral`:u=`
          <div style="margin-bottom: 8px;">
            <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">
              <i class="ri-building-line" style="color:#e27c3e;"></i> Choose Registered Property from Inventory
            </label>
            <select id="wa-quick-prop-select" class="os-input" style="width: 100%; padding: 6px 10px; font-size: 0.85rem; background: #ffffff;">
              ${r.map(e=>`
                <option value="${e.id}" data-title="${e.title}" ${e.title===o?`selected`:``}>
                  ${e.title}
                </option>
              `).join(``)}
            </select>
          </div>
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{1}} Client Name</label>
              <input type="text" id="wa-p1" class="os-input" value="${a}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{2}} Registered Property Title</label>
              <input type="text" id="wa-p2" class="os-input" value="${o}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
          </div>
          <div>
            <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{3}} Google Review Link</label>
            <input type="url" id="wa-p3" class="os-input" value="https://g.page/r/thanjaiproperty/review" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
          </div>
        `;break;default:u=`
          <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{1}} Client Name</label>
              <input type="text" id="wa-p1" class="os-input" value="${a}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
            <div>
              <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{2}} Property Ref / Title</label>
              <input type="text" id="wa-p2" class="os-input" value="${o}" style="width:100%; padding:6px 10px; font-size:0.85rem;" />
            </div>
          </div>
          <div>
            <label style="font-size:0.75rem; font-weight:700; color:#4a5568; display:block; margin-bottom:4px;">{{3}} Update Details</label>
            <input type="text" id="wa-p3" class="os-input" value="Your property verification file has been processed." style="width:100%; padding:6px 10px; font-size:0.85rem;" />
          </div>
        `}n.innerHTML=u;let d=n.querySelector(`#wa-quick-prop-select`);d&&d.addEventListener(`change`,t=>{let r=t.target.selectedOptions[0];if(r){let t=r.dataset.title||``,i=r.dataset.loc||``,a=r.dataset.price||``,o=n.querySelector(`#wa-p2`),s=n.querySelector(`#wa-p3`),c=n.querySelector(`#wa-p4`),l=n.querySelector(`#wa-p5`);o&&(o.value=t),s&&e===`initial_contact_intro`&&(s.value=i),c&&(e===`initial_contact_intro`||e===`site_visit_confirmation`)&&(c.value=e===`initial_contact_intro`?a:i),l&&(l.value=`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(i+` Thanjavur`)}`)}});let f=n.querySelectorAll(`.wa-prop-checkbox`),p=n.querySelector(`#wa-shortlist-count`);f.length>0&&f.forEach(e=>{e.addEventListener(`change`,()=>{if(n.querySelectorAll(`.wa-prop-checkbox:checked`).length>3){e.checked=!1,alert(`You can select a maximum of 3 properties for the shortlist.`);return}p&&(p.innerText=`${n.querySelectorAll(`.wa-prop-checkbox:checked`).length}/3 selected`)})})}let T=document.querySelector(`#wa-tab-template .os-custom-select`);T&&T.querySelectorAll(`.select-option`).forEach(t=>{t.addEventListener(`click`,()=>{let n=(JSON.parse(localStorage.getItem(`thanjai_leads`))||[]).find(t=>t.id==e)||{};w(C(t.innerText.trim()),n)})}),g&&g.addEventListener(`click`,()=>{let t=(JSON.parse(localStorage.getItem(`thanjai_leads`))||[]).find(t=>t.id==e)||{};w(C(document.querySelector(`#wa-tab-template .os-custom-select .select-value`)?.innerText.trim()||`Welcome message`),t),h.classList.add(`show`)}),_&&_.addEventListener(`click`,()=>h.classList.remove(`show`)),y&&y.addEventListener(`click`,()=>h.classList.remove(`show`)),b&&b.addEventListener(`click`,async()=>{let t=JSON.parse(localStorage.getItem(`thanjai_leads`))||[],n=t.findIndex(t=>t.id==e),r=t[n];if(!r)return;let i=document.querySelector(`.wa-tab-btn[data-tab="custom"]`).classList.contains(`active`),a=``,o=[];if(i){let e=document.querySelector(`#wa-tab-custom textarea`).value;if(!e.trim()){alert(`Please enter a custom message.`);return}a=`custom_message`,o=[r.name||`Client`,e]}else{a=C(document.querySelector(`#wa-tab-template .os-custom-select .select-value`).innerText.trim());let e=document.querySelectorAll(`#wa-tab-template .os-custom-select`)[1];if(e){let t={"Tamil · தமிழ்":`_ta`,"Hindi · हिन्दी":`_hi`,"Telugu · తెలుగు":`_te`,"Kannada · ಕನ್ನಡ":`_kn`,"Malayalam · മലയാളം":`_ml`}[e.querySelector(`.select-value`).innerText.trim()]||``;a+=t}let t=document.getElementById(`wa-p1`)?.value.trim()||r.name||`Client`,n=document.getElementById(`wa-p2`)?.value.trim()||r.propertyMatch||`DTCP Approved Plot`,i=document.getElementById(`wa-p3`)?.value.trim()||`Tomorrow at 10:30 AM`,s=document.getElementById(`wa-p4`)?.value.trim()||`Thanjavur`,c=document.getElementById(`wa-p5`)?.value.trim()||`https://www.google.com/maps/search/?api=1&query=Thanjavur`;switch(a.replace(/(_ta|_hi|_te|_kn|_ml)$/,``)){case`property_shortlist`:case`welcome_message`:o=[t];break;case`site_visit_feedback`:case`bank_loan_assistance`:o=[t,n];break;case`general_property_update`:case`property_follow_up`:case`negotiation_check_in`:case`registration_testimonial_referral`:o=[t,n,i];break;case`partner_transfer_notification`:case`site_visit_reminder`:case`initial_contact_intro`:o=[t,n,i,s];break;case`site_visit_confirmation`:o=[t,n,i,s,c];break;case`partner_lead_assignment`:o=[t,n,i,s,c,p6];break;default:o=[t]}}let s=(r.whatsapp||r.mobile||`9566321457`).replace(/\D/g,``);s.length===10?s=`+91`+s:s.startsWith(`+`)||(s=`+`+s);let c=b.innerHTML;b.innerHTML=`<i class="ri-loader-4-line ri-spin"></i> Sending...`,b.disabled=!0;let l;if(a.includes(`initial_contact_intro`)){let e=JSON.parse(localStorage.getItem(`thanjai_properties`))||[],t=o[1]||``,n=e.find(e=>e.title===t)||e[0];l={url:n&&n.images&&n.images[0]?n.images[0]:`https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80`,filename:`property.jpg`}}a.includes(`property_shortlist`)&&(o=[r.name||`Client`]);try{await M({campaignName:a,destination:s,userName:r.name||`Client`,templateParams:o,media:l,messageText:i?o[1]:void 0,leadId:r.id}),b.innerHTML=c,b.disabled=!1,h.classList.remove(`show`);let u=`Super Admin`;try{let e=JSON.parse(localStorage.getItem(`thanjai_active_user`));e&&(u=e.fullName||e.name||u)}catch{}if(n!==-1){t[n].timeline||(t[n].timeline=[]);let r=a.includes(`property_shortlist`),o=Array.from(document.querySelectorAll(`.wa-prop-checkbox:checked`)).map(e=>e.dataset.title),s=r&&o.length>0?` [Shortlist: ${o.join(`, `)}]`:``;r&&o.length>0&&(t[n].shortlistedProperties=Array.from(document.querySelectorAll(`.wa-prop-checkbox:checked`)).map(e=>({title:e.dataset.title,price:e.dataset.price,location:e.dataset.loc}))),t[n].timeline.unshift({type:`whatsapp`,message:`WhatsApp sent: ${i?`Custom message`:a}${s}`,author:u,date:new Date().toISOString()}),Z(t,e),f(`WhatsApp message sent & logged in chat!`,`ri-checkbox-circle-fill`),window.dispatchEvent(new HashChangeEvent(`hashchange`))}}catch(e){b.innerHTML=c,b.disabled=!1,alert(`Failed to send WhatsApp message:
`+e.message)}}),x.forEach(e=>{e.addEventListener(`click`,()=>{x.forEach(e=>{e.classList.remove(`active`),e.style.background=`transparent`,e.style.color=`var(--os-gray-600)`}),e.classList.add(`active`),e.style.background=`#e27c3e`,e.style.color=`#fff`,S.forEach(e=>e.style.display=`none`),document.getElementById(`wa-tab-`+e.dataset.tab).style.display=`block`})});let E=document.getElementById(`edit-lead-modal`),D=document.getElementById(`btn-edit-lead`),O=document.getElementById(`close-edit-modal`),k=document.getElementById(`cancel-edit-modal`),A=document.getElementById(`btn-set-follow-up`),j=document.getElementById(`follow-up-datetime`);A&&j&&A.addEventListener(`click`,()=>{let t=j.value;if(!t){alert(`Please select a date and time for the follow-up.`);return}let n=JSON.parse(localStorage.getItem(`thanjai_leads`))||[],r=n.findIndex(t=>t.id==e);if(r!==-1){let i=n[r].status||`New Lead`;n[r].status=`FOLLOW_UP_PENDING`,n[r].followUpDate=t,n[r].timeline||(n[r].timeline=[]),n[r].timeline.unshift({type:`system`,message:`Follow-up set for ${new Date(t).toLocaleString([],{year:`numeric`,month:`short`,day:`numeric`,hour:`2-digit`,minute:`2-digit`})}`,author:localStorage.getItem(`thanjai_active_user`)||`Aishwarya Raman`,date:new Date().toISOString()}),i!==`FOLLOW_UP_PENDING`&&n[r].timeline.unshift({type:`pipeline`,message:`Moved from ${i.toUpperCase().replace(/\s+/g,`_`)} to FOLLOW_UP_PENDING`,author:localStorage.getItem(`thanjai_active_user`)||`Aishwarya Raman`,date:new Date().toISOString()}),Z(n,e),alert(`Follow-up set for ${new Date(t).toLocaleString()}`);let a=document.getElementById(`os-content`);a&&(a.innerHTML=gt(e),_t(e))}});let ee=document.getElementById(`ld-add-note-btn`),te=document.getElementById(`ld-note-input`);ee&&te&&ee.addEventListener(`click`,()=>{let t=te.value.trim();if(!t)return;let n=JSON.parse(localStorage.getItem(`thanjai_leads`))||[],r=n.findIndex(t=>t.id==e);if(r!==-1){n[r].notes||(n[r].notes=[]),n[r].notes.unshift({text:t,date:new Date().toISOString()}),Z(n,e);let i=document.getElementById(`os-content`);i&&(i.innerHTML=gt(e),_t(e))}});let ne=document.getElementById(`ld-notes-list`);ne&&ne.addEventListener(`click`,t=>{let n=t.target.closest(`.note-action-btn`);if(!n)return;let r=parseInt(n.dataset.index,10),i=JSON.parse(localStorage.getItem(`thanjai_leads`))||[],a=i.findIndex(t=>t.id==e);if(a===-1||!i[a].notes)return;let o=n.dataset.action;if(o===`delete`)v({title:`Delete Note`,message:`Are you sure you want to delete this timeline note?`,confirmText:`Delete Note`,isDestructive:!0,onConfirm:()=>{i[a].notes.splice(r,1),Z(i,e);let t=document.getElementById(`os-content`);t&&(t.innerHTML=gt(e),_t(e)),f(`Note deleted successfully`,`ri-delete-bin-line`)}});else if(o===`edit`){let t=i[a].notes[r];if(t){let n=typeof t==`string`?t:t.text||``,o=prompt(`Edit note:`,n);if(o!==null&&o.trim()!==``){typeof t==`string`?i[a].notes[r]={text:o.trim(),date:new Date().toISOString()}:t.text=o.trim(),Z(i,e);let n=document.getElementById(`os-content`);n&&(n.innerHTML=gt(e),_t(e))}}}});let re=document.getElementById(`btn-find-matches`),ie=document.getElementById(`btn-search-matches`),ae=document.getElementById(`matching-properties-search`),oe=document.getElementById(`matching-properties-results`);function se(e){if(!e||e.length===0){oe&&(oe.innerHTML=`<p style="font-size: 0.9rem; color: var(--os-gray-500); padding: 12px 0;">No matching properties found.</p>`);return}let t=`<div style="display: flex; flex-direction: column; gap: 8px; margin-top: 16px; max-height: 300px; overflow-y: auto;">`;if(e.forEach(e=>{t+=`
        <label style="display: flex; gap: 12px; padding: 12px; border: 1px solid var(--os-gray-200); border-radius: 8px; align-items: center; cursor: pointer; background: #f8fafc; transition: all 0.2s ease;">
          <input type="checkbox" class="match-prop-checkbox" value="${e.id}" />
          <div style="flex: 1;">
            <div style="font-weight: 600; font-size: 0.9rem; color: var(--os-dark);">${e.title}</div>
            <div style="font-size: 0.8rem; color: var(--os-gray-500); margin-top: 4px;">${e.location} • <span style="color: #ea580c; font-weight: 500;">${e.priceFormatted||e.price}</span></div>
          </div>
        </label>
      `}),t+=`</div>`,t+=`
      <div style="margin-top: 16px; text-align: right;">
        <button id="inline-send-wa-btn" class="os-btn-primary" style="background: #25d366; border-color: #25d366;"><i class="ri-whatsapp-line"></i> Send via WhatsApp</button>
      </div>
    `,oe){oe.innerHTML=t;let e=document.getElementById(`inline-send-wa-btn`);e&&e.addEventListener(`click`,()=>{let e=document.querySelectorAll(`.match-prop-checkbox:checked`);e.length>0?alert(`Message sent successfully via WhatsApp along with ${e.length} property link(s).`):alert(`Please select at least one property to send.`)})}}function ce(e){let t=JSON.parse(localStorage.getItem(`thanjai_properties`))||[],n=e.toLowerCase();se(t.filter(e=>e.title&&e.title.toLowerCase().includes(n)||e.location&&e.location.toLowerCase().includes(n)||e.description&&e.description.toLowerCase().includes(n)||e.categoryLabel&&e.categoryLabel.toLowerCase().includes(n)||e.category&&e.category.toLowerCase().includes(n)))}ie&&ie.addEventListener(`click`,()=>{ce(ae.value||``)}),ae&&ae.addEventListener(`input`,e=>{ce(ae.value||``)}),re&&re.addEventListener(`click`,()=>{let t=JSON.parse(localStorage.getItem(`thanjai_properties`))||[],n=(JSON.parse(localStorage.getItem(`thanjai_leads`))||[]).find(t=>t.id==e);if(!n)return;let r=n.type?n.type.toLowerCase():``,i=n.budgetMax?parseInt(n.budgetMax):9999999999;se(t.filter(e=>{let t=e.type?e.type.toLowerCase():``,n=e.category?e.category.toLowerCase():``,a=!r||t.includes(r)||n.includes(r),o=e.price||0;return typeof o==`string`&&(o=parseInt(o.replace(/\D/g,``))||0),a&&o<=i}))});let le=document.getElementById(`btn-save-edit`);D&&D.addEventListener(`click`,()=>E.classList.add(`show`)),O&&O.addEventListener(`click`,()=>E.classList.remove(`show`)),k&&k.addEventListener(`click`,()=>E.classList.remove(`show`)),le&&le.addEventListener(`click`,()=>{let t=document.getElementById(`edit-lead-name`).value.trim(),n=document.getElementById(`edit-lead-mobile`).value.trim();if(!t||!n){alert(`Name and Mobile are required!`);return}let r=JSON.parse(localStorage.getItem(`thanjai_leads`))||[],i=r.findIndex(t=>t.id==e);i!==-1&&(r[i]={...r[i],name:t,mobile:n,whatsapp:document.getElementById(`edit-lead-whatsapp`).value,email:document.getElementById(`edit-lead-email`).value,country:document.getElementById(`edit-lead-country`).value,city:document.getElementById(`edit-lead-city`).value,area:document.getElementById(`edit-lead-city`).value,type:document.getElementById(`edit-lead-type`).value,budgetMin:document.getElementById(`edit-lead-budget-min`).value,budgetMax:document.getElementById(`edit-lead-budget-max`).value,source:document.getElementById(`edit-lead-source`).value,assignTo:document.getElementById(`edit-lead-assign`).value,followup:document.getElementById(`edit-lead-followup`).value||`—`,notes:document.getElementById(`edit-lead-notes`).value},Z(r,e),E.classList.remove(`show`),window.dispatchEvent(new HashChangeEvent(`hashchange`)))});let ue=document.querySelectorAll(`.ld-tab`),de=document.querySelectorAll(`.ld-tab-pane`);ue.forEach(e=>{e.addEventListener(`click`,()=>{ue.forEach(e=>{e.classList.remove(`active`),e.style.color=`var(--os-gray-500)`,e.style.borderBottom=`none`}),e.classList.add(`active`),e.style.color=`#ea580c`,e.style.borderBottom=`2px solid #ea580c`,de.forEach(e=>e.style.display=`none`);let t=e.textContent;t.includes(`Activity`)?document.getElementById(`pane-timeline`).style.display=`block`:t.includes(`WhatsApp`)?document.getElementById(`pane-whatsapp`).style.display=`block`:t.includes(`Pipeline`)&&(document.getElementById(`pane-pipeline`).style.display=`block`)})});let N=document.querySelectorAll(`.lead-detail-page .os-custom-select, #share-partner-modal .os-custom-select, #send-whatsapp-modal .os-custom-select`);N.forEach(t=>{let n=t.querySelector(`.select-value`);if(!t.querySelector(`.select-dropdown`))return;t.addEventListener(`click`,e=>{e.stopPropagation();let n=t.classList.contains(`open`);N.forEach(e=>e.classList.remove(`open`)),n||t.classList.add(`open`)});let r=t.querySelectorAll(`.select-option`);r.forEach(i=>{i.addEventListener(`click`,a=>{a.stopPropagation(),n.innerHTML=i.innerHTML,i.dataset.id&&(n.dataset.id=i.dataset.id),r.forEach(e=>{e.classList.remove(`selected`),e.style.background=``,e.style.color=``}),i.classList.add(`selected`),t.classList.contains(`ld-stage-selector`)&&(i.style.background=`#2563eb`,i.style.color=`#fff`),t.classList.remove(`open`);let o=JSON.parse(localStorage.getItem(`thanjai_leads`))||[],s=o.findIndex(t=>t.id==e);if(s!==-1){if(t.id===`ld-assign-dropdown`){let t=i.textContent.trim(),n=t===`Assign to...`?`Unassigned`:t;o[s].assignTo!==n&&(o[s].assignTo=n,o[s].timeline||(o[s].timeline=[]),o[s].timeline.unshift({type:`system`,message:`Assigned to ${n}`,author:localStorage.getItem(`thanjai_active_user`)||`Aishwarya Raman`,date:new Date().toISOString()}),Z(o,e),window.dispatchEvent(new HashChangeEvent(`hashchange`)))}else if(t.classList.contains(`ld-stage-selector`)){let t=i.textContent.trim();if(t.includes(`sends WhatsApp`)&&(t=t.split(`sends WhatsApp`)[0].trim()),o[s].status!==t){let n=o[s].status||`New Lead`;o[s].status=t,o[s].timeline||(o[s].timeline=[]),o[s].timeline.unshift({type:`pipeline`,message:`Moved from ${n.toUpperCase().replace(/\s+/g,`_`)} to ${t.toUpperCase().replace(/\s+/g,`_`)}`,author:localStorage.getItem(`thanjai_active_user`)||`Aishwarya Raman`,date:new Date().toISOString()}),Z(o,e),window.dispatchEvent(new HashChangeEvent(`hashchange`))}}}})})});let P=document.querySelectorAll(`.ld-tab`),F=document.querySelectorAll(`.ld-tab-pane`);P.forEach(e=>{e.addEventListener(`click`,()=>{P.forEach(e=>{e.classList.remove(`active`),e.style.color=`var(--os-gray-500)`,e.style.borderBottom=`none`}),e.classList.add(`active`),e.style.color=`#ea580c`,e.style.borderBottom=`2px solid #ea580c`,F.forEach(e=>e.style.display=`none`);let t=e.getAttribute(`data-target`);if(t){let e=document.getElementById(t);e&&(e.style.display=`block`)}})}),document.addEventListener(`click`,()=>{N.forEach(e=>e.classList.remove(`open`))})}async function Z(e,t=null){if(localStorage.setItem(`thanjai_leads`,JSON.stringify(e)),t){let n=e.find(e=>e.id==t);if(n)try{let e={...n,phone:n.phone||n.mobile||n.whatsapp||``,budget:n.budgetMax?n.budgetMax:n.budgetMin||``,requirement:n.type||``,location:n.city||n.area||``,source:n.source||``,status:n.status||``,assignedTo:n.assignTo||``,notes:typeof n.notes==`string`?n.notes:JSON.stringify(n.notes||[]),timeline:typeof n.timeline==`string`?n.timeline:JSON.stringify(n.timeline||[]),followup:n.followUpDate||n.followup||``};await o(`/leads/`+t,{method:`PUT`,body:JSON.stringify(e)})}catch(e){console.error(`Failed to sync lead update to backend:`,e)}}}var Q={isFormOpen:!1,editingPostId:null,activeCategory:`all`,searchQuery:``};function vt(){let e=ie(),t=e.filter(e=>{let t=Q.activeCategory===`all`||e.category===Q.activeCategory,n=Q.searchQuery.toLowerCase(),r=!n||e.title.toLowerCase().includes(n)||e.category.toLowerCase().includes(n)||e.author.toLowerCase().includes(n)||e.excerpt&&e.excerpt.toLowerCase().includes(n);return t&&r});return`
    <div class="view-enter blog-cms-view">
      <style>
        .blog-filter-btn {
          padding: 6px 14px;
          border-radius: 20px;
          border: 1px solid #e2e8f0;
          background: #fff;
          color: #4a5568;
          font-size: 0.85rem;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.2s;
        }
        .blog-filter-btn:hover {
          background: #f7fafc;
          border-color: #cbd5e0;
        }
        .blog-filter-btn.active {
          background: #2d3748;
          color: #fff;
          border-color: #2d3748;
        }
      </style>
      <!-- Top Header -->
      <div style="display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 16px; margin-bottom: 24px;">
        <div>
          <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px;">
            <span style="font-size: 0.75rem; font-weight: 700; color: var(--os-luxury-orange); letter-spacing: 1px; text-transform: uppercase;">
              <i class="ri-article-line" style="margin-right: 4px;"></i> CONTENT MANAGEMENT SYSTEM
            </span>
          </div>
          <h1 class="view-title" style="margin: 4px 0;">Blog Posts & Publishing CMS</h1>
          <p class="view-subtitle" style="margin: 0;">Write, edit, and manage articles, legal Patta guides, and market perspectives for the public website.</p>
        </div>

        <div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
          <a href="/index.html#blog" target="_blank" class="os-btn-secondary" style="display: inline-flex; align-items: center; gap: 8px; text-decoration: none;">
            <i class="ri-external-link-line"></i> View Live Journal
          </a>
          <button class="os-btn-secondary" id="reset-blog-posts-btn" style="color: #e53e3e; border-color: rgba(229, 62, 62, 0.3);">
            <i class="ri-refresh-line"></i> Reset Articles
          </button>
          <button class="os-btn-primary" id="open-blog-form-btn">
            <i class="ri-add-line"></i> Write New Article
          </button>
        </div>
      </div>

      <!-- Article Creation / Edit Form Container -->
      <div id="blog-form-wrapper" style="display: ${Q.isFormOpen?`block`:`none`}; margin-bottom: 32px;">
        ${yt()}
      </div>

      <!-- KPI Summary Cards -->
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px;">
        <div style="background: #ffffff; border: 1px solid rgba(0,0,0,0.06); border-radius: 14px; padding: 18px; box-shadow: 0 2px 8px rgba(0,0,0,0.02);">
          <span style="font-size: 0.78rem; text-transform: uppercase; color: #777; font-weight: 700;">Total Published</span>
          <h3 style="font-size: 1.6rem; font-weight: 800; color: #1a1a1a; margin-top: 4px;">${e.length}</h3>
        </div>
        <div style="background: #ffffff; border: 1px solid rgba(0,0,0,0.06); border-radius: 14px; padding: 18px; box-shadow: 0 2px 8px rgba(0,0,0,0.02);">
          <span style="font-size: 0.78rem; text-transform: uppercase; color: #777; font-weight: 700;">Legal & Patta Guides</span>
          <h3 style="font-size: 1.6rem; font-weight: 800; color: #eb5e28; margin-top: 4px;">${e.filter(e=>e.category===`Legal & Patta`).length}</h3>
        </div>
        <div style="background: #ffffff; border: 1px solid rgba(0,0,0,0.06); border-radius: 14px; padding: 18px; box-shadow: 0 2px 8px rgba(0,0,0,0.02);">
          <span style="font-size: 0.78rem; text-transform: uppercase; color: #777; font-weight: 700;">Investment & Market</span>
          <h3 style="font-size: 1.6rem; font-weight: 800; color: #1a1a1a; margin-top: 4px;">${e.filter(e=>e.category===`Investment`||e.category===`Market Guide`).length}</h3>
        </div>
        <div style="background: #ffffff; border: 1px solid rgba(0,0,0,0.06); border-radius: 14px; padding: 18px; box-shadow: 0 2px 8px rgba(0,0,0,0.02);">
          <span style="font-size: 0.78rem; text-transform: uppercase; color: #777; font-weight: 700;">Architecture & NRI</span>
          <h3 style="font-size: 1.6rem; font-weight: 800; color: #1a1a1a; margin-top: 4px;">${e.filter(e=>e.category===`Architecture`||e.category===`NRI Guide`).length}</h3>
        </div>
      </div>

      <!-- Filter Controls Bar -->
      <div class="os-filter-bar" style="margin-bottom: 24px;">
        <div class="search-box" style="flex: 1; max-width: 380px;">
          <i class="ri-search-line"></i>
          <input type="text" id="blog-cms-search" value="${Q.searchQuery}" placeholder="Search article title, category, author..." />
        </div>
      </div>

      <!-- Articles Data Table -->
      <div style="background: #ffffff; border: 1px solid rgba(0,0,0,0.08); border-radius: 16px; overflow: hidden; box-shadow: 0 4px 16px rgba(0,0,0,0.03);">
        <table style="width: 100%; border-collapse: collapse; text-align: left;">
          <thead>
            <tr style="background: #fdfbf7; border-bottom: 1px solid rgba(0,0,0,0.06); font-size: 0.78rem; text-transform: uppercase; color: #666; letter-spacing: 0.05em;">
              <th style="padding: 16px 20px;">Article Title</th>
              <th style="padding: 16px 20px;">Category</th>
              <th style="padding: 16px 20px;">Date & Read Time</th>
              <th style="padding: 16px 20px; text-align: right;">Actions</th>
            </tr>
          </thead>
          <tbody>
            ${t.length===0?`
              <tr>
                <td colspan="4" style="padding: 40px 20px; text-align: center; color: #888;">
                  <i class="ri-draft-line" style="font-size: 2.5rem; color: #ccc; display: block; margin-bottom: 8px;"></i>
                  <p style="font-weight: 600;">No articles match your query.</p>
                </td>
              </tr>
            `:t.map(e=>`
              <tr style="border-bottom: 1px solid rgba(0,0,0,0.05); transition: background 0.2s;" onmouseenter="this.style.background='#faf7f2'" onmouseleave="this.style.background='transparent'">
                <td style="padding: 16px 20px;">
                  <div style="display: flex; align-items: center; gap: 14px;">
                    <img src="${e.image}" alt="${e.title}" style="width: 64px; height: 44px; border-radius: 8px; object-fit: cover; background: #eee;" onerror="this.src='https://via.placeholder.com/100x70';" />
                    <div>
                      <strong style="font-size: 0.95rem; color: #1a1a1a; display: block; line-height: 1.3;">${e.title}</strong>
                      <span style="font-size: 0.8rem; color: #777; line-height: 1.3; display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden; max-width: 380px;">${e.excerpt||``}</span>
                    </div>
                  </div>
                </td>
                <td style="padding: 16px 20px; white-space: nowrap;">
                  <span class="badge badge-orange" style="font-size: 0.78rem; font-weight: 700; padding: 4px 10px; border-radius: 12px; background: rgba(235,94,40,0.1); color: #eb5e28;">
                    ${e.category||`General`}
                  </span>
                </td>
                <td style="padding: 16px 20px;">
                  <span style="font-size: 0.85rem; color: #444; display: block;">${e.date}</span>
                  <span style="font-size: 0.75rem; color: #888;">${e.readTime||`5 min read`}</span>
                </td>
                <td style="padding: 16px 20px; text-align: right;">
                  <div style="display: flex; gap: 8px; justify-content: flex-end;">
                    <button class="os-btn-secondary edit-post-btn" data-id="${e.id}" style="padding: 6px 12px; font-size: 0.8rem;" title="Edit article">
                      <i class="ri-edit-line"></i> Edit
                    </button>
                    <button class="os-btn-secondary delete-post-btn" data-id="${e.id}" style="padding: 6px 12px; font-size: 0.8rem; color: #e53e3e; border-color: rgba(229,62,62,0.3);" title="Delete article">
                      <i class="ri-delete-bin-line"></i>
                    </button>
                  </div>
                </td>
              </tr>
            `).join(``)}
          </tbody>
        </table>
      </div>
    </div>
  `}function yt(){let e=!!Q.editingPostId,t=e?ie().find(e=>e.id===Q.editingPostId):null;return`
    <div style="background: #ffffff; border: 1px solid var(--color-orange, #eb5e28); border-radius: 16px; padding: 24px; box-shadow: 0 8px 24px rgba(235,94,40,0.08);">
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid rgba(0,0,0,0.06); padding-bottom: 12px;">
        <h2 style="font-size: 1.2rem; font-weight: 700; color: #1a1a1a; display: flex; align-items: center; gap: 8px;">
          <i class="${e?`ri-edit-line`:`ri-file-add-line`}" style="color: #eb5e28;"></i>
          ${e?`Edit Published Article`:`Create & Publish New Article`}
        </h2>
        <button id="close-blog-form-btn" style="background: none; border: none; font-size: 1.4rem; color: #777; cursor: pointer;">
          <i class="ri-close-line"></i>
        </button>
      </div>

      <form id="blog-editor-form" style="display: flex; flex-direction: column; gap: 16px;">
        <!-- Title, Category / Keyword & URL Slug -->
        <div style="display: grid; grid-template-columns: 2fr 1fr 1fr; gap: 16px;">
          <div>
            <label style="font-size: 0.8rem; font-weight: 700; color: #444; display: block; margin-bottom: 6px;">Article Title *</label>
            <input type="text" id="form-title" value="${t?t.title:``}" required placeholder="e.g. Essential Patta Title Verification Guide for Buyers" style="width: 100%; padding: 10px 14px; font-size: 0.9rem; border-radius: 8px; border: 1px solid #cbd5e0;" />
          </div>

          <div>
            <label style="font-size: 0.8rem; font-weight: 700; color: #444; display: block; margin-bottom: 6px;">Category / Keyword *</label>
            <input type="text" id="form-category" value="${t?t.category:``}" required placeholder="e.g. Legal & Patta, Market Guide" style="width: 100%; padding: 10px 14px; font-size: 0.9rem; border-radius: 8px; border: 1px solid #cbd5e0; background: white;" />
          </div>

          <div>
            <label style="font-size: 0.8rem; font-weight: 700; color: #444; display: block; margin-bottom: 6px;">URL Slug *</label>
            <input type="text" id="form-slug" value="${t?t.slug||t.id:``}" required placeholder="e.g. market-guide-patta-verification" style="width: 100%; padding: 10px 14px; font-size: 0.9rem; border-radius: 8px; border: 1px solid #cbd5e0; background: white;" />
          </div>
        </div>
        <!-- Publish Date -->
        <div>
          <label style="font-size: 0.8rem; font-weight: 700; color: #444; display: block; margin-bottom: 6px;">Publish Date</label>
          <input type="text" id="form-date" value="${t?t.date:new Date().toLocaleDateString(`en-IN`,{day:`2-digit`,month:`short`,year:`numeric`})}" style="width: 100%; padding: 10px 14px; font-size: 0.9rem; border-radius: 8px; border: 1px solid #cbd5e0; background: #ffffff;" />
        </div>

        <!-- Cover Image URL & File Upload -->
        <div>
          <label style="font-size: 0.8rem; font-weight: 700; color: #444; display: block; margin-bottom: 6px;">Cover Image URL / Upload File</label>
          <div style="display: flex; gap: 10px; align-items: center;">
            <input type="url" id="form-image" value="${t?t.image:``}" placeholder="https://images.unsplash.com/... or choose file" style="flex: 1; padding: 10px 14px; font-size: 0.9rem; border-radius: 8px; border: 1px solid #cbd5e0;" />
            <label style="cursor: pointer; padding: 10px 16px; border-radius: 8px; background: #f7fafc; border: 1px dashed #cbd5e0; font-size: 0.85rem; font-weight: 600; color: #444; display: inline-flex; align-items: center; gap: 6px;">
              <i class="ri-upload-cloud-line" style="color: #eb5e28;"></i> Upload Image
              <input type="file" id="form-file-input" accept="image/*" style="display: none;" />
            </label>
          </div>
        </div>

        <!-- Excerpt -->
        <div>
          <label style="font-size: 0.8rem; font-weight: 700; color: #444; display: block; margin-bottom: 6px;">Short Summary / Excerpt *</label>
          <textarea id="form-excerpt" rows="2" required placeholder="Provide a brief compelling summary displayed on article cards..." style="width: 100%; padding: 10px 14px; font-size: 0.9rem; border-radius: 8px; border: 1px solid #cbd5e0; font-family: inherit;">${t?t.excerpt:``}</textarea>
        </div>

        <!-- SEO Metadata Settings (Meta Title & Meta Description) -->
        <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 18px; margin-top: 4px;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px; flex-wrap: wrap; gap: 8px;">
            <span style="font-size: 0.85rem; font-weight: 800; color: #1a202c; display: flex; align-items: center; gap: 6px;">
              <i class="ri-search-eye-line" style="color: #eb5e28;"></i> Search Engine Optimization (SEO Metadata)
            </span>
            <span style="font-size: 0.75rem; color: #718096; font-style: italic;">Defaults will auto-fill from Title & Excerpt if left empty</span>
          </div>

          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 14px;">
            <div>
              <label style="font-size: 0.8rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">SEO Meta Title</label>
              <input type="text" id="form-meta-title" value="${t&&t.metaTitle||``}" placeholder="Default: ${t?t.title:`Article Title`} | Thanjai Property" style="width: 100%; padding: 10px 14px; font-size: 0.9rem; border-radius: 8px; border: 1px solid #cbd5e0; background: #ffffff;" />
              <span style="font-size: 0.74rem; color: #718096; margin-top: 4px; display: block;">Recommended: 50–60 characters</span>
            </div>

            <div>
              <label style="font-size: 0.8rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 6px;">SEO Meta Description</label>
              <textarea id="form-meta-desc" rows="2" placeholder="Default: Auto-populates from Short Summary / Excerpt..." style="width: 100%; padding: 10px 14px; font-size: 0.88rem; border-radius: 8px; border: 1px solid #cbd5e0; background: #ffffff; font-family: inherit;">${t&&t.metaDescription||``}</textarea>
              <span style="font-size: 0.74rem; color: #718096; margin-top: 4px; display: block;">Recommended: 150–160 characters</span>
            </div>
          </div>

          <!-- Google Search Engine Snippet Live Preview -->
          <div style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px 18px; box-shadow: 0 2px 6px rgba(0,0,0,0.02);">
            <div style="font-size: 0.72rem; font-weight: 700; text-transform: uppercase; color: #a0aec0; margin-bottom: 6px; letter-spacing: 0.05em;">
              Google Search Snippet Preview
            </div>
            <div id="seo-preview-title" style="font-size: 1.08rem; color: #1a0dab; font-weight: 600; text-decoration: none; margin-bottom: 2px; line-height: 1.3;">
              ${t&&t.metaTitle?t.metaTitle:t?`${t.title} | Thanjai Property`:`Article Title | Thanjai Property`}
            </div>
            <div id="seo-preview-url" style="font-size: 0.8rem; color: #006621; margin-bottom: 4px;">
              https://www.thanjaiproperty.com/blog/${t&&t.slug||`article-slug`}
            </div>
            <div id="seo-preview-desc" style="font-size: 0.84rem; color: #545454; line-height: 1.45;">
              ${t&&t.metaDescription?t.metaDescription:t&&t.excerpt?t.excerpt:`Compelling article summary and legal land verification guide on Thanjai Property.`}
            </div>
          </div>
        </div>

        <!-- Full Article Body Content (Rich Text Toolbar matching Image 3) -->
        <div>
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
            <label style="font-size: 0.8rem; font-weight: 700; color: #444;">Article Body Content *</label>
            <div style="display: flex; gap: 8px; align-items: center;">
              <button type="button" id="editor-add-media-btn" style="padding: 5px 12px; font-size: 0.82rem; font-weight: 600; background: #ffffff; border: 1px solid #cbd5e0; border-radius: 6px; cursor: pointer; color: #2d3748; display: inline-flex; align-items: center; gap: 6px;">
                <i class="ri-image-add-line" style="color: #eb5e28;"></i> Add Media
              </button>
              <div style="display: inline-flex; border: 1px solid #cbd5e0; border-radius: 6px; overflow: hidden; background: #edf2f7;">
                <button type="button" id="editor-mode-text-btn" class="editor-mode-tab active" style="padding: 5px 12px; font-size: 0.8rem; font-weight: 700; border: none; background: #2d3748; color: #ffffff; cursor: pointer;">Text</button>
                <button type="button" id="editor-mode-html-btn" class="editor-mode-tab" style="padding: 5px 12px; font-size: 0.8rem; font-weight: 700; border: none; background: transparent; color: #4a5568; cursor: pointer;">HTML</button>
              </div>
            </div>
          </div>

          <!-- Formatting Toolbar -->
          <div id="wysiwyg-toolbar" style="display: flex; flex-wrap: wrap; gap: 6px; align-items: center; padding: 8px 12px; background: #f8fafc; border: 1px solid #cbd5e0; border-bottom: none; border-top-left-radius: 8px; border-top-right-radius: 8px; user-select: none;">
            <!-- Undo / Redo -->
            <button type="button" class="toolbar-btn" data-cmd="undo" title="Undo (Ctrl+Z)" style="padding: 5px 9px; font-size: 0.95rem; border: 1px solid #cbd5e0; border-radius: 4px; background: white; cursor: pointer; color: #2d3748;"><i class="ri-arrow-go-back-line"></i></button>
            <button type="button" class="toolbar-btn" data-cmd="redo" title="Redo (Ctrl+Y)" style="padding: 5px 9px; font-size: 0.95rem; border: 1px solid #cbd5e0; border-radius: 4px; background: white; cursor: pointer; color: #2d3748;"><i class="ri-arrow-go-forward-line"></i></button>

            <div style="width: 1px; height: 20px; background: #cbd5e0; margin: 0 4px;"></div>

            <!-- Block Format Dropdown (Paragraph, H1-H6, Blockquote, Code) -->
            <select id="toolbar-format-select" style="padding: 5px 8px; font-size: 0.82rem; border-radius: 4px; border: 1px solid #cbd5e0; background: white; font-weight: 700; color: #2d3748; cursor: pointer;">
              <option value="p">¶ Paragraph</option>
              <option value="h1">H1 Heading 1</option>
              <option value="h2">H2 Heading 2</option>
              <option value="h3">H3 Heading 3</option>
              <option value="h4">H4 Heading 4</option>
              <option value="h5">H5 Heading 5</option>
              <option value="h6">H6 Heading 6</option>
              <option value="blockquote">❝ Blockquote</option>
              <option value="pre">&lt;/&gt; Code Block</option>
            </select>

            <div style="width: 1px; height: 20px; background: #cbd5e0; margin: 0 4px;"></div>

            <!-- Text Formatting (B, I, U, S) -->
            <button type="button" class="toolbar-btn" data-cmd="bold" title="Bold (Ctrl+B)" style="padding: 5px 10px; font-size: 0.95rem; font-weight: 800; border: 1px solid #cbd5e0; border-radius: 4px; background: white; cursor: pointer;">B</button>
            <button type="button" class="toolbar-btn" data-cmd="italic" title="Italic (Ctrl+I)" style="padding: 5px 10px; font-size: 0.95rem; font-style: italic; font-weight: 700; border: 1px solid #cbd5e0; border-radius: 4px; background: white; cursor: pointer;">I</button>
            <button type="button" class="toolbar-btn" data-cmd="underline" title="Underline (Ctrl+U)" style="padding: 5px 10px; font-size: 0.95rem; text-decoration: underline; font-weight: 700; border: 1px solid #cbd5e0; border-radius: 4px; background: white; cursor: pointer;">U</button>
            <button type="button" class="toolbar-btn" data-cmd="strikeThrough" title="Strikethrough" style="padding: 5px 10px; font-size: 0.95rem; text-decoration: line-through; font-weight: 700; border: 1px solid #cbd5e0; border-radius: 4px; background: white; cursor: pointer;">S</button>

            <div style="width: 1px; height: 20px; background: #cbd5e0; margin: 0 4px;"></div>

            <!-- Lists & Blockquote -->
            <button type="button" class="toolbar-btn" data-cmd="insertUnorderedList" title="Bulleted List" style="padding: 5px 8px; font-size: 0.95rem; border: 1px solid #cbd5e0; border-radius: 4px; background: white; cursor: pointer;"><i class="ri-list-unordered"></i></button>
            <button type="button" class="toolbar-btn" data-cmd="insertOrderedList" title="Numbered List" style="padding: 5px 8px; font-size: 0.95rem; border: 1px solid #cbd5e0; border-radius: 4px; background: white; cursor: pointer;"><i class="ri-list-ordered-2"></i></button>
            <button type="button" class="toolbar-btn" id="toolbar-quote-btn" title="Insert Blockquote" style="padding: 5px 8px; font-size: 0.95rem; border: 1px solid #cbd5e0; border-radius: 4px; background: white; cursor: pointer;"><i class="ri-double-quotes-l"></i></button>
            <button type="button" class="toolbar-btn" data-cmd="insertHorizontalRule" title="Horizontal Divider" style="padding: 5px 8px; font-size: 0.95rem; border: 1px solid #cbd5e0; border-radius: 4px; background: white; cursor: pointer;"><i class="ri-separator"></i></button>

            <div style="width: 1px; height: 20px; background: #cbd5e0; margin: 0 4px;"></div>

            <!-- Alignments -->
            <button type="button" class="toolbar-btn" data-cmd="justifyLeft" title="Align Left" style="padding: 5px 8px; font-size: 0.95rem; border: 1px solid #cbd5e0; border-radius: 4px; background: white; cursor: pointer;"><i class="ri-align-left"></i></button>
            <button type="button" class="toolbar-btn" data-cmd="justifyCenter" title="Align Center" style="padding: 5px 8px; font-size: 0.95rem; border: 1px solid #cbd5e0; border-radius: 4px; background: white; cursor: pointer;"><i class="ri-align-center"></i></button>
            <button type="button" class="toolbar-btn" data-cmd="justifyRight" title="Align Right" style="padding: 5px 8px; font-size: 0.95rem; border: 1px solid #cbd5e0; border-radius: 4px; background: white; cursor: pointer;"><i class="ri-align-right"></i></button>
            <button type="button" class="toolbar-btn" data-cmd="justifyFull" title="Justify Full" style="padding: 5px 8px; font-size: 0.95rem; border: 1px solid #cbd5e0; border-radius: 4px; background: white; cursor: pointer;"><i class="ri-align-justify"></i></button>

            <div style="width: 1px; height: 20px; background: #cbd5e0; margin: 0 4px;"></div>

            <!-- Table, Link, Clear Format -->
            <button type="button" class="toolbar-btn" id="toolbar-table-btn" title="Insert Table" style="padding: 5px 8px; font-size: 0.95rem; border: 1px solid #cbd5e0; border-radius: 4px; background: white; cursor: pointer;"><i class="ri-table-line"></i></button>
            <button type="button" class="toolbar-btn" id="toolbar-link-btn" title="Insert Link" style="padding: 5px 8px; font-size: 0.95rem; border: 1px solid #cbd5e0; border-radius: 4px; background: white; cursor: pointer;"><i class="ri-link"></i></button>
            <button type="button" class="toolbar-btn" data-cmd="unlink" title="Remove Link" style="padding: 5px 8px; font-size: 0.95rem; border: 1px solid #cbd5e0; border-radius: 4px; background: white; cursor: pointer;"><i class="ri-link-unlink"></i></button>
            <button type="button" class="toolbar-btn" data-cmd="removeFormat" title="Clear Formatting" style="padding: 5px 8px; font-size: 0.95rem; border: 1px solid #cbd5e0; border-radius: 4px; background: white; cursor: pointer; color: #e53e3e;"><i class="ri-format-clear"></i></button>
          </div>

          <!-- Link Manager Dialog Popover -->
          <div id="editor-link-popover" style="display: none; background: #ffffff; border: 2px solid #eb5e28; border-radius: 10px; box-shadow: 0 12px 30px rgba(0,0,0,0.15); padding: 16px; margin-bottom: 12px; position: relative; z-index: 100;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
              <span style="font-size: 0.9rem; font-weight: 800; color: #1a202c; display: flex; align-items: center; gap: 8px;">
                <i class="ri-link" style="color: #eb5e28; font-size: 1.1rem;"></i> Hyperlink Manager
              </span>
              <button type="button" id="link-popover-close-btn" style="background: none; border: none; font-size: 1.2rem; color: #718096; cursor: pointer; padding: 2px 6px; line-height: 1;">&times;</button>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1.2fr; gap: 12px; margin-bottom: 14px;">
              <div>
                <label style="display: block; font-size: 0.8rem; font-weight: 700; color: #4a5568; margin-bottom: 4px;">Text to Display *</label>
                <input type="text" id="link-popover-text" placeholder="e.g. thanjai property" style="width: 100%; padding: 8px 12px; font-size: 0.9rem; border: 1px solid #cbd5e0; border-radius: 6px; outline: none;" />
              </div>
              <div>
                <label style="display: block; font-size: 0.8rem; font-weight: 700; color: #4a5568; margin-bottom: 4px;">Destination URL *</label>
                <input type="text" id="link-popover-url" placeholder="https://www.thanjaiproperty.com/" style="width: 100%; padding: 8px 12px; font-size: 0.9rem; border: 1px solid #cbd5e0; border-radius: 6px; outline: none;" />
              </div>
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
              <label style="display: flex; align-items: center; gap: 6px; font-size: 0.82rem; font-weight: 600; color: #4a5568; cursor: pointer;">
                <input type="checkbox" id="link-popover-newtab" checked style="accent-color: #eb5e28;" /> Open link in new tab
              </label>
              <div style="display: flex; gap: 8px;">
                <button type="button" id="link-popover-remove-btn" style="display: none; padding: 7px 14px; font-size: 0.82rem; font-weight: 700; color: #e53e3e; background: #fff5f5; border: 1px solid #feb2b2; border-radius: 6px; cursor: pointer;">
                  <i class="ri-link-unlink"></i> Remove Link
                </button>
                <button type="button" id="link-popover-apply-btn" style="padding: 7px 18px; font-size: 0.85rem; font-weight: 800; color: #ffffff; background: #eb5e28; border: none; border-radius: 6px; cursor: pointer; display: inline-flex; align-items: center; gap: 6px;">
                  <i class="ri-check-line"></i> Apply Link
                </button>
              </div>
            </div>
          </div>

          <!-- Content Editable & Raw HTML Area -->
          <div style="position: relative;">
            <style>
              #editor-visual-body a, .editor-article-link {
                color: #eb5e28 !important;
                text-decoration: underline !important;
                font-weight: 700 !important;
                cursor: pointer !important;
                background: rgba(235,94,40,0.1) !important;
                padding: 1px 6px !important;
                border-radius: 4px !important;
                border: 1px solid rgba(235,94,40,0.3) !important;
                display: inline-block !important;
                transition: all 0.2s ease;
              }
              #editor-visual-body a:hover, .editor-article-link:hover {
                color: #c84919 !important;
                background: rgba(235,94,40,0.2) !important;
                border-color: #eb5e28 !important;
              }
              #editor-visual-body a::before {
                content: "🔗 ";
                font-size: 0.75rem;
                opacity: 0.85;
              }
              #editor-visual-body h1, #editor-visual-body h2, #editor-visual-body h3, #editor-visual-body h4, #editor-visual-body h5, #editor-visual-body h6 {
                font-family: var(--font-serif, serif);
                color: #1a202c;
                margin-top: 1.2em;
                margin-bottom: 0.5em;
                font-weight: 800;
              }
              #editor-visual-body h1 { font-size: 2rem; }
              #editor-visual-body h2 { font-size: 1.65rem; }
              #editor-visual-body h3 { font-size: 1.4rem; }
              #editor-visual-body h4 { font-size: 1.2rem; }
              #editor-visual-body p { margin-bottom: 1em; line-height: 1.7; }
              #editor-visual-body blockquote {
                border-left: 4px solid #eb5e28;
                padding: 10px 18px;
                margin: 16px 0;
                background: #faf8f5;
                font-style: italic;
                color: #4a5568;
                border-radius: 0 8px 8px 0;
              }
              .link-quick-action-pill {
                position: absolute;
                display: none;
                z-index: 120;
                background: #1a202c;
                color: #ffffff;
                border-radius: 8px;
                padding: 6px 12px;
                font-size: 0.8rem;
                box-shadow: 0 8px 24px rgba(0,0,0,0.25);
                align-items: center;
                gap: 8px;
                white-space: nowrap;
              }
            </style>
            
            <!-- Floating Quick Action Pill for Links in Editor -->
            <div id="link-quick-action-pill" class="link-quick-action-pill">
              <span id="pill-url-preview" style="max-width: 180px; overflow: hidden; text-overflow: ellipsis; color: #fed7aa; font-weight: 600;"></span>
              <button type="button" id="pill-open-btn" style="background: none; border: none; color: #90cdf4; cursor: pointer; font-size: 0.78rem; font-weight: 700; padding: 2px 4px;" title="Open link in new tab">↗ Open</button>
              <button type="button" id="pill-edit-btn" style="background: none; border: none; color: #ffffff; cursor: pointer; font-size: 0.78rem; font-weight: 700; padding: 2px 4px;" title="Edit this link">✏ Edit</button>
              <button type="button" id="pill-unlink-btn" style="background: none; border: none; color: #feb2b2; cursor: pointer; font-size: 0.78rem; font-weight: 700; padding: 2px 4px;" title="Remove link">✕ Remove</button>
            </div>

            <div 
              id="editor-visual-body" 
              contenteditable="true" 
              style="min-height: 220px; max-height: 480px; overflow-y: auto; padding: 16px; background: #ffffff; border: 1px solid #cbd5e0; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px; font-size: 0.95rem; line-height: 1.6; outline: none;"
            >${t?t.content:``}</div>
            
            <textarea 
              id="form-content" 
              rows="8"
              style="display: none; width: 100%; min-height: 220px; padding: 16px; font-size: 0.9rem; font-family: monospace; border: 1px solid #cbd5e0; border-bottom-left-radius: 8px; border-bottom-right-radius: 8px;"
            >${t?t.content:``}</textarea>
            
            <input type="file" id="media-file-input" accept="image/*" style="display: none;" />
          </div>
        </div>

        <!-- Submit & Cancel buttons -->
        <div style="display: flex; gap: 12px; justify-content: flex-end; margin-top: 8px;">
          <button type="button" class="os-btn-secondary" id="cancel-blog-form-btn">Cancel</button>
          <button type="submit" class="os-btn-primary" style="padding: 10px 24px;">
            <i class="ri-send-plane-line"></i> ${e?`Save Changes`:`Publish Article`}
          </button>
        </div>
      </form>
    </div>
  `}function bt(){document.getElementById(`blog-cms-search`)?.addEventListener(`input`,e=>{Q.searchQuery=e.target.value.toLowerCase();let t=document.querySelectorAll(`.blog-cms-view tbody tr`),n=0;t.forEach(e=>{e.querySelector(`td[colspan]`)||(e.textContent.toLowerCase().includes(Q.searchQuery)?(e.style.display=`table-row`,n++):e.style.display=`none`)})}),document.querySelectorAll(`#blog-cms-tabs .img-tab-btn`).forEach(e=>{e.addEventListener(`click`,()=>{Q.activeCategory=e.dataset.category||`all`,$()})}),document.getElementById(`open-blog-form-btn`)?.addEventListener(`click`,()=>{Q.isFormOpen=!0,Q.editingPostId=null,$()}),document.getElementById(`close-blog-form-btn`)?.addEventListener(`click`,()=>{Q.isFormOpen=!1,Q.editingPostId=null,$()}),document.getElementById(`cancel-blog-form-btn`)?.addEventListener(`click`,()=>{Q.isFormOpen=!1,Q.editingPostId=null,$()}),document.querySelectorAll(`.edit-post-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.id;t&&(Q.isFormOpen=!0,Q.editingPostId=t,$(),document.getElementById(`blog-form-wrapper`)?.scrollIntoView({behavior:`smooth`}))})}),document.querySelectorAll(`.delete-post-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.id;t&&v({title:`Delete Blog Article`,message:`Are you sure you want to delete this blog article from the public website? This action cannot be undone.`,confirmText:`Delete Article`,isDestructive:!0,onConfirm:async()=>{await ne(t),f(`Article deleted successfully.`,`ri-delete-bin-line`),$()}})})}),document.getElementById(`reset-blog-posts-btn`)?.addEventListener(`click`,()=>{v({title:`Reset Blog Articles`,message:`Restore all default factory seed blog articles? Your current custom articles will be reset.`,confirmText:`Reset Articles`,isDestructive:!0,onConfirm:()=>{te(),f(`Restored default seed articles.`,`ri-refresh-line`),$()}})});let e=document.getElementById(`form-title`),t=document.getElementById(`form-category`),n=document.getElementById(`form-slug`),r=!1;n?.addEventListener(`input`,()=>{r=!0});let i=()=>{if(r)return;let i=t?t.value.trim():``,a=e?e.value.trim():``,o=(i||a||``).toLowerCase().replace(/[^a-z0-9]+/g,`-`).replace(/(^-|-$)+/g,``);n&&o&&(n.value=o)};t?.addEventListener(`input`,i),e?.addEventListener(`input`,i);let a=document.getElementById(`form-meta-title`),o=document.getElementById(`form-meta-desc`),s=document.getElementById(`form-excerpt`),c=document.getElementById(`seo-preview-title`),l=document.getElementById(`seo-preview-url`),u=document.getElementById(`seo-preview-desc`);function d(){let t=e?e.value.trim():``,r=n?n.value.trim():``,i=a?a.value.trim():``,d=s?s.value.trim():``,f=o?o.value.trim():``;c&&(c.textContent=i||(t?`${t} | Thanjai Property`:`Article Title | Thanjai Property`)),l&&(l.textContent=`https://www.thanjaiproperty.com/blog/${r||`article-slug`}`),u&&(u.textContent=f||d||`Compelling article summary and legal land verification guide on Thanjai Property.`)}a?.addEventListener(`input`,d),o?.addEventListener(`input`,d),s?.addEventListener(`input`,d),e?.addEventListener(`input`,d),n?.addEventListener(`input`,d);let p=document.getElementById(`editor-visual-body`),m=document.getElementById(`form-content`),h=document.getElementById(`wysiwyg-toolbar`),g=document.getElementById(`toolbar-format-select`);document.getElementById(`toolbar-fontsize-select`);let _=null;function y(){let e=window.getSelection();e&&e.rangeCount>0&&p&&p.contains(e.anchorNode)&&(_=e.getRangeAt(0).cloneRange())}function b(){if(_&&p){let e=window.getSelection();e.removeAllRanges(),e.addRange(_)}}function x(){p&&m&&p.style.display!==`none`&&(m.value=p.innerHTML)}function S(){if(!p||p.style.display===`none`)return;y();let e=window.getSelection();if(e&&e.anchorNode&&p.contains(e.anchorNode)){let t=e.anchorNode;t.nodeType===3&&(t=t.parentNode);let n=`p`,r=t;for(;r&&r!==p;){let e=r.tagName?r.tagName.toLowerCase():``;if([`h1`,`h2`,`h3`,`h4`,`h5`,`h6`,`blockquote`,`pre`,`p`].includes(e)){n=e;break}r=r.parentNode}g&&(g.value=n)}document.querySelectorAll(`.toolbar-btn[data-cmd]`).forEach(e=>{let t=e.dataset.cmd;try{[`bold`,`italic`,`underline`,`strikeThrough`,`insertUnorderedList`,`insertOrderedList`,`justifyLeft`,`justifyCenter`,`justifyRight`,`justifyFull`].includes(t)&&(document.queryCommandState(t)?(e.style.background=`#edf2f7`,e.style.color=`#eb5e28`,e.style.borderColor=`#cbd5e0`):(e.style.background=`#ffffff`,e.style.color=`#2d3748`,e.style.borderColor=`#cbd5e0`))}catch{}})}p?.addEventListener(`keyup`,()=>{y(),x(),S()}),p?.addEventListener(`mouseup`,()=>{y(),S()}),p?.addEventListener(`input`,()=>{x(),S()}),p?.addEventListener(`focus`,()=>{y(),S()}),p?.addEventListener(`paste`,e=>{let t=e.clipboardData||window.clipboardData;if(!t)return;let n=t.getData(`text/plain`).trim();if(/^https?:\/\/[^\s]+$/i.test(n)||/^www\.[^\s]+$/i.test(n)){let t=window.getSelection(),r=n.startsWith(`www.`)?`https://${n}`:n;if(t&&t.rangeCount>0&&p.contains(t.anchorNode)){let n=t.getRangeAt(0),i=n.toString().trim();if(!n.collapsed&&i.length>0){e.preventDefault();let a=document.createElement(`a`);a.href=r,a.target=`_blank`,a.rel=`noopener noreferrer`,a.className=`editor-article-link`,a.textContent=n.toString(),n.deleteContents(),n.insertNode(a);let o=document.createRange();o.setStartAfter(a),o.setEndAfter(a),t.removeAllRanges(),t.addRange(o),_=o.cloneRange(),x(),S(),f(`Wrapped "${i}" with link!`,`ri-link`);return}{e.preventDefault();let i=document.createElement(`a`);i.href=r,i.target=`_blank`,i.rel=`noopener noreferrer`,i.className=`editor-article-link`,i.textContent=r,n.deleteContents(),n.insertNode(i);let a=document.createTextNode(`\xA0`);i.parentNode.insertBefore(a,i.nextSibling);let o=document.createRange();o.setStartAfter(a),o.setEndAfter(a),t.removeAllRanges(),t.addRange(o),_=o.cloneRange(),x(),S(),f(`Pasted as active link!`,`ri-link`);return}}}}),p?.addEventListener(`keydown`,e=>{if(e.key===` `||e.key===`Enter`){let e=window.getSelection();if(!e||!e.anchorNode||e.anchorNode.nodeType!==3)return;let t=e.anchorNode.textContent,n=e.anchorOffset,r=t.slice(0,n).split(/\s+/),i=r[r.length-1];if((/^https?:\/\/[^\s]+$/i.test(i)||/^www\.[^\s]+$/i.test(i))&&!e.anchorNode.parentNode.closest(`a`)){let t=i.startsWith(`www.`)?`https://${i}`:i,r=n-i.length,a=document.createRange();a.setStart(e.anchorNode,r),a.setEnd(e.anchorNode,n);let o=document.createElement(`a`);o.href=t,o.target=`_blank`,o.rel=`noopener noreferrer`,o.className=`editor-article-link`,o.textContent=i,a.deleteContents(),a.insertNode(o);let s=document.createTextNode(`\xA0`);o.parentNode.insertBefore(s,o.nextSibling);let c=document.createRange();c.setStartAfter(s),c.setEndAfter(s),e.removeAllRanges(),e.addRange(c),_=c.cloneRange(),x(),S()}}}),document.querySelectorAll(`.toolbar-btn`).forEach(e=>{e.addEventListener(`mousedown`,e=>{e.preventDefault()})}),document.querySelectorAll(`.toolbar-btn[data-cmd]`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault();let n=e.dataset.cmd;p&&(p.focus(),b(),document.execCommand(n,!1,null),y(),x(),S())})});function C(e){if(!p)return;p.focus(),b();let t=e.toLowerCase(),n=!1;try{n=document.execCommand(`formatBlock`,!1,`<${t}>`)}catch{}if(!n)try{document.execCommand(`formatBlock`,!1,t)}catch{}y(),x(),S()}g?.addEventListener(`change`,e=>{C(e.target.value)}),document.getElementById(`toolbar-quote-btn`)?.addEventListener(`click`,e=>{e.preventDefault(),C(`blockquote`)}),document.getElementById(`toolbar-table-btn`)?.addEventListener(`click`,e=>{e.preventDefault();let t=prompt(`Enter number of rows:`,`3`),n=prompt(`Enter number of columns:`,`3`),r=parseInt(t,10)||3,i=parseInt(n,10)||3,a=`<table class="blog-table" style="width: 100%; border-collapse: collapse; margin: 20px 0; font-size: 0.92rem; border: 1px solid #cbd5e0;"><thead><tr style="background: #f7fafc;">`;for(let e=1;e<=i;e++)a+=`<th style="border: 1px solid #cbd5e0; padding: 10px 14px; font-weight: 700; color: #1a202c; text-align: left;">Header ${e}</th>`;a+=`</tr></thead><tbody>`;for(let e=1;e<=Math.max(1,r-1);e++){a+=`<tr>`;for(let t=1;t<=i;t++)a+=`<td style="border: 1px solid #cbd5e0; padding: 10px 14px; color: #2d3748;">Data ${e}.${t}</td>`;a+=`</tr>`}a+=`</tbody></table><p></p>`,p&&p.style.display!==`none`?(p.focus(),b(),document.execCommand(`insertHTML`,!1,a),x()):m&&(m.value+=`\n${a}\n`),f(`Table inserted into article!`,`ri-table-line`)});let w=null,T=null,E=document.getElementById(`editor-link-popover`),D=document.getElementById(`link-popover-text`),O=document.getElementById(`link-popover-url`),k=document.getElementById(`link-popover-newtab`),A=document.getElementById(`link-popover-apply-btn`),j=document.getElementById(`link-popover-remove-btn`),ee=document.getElementById(`link-popover-close-btn`),M=document.getElementById(`link-quick-action-pill`),oe=document.getElementById(`pill-url-preview`),se=document.getElementById(`pill-open-btn`),ce=document.getElementById(`pill-edit-btn`),le=document.getElementById(`pill-unlink-btn`);function ue(e=null){if(E){if(w=e,y(),e)D&&(D.value=e.textContent.replace(/^🔗\s*/,``).trim()),O&&(O.value=e.getAttribute(`href`)||``),k&&(k.checked=e.getAttribute(`target`)===`_blank`),j&&(j.style.display=`inline-flex`);else{let e=``;_&&(e=_.toString().trim()),D&&(D.value=e),e.startsWith(`http://`)||e.startsWith(`https://`)||e.startsWith(`www.`)?O&&(O.value=e.startsWith(`www.`)?`https://${e}`:e):O&&(O.value=`https://`),k&&(k.checked=!0),j&&(j.style.display=`none`)}E.style.display=`block`,P(),setTimeout(()=>{O&&(O.focus(),O.value===`https://`?O.setSelectionRange(8,8):O.select())},50)}}function de(){E&&(E.style.display=`none`),w=null}function N(e){!M||!p||(T=e,oe&&(oe.textContent=e.getAttribute(`href`)||``),M.style.top=`${e.offsetTop+e.offsetHeight+6}px`,M.style.left=`${Math.max(12,e.offsetLeft)}px`,M.style.display=`flex`)}function P(){M&&(M.style.display=`none`),T=null}A?.addEventListener(`click`,e=>{e.preventDefault();let t=O?O.value.trim():``,n=D?D.value.trim():``;if(!t||t===`https://`||t===`http://`){f(`Please enter a valid destination URL.`,`ri-alert-line`),O?.focus();return}let r=t.startsWith(`http://`)||t.startsWith(`https://`)||t.startsWith(`/`)||t.startsWith(`tel:`)||t.startsWith(`mailto:`)?t:`https://${t}`;n||=r;let i=!k||k.checked;if(w)w.href=r,w.textContent=n,i?(w.setAttribute(`target`,`_blank`),w.setAttribute(`rel`,`noopener noreferrer`)):(w.removeAttribute(`target`),w.removeAttribute(`rel`));else{p&&p.focus(),b();let e=window.getSelection(),t=e&&e.rangeCount>0&&p.contains(e.anchorNode)?e.getRangeAt(0):_,a=document.createElement(`a`);a.href=r,i&&(a.setAttribute(`target`,`_blank`),a.setAttribute(`rel`,`noopener noreferrer`)),a.className=`editor-article-link`,a.textContent=n,t&&!t.collapsed?(t.deleteContents(),t.insertNode(a)):t?t.insertNode(a):p&&p.appendChild(a)}de(),x(),S(),f(`Hyperlink applied successfully!`,`ri-link`)}),j?.addEventListener(`click`,e=>{if(e.preventDefault(),w){let e=document.createTextNode(w.textContent);w.parentNode.replaceChild(e,w),de(),x(),S(),f(`Link removed.`,`ri-link-unlink`)}}),ee?.addEventListener(`click`,de),se?.addEventListener(`click`,e=>{e.preventDefault(),T&&T.href&&window.open(T.href,`_blank`)}),ce?.addEventListener(`click`,e=>{e.preventDefault(),T&&ue(T)}),le?.addEventListener(`click`,e=>{if(e.preventDefault(),T){let e=document.createTextNode(T.textContent);T.parentNode.replaceChild(e,T),P(),x(),S(),f(`Link removed.`,`ri-link-unlink`)}}),p?.addEventListener(`click`,e=>{let t=e.target.closest(`a`);t&&p.contains(t)?(e.preventDefault(),N(t)):P()}),document.getElementById(`toolbar-link-btn`)?.addEventListener(`click`,e=>{e.preventDefault(),ue()});let F=document.getElementById(`editor-mode-text-btn`),fe=document.getElementById(`editor-mode-html-btn`);F?.addEventListener(`click`,()=>{m&&p&&(p.innerHTML=m.value,p.style.display=`block`,h&&(h.style.display=`flex`),m.style.display=`none`,F.style.background=`#2d3748`,F.style.color=`#ffffff`,fe.style.background=`transparent`,fe.style.color=`#4a5568`,S())}),fe?.addEventListener(`click`,()=>{m&&p&&(m.value=p.innerHTML,m.style.display=`block`,p.style.display=`none`,h&&(h.style.display=`none`),fe.style.background=`#2d3748`,fe.style.color=`#ffffff`,F.style.background=`transparent`,F.style.color=`#4a5568`)});let pe=document.getElementById(`media-file-input`);document.getElementById(`editor-add-media-btn`)?.addEventListener(`click`,()=>{pe?.click()}),pe?.addEventListener(`change`,e=>{let t=e.target.files[0];if(t){if(t.size>5242880){f(`Media file size exceeds 5MB limit.`,`ri-alert-line`);return}let e=new FileReader;e.onload=function(e){let t=`<img src="${e.target.result}" alt="Article Image" style="max-width: 100%; border-radius: 12px; margin: 16px 0; box-shadow: 0 4px 16px rgba(0,0,0,0.08);" /><p></p>`;p&&p.style.display!==`none`?(p.focus(),b(),document.execCommand(`insertHTML`,!1,t),x()):m&&(m.value+=`\n${t}\n`),f(`Image inserted into article body!`,`ri-image-add-line`)},e.readAsDataURL(t)}}),document.getElementById(`form-file-input`)?.addEventListener(`change`,e=>{let t=e.target.files[0];if(t){if(t.size>5242880){f(`Image file size exceeds 5MB limit.`,`ri-alert-line`);return}let e=new FileReader;e.onload=function(e){let t=document.getElementById(`form-image`);t&&(t.value=e.target.result),f(`Cover image loaded. Click Publish to save.`,`ri-check-line`)},e.readAsDataURL(t)}});let me=document.getElementById(`form-author-avatar`),I=document.getElementById(`form-author-avatar-preview`),he=document.getElementById(`form-author-file-input`);me?.addEventListener(`input`,e=>{I&&(I.src=e.target.value||`https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80`)}),he?.addEventListener(`change`,e=>{let t=e.target.files[0];if(t){if(t.size>5242880){f(`Author image exceeds 5MB limit.`,`ri-alert-line`);return}let e=new FileReader;e.onload=function(e){me&&(me.value=e.target.result),I&&(I.src=e.target.result),f(`Author photo uploaded!`,`ri-check-line`)},e.readAsDataURL(t)}}),document.getElementById(`blog-editor-form`)?.addEventListener(`submit`,async e=>{e.preventDefault(),p&&p.style.display!==`none`&&m&&(m.value=p.innerHTML);let t=document.getElementById(`form-title`).value.trim(),n=document.getElementById(`form-category`).value.trim(),r=document.getElementById(`form-slug`).value.trim(),i=document.getElementById(`form-author`)?.value.trim()||`Admin`,a=document.getElementById(`form-date`).value.trim(),o=document.getElementById(`form-image`).value.trim(),s=document.getElementById(`form-excerpt`).value.trim(),c=document.getElementById(`form-meta-title`)?.value.trim()||(t?`${t} | Thanjai Property`:``),l=document.getElementById(`form-meta-desc`)?.value.trim()||s||``,u=document.getElementById(`form-content`).value.trim();if(!t||!n||!u){f(`Please complete all required fields.`,`ri-alert-line`);return}let d=Q.editingPostId?ie().find(e=>e.id===Q.editingPostId):null,h={title:t,category:n||`Market Guide`,slug:r||t.toLowerCase().replace(/[^a-z0-9]+/g,`-`).replace(/(^-|-$)+/g,``),author:i||`Thanjai Editorial Desk`,authorRole:``,authorBio:``,authorSocial:``,authorAvatar:d&&d.authorAvatar?d.authorAvatar:`https://ui-avatars.com/api/?name=${encodeURIComponent(i||`Thanjai Desk`)}&background=2A1808&color=F8F4EC`,date:a||new Date().toLocaleDateString(`en-IN`,{day:`2-digit`,month:`short`,year:`numeric`}),image:o||`https://images.unsplash.com/photo-1524813686514-a57563d77965?auto=format&fit=crop&w=1200&q=80`,excerpt:s||t,metaTitle:c||`${t} | Thanjai Property`,metaDescription:l||s||`Expert real estate guides and market insights from Thanjai Property.`,content:u};try{Q.editingPostId?(f(`Saving updates to database...`,`ri-loader-4-line`),await re(Q.editingPostId,h),f(`Article updated successfully!`,`ri-checkbox-circle-line`)):(f(`Publishing to database...`,`ri-loader-4-line`),await ae(h),f(`Article published to public website!`,`ri-checkbox-circle-fill`)),Q.isFormOpen=!1,Q.editingPostId=null,$()}catch{f(`Database Error: Image or content might be too large.`,`ri-error-warning-line`)}})}function $(){let e=document.getElementById(`os-content`);e&&(e.innerHTML=vt(),bt())}function xt(){let e=d(),t=k();return`
    <div class="view-enter">
      
      <!-- HEADER TITLE BAR -->
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px;">
        <div>
          <span style="font-size: 0.78rem; font-weight: 800; color: var(--os-luxury-orange); letter-spacing: 0.12em; text-transform: uppercase;">
            PORTAL USERS & SELLER ACCOUNTS
          </span>
          <h1 style="font-family: var(--font-sans); font-size: 1.8rem; font-weight: 800; color: var(--os-charcoal); margin-top: 4px;">
            Registered Users Management
          </h1>
          <p style="font-size: 0.88rem; color: var(--os-gray-400);">
            Track client portal account registrations, user roles, OTP verification status, and listed properties across Tamil Nadu.
          </p>
        </div>
      </div>

      <!-- USER STATS SUMMARY CARDS -->
      <div class="kpi-grid" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); margin-bottom: 28px;">
        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-title">TOTAL REGISTERED</span>
            <div class="kpi-icon" style="background: #ebf8ff; color: #3182ce;"><i class="ri-group-line"></i></div>
          </div>
          <div class="kpi-value">${e.length}</div>
          <div class="kpi-trend up"><i class="ri-arrow-up-line"></i> 100% verified</div>
        </div>

        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-title">INDIVIDUAL OWNERS</span>
            <div class="kpi-icon" style="background: #feebc8; color: #dd6b20;"><i class="ri-user-3-line"></i></div>
          </div>
          <div class="kpi-value">${e.filter(e=>St(e)===`Individual Owner`).length}</div>
          <div class="kpi-trend neutral"><i class="ri-shield-check-line"></i> Land owners</div>
        </div>

        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-title">AGENTS & BROKERS</span>
            <div class="kpi-icon" style="background: #e6fffa; color: #319795;"><i class="ri-briefcase-line"></i></div>
          </div>
          <div class="kpi-value">${e.filter(e=>St(e)===`Agent / Broker`).length}</div>
          <div class="kpi-trend neutral"><i class="ri-building-line"></i> Network pros</div>
        </div>

        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-title">BUILDERS & DEVS</span>
            <div class="kpi-icon" style="background: #faf5ff; color: #805ad5;"><i class="ri-community-line"></i></div>
          </div>
          <div class="kpi-value">${e.filter(e=>St(e)===`Builder / Developer`).length}</div>
          <div class="kpi-trend neutral"><i class="ri-layout-line"></i> Layout developers</div>
        </div>
      </div>

      <!-- MAIN USERS DIRECTORY TABLE -->
      <div class="os-chart-card">
        <div class="os-chart-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
          <div style="display: flex; align-items: center; gap: 16px; flex-wrap: wrap;">
            <span><i class="ri-user-shared-line"></i> Registered Portal Users Directory</span>
          </div>
          
          <div style="display: flex; gap: 16px; align-items: center; flex-wrap: wrap;">
            <div style="position: relative;">
              <i class="ri-search-line" style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--os-gray-400);"></i>
              <input type="text" id="user-search-input" placeholder="Search by name, email, phone..." style="padding: 8px 14px 8px 36px; border-radius: 8px; border: 1px solid var(--os-border); font-size: 0.85rem; outline: none; width: 240px; background: #fff;" />
            </div>
            
            <select id="user-role-filter" style="padding: 8px 12px; border-radius: 8px; border: 1px solid var(--os-border); background: #fff; font-size: 0.85rem; font-weight: 600; color: var(--os-charcoal); outline: none; cursor: pointer;">
              <option value="all">All Roles</option>
              <option value="Individual Owner">Individual Owner</option>
              <option value="Agent / Broker">Agent / Broker</option>
              <option value="Builder / Developer">Builder / Developer</option>
            </select>
          </div>
        </div>

        <div class="table-responsive" style="margin-top: 16px; overflow-x: auto; width: 100%;">
          <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 0.88rem;" id="users-directory-table">
            <thead>
              <tr style="border-bottom: 1px solid rgba(0,0,0,0.08); text-transform: uppercase; font-size: 0.75rem; color: var(--os-gray-400);">
                <th style="padding: 14px 16px;">User ID</th>
                <th style="padding: 14px 16px;">Full Name</th>
                <th style="padding: 14px 16px;">Email Address</th>
                <th style="padding: 14px 16px;">Mobile Phone</th>
                <th style="padding: 14px 16px;">Role</th>
                <th style="padding: 14px 16px;">Listed Properties</th>
                <th style="padding: 14px 16px;">Status</th>
                <th style="padding: 14px 16px; text-align: right;">Actions</th>
              </tr>
            </thead>
            <tbody id="users-tbody">
              ${wt(e,t)}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  `}function St(e){let t=(e.role||e.roleLabel||e.roleCode||``).toLowerCase(),n=(e.email||``).toLowerCase();return t.includes(`builder`)||n.includes(`builder`)?`Builder / Developer`:t.includes(`agent`)||t.includes(`broker`)||n.includes(`agent`)?`Agent / Broker`:`Individual Owner`}function Ct(e){return e===`Builder / Developer`?`<span style="background: rgba(128,90,213,0.12); color: #805ad5; font-weight: 700; padding: 4px 10px; border-radius: 6px; font-size: 0.8rem; display: inline-block; white-space: nowrap;"><i class="ri-community-line" style="margin-right: 3px;"></i> Builder / Developer</span>`:e===`Agent / Broker`?`<span style="background: rgba(49,151,149,0.12); color: #319795; font-weight: 700; padding: 4px 10px; border-radius: 6px; font-size: 0.8rem; display: inline-block; white-space: nowrap;"><i class="ri-briefcase-line" style="margin-right: 3px;"></i> Agent / Broker</span>`:`<span style="background: rgba(49,130,206,0.12); color: #3182ce; font-weight: 700; padding: 4px 10px; border-radius: 6px; font-size: 0.8rem; display: inline-block; white-space: nowrap;"><i class="ri-user-3-line" style="margin-right: 3px;"></i> Individual Owner</span>`}function wt(e,t){return e.length===0?`
      <tr>
        <td colspan="8" style="padding: 30px; text-align: center; color: var(--os-gray-400);">
          No registered users found matching filter parameters.
        </td>
      </tr>
    `:e.map(e=>{let n=St(e),r=t.filter(t=>t.userEmail&&e.email&&t.userEmail.toLowerCase()===e.email.toLowerCase()||t.userId&&e.id&&t.userId===e.id||t.ownerPhone&&e.phone&&String(t.ownerPhone).replace(/\D/g,``)===String(e.phone).replace(/\D/g,``)||t.ownerName&&e.fullName&&(t.ownerName.toLowerCase().includes(e.fullName.toLowerCase())||e.fullName.toLowerCase().includes(t.ownerName.toLowerCase()))||t.listedBy&&e.fullName&&(t.listedBy.toLowerCase().includes(e.fullName.toLowerCase())||e.fullName.toLowerCase().includes(t.listedBy.toLowerCase()))).length;return`
      <tr style="border-bottom: 1px solid rgba(0,0,0,0.04);">
        <td style="padding: 14px 16px; font-weight: 700; color: var(--os-luxury-orange);">${e.id}</td>
        <td style="padding: 14px 16px; font-weight: 700;">${e.fullName}</td>
        <td style="padding: 14px 16px; color: var(--os-gray-600);">
          <div>${e.email}</div>
          <div style="margin-top: 4px;">
            ${e.isTemporaryPassword?`<span style="color: #DD6B20; font-size: 0.72rem; font-weight: 700; background: #FFFAF0; border: 1px solid #FEEBC8; padding: 2px 6px; border-radius: 4px; display: inline-flex; align-items: center; gap: 3px;"><i class="ri-key-2-line"></i> Temp PW: <strong>${e.temporaryPassword||e.password}</strong></span>`:`<span style="color: #38A169; font-size: 0.72rem; font-weight: 700; background: #F0FDF4; border: 1px solid #DCFCE7; padding: 2px 6px; border-radius: 4px; display: inline-flex; align-items: center; gap: 3px;"><i class="ri-shield-check-line"></i> Custom Password</span>`}
          </div>
        </td>
        <td style="padding: 14px 16px;">
          <a href="tel:${e.phone}" style="color: #3182ce; font-weight: 700; text-decoration: none;">
            ${e.phone||`N/A`}
          </a>
        </td>
        <td style="padding: 14px 16px;">
          ${Ct(n)}
        </td>
        <td style="padding: 14px 16px; font-weight: 800; color: var(--os-charcoal);">
          ${r} Properties
        </td>
        <td style="padding: 14px 16px;">
          <span style="color: #38a169; font-weight: 800; font-size: 0.82rem;">
            <i class="ri-checkbox-circle-fill"></i> ${e.status||`Active`}
          </span>
        </td>
        <td style="padding: 14px 16px; white-space: nowrap; text-align: right;">
          <div style="display: flex; justify-content: flex-end; align-items: center; gap: 8px;">
            <button class="view-user-props-btn" data-user-name="${e.fullName}" data-user-email="${e.email}" data-user-phone="${e.phone}" style="
              background: linear-gradient(135deg, #FFF5F2 0%, #FFEBE5 100%); color: #EB5E28;
              border: 1px solid #FFD0C2; font-weight: 700; border-radius: 8px; font-size: 0.82rem;
              padding: 6px 14px; box-shadow: 0 2px 6px rgba(235,94,40,0.12); cursor: pointer;
              display: inline-flex; align-items: center; gap: 6px; transition: all 0.2s ease;
            ">
              <i class="ri-building-4-line"></i> View Props
            </button>
            <button class="del-user-btn" data-user-id="${e.id}" style="
              background: linear-gradient(135deg, #FFF0F2 0%, #FFE5E8 100%); color: #E53E3E;
              border: 1px solid #FED7D7; font-weight: 700; border-radius: 8px; font-size: 0.82rem;
              padding: 6px 10px; box-shadow: 0 2px 6px rgba(229,62,62,0.12); cursor: pointer;
              display: inline-flex; align-items: center; transition: all 0.2s ease;
            " title="Delete User">
              <i class="ri-delete-bin-line"></i>
            </button>
          </div>
        </td>
      </tr>
    `}).join(``)}function Tt(){let e=document.getElementById(`user-search-input`),t=document.getElementById(`user-role-filter`),n=document.getElementById(`users-tbody`);function r(){let r=(e?.value||``).toLowerCase(),a=t?.value||`all`,o=d().filter(e=>{let t=St(e),n=!r||e.fullName.toLowerCase().includes(r)||e.email.toLowerCase().includes(r)||e.phone&&e.phone.includes(r),i=a===`all`||t.toLowerCase().includes(a.toLowerCase())||e.role&&e.role.toLowerCase().includes(a.toLowerCase());return n&&i});n&&(n.innerHTML=wt(o,k()),i())}function i(){document.querySelectorAll(`.view-user-props-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.userName,n=e.dataset.userEmail,r=e.dataset.userPhone;Et(t,n,r)})}),document.querySelectorAll(`.del-user-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.userId;t&&v({title:`Delete Portal User`,message:`Are you sure you want to delete user ${t}? This action cannot be undone.`,confirmText:`Delete User`,isDestructive:!0,onConfirm:()=>{l(t),f(`User deleted successfully`,`ri-delete-bin-line`)}})})})}e?.addEventListener(`input`,r),t?.addEventListener(`change`,r),i(),window.addEventListener(`userAuthUpdated`,r),window.addEventListener(`propertiesUpdated`,r),window.addEventListener(`storage`,r)}function Et(e,t,n){document.getElementById(`user-props-modal-overlay`)?.remove();let r=k().filter(t=>t.ownerName===e||t.ownerPhone===n||t.listedBy===e||e&&t.ownerName?.toLowerCase().includes(e.toLowerCase())),i=document.createElement(`div`);i.id=`user-props-modal-overlay`,i.style.cssText=`
    position: fixed !important; top: 0 !important; left: 0 !important; right: 0 !important; bottom: 0 !important;
    width: 100vw !important; height: 100vh !important; z-index: 999999 !important;
    background: rgba(15, 23, 42, 0.75) !important; backdrop-filter: blur(8px) !important;
    display: flex !important; align-items: center !important; justify-content: center !important;
    padding: 24px !important; box-sizing: border-box !important; margin: 0 !important;
  `,i.innerHTML=`
    <div style="
      background: #ffffff; width: 100%; max-width: 800px; max-height: 85vh; border-radius: 20px;
      display: flex; flex-direction: column; overflow: hidden; box-shadow: 0 24px 48px rgba(0,0,0,0.3);
      border: 1px solid #E2E8F0; box-sizing: border-box; animation: pageFadeIn 0.25s ease;
    ">
      <!-- MODAL HEADER -->
      <div style="
        padding: 20px 28px; background: #2B3648; color: #ffffff; display: flex;
        align-items: center; justify-content: space-between; border-bottom: 1px solid rgba(255,255,255,0.1);
      ">
        <div style="display: flex; align-items: center; gap: 12px;">
          <div style="width: 42px; height: 42px; border-radius: 12px; background: rgba(235,94,40,0.2); color: #eb5e28; display: flex; align-items: center; justify-content: center; font-size: 1.4rem;">
            <i class="ri-user-3-line"></i>
          </div>
          <div>
            <h3 style="font-size: 1.15rem; font-weight: 800; color: #ffffff; margin: 0;">${e}'s Portfolio</h3>
            <span style="font-size: 0.8rem; color: rgba(255,255,255,0.7);">${t||n||`Registered User`} • ${r.length} Properties Submitted</span>
          </div>
        </div>

        <button id="close-user-props-modal-btn" style="
          background: rgba(255,255,255,0.12); border: none; color: #ffffff; width: 34px; height: 34px;
          border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; cursor: pointer;
        ">
          <i class="ri-close-line"></i>
        </button>
      </div>

      <!-- MODAL BODY -->
      <div style="padding: 24px 28px; overflow-y: auto; flex: 1; background: #F8FAFC;">
        ${r.length===0?`
          <div style="padding: 48px; text-align: center; color: #718096;">
            <i class="ri-building-line" style="font-size: 3rem; color: #eb5e28; margin-bottom: 12px; display: block;"></i>
            <h4 style="font-size: 1.1rem; color: #1A202C; margin-bottom: 4px;">No Properties Uploaded Yet</h4>
            <p style="font-size: 0.88rem;">This user has not listed any property listings under their account yet.</p>
          </div>
        `:`
          <div style="display: flex; flex-direction: column; gap: 16px;">
            ${r.map(e=>{let t=e.approvalStatus===`Approved`||e.status===`Available`;return`
                <div style="background: #ffffff; border: 1px solid #E2E8F0; border-radius: 14px; padding: 16px; display: flex; gap: 16px; align-items: center; box-shadow: 0 2px 8px rgba(0,0,0,0.02);">
                  <img src="${e.images&&e.images[0]||`https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=200&q=80`}" style="width: 100px; height: 80px; border-radius: 10px; object-fit: cover;" />
                  
                  <div style="flex: 1;">
                    <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 4px;">
                      <span style="font-weight: 800; color: #eb5e28; font-size: 0.8rem;">${e.id}</span>
                      <h4 style="font-size: 1rem; font-weight: 700; color: #1A202C; margin: 0;">${e.title}</h4>
                    </div>

                    <div style="font-size: 0.82rem; color: #718096; display: flex; gap: 12px; margin-bottom: 6px; flex-wrap: wrap;">
                      <span><i class="ri-map-pin-line" style="color: #eb5e28;"></i> ${e.location}</span>
                      <span style="font-weight: 700; color: #2b6cb0;">${e.priceFormatted||`₹ `+e.price}</span>
                      <span>Type: ${e.type}</span>
                    </div>

                    <div>
                      ${t?`
                        <span style="background: #E6FFFA; color: #234E52; border: 1px solid #B2F5EA; font-weight: 800; padding: 3px 8px; border-radius: 6px; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 4px;">
                          <i class="ri-checkbox-circle-fill" style="color: #38A169;"></i> Approved & Published Live
                        </span>
                      `:`
                        <span style="background: #FEFCBF; color: #744210; border: 1px solid #F6E05E; font-weight: 800; padding: 3px 8px; border-radius: 6px; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 4px;">
                          <i class="ri-time-line" style="color: #D69E2E;"></i> Pending Admin Approval
                        </span>
                      `}
                    </div>
                  </div>
                </div>
              `}).join(``)}
          </div>
        `}
      </div>
    </div>
  `,document.body.appendChild(i);let a=()=>i.remove();document.getElementById(`close-user-props-modal-btn`)?.addEventListener(`click`,a),i.addEventListener(`click`,e=>{e.target===i&&a()})}function Dt(){let e=k(),t=e.filter(e=>e.approvalStatus===`Pending Approval`||e.status===`Pending Approval`),n=e.filter(e=>e.approvalStatus===`Approved`);return`
    <div class="view-enter">
      
      <!-- HEADER TITLE BAR -->
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px;">
        <div>
          <span style="font-size: 0.78rem; font-weight: 800; color: var(--os-luxury-orange); letter-spacing: 0.12em; text-transform: uppercase;">
            VERIFICATION & APPROVAL DESK
          </span>
          <h1 style="font-family: var(--font-sans); font-size: 1.8rem; font-weight: 800; color: var(--os-charcoal); margin-top: 4px;">
            Property Submissions Approval Desk
          </h1>
          <p style="font-size: 0.88rem; color: var(--os-gray-400);">
            Inspect land & property listings submitted by registered portal users before publishing live to the public website showcase.
          </p>
        </div>

        <div style="display: flex; gap: 12px; align-items: center;">
          <span style="background: rgba(229,46,61,0.12); color: #E52E3D; font-weight: 800; padding: 6px 14px; border-radius: 20px; font-size: 0.82rem;">
            <i class="ri-notification-3-fill"></i> ${t.length} Pending Approval
          </span>
        </div>
      </div>

      <!-- SUMMARY KPI CARDS -->
      <div class="kpi-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); margin-bottom: 28px;">
        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-title">PENDING APPROVAL</span>
            <div class="kpi-icon" style="background: #feebc8; color: #dd6b20;"><i class="ri-time-line"></i></div>
          </div>
          <div class="kpi-value">${t.length}</div>
          <div class="kpi-trend neutral"><i class="ri-shield-keyhole-line"></i> Needs verification</div>
        </div>

        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-title">APPROVED & PUBLISHED</span>
            <div class="kpi-icon" style="background: #e6fffa; color: #319795;"><i class="ri-checkbox-circle-line"></i></div>
          </div>
          <div class="kpi-value">${n.length}</div>
          <div class="kpi-trend up"><i class="ri-arrow-up-line"></i> Live on website</div>
        </div>
      </div>

      <!-- MAIN PENDING SUBMISSIONS LISTING CARDS -->
      <div class="os-chart-card">
        <div class="os-chart-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span><i class="ri-time-line"></i> Submissions Awaiting Approval (${t.length})</span>
        </div>

        <div style="padding: 24px;">
          ${t.length===0?`
            <div style="text-align: center; padding: 48px 24px; color: var(--os-gray-400);">
              <i class="ri-checkbox-circle-fill" style="font-size: 3rem; color: #38a169; margin-bottom: 12px; display: block;"></i>
              <h3 style="font-size: 1.1rem; color: var(--os-charcoal); margin-bottom: 4px;">All Catch Up! No Pending Submissions</h3>
              <p style="font-size: 0.88rem;">All user-submitted properties have been verified and approved.</p>
            </div>
          `:`
            <div style="display: flex; flex-direction: column; gap: 24px;" id="pending-cards-container">
              ${t.map(e=>Ot(e)).join(``)}
            </div>
          `}
        </div>
      </div>

    </div>
  `}function Ot(e){return`
    <div class="pending-prop-card" style="background: #FAF8F5; border: 1px solid #E7E0D8; border-radius: 16px; padding: 24px; display: grid; grid-template-columns: 240px 1fr; gap: 24px; align-items: start;">
      
      <!-- PROPERTY IMAGE PREVIEW -->
      <div style="width: 100%; height: 170px; border-radius: 12px; overflow: hidden; position: relative;">
        <img src="${e.images&&e.images[0]||`/default-property.jpg`}" alt="${e.title}" style="width: 100%; height: 100%; object-fit: cover;" />
        <span style="position: absolute; top: 10px; left: 10px; background: rgba(229,46,61,0.9); color: #fff; font-size: 0.72rem; font-weight: 800; padding: 4px 10px; border-radius: 12px; text-transform: uppercase;">
          ${e.type||`Property`}
        </span>
      </div>

      <!-- PROPERTY & POSTER DETAILS -->
      <div style="display: flex; flex-direction: column; justify-content: space-between; min-height: 170px;">
        <div>
          <!-- POSTER CREDENTIALS BADGE -->
          <div style="display: flex; gap: 12px; align-items: center; margin-bottom: 10px; flex-wrap: wrap;">
            <span style="background: #2B3648; color: #fff; font-size: 0.78rem; font-weight: 700; padding: 4px 10px; border-radius: 6px; display: inline-flex; align-items: center; gap: 6px;">
              <i class="ri-user-3-line" style="color: #eb5e28;"></i> Posted By: <strong>${e.ownerName||`Portal User`}</strong>
            </span>
            <span style="background: rgba(49,130,206,0.12); color: #3182ce; font-size: 0.78rem; font-weight: 700; padding: 4px 10px; border-radius: 6px;">
              Role: ${e.listedBy||`Individual Owner`}
            </span>
            <span style="color: #718096; font-size: 0.78rem; font-weight: 600;">
              <i class="ri-phone-line"></i> ${e.ownerPhone||`9585777772`}
            </span>
          </div>

          <h3 style="font-family: var(--font-sans); font-size: 1.25rem; font-weight: 800; color: #1A202C; margin-bottom: 6px;">
            ${e.title}
          </h3>

          <div style="display: flex; gap: 16px; font-size: 0.88rem; color: #4A5568; margin-bottom: 12px; flex-wrap: wrap;">
            <span><i class="ri-map-pin-line" style="color: #eb5e28;"></i> ${e.location||`Thanjavur, Tamil Nadu`}</span>
            <span style="font-weight: 800; color: #2b6cb0;">Price: ${e.priceFormatted||`₹ `+(e.price||0).toLocaleString(`en-IN`)}</span>
            <span>Purpose: ${e.purpose===`rent`?`For Rent`:`For Sale`}</span>
          </div>
        </div>

        <!-- ACTION BUTTONS -->
        <div style="display: flex; gap: 12px; padding-top: 14px; border-top: 1px solid rgba(0,0,0,0.06); flex-wrap: wrap;">
          <button class="preview-approval-btn" data-id="${e.id}" style="
            background: #EDF2F7; color: #2D3748; border: 1px solid #CBD5E0;
            padding: 10px 18px; border-radius: 10px; font-weight: 700; font-size: 0.88rem;
            cursor: pointer; display: inline-flex; align-items: center; gap: 8px; transition: all 0.2s ease;
          ">
            <i class="ri-eye-line" style="font-size: 1.1rem; color: #eb5e28;"></i> View Details
          </button>

          <button class="approve-prop-btn" data-id="${e.id}" style="
            background: linear-gradient(135deg, #38A169 0%, #2F855A 100%); color: #ffffff;
            border: none; padding: 10px 22px; border-radius: 10px; font-weight: 700; font-size: 0.88rem;
            cursor: pointer; display: inline-flex; align-items: center; gap: 8px;
            box-shadow: 0 4px 12px rgba(56,161,105,0.25); transition: all 0.2s ease;
          ">
            <i class="ri-checkbox-circle-fill" style="font-size: 1.1rem;"></i> Approve & Publish Live
          </button>
          
          <button class="reject-prop-btn" data-id="${e.id}" style="
            background: #FFF5F5; color: #E52E3D; border: 1px solid #FED7D7;
            padding: 10px 20px; border-radius: 10px; font-weight: 700; font-size: 0.88rem;
            cursor: pointer; display: inline-flex; align-items: center; gap: 8px;
            transition: all 0.2s ease;
          ">
            <i class="ri-close-circle-line" style="font-size: 1.1rem;"></i> Reject Submission
          </button>
        </div>
      </div>

    </div>
  `}function kt(){document.querySelectorAll(`.preview-approval-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault();let n=e.dataset.id,r=k().find(e=>e.id===n);r&&jt(r)})}),document.querySelectorAll(`.approve-prop-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault();let n=e.dataset.id;if(O(n)){f(`Success! Property ${n} Approved & Published Live to website showcase!`,`ri-checkbox-circle-fill`);let e=document.getElementById(`os-content`);e&&(e.innerHTML=Dt(),kt())}})}),document.querySelectorAll(`.reject-prop-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault();let n=e.dataset.id;At(n,k().find(e=>e.id===n)?.title||``,e=>{ee(n,e),f(`Property ${n} submission rejected.`,`ri-close-circle-line`);let t=document.getElementById(`os-content`);t&&(t.innerHTML=Dt(),kt())})})})}function At(e,t,n){document.getElementById(`rejection-modal-overlay`)?.remove();let r=document.createElement(`div`);r.id=`rejection-modal-overlay`,r.style.cssText=`
    position: fixed !important; top: 0 !important; left: 0 !important; right: 0 !important; bottom: 0 !important;
    width: 100vw !important; height: 100vh !important; z-index: 999999 !important;
    background: rgba(15, 23, 42, 0.75) !important; backdrop-filter: blur(8px) !important;
    display: flex !important; align-items: center !important; justify-content: center !important;
    padding: 24px !important; box-sizing: border-box !important; margin: 0 !important;
  `,r.innerHTML=`
    <div style="
      background: #ffffff; width: 100%; max-width: 480px; border-radius: 20px;
      overflow: hidden; box-shadow: 0 24px 48px rgba(0,0,0,0.3); border: 1px solid #E2E8F0;
      animation: pageFadeIn 0.25s ease; padding: 24px; box-sizing: border-box;
    ">
      <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 16px;">
        <div style="width: 44px; height: 44px; border-radius: 12px; background: #FFF5F5; color: #E52E3D; display: flex; align-items: center; justify-content: center; font-size: 1.4rem;">
          <i class="ri-close-circle-fill"></i>
        </div>
        <div>
          <h3 style="font-size: 1.15rem; font-weight: 800; color: #1A202C; margin: 0;">Reject Submission</h3>
          <span style="font-size: 0.8rem; color: #718096;">Property ID: ${e}</span>
        </div>
      </div>

      <p style="font-size: 0.88rem; color: #4A5568; margin-bottom: 16px;">
        Provide the rejection reason for <strong>${t||e}</strong>. This feedback will be sent directly to the seller's user dashboard.
      </p>

      <div style="margin-bottom: 20px;">
        <label style="font-size: 0.82rem; font-weight: 700; color: #4A5568; display: block; margin-bottom: 6px;">Rejection Reason</label>
        <textarea id="rejection-reason-input" rows="3" style="
          width: 100%; padding: 10px; border-radius: 10px; border: 1px solid #CBD5E0;
          font-size: 0.88rem; outline: none; box-sizing: border-box; font-family: inherit;
        " placeholder="Enter reason (e.g. Did not meet Patta title legal verification guidelines)">Did not meet Patta title legal verification guidelines</textarea>
      </div>

      <div style="display: flex; justify-content: flex-end; gap: 12px;">
        <button id="cancel-rejection-btn" style="
          padding: 10px 18px; border-radius: 10px; border: 1px solid #CBD5E0; background: #ffffff;
          color: #4A5568; font-weight: 700; font-size: 0.88rem; cursor: pointer;
        ">Cancel</button>

        <button id="confirm-rejection-btn" style="
          padding: 10px 22px; border-radius: 10px; border: none; background: #E52E3D;
          color: #ffffff; font-weight: 700; font-size: 0.88rem; cursor: pointer;
          box-shadow: 0 4px 12px rgba(229,46,61,0.25);
        ">Confirm Rejection</button>
      </div>
    </div>
  `,document.body.appendChild(r);let i=()=>r.remove();document.getElementById(`cancel-rejection-btn`)?.addEventListener(`click`,i),r.addEventListener(`click`,e=>{e.target===r&&i()}),document.getElementById(`confirm-rejection-btn`)?.addEventListener(`click`,()=>{let e=document.getElementById(`rejection-reason-input`)?.value.trim()||`Submission did not meet legal Patta verification guidelines.`;i(),n(e)})}function jt(e){document.getElementById(`approval-preview-modal-overlay`)?.remove();let t=0,n=Array.isArray(e.images)?e.images.filter(Boolean):[],r=[...new Set(n)],i=r.length>0?r:[`/default-property.jpg`],a=e.status||e.availability||`Pending Approval`,o=document.createElement(`div`);o.id=`approval-preview-modal-overlay`,o.style.cssText=`
    position: fixed !important; top: 0 !important; left: 0 !important; right: 0 !important; bottom: 0 !important;
    width: 100vw !important; height: 100vh !important; z-index: 999999 !important;
    background: rgba(15, 23, 42, 0.82) !important; backdrop-filter: blur(8px) !important;
    display: flex !important; align-items: center !important; justify-content: center !important;
    padding: 24px !important; box-sizing: border-box !important; margin: 0 !important;
  `;function s(){let n=i.length;t>=n&&(t=0);let r=i[t]||i[0];o.innerHTML=`
      <div style="
        background: #ffffff; width: 100%; max-width: 920px; max-height: 90vh; border-radius: 24px;
        overflow: hidden; box-shadow: 0 25px 60px rgba(0,0,0,0.5); border: 1px solid #e2e8f0; display: flex; flex-direction: column; animation: pageFadeIn 0.25s ease;
      ">
        
        <!-- Modal Fixed Top Bar -->
        <div style="padding: 18px 28px; background: #faf8f5; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; flex-shrink: 0;">
          <div>
            <span style="font-size: 0.75rem; font-weight: 800; color: #eb5e28; letter-spacing: 0.08em; text-transform: uppercase;">
              ADMIN PROPERTY PREVIEW • ID: ${e.id}
            </span>
            <h3 style="font-size: 1.3rem; font-weight: 800; color: #1a202c; margin: 2px 0 0 0;">${e.title}</h3>
          </div>

          <button id="close-approval-preview-btn" type="button" style="background: #ffffff; border: 1px solid #cbd5e0; color: #4a5568; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; cursor: pointer;">
            <i class="ri-close-line"></i>
          </button>
        </div>

        <!-- Scrollable Modal Body -->
        <div style="padding: 24px 28px; overflow-y: auto; display: flex; flex-direction: column; gap: 24px; flex: 1; background: #F8FAFC;">
          
          <!-- HERO MEDIA VIEWPORT WITH ARROWS (IMAGE 3 MATCH) -->
          <div style="width: 100%;">
            <div style="width: 100%; height: 380px; border-radius: 16px; overflow: hidden; background: #f0f4f8; position: relative; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
              <img src="${r}" alt="${e.title}" style="width: 100%; height: 100%; object-fit: cover;" />

              <!-- Counter Badge -->
              <div style="position: absolute; top: 16px; left: 16px; background: rgba(0,0,0,0.75); color: #ffffff; font-size: 0.8rem; font-weight: 700; padding: 6px 14px; border-radius: 20px; backdrop-filter: blur(4px); display: flex; align-items: center; gap: 6px; z-index: 10;">
                <i class="ri-image-line" style="color: #eb5e28;"></i>
                <span>Photo ${t+1} of ${n}</span>
              </div>

              <!-- Status Badge -->
              <span style="position: absolute; top: 16px; right: 16px; background: #eb5e28; color: #fff; font-size: 0.78rem; font-weight: 800; padding: 6px 14px; border-radius: 20px; z-index: 10; box-shadow: 0 4px 12px rgba(0,0,0,0.25);">
                ${a.toUpperCase()}
              </span>

              <!-- Carousel Arrows -->
              ${n>1?`
                <button id="prev-approval-media-btn" type="button" style="
                  position: absolute; left: 16px; top: 50%; transform: translateY(-50%); width: 44px; height: 44px; border-radius: 50%;
                  background: rgba(0,0,0,0.65); color: #ffffff; border: 1px solid rgba(255,255,255,0.3); font-size: 1.4rem;
                  display: flex; align-items: center; justify-content: center; cursor: pointer; backdrop-filter: blur(6px); z-index: 10;
                ">
                  <i class="ri-arrow-left-s-line"></i>
                </button>

                <button id="next-approval-media-btn" type="button" style="
                  position: absolute; right: 16px; top: 50%; transform: translateY(-50%); width: 44px; height: 44px; border-radius: 50%;
                  background: rgba(0,0,0,0.65); color: #ffffff; border: 1px solid rgba(255,255,255,0.3); font-size: 1.4rem;
                  display: flex; align-items: center; justify-content: center; cursor: pointer; backdrop-filter: blur(6px); z-index: 10;
                ">
                  <i class="ri-arrow-right-s-line"></i>
                </button>
              `:``}
            </div>

            <!-- Thumbnail Grid -->
            ${n>1?`
              <div style="display: flex; gap: 12px; overflow-x: auto; padding: 14px 4px 6px 4px; margin-top: 12px;">
                ${i.map((e,n)=>`
                  <div class="approval-thumb-item" data-index="${n}" style="
                    width: 90px; height: 65px; border-radius: 10px; overflow: hidden; flex-shrink: 0; cursor: pointer;
                    border: 2px solid ${n===t?`#eb5e28`:`transparent`};
                    opacity: ${n===t?`1`:`0.65`}; transition: all 0.2s ease;
                  ">
                    <img src="${e}" style="width: 100%; height: 100%; object-fit: cover;" />
                  </div>
                `).join(``)}
              </div>
            `:``}
          </div>

          <!-- DETAILS GRID -->
          <div style="background: #ffffff; padding: 20px; border-radius: 16px; border: 1px solid #E2E8F0; display: flex; flex-direction: column; gap: 16px;">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 12px;">
              <div>
                <span style="color: #718096; font-size: 0.88rem;"><i class="ri-map-pin-line" style="color: #eb5e28;"></i> ${e.location||`Thanjavur`}</span>
                <div style="font-size: 1.6rem; font-weight: 800; color: #eb5e28; margin-top: 4px;">${e.priceFormatted||`₹ `+(e.price||0).toLocaleString(`en-IN`)}</div>
              </div>
              <div style="font-size: 0.88rem; color: #4A5568; font-weight: 700; background: #EDF2F7; padding: 6px 14px; border-radius: 8px;">
                Type: ${e.type||`Property`} • Purpose: ${e.purpose===`rent`?`For Rent`:`For Sale`}
              </div>
            </div>

            <!-- SPECS PILLS -->
            <div style="display: flex; gap: 12px; flex-wrap: wrap; font-size: 0.85rem; font-weight: 700; color: #2D3748;">
              ${e.size?`<span style="background: #F7FAFC; padding: 6px 12px; border-radius: 6px; border: 1px solid #E2E8F0;"><i class="ri-ruler-2-line" style="color: #eb5e28;"></i> ${e.size}</span>`:``}
              ${e.bedrooms?`<span style="background: #F7FAFC; padding: 6px 12px; border-radius: 6px; border: 1px solid #E2E8F0;"><i class="ri-hotel-bed-line" style="color: #eb5e28;"></i> ${e.bedrooms} Bedrooms</span>`:``}
              ${e.bathrooms?`<span style="background: #F7FAFC; padding: 6px 12px; border-radius: 6px; border: 1px solid #E2E8F0;"><i class="ri-drop-line" style="color: #eb5e28;"></i> ${e.bathrooms} Bathrooms</span>`:``}
              ${e.furnishing?`<span style="background: #F7FAFC; padding: 6px 12px; border-radius: 6px; border: 1px solid #E2E8F0;"><i class="ri-armchair-line" style="color: #eb5e28;"></i> ${e.furnishing}</span>`:``}
            </div>

            <div style="background: #F8FAFC; padding: 14px 16px; border-radius: 10px; border: 1px solid #E2E8F0;">
              <strong style="font-size: 0.8rem; color: #718096; text-transform: uppercase; display: block; margin-bottom: 4px;">Poster / Owner Details:</strong>
              <span style="font-weight: 700; color: #1A202C;">${e.ownerName||`Portal User`} (${e.listedBy||`Individual Owner`})</span> • 
              <a href="tel:${e.ownerPhone}" style="color: #2b6cb0; text-decoration: none; font-weight: 700;">${e.ownerPhone||`N/A`}</a>
            </div>

            <div>
              <strong style="font-size: 0.8rem; color: #718096; text-transform: uppercase; display: block; margin-bottom: 4px;">Description:</strong>
              <p style="font-size: 0.9rem; color: #4A5568; line-height: 1.5; margin: 0;">${e.description||`No detailed description provided.`}</p>
            </div>

            ${e.features&&e.features.length>0?`
              <div>
                <strong style="font-size: 0.8rem; color: #718096; text-transform: uppercase; display: block; margin-bottom: 6px;">Features & Assurances:</strong>
                <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                  ${e.features.map(e=>`<span style="background: #E6FFFA; color: #234E52; font-size: 0.78rem; font-weight: 700; padding: 4px 10px; border-radius: 6px;"><i class="ri-checkbox-circle-fill" style="color: #38A169;"></i> ${e}</span>`).join(``)}
                </div>
              </div>
            `:``}
          </div>
        </div>

        <!-- FOOTER BUTTONS -->
        <div style="padding: 16px 28px; background: #faf8f5; border-top: 1px solid #e2e8f0; display: flex; justify-content: flex-end; gap: 12px;">
          <button id="modal-approve-btn" type="button" style="
            background: linear-gradient(135deg, #38A169 0%, #2F855A 100%); color: #ffffff; border: none;
            padding: 10px 24px; border-radius: 10px; font-weight: 700; font-size: 0.9rem; cursor: pointer;
            box-shadow: 0 4px 12px rgba(56,161,105,0.25);
          ">
            <i class="ri-checkbox-circle-fill"></i> Approve & Publish Live
          </button>
          
          <button id="modal-close-preview-btn" type="button" style="
            background: #ffffff; color: #4A5568; border: 1px solid #CBD5E0;
            padding: 10px 20px; border-radius: 10px; font-weight: 700; font-size: 0.9rem; cursor: pointer;
          ">
            Close Preview
          </button>
        </div>
      </div>
    `,c()}function c(){let n=()=>o.remove();o.querySelector(`#close-approval-preview-btn`)?.addEventListener(`click`,n),o.querySelector(`#modal-close-preview-btn`)?.addEventListener(`click`,n),o.querySelector(`#prev-approval-media-btn`)?.addEventListener(`click`,e=>{e.stopPropagation(),t=(t-1+i.length)%i.length,s()}),o.querySelector(`#next-approval-media-btn`)?.addEventListener(`click`,e=>{e.stopPropagation(),t=(t+1)%i.length,s()}),o.querySelectorAll(`.approval-thumb-item`).forEach(e=>{e.addEventListener(`click`,n=>{n.stopPropagation();let r=parseInt(e.dataset.index,10);isNaN(r)||(t=r,s())})}),o.querySelector(`#modal-approve-btn`)?.addEventListener(`click`,t=>{t.stopPropagation(),O(e.id),f(`Success! Property ${e.id} Approved & Published Live!`,`ri-checkbox-circle-fill`),n();let r=document.getElementById(`os-content`);r&&(r.innerHTML=Dt(),kt())})}o.addEventListener(`click`,e=>{e.target===o&&o.remove()}),s(),document.body.appendChild(o)}function Mt(){let e=d().filter(e=>e.role.toLowerCase().includes(`agent`)||e.roleCode===`agent`),t=k();return`
    <div class="view-enter">
      
      <!-- HEADER TITLE BAR -->
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px;">
        <div>
          <span style="font-size: 0.78rem; font-weight: 800; color: var(--os-luxury-orange); letter-spacing: 0.12em; text-transform: uppercase;">
            REAL ESTATE NETWORK PROS
          </span>
          <h1 style="font-family: var(--font-sans); font-size: 1.8rem; font-weight: 800; color: var(--os-charcoal); margin-top: 4px;">
            Agents & Brokers Directory
          </h1>
          <p style="font-size: 0.88rem; color: var(--os-gray-400);">
            Dedicated CRM module for managing registered real estate agents, active listings, verified brokerage licenses, and agent audit logs across Tamil Nadu.
          </p>
        </div>

        <div style="display: flex; gap: 12px; align-items: center;">
          <span style="background: rgba(49,130,206,0.12); color: #3182ce; font-weight: 800; padding: 6px 14px; border-radius: 20px; font-size: 0.82rem;">
            <i class="ri-briefcase-line"></i> ${e.length} Registered Agents
          </span>
        </div>
      </div>

      <!-- KPI SUMMARY CARDS -->
      <div class="kpi-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); margin-bottom: 28px;">
        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-title">TOTAL AGENTS</span>
            <div class="kpi-icon" style="background: #e6fffa; color: #319795;"><i class="ri-briefcase-line"></i></div>
          </div>
          <div class="kpi-value">${e.length}</div>
          <div class="kpi-trend up"><i class="ri-arrow-up-line"></i> Active Network</div>
        </div>

        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-title">AGENT LISTINGS</span>
            <div class="kpi-icon" style="background: #ebf8ff; color: #3182ce;"><i class="ri-building-line"></i></div>
          </div>
          <div class="kpi-value">${t.filter(e=>e.listedBy&&e.listedBy.toLowerCase().includes(`agent`)).length||6}</div>
          <div class="kpi-trend neutral"><i class="ri-checkbox-circle-line"></i> Verified Listings</div>
        </div>
      </div>

      <!-- AGENTS DIRECTORY TABLE -->
      <div class="os-chart-card">
        <div class="os-chart-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span><i class="ri-user-star-line"></i> Registered Real Estate Agents & Brokers</span>
        </div>

        <div class="table-responsive" style="margin-top: 16px;">
          <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 0.88rem;">
            <thead>
              <tr style="border-bottom: 1px solid rgba(0,0,0,0.08); text-transform: uppercase; font-size: 0.75rem; color: var(--os-gray-400);">
                <th style="padding: 14px 16px;">Agent ID</th>
                <th style="padding: 14px 16px;">Agent Name</th>
                <th style="padding: 14px 16px;">Brokerage Email</th>
                <th style="padding: 14px 16px;">Contact Phone</th>
                <th style="padding: 14px 16px;">Active Listings</th>
                <th style="padding: 14px 16px;">Status</th>
                <th style="padding: 14px 16px;">Audit Log</th>
              </tr>
            </thead>
            <tbody>
              ${e.length===0?`
                <tr>
                  <td colspan="7" style="padding: 30px; text-align: center; color: var(--os-gray-400);">
                    No registered agents found. New agent registrations will appear here.
                  </td>
                </tr>
              `:e.map(e=>`
                <tr style="border-bottom: 1px solid rgba(0,0,0,0.04);">
                  <td style="padding: 14px 16px; font-weight: 700; color: var(--os-luxury-orange);">${e.id}</td>
                  <td style="padding: 14px 16px; font-weight: 700;">${e.fullName}</td>
                  <td style="padding: 14px 16px; color: var(--os-gray-600);">${e.email}</td>
                  <td style="padding: 14px 16px;">
                    <a href="tel:${e.phone}" style="color: #3182ce; font-weight: 700; text-decoration: none;">${e.phone||`9585777772`}</a>
                  </td>
                  <td style="padding: 14px 16px; font-weight: 800;">
                    ${t.filter(t=>t.ownerName===e.fullName||t.ownerPhone===e.phone).length} Properties
                  </td>
                  <td style="padding: 14px 16px;">
                    <span style="color: #38a169; font-weight: 800; font-size: 0.82rem;">
                      <i class="ri-checkbox-circle-fill"></i> Verified Agent
                    </span>
                  </td>
                  <td style="padding: 14px 16px;">
                    <button class="os-btn secondary-btn view-agent-audit-btn" data-name="${e.fullName}" style="padding: 6px 12px; font-size: 0.8rem;">
                      <i class="ri-history-line"></i> View Audit Log
                    </button>
                  </td>
                </tr>
              `).join(``)}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  `}function Nt(){document.querySelectorAll(`.view-agent-audit-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.name;alert(`Agent Audit Trail for: ${t}\n- Account activated via OTP verification\n- Status: Verified Active Broker`)})})}function Pt(){let e=d().filter(e=>e.role.toLowerCase().includes(`builder`)||e.roleCode===`builder`),t=k();return`
    <div class="view-enter">
      
      <!-- HEADER TITLE BAR -->
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px;">
        <div>
          <span style="font-size: 0.78rem; font-weight: 800; color: var(--os-luxury-orange); letter-spacing: 0.12em; text-transform: uppercase;">
            TOWNSHIP & LAYOUT DEVELOPERS
          </span>
          <h1 style="font-family: var(--font-sans); font-size: 1.8rem; font-weight: 800; color: var(--os-charcoal); margin-top: 4px;">
            Builders & Developers Directory
          </h1>
          <p style="font-size: 0.88rem; color: var(--os-gray-400);">
            Dedicated CRM module for tracking registered property builders, DTCP layout developers, commercial projects, and builder audit logs.
          </p>
        </div>

        <div style="display: flex; gap: 12px; align-items: center;">
          <span style="background: rgba(128,90,213,0.12); color: #805ad5; font-weight: 800; padding: 6px 14px; border-radius: 20px; font-size: 0.82rem;">
            <i class="ri-community-line"></i> ${e.length} Registered Builders
          </span>
        </div>
      </div>

      <!-- KPI SUMMARY CARDS -->
      <div class="kpi-grid" style="grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); margin-bottom: 28px;">
        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-title">TOTAL BUILDERS</span>
            <div class="kpi-icon" style="background: #faf5ff; color: #805ad5;"><i class="ri-community-line"></i></div>
          </div>
          <div class="kpi-value">${e.length}</div>
          <div class="kpi-trend up"><i class="ri-arrow-up-line"></i> Approved Developers</div>
        </div>

        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-title">BUILDER TOWNSHIPS</span>
            <div class="kpi-icon" style="background: #feebc8; color: #dd6b20;"><i class="ri-layout-line"></i></div>
          </div>
          <div class="kpi-value">${t.filter(e=>e.listedBy&&e.listedBy.toLowerCase().includes(`builder`)).length||4}</div>
          <div class="kpi-trend neutral"><i class="ri-shield-check-line"></i> DTCP Approved</div>
        </div>
      </div>

      <!-- BUILDERS DIRECTORY TABLE -->
      <div class="os-chart-card">
        <div class="os-chart-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span><i class="ri-building-2-line"></i> Registered Builders & Layout Developers</span>
        </div>

        <div class="table-responsive" style="margin-top: 16px;">
          <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 0.88rem;">
            <thead>
              <tr style="border-bottom: 1px solid rgba(0,0,0,0.08); text-transform: uppercase; font-size: 0.75rem; color: var(--os-gray-400);">
                <th style="padding: 14px 16px;">Builder ID</th>
                <th style="padding: 14px 16px;">Company / Developer</th>
                <th style="padding: 14px 16px;">Official Email</th>
                <th style="padding: 14px 16px;">Contact Phone</th>
                <th style="padding: 14px 16px;">Active Layouts</th>
                <th style="padding: 14px 16px;">Status</th>
                <th style="padding: 14px 16px;">Audit Log</th>
              </tr>
            </thead>
            <tbody>
              ${e.length===0?`
                <tr>
                  <td colspan="7" style="padding: 30px; text-align: center; color: var(--os-gray-400);">
                    No registered builders found. New developer registrations will appear here.
                  </td>
                </tr>
              `:e.map(e=>`
                <tr style="border-bottom: 1px solid rgba(0,0,0,0.04);">
                  <td style="padding: 14px 16px; font-weight: 700; color: var(--os-luxury-orange);">${e.id}</td>
                  <td style="padding: 14px 16px; font-weight: 700;">${e.fullName}</td>
                  <td style="padding: 14px 16px; color: var(--os-gray-600);">${e.email}</td>
                  <td style="padding: 14px 16px;">
                    <a href="tel:${e.phone}" style="color: #3182ce; font-weight: 700; text-decoration: none;">${e.phone||`9585777772`}</a>
                  </td>
                  <td style="padding: 14px 16px; font-weight: 800;">
                    ${t.filter(t=>t.ownerName===e.fullName||t.ownerPhone===e.phone).length} Layouts
                  </td>
                  <td style="padding: 14px 16px;">
                    <span style="color: #805ad5; font-weight: 800; font-size: 0.82rem;">
                      <i class="ri-checkbox-circle-fill"></i> Registered Developer
                    </span>
                  </td>
                  <td style="padding: 14px 16px;">
                    <button class="os-btn secondary-btn view-builder-audit-btn" data-name="${e.fullName}" style="padding: 6px 12px; font-size: 0.8rem;">
                      <i class="ri-history-line"></i> View Audit Log
                    </button>
                  </td>
                </tr>
              `).join(``)}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  `}function Ft(){document.querySelectorAll(`.view-builder-audit-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.name;alert(`Builder Audit Trail for: ${t}\n- Account activated via OTP verification\n- Status: Registered Township Developer`)})})}function It(e,t){let n=e?new Date(e):new Date(new Date().getFullYear(),0,1),r=t?new Date(t):new Date(new Date().getFullYear(),11,31),i=`${n.getFullYear()}-${String(n.getMonth()+1).padStart(2,`0`)}-${String(n.getDate()).padStart(2,`0`)}`,a=`${r.getFullYear()}-${String(r.getMonth()+1).padStart(2,`0`)}-${String(r.getDate()).padStart(2,`0`)}`,o=new Date(r);o.setHours(23,59,59,999);let s=JSON.parse(localStorage.getItem(`thanjai_leads`))||[],c=JSON.parse(localStorage.getItem(`thanjai_partners`))||[],l=JSON.parse(localStorage.getItem(`thanjai_properties`))||[],u=s.filter(e=>{let t=e.createdAt?new Date(e.createdAt):new Date(`2026-01-01T00:00:00`);return t>=n&&t<=o}),d={},f={},p={},m=0;u.forEach(e=>{let t=e.source||`Manual`;d[t]=(d[t]||0)+1;let n=e.status||`New`;f[n]=(f[n]||0)+1;let r=e.assignTo||`Unassigned`;p[r]||(p[r]={total:0,converted:0}),p[r].total+=1,(n===`Registration`||n===`Converted`)&&(p[r].converted+=1),e.budgetMax&&(m+=parseInt(e.budgetMax.replace(/[^0-9]/g,``))||0)});let h=Object.entries(d).sort((e,t)=>t[1]-e[1]).map(([e,t])=>`<div class="report-list-item"><span>${e}</span><strong>${t}</strong></div>`).join(``)||`<div class="report-empty">No leads in this range</div>`,g=Object.entries(f).sort((e,t)=>t[1]-e[1]).map(([e,t])=>`<div class="report-list-item"><span>${e}</span><strong>${t}</strong></div>`).join(``)||`<div class="report-empty">No leads in this range</div>`,_=Object.entries(p).sort((e,t)=>t[1].total-e[1].total).map(([e,t])=>{let n=t.total>0?Math.round(t.converted/t.total*100):0;return`
        <tr>
          <td>${e}</td>
          <td class="right-align">${t.total}</td>
          <td class="right-align">${t.converted}</td>
          <td class="right-align">${n}%</td>
          <td class="right-align">-</td>
          <td class="right-align">-</td>
          <td class="right-align">-</td>
        </tr>
      `}).join(``)||`<tr><td colspan="7" class="report-empty" style="text-align:center; padding: 24px;">No leads found in this range</td></tr>`,v=`₹`+m.toLocaleString(`en-IN`),y=[{label:`Jan`,total:60,converted:22},{label:`Feb`,total:75,converted:28},{label:`Mar`,total:85,converted:35},{label:`Apr`,total:70,converted:25},{label:`May`,total:90,converted:40},{label:`Jun`,total:110,converted:45},{label:`Jul`,total:95,converted:38},{label:`Aug`,total:125,converted:55},{label:`Sep`,total:40,converted:12},{label:`Oct`,total:45,converted:15},{label:`Nov`,total:55,converted:18},{label:`Dec`,total:42,converted:10}].map((e,t)=>{let n=e.total/150*100,r=e.converted/150*100,i=t*.05;return`
      <div class="os-bar-group">
        <div class="os-bar-tooltip">${e.total} Leads, ${e.converted} Converted</div>
        <div class="os-bars">
          <div class="os-bar total" style="height: ${n}%; animation-delay: ${i}s;"></div>
          <div class="os-bar converted" style="height: ${r}%; animation-delay: ${i}s;"></div>
        </div>
        <span class="os-bar-label">${e.label}</span>
      </div>
    `}).join(``),b=c.length>0?c.map((e,t)=>{let n=[3,3,2,1,0][t%5]||0,r=n>0?`Shared: ${n}${t===0?` · Property Sent: 1`:``}`:`—`;return`
      <tr>
        <td style="font-weight: 600;">${e.company||e.name}</td>
        <td class="right-align">${n}</td>
        <td class="right-align">0</td>
        <td class="right-align">0%</td>
        <td class="status-breakdown">${r}</td>
      </tr>
    `}).join(``):`<tr><td colspan="5" class="report-empty" style="text-align:center; padding: 24px;">No partners data available</td></tr>`,x={};u.forEach(e=>{e.mobile&&(x[e.mobile]=(x[e.mobile]||0)+1)});let S=Object.values(x).filter(e=>e>1).length,C=u.filter(e=>e.status===`Converted`).length,w=`
    <div class="buyer-stats-grid">
      <div class="buyer-stat-box">
        <span class="buyer-stat-value">${S||1}</span>
        <span class="buyer-stat-label">Repeat inquirers</span>
      </div>
      <div class="buyer-stat-box">
        <span class="buyer-stat-value">${C||2}</span>
        <span class="buyer-stat-label">Converted leads</span>
      </div>
      <div class="buyer-stat-box">
        <span class="buyer-stat-value">20d</span>
        <span class="buyer-stat-label">Avg. decision time</span>
      </div>
      <div class="buyer-stat-box">
        <span class="buyer-stat-value">0.5</span>
        <span class="buyer-stat-label">Avg. shortlist size</span>
      </div>
    </div>
  `,T=l.slice(0,6).map((e,t)=>{let n=[20,18,10,5,3,2][t%6]||Math.floor(Math.random()*5),r=[3,0,1,1,1,0][t%6]||0,i=e.location||e.district||`Unknown`,a=i.length>35?`<span style="font-size:0.8rem; color:var(--os-gray-500);">${i.substring(0,35)}...</span>`:i;return`
      <tr>
        <td style="font-weight: 500;">${e.title}</td>
        <td class="sub-text">${a}</td>
        <td class="sub-text">${e.status||`Available`}</td>
        <td class="right-align">${n}</td>
        <td class="right-align">${r}</td>
      </tr>
    `}).join(``)||`<tr><td colspan="5" class="report-empty" style="text-align:center; padding: 24px;">No property data available</td></tr>`,E=u.filter(e=>e.status&&(e.status.toLowerCase().includes(`lost`)||e.status===`Dropped`));return`
    <div class="reports-container view-enter">
      
      <!-- Header Section -->
      <div class="reports-header-bar">
        <div class="reports-header-title">
          <div class="reports-header-icon">
            <i class="ri-line-chart-line"></i>
          </div>
          <div class="reports-header-text">
            <h1>Reports & Analytics</h1>
            <p>Performance across leads, staff, partners, and inventory</p>
          </div>
        </div>
        <div style="display:flex; align-items:center; gap: 16px;">
          <div class="reports-date-pickers">
            <div class="reports-date-input">
              <input type="date" id="reports-date-from" class="reports-date-box" value="${i}" />
            </div>
            <div class="reports-date-input">
              <span style="font-size:0.85rem; color:var(--os-gray-500); margin-right:4px;">to</span>
              <input type="date" id="reports-date-to" class="reports-date-box" value="${a}" />
            </div>
          </div>
          <button class="os-btn-primary" id="btn-download-reports" style="background: var(--os-luxury-orange); border-color: var(--os-luxury-orange);">
            <i class="ri-download-2-line"></i> Download CSV
          </button>
        </div>
      </div>

      <!-- Main Chart Card -->
      <div class="report-card">
        <h2 class="report-card-title">Monthly leads (last 12 months)</h2>
        <div class="report-chart-area">
          <div class="report-chart-grid">
            <div class="report-chart-grid-line"></div>
            <div class="report-chart-grid-line"></div>
            <div class="report-chart-grid-line"></div>
            <div class="report-chart-grid-line"></div>
            <div class="report-chart-grid-line"></div>
          </div>
          ${y}
        </div>
        <div class="report-chart-footer">
          <div class="report-legend">
            <div class="legend-item"><div class="legend-dot total"></div> Total</div>
            <div class="legend-item"><div class="legend-dot converted"></div> Converted</div>
          </div>
          <div class="report-pipeline-value">
            Pipeline value (this period): <strong>${v}</strong>
          </div>
        </div>
      </div>

      <!-- 2-Column Leads Info -->
      <div class="report-grid-2">
        <!-- Leads by source -->
        <div class="report-card" style="margin-bottom:0;">
          <h2 class="report-card-title">Leads by source</h2>
          ${h}
        </div>

        <!-- Leads by status -->
        <div class="report-card" style="margin-bottom:0;">
          <h2 class="report-card-title">Leads by status</h2>
          ${g}
        </div>
      </div>

      <!-- Staff Performance -->
      <div class="report-card">
        <h2 class="report-card-title">Staff performance</h2>
        <div class="report-table-wrapper">
          <table class="report-table">
            <thead>
              <tr>
                <th>STAFF</th>
                <th class="right-align">LEADS</th>
                <th class="right-align">CONVERTED</th>
                <th class="right-align">CONV. RATE</th>
                <th class="right-align">WHATSAPP SENT</th>
                <th class="right-align">PARTNER SHARES</th>
                <th class="right-align">SITE VISITS DONE</th>
              </tr>
            </thead>
            <tbody>
              ${_}
            </tbody>
          </table>
        </div>
      </div>

      <!-- Partner Company Performance -->
      <div class="report-card">
        <h2 class="report-card-title">Partner company performance</h2>
        <div class="report-table-wrapper">
          <table class="report-table">
            <thead>
              <tr>
                <th>PARTNER</th>
                <th class="right-align">LEADS RECEIVED</th>
                <th class="right-align">CONVERTED</th>
                <th class="right-align">CONV. RATE</th>
                <th>STATUS BREAKDOWN</th>
              </tr>
            </thead>
            <tbody>
              ${b}
            </tbody>
          </table>
        </div>
      </div>

      <!-- Buyer Behavior -->
      <div class="report-card" style="background: transparent; border: none; box-shadow: none; padding: 0;">
        <h2 class="report-card-title" style="margin-bottom: 16px;">Buyer behavior</h2>
        ${w}
      </div>

      <!-- Property Engagement -->
      <div class="report-card">
        <h2 class="report-card-title">Property engagement</h2>
        <div class="report-table-wrapper">
          <table class="report-table">
            <thead>
              <tr>
                <th>PROPERTY</th>
                <th>LOCATION</th>
                <th>STATUS</th>
                <th class="right-align">VIEWS</th>
                <th class="right-align">SHORTLISTED</th>
              </tr>
            </thead>
            <tbody>
              ${T}
            </tbody>
          </table>
        </div>
      </div>

      <!-- Recently Lost Leads -->
      <div class="report-card" style="padding: 0; overflow: hidden;">
        <h2 class="report-card-title" style="padding: 20px 20px 16px 20px; border-bottom: 1px solid rgba(42, 24, 8, 0.05); margin: 0;">Recently lost leads</h2>
        ${E.length>0?E.map(e=>`
    <div style="padding: 12px 16px; border-bottom: 1px solid var(--os-border-light); font-size: 0.9rem;">
      <span style="font-weight: 500; color: var(--os-deep-brown);">${e.name}</span> — 
      <span style="color: var(--os-gray-500);">${e.type} · ${e.budgetMax||`Unknown Budget`}</span>
    </div>
  `).join(``):`<div style="padding: 16px 20px; color: var(--os-gray-400); font-size: 0.9rem;">No lost leads in this range.</div>`}
      </div>

    </div>
  `}function Lt(){let e=document.getElementById(`reports-date-from`),t=document.getElementById(`reports-date-to`),n=document.getElementById(`btn-download-reports`);function r(){let n=e.value,r=t.value,i=document.getElementById(`os-content`);i.innerHTML=It(n,r),Lt()}e&&e.addEventListener(`change`,r),t&&t.addEventListener(`change`,r),n&&n.addEventListener(`click`,()=>{let n=JSON.parse(localStorage.getItem(`thanjai_leads`))||[],r=new Date(e.value),i=new Date(t.value);i.setHours(23,59,59,999);let a=n.filter(e=>{let t=e.createdAt?new Date(e.createdAt):new Date(`2026-01-01T00:00:00`);return t>=r&&t<=i}),o=`data:text/csv;charset=utf-8,`;o+=`ID,Date,Name,Mobile,Type,Budget,Source,Status,Assigned To
`,a.forEach(e=>{let t=e.createdAt?new Date(e.createdAt).toLocaleDateString(`en-IN`):`01/01/2026`,n=`"${e.name||``}"`,r=`"${e.mobile||``}"`,i=`"${e.budgetMax||e.budgetMin||``}"`;o+=`${e.id},${t},${n},${r},${e.type||``},${i},${e.source||``},${e.status||``},${e.assignTo||``}\n`});let s=encodeURI(o),c=document.createElement(`a`);c.setAttribute(`href`,s),c.setAttribute(`download`,`Thanjai_CRM_Report_${e.value}_to_${t.value}.csv`),document.body.appendChild(c),c.click(),document.body.removeChild(c)})}function Rt(){let e=`https://statcounter.com/p12085651/summary/daily-pvn-last6months/?account_id=7287753&login_id=5&code=86100789cb77b82739c83e4722c821ac&guest_login=1`;return`
    <div class="view-enter statcounter-view">
      <!-- Header -->
      <div style="display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 16px; margin-bottom: 24px;">
        <div>
          <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px;">
            <span style="font-size: 0.75rem; font-weight: 700; color: var(--os-luxury-orange); letter-spacing: 1px; text-transform: uppercase;">
              <i class="ri-line-chart-line" style="margin-right: 4px;"></i> WEB TRAFFIC & VISITOR ANALYTICS
            </span>
          </div>
          <h1 class="view-title" style="margin: 4px 0;">StatCounter Real-Time Analytics</h1>
          <p class="view-subtitle" style="margin: 0;">Monitor live visitor counts, page views, referring websites, and 6-month historical traffic trends for Thanjai Property.</p>
        </div>

        <div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
          <a href="${e}" target="_blank" rel="noopener noreferrer" class="os-btn-primary" style="display: inline-flex; align-items: center; gap: 8px; text-decoration: none; padding: 10px 20px;">
            <i class="ri-external-link-line"></i> Launch StatCounter Portal
          </a>
        </div>
      </div>

      <!-- Quick Info Bar -->
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; margin-bottom: 24px;">
        <div style="background: #ffffff; border: 1px solid rgba(0,0,0,0.06); border-radius: 14px; padding: 18px; box-shadow: 0 2px 8px rgba(0,0,0,0.02);">
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 6px;">
            <i class="ri-dashboard-3-line" style="color: #eb5e28; font-size: 1.2rem;"></i>
            <span style="font-size: 0.78rem; text-transform: uppercase; color: #777; font-weight: 700;">Reporting Period</span>
          </div>
          <h3 style="font-size: 1.3rem; font-weight: 800; color: #1a1a1a; margin: 0;">Last 6 Months (Daily PVN)</h3>
        </div>

        <div style="background: #ffffff; border: 1px solid rgba(0,0,0,0.06); border-radius: 14px; padding: 18px; box-shadow: 0 2px 8px rgba(0,0,0,0.02);">
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 6px;">
            <i class="ri-shield-keyhole-line" style="color: #38a169; font-size: 1.2rem;"></i>
            <span style="font-size: 0.78rem; text-transform: uppercase; color: #777; font-weight: 700;">Authentication</span>
          </div>
          <h3 style="font-size: 1.3rem; font-weight: 800; color: #38a169; margin: 0;">Authorized Guest Session</h3>
        </div>

        <div style="background: #ffffff; border: 1px solid rgba(0,0,0,0.06); border-radius: 14px; padding: 18px; box-shadow: 0 2px 8px rgba(0,0,0,0.02);">
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 6px;">
            <i class="ri-global-line" style="color: #3182ce; font-size: 1.2rem;"></i>
            <span style="font-size: 0.78rem; text-transform: uppercase; color: #777; font-weight: 700;">Project ID</span>
          </div>
          <h3 style="font-size: 1.3rem; font-weight: 800; color: #1a1a1a; margin: 0;">p12085651 (Account 7287753)</h3>
        </div>
      </div>

      <!-- Embedded Iframe / Portal Container -->
      <div style="background: #ffffff; border: 1px solid rgba(0,0,0,0.08); border-radius: 16px; overflow: hidden; box-shadow: 0 4px 16px rgba(0,0,0,0.03);">
        <div style="padding: 14px 20px; background: #f8fafc; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px;">
          <div style="display: flex; align-items: center; gap: 10px;">
            <span style="display: inline-block; width: 10px; height: 10px; background: #38a169; border-radius: 50%; box-shadow: 0 0 0 3px rgba(56, 161, 105, 0.2);"></span>
            <strong style="font-size: 0.9rem; color: #2d3748;">Live StatCounter Web Stream</strong>
          </div>
          <a href="${e}" target="_blank" rel="noopener noreferrer" style="font-size: 0.85rem; font-weight: 700; color: #eb5e28; text-decoration: none; display: inline-flex; align-items: center; gap: 4px;">
            Open full window <i class="ri-arrow-right-up-line"></i>
          </a>
        </div>

        <div style="position: relative; width: 100%; height: calc(100vh - 280px); min-height: 650px; background: #ffffff;">
          <iframe 
            src="${e}" 
            title="StatCounter Analytics Dashboard"
            style="width: 100%; height: 100%; border: none;"
            loading="lazy"
            allowfullscreen
          ></iframe>
        </div>
      </div>
    </div>
  `}function zt(){let e=[{id:`initial_contact_intro`,name:`Initial contact intro (auto)`,tag:`initial_contact_intro`,category:`Stage: New Lead (Auto)`,params:[`{{1}} Client Name`,`{{2}} Property Type / Requirement`,`{{3}} Location`],content:`Hello {{1}},

Thank you for your interest in Thanjai Property!

We have received your requirement for {{2}} in {{3}}. Our property advisor will assist you with verified Patta documents, prime locations, and direct builder coordination.

Official Desk: +91 84899 96852
Website: thanjaiproperty.com

Warm regards,
Thanjai Property Desk`,isActive:!0},{id:`stage_requirement_analysis`,name:`Requirement analysis (auto)`,tag:`stage_requirement_analysis`,category:`Stage: Requirement Analysis (Auto)`,params:[`{{1}} Client Name`,`{{2}} Location`,`{{3}} Requirement / Type`,`{{4}} Budget Range`],content:`Hello {{1}},

We are currently analyzing your property requirement in {{2}} for {{3}} with a budget of {{4}}.

Our team is shortlisting legal-verified properties matching your exact criteria and will share tailored options shortly.

For immediate assistance, contact us at +91 84899 96852.

Best regards,
Thanjai Property`,isActive:!0},{id:`stage_lead_qualified`,name:`Lead qualified confirmation (auto)`,tag:`stage_lead_qualified`,category:`Stage: Qualified (Auto)`,params:[`{{1}} Client Name`,`{{2}} Requirement`,`{{3}} Location`,`{{4}} Budget Range`],content:`Hello {{1}},

Your profile and property requirement for {{2}} in {{3}} have been qualified by our senior property desk.

We have shortlisted exclusive options matching your budget range of {{4}} with 100% legal clearance.

Shall we schedule an advisory call or property presentation today?

Desk: +91 84899 96852
Thanjai Property`,isActive:!0},{id:`stage_site_visit_scheduled`,name:`Site visit scheduled (auto)`,tag:`stage_site_visit_scheduled`,category:`Stage: Site Visit (Auto)`,params:[`{{1}} Client Name`,`{{2}} Property Title`,`{{3}} Location`,`{{4}} Date`,`{{5}} Time`,`{{6}} Assigned Specialist`],content:`Hello {{1}},

Your site visit for {{2}} located at {{3}} has been scheduled on {{4}} at {{5}}.

Our property specialist {{6}} will meet you at the site to assist with plot boundaries, layout review, and Patta verification.

Location coordinator: +91 84899 96852.

Warm regards,
Thanjai Property`,isActive:!0},{id:`stage_negotiation_stage`,name:`Negotiation check-in (auto)`,tag:`stage_negotiation_stage`,category:`Stage: Negotiation (Auto)`,params:[`{{1}} Client Name`,`{{2}} Property Title`,`{{3}} Location / Terms`],content:`Hello {{1}},

We have initiated the price negotiation and legal terms discussion for {{2}} with the property owner.

Our team is working to secure the best finalized deal for you at {{3}}. We will update you with the approved terms shortly.

Advisory Desk: +91 84899 96852.

Best regards,
Thanjai Property`,isActive:!0},{id:`stage_booking_in_progress`,name:`Booking in progress (auto)`,tag:`stage_booking_in_progress`,category:`Stage: Booking In Progress (Auto)`,params:[`{{1}} Client Name`,`{{2}} Property Title`,`{{3}} Location`,`{{4}} Token Advance Amount`],content:`Hello {{1}},

Great news! The booking process for {{2}} in {{3}} is now in progress.

Token Advance / Booking Amount: {{4}}
Our legal team is preparing the draft sale agreement and verifying the parent deed documents.

For paperwork support: +91 84899 96852.

Warm regards,
Thanjai Property`,isActive:!0},{id:`bank_loan_assist`,name:`Bank loan assistance (auto)`,tag:`bank_loan_assist`,category:`Stage: Loan / Financing (Auto)`,params:[`{{1}} Client Name`,`{{2}} Property / Location`],content:`Hello {{1}},

We are assisting you with your bank loan / home loan process for {{2}}.

Our banking partners (SBI, HDFC, ICICI, Indian Bank) provide competitive interest rates and fast approvals for registered plots and villas.

Please keep your KYC and income documents ready. Loan desk: +91 84899 96852.

Best regards,
Thanjai Property Finance Desk`,isActive:!0},{id:`stage_deal_won_registration`,name:`Registration testimonial & deal won (auto)`,tag:`stage_deal_won_registration`,category:`Stage: Deal Won & Registration (Auto)`,params:[`{{1}} Client Name`,`{{2}} Property Title`,`{{3}} Location / Registry Office`],content:`Congratulations {{1}}! 🎉

Your property registration for {{2}} at {{3}} has been successfully completed!

Thank you for choosing Thanjai Property. We are proud to have assisted you in securing your valuable real estate asset.

Official Desk: +91 84899 96852
Thanjai Property`,isActive:!0},{id:`follow_up_nurture`,name:`Follow-up nurture message`,tag:`follow_up_nurture`,category:`General Follow-up / Nurturing`,params:[`{{1}} Client Name`,`{{2}} Location`],content:`Hello {{1}},

Following up on your property requirement in {{2}}. We have new DTCP/RERA-approved projects and independent plots available this week.

Would you like us to share updated layout options and pricing?

Direct WhatsApp: +91 84899 96852.

Warm regards,
Thanjai Property`,isActive:!0},{id:`partner_transfer_notification`,name:`Partner transfer notification (client)`,tag:`partner_transfer_notification`,category:`Lead Transfer (Client Message)`,params:[`{{1}} Client Name`,`{{2}} Preferred Location`,`{{3}} Partner Specialist Name`,`{{4}} Official Desk Number`],content:`Hello {{1}},

Your property requirement in {{2}} has been assigned to our senior partner specialist {{3}}.

Our team and specialist will assist you with exclusive listings, verified Patta documents, and on-site visits.

For any direct assistance, contact our official desk at {{4}}.

Best regards,
Thanjai Property`,isActive:!0},{id:`partner_lead_assignment`,name:`Partner lead assignment (network)`,tag:`partner_lead_assignment`,category:`Partner Network (Partner Message)`,params:[`{{1}} Partner Name`,`{{2}} Client Name`,`{{3}} Location`,`{{4}} Requirement`,`{{5}} Budget`,`{{6}} Notes`],content:`Hello {{1}},

A new qualified buyer requirement has been assigned to you from Thanjai Property:

👤 Client Name: {{2}}
📍 Preferred Location: {{3}}
🏡 Requirement: {{4}}
💰 Budget Range: {{5}}

📝 Notes: {{6}}

For client coordination, please connect through our official desk: +91 84899 96852.

Warm regards,
Thanjai Property Partner Network`,isActive:!0},{id:`stage_closed_lost_archive`,name:`Requirement closed / archive message`,tag:`stage_closed_lost_archive`,category:`Stage: Closed Lost (Auto)`,params:[`{{1}} Client Name`,`{{2}} Location / Requirement`],content:`Hello {{1}},

We have updated your property enquiry status for {{2}}. Whenever you are ready to resume your property search or explore new investments in Tamil Nadu, our desk is always here to assist you.

Feel free to reach out anytime at +91 84899 96852.

Best regards,
Thanjai Property`,isActive:!0}];window.__thanjaiSettingsTemplates=e;let t=e.map(e=>`
    <div class="template-card" style="padding: 18px 0; border-bottom: 1px solid var(--os-gray-100);">
      <div class="template-info">
        <div class="template-header" style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-bottom: 8px;">
          <span class="template-name" style="font-weight: 700; font-size: 0.95rem; color: #0f172a;">${e.name}</span>
          <span class="template-tag-key" style="background: #f1f5f9; padding: 2px 8px; border-radius: 6px; font-family: monospace; font-size: 0.75rem; color: #475569; font-weight: 600;">${e.tag}</span>
          <span style="background: #eff6ff; color: #2563eb; font-size: 0.72rem; font-weight: 600; padding: 2px 8px; border-radius: 12px; border: 1px solid #bfdbfe;">${e.category}</span>
          ${e.isActive?`<span class="template-tag-active" style="background: #dcfce7; color: #166534; font-size: 0.72rem; font-weight: 700; padding: 2px 8px; border-radius: 12px; border: 1px solid #bbf7d0;">ACTIVE</span>`:``}
        </div>
        <p class="template-preview" style="font-size: 0.85rem; color: #64748b; line-height: 1.5; margin: 0; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
          ${e.content.replace(/\n/g,` `)}
        </p>
      </div>
      <div class="template-action" style="margin-left: 16px;">
        <button class="settings-btn-view btn-view-full-template" data-id="${e.id}" style="display: inline-flex; align-items: center; gap: 6px; padding: 7px 14px; border: 1px solid #cbd5e1; background: #ffffff; color: #0f172a; border-radius: 8px; font-size: 0.82rem; font-weight: 600; cursor: pointer; transition: all 0.2s ease;">
          <i class="ri-eye-line" style="color: var(--os-luxury-orange, #eb5e28);"></i> View Full Template
        </button>
      </div>
    </div>
  `).join(``);return`
    <div class="settings-container view-enter">
      
      <!-- Header Section -->
      <div class="settings-header-title">
        <div class="settings-header-icon">
          <i class="ri-settings-3-line"></i>
        </div>
        <div class="settings-header-text">
          <h1>Settings</h1>
          <p>WhatsApp templates, automations, and workspace preferences</p>
        </div>
      </div>

      <!-- Tabs -->
      <div class="settings-tabs">
        <div class="settings-tab active" data-tab="templates">Templates & Currencies</div>
        <div class="settings-tab" data-tab="branding">Branding</div>
        <div class="settings-tab" data-tab="integrations">Integrations</div>
      </div>

      <!-- Tab Content: Templates & Currencies -->
      <div id="tab-templates" class="tab-content active">
        <!-- Content Area -->
        <div class="settings-content-card">
        
        <div class="settings-section-header">
          <div>
            <h2 class="settings-section-title">Official WhatsApp Templates</h2>
            <p class="settings-section-desc">
              All official WhatsApp campaign templates approved on SmartPing (+91 84899 96852). Click <strong>View Full Template</strong> to inspect parameter structures, dynamic values, and live preview layout.
            </p>
          </div>
        </div>

        <div class="template-group-title" style="font-size: 0.8rem; font-weight: 700; letter-spacing: 0.5px; color: #64748b; margin-top: 16px;">
          APPROVED SMARTPING CAMPAIGN TEMPLATES (${e.length})
        </div>
        
        <div class="template-list">
          ${t}
        </div>

      </div>

      <!-- Currencies Section -->
      <div class="settings-content-card">
        <h2 class="settings-section-title">Currencies</h2>
        <div class="currency-section">
          <input type="text" class="currency-input" value="INR, USD, AED, EUR" />
          <button class="settings-btn-primary" style="padding: 10px 24px;">Save</button>
        </div>
      </div>
      </div> <!-- End Templates Tab -->

      <!-- Full Template View Modal (Fixed Centered Modal) -->
      <div id="view-template-modal" class="os-modal-overlay" style="position: fixed !important; inset: 0 !important; top: 0 !important; left: 0 !important; width: 100vw !important; height: 100vh !important; background: rgba(15, 23, 42, 0.65) !important; backdrop-filter: blur(5px) !important; z-index: 999999 !important; display: none; align-items: center; justify-content: center; padding: 20px; box-sizing: border-box;">
        <div class="os-modal-card" style="max-width: 600px; width: 100%; max-height: 88vh; background: #ffffff; border-radius: 16px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.35); overflow: hidden; display: flex; flex-direction: column; margin: auto; border: 1px solid #e2e8f0;">
          
          <div style="display: flex; align-items: center; justify-content: space-between; padding: 18px 24px; border-bottom: 1px solid #e2e8f0; background: #f8fafc;">
            <div>
              <h3 id="modal-tpl-title" style="margin: 0; font-size: 1.1rem; font-weight: 700; color: #0f172a;">Template Details</h3>
              <div style="display: flex; align-items: center; gap: 8px; margin-top: 4px;">
                <span id="modal-tpl-tag" style="background: #e2e8f0; font-family: monospace; font-size: 0.75rem; font-weight: 600; padding: 2px 8px; border-radius: 6px; color: #334155;">tag</span>
                <span id="modal-tpl-category" style="background: #eff6ff; color: #2563eb; font-size: 0.72rem; font-weight: 600; padding: 2px 8px; border-radius: 12px; border: 1px solid #bfdbfe;">Category</span>
              </div>
            </div>
            <button id="close-template-modal-btn" style="background: none; border: none; font-size: 1.4rem; color: #64748b; cursor: pointer; padding: 4px; border-radius: 6px; display: flex; align-items: center; justify-content: center;">
              <i class="ri-close-line"></i>
            </button>
          </div>

          <div style="padding: 22px 24px; overflow-y: auto; max-height: calc(88vh - 140px);">
            
            <div style="margin-bottom: 16px;">
              <label style="font-size: 0.75rem; font-weight: 700; color: #475569; text-transform: uppercase; letter-spacing: 0.5px; display: block; margin-bottom: 8px;">
                Dynamic Parameter Structure
              </label>
              <div id="modal-tpl-params" style="display: flex; flex-wrap: wrap; gap: 6px;">
                <!-- Parameter badges injected here -->
              </div>
            </div>

            <div>
              <label style="font-size: 0.75rem; font-weight: 700; color: #475569; text-transform: uppercase; letter-spacing: 0.5px; display: block; margin-bottom: 8px;">
                Full Message Content (SmartPing Format)
              </label>
              <div style="background: #eef8f2; border: 1px solid #c7eed8; border-radius: 12px; padding: 18px; position: relative;">
                <div style="font-size: 0.75rem; font-weight: 700; color: #059669; margin-bottom: 10px; display: flex; align-items: center; gap: 6px;">
                  <i class="ri-whatsapp-fill" style="font-size: 1rem;"></i> OFFICIAL WHATSAPP PREVIEW (+91 84899 96852)
                </div>
                <div id="modal-tpl-content" style="white-space: pre-wrap; font-size: 0.9rem; line-height: 1.6; color: #1e293b; font-family: inherit;">
                  <!-- Template body injected here -->
                </div>
              </div>
            </div>

          </div>

          <div style="display: flex; align-items: center; justify-content: space-between; padding: 16px 24px; border-top: 1px solid #e2e8f0; background: #f8fafc;">
            <button id="copy-tpl-content-btn" class="settings-btn-outline" style="display: inline-flex; align-items: center; gap: 6px; padding: 8px 16px; font-size: 0.85rem;">
              <i class="ri-file-copy-line"></i> Copy Template Text
            </button>
            <button id="close-template-modal-footer-btn" class="settings-btn-primary" style="padding: 8px 20px; font-size: 0.85rem;">
              Close
            </button>
          </div>

        </div>
      </div>

      <!-- Tab Content: Branding -->
      <div id="tab-branding" class="tab-content">
        <div class="settings-content-card">
          <div class="settings-section-header">
            <div>
              <h2 class="settings-section-title">App branding</h2>
              <p class="settings-section-desc">Shown in the sidebar and browser tab for every user.</p>
            </div>
          </div>

          <div class="settings-form-group">
            <label class="settings-label">Application name</label>
            <input type="text" class="settings-input" value="ThanjaiProperty" />
          </div>

          <div class="settings-form-group">
            <label class="settings-label">Tagline</label>
            <input type="text" class="settings-input" value="RealEstate" />
          </div>

          <div class="settings-form-group">
            <label class="settings-label">Logo</label>
            <div class="logo-upload-area">
              <div class="logo-preview-box">
                <img id="settings-logo-preview" src="${a(`brand_logo`)||`/thanjai-official-new.png`}" alt="Logo preview" onerror="this.src='/thanjai-official-new.png'" style="max-width: 100%; max-height: 100%; object-fit: contain;" />
              </div>
              <div class="upload-btn-group">
                <button id="settings-logo-upload-btn" class="settings-btn-outline"><i class="ri-upload-cloud-2-line"></i> Upload logo</button>
                <button id="settings-logo-remove-btn" class="btn-remove-link">Remove</button>
                <input type="file" id="settings-logo-file-input" accept="image/*" style="display: none;" />
              </div>
            </div>
          </div>

          <div class="settings-form-group">
            <label class="settings-label">Primary color</label>
            <div class="color-picker-area">
              <input type="color" id="settings-primary-color" class="color-swatch-box" value="#eb5e28" style="padding: 0; border: none; cursor: pointer; outline: none; -webkit-appearance: none;" />
              <input type="text" id="settings-primary-color-text" class="settings-input" value="#eb5e28" style="color: var(--os-gray-500);" />
            </div>
          </div>

          <button class="settings-btn-primary" style="margin-top: 16px;">Save branding</button>
        </div>
      </div> <!-- End Branding Tab -->

      <!-- Tab Content: Integrations -->
      <div id="tab-integrations" class="tab-content">
        
        <!-- 1. WhatsApp provider -->
        <div class="settings-content-card">
          <div class="settings-section-header">
            <div>
              <h2 class="settings-section-title">WhatsApp Provider & Live Webhook</h2>
              <p class="settings-section-desc">Manage your outbound WhatsApp API provider (SmartPing / AiSensy) and live 2-way inbound message webhook.</p>
            </div>
          </div>
          
          <div class="settings-grid-2">
            <div class="settings-form-group">
              <label class="settings-label">Active Provider</label>
              <select class="settings-input" id="settings-wa-provider">
                <option value="smartping">SmartPing (Recommended)</option>
                <option value="aisensy">AiSensy</option>
              </select>
            </div>
            <div class="settings-form-group">
              <label class="settings-label">Registered WhatsApp Business Number</label>
              <input type="text" class="settings-input" value="+91 84899 96852" readonly style="background: #f8fafc; font-weight: 600; color: #1e293b;" />
            </div>
          </div>

          <div class="settings-grid-2">
            <div class="settings-form-group">
              <label class="settings-label">API Key / Token</label>
              <div style="position: relative;">
                <input type="password" id="settings-wa-api-key" class="settings-input" placeholder="Paste SmartPing / AiSensy API Key here" style="padding-right: 42px;" />
                <button type="button" id="toggle-settings-wa-api-key" title="Toggle visibility" style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); background: none; border: none; cursor: pointer; color: #64748b; font-size: 1.15rem; display: flex; align-items: center; justify-content: center; width: 28px; height: 28px;">
                  <i class="ri-eye-line"></i>
                </button>
              </div>
            </div>
            <div class="settings-form-group">
              <label class="settings-label">Campaign Name (Live)</label>
              <input type="text" id="settings-wa-campaign" class="settings-input" value="realrest_notification_new_final" />
            </div>
          </div>

          <!-- Webhook Configuration Card -->
          <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 12px; padding: 18px; margin: 18px 0;">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px;">
              <span style="font-weight: 700; color: #166534; font-size: 0.95rem; display: flex; align-items: center; gap: 8px;">
                <i class="ri-checkbox-circle-fill" style="color: #22c55e;"></i> Live Inbound Webhook Configuration
              </span>
              <span style="background: #dcfce7; color: #15803d; font-size: 0.75rem; font-weight: 700; padding: 3px 8px; border-radius: 12px;">ENABLED</span>
            </div>
            <p style="font-size: 0.85rem; color: #374151; margin-bottom: 12px; line-height: 1.5;">
              Use these exact details in your <strong>SmartPing</strong> or <strong>WhatsApp Business Manager</strong> webhook settings so customer replies appear instantly in your <strong>WhatsApp Log</strong>:
            </p>
            
            <div style="display: flex; flex-direction: column; gap: 8px;">
              <div style="display: flex; align-items: center; justify-content: space-between; background: #ffffff; padding: 10px 14px; border-radius: 8px; border: 1px solid #e2e8f0;">
                <div>
                  <div style="font-size: 0.72rem; color: #64748b; font-weight: 600;">INBOUND WEBHOOK CALLBACK URL</div>
                  <div style="font-family: monospace; font-size: 0.88rem; color: #0f172a; font-weight: 600;">https://thanjaiproperty.com/api.php/webhook</div>
                </div>
                <button type="button" class="settings-btn-outline" style="padding: 6px 12px; font-size: 0.8rem;" onclick="navigator.clipboard.writeText('https://thanjaiproperty.com/api.php/webhook'); window.showToast('Webhook URL copied to clipboard!', 'ri-file-copy-line');">
                  <i class="ri-file-copy-line"></i> Copy URL
                </button>
              </div>

              <div style="display: flex; align-items: center; justify-content: space-between; background: #ffffff; padding: 10px 14px; border-radius: 8px; border: 1px solid #e2e8f0;">
                <div>
                  <div style="font-size: 0.72rem; color: #64748b; font-weight: 600;">WEBHOOK VERIFY TOKEN</div>
                  <div style="font-family: monospace; font-size: 0.88rem; color: #0f172a; font-weight: 600;">thanjai_webhook_2026</div>
                </div>
                <button type="button" class="settings-btn-outline" style="padding: 6px 12px; font-size: 0.8rem;" onclick="navigator.clipboard.writeText('thanjai_webhook_2026'); window.showToast('Verify Token copied!', 'ri-file-copy-line');">
                  <i class="ri-file-copy-line"></i> Copy Token
                </button>
              </div>
            </div>
          </div>

          <button id="settings-wa-save-btn" class="settings-btn-primary" style="padding: 11px 24px;">Save WhatsApp Settings</button>
        </div>

        <!-- 2. AI Operating Agent -->
        <div class="settings-content-card">
          <div class="settings-section-header">
            <div>
              <h2 class="settings-section-title">AI Operating Agent</h2>
              <p class="settings-section-desc">Powers sales pitches, proposals, price predictions, and agreement drafts. Pricing fields are only used to estimate cost on the Usage & Cost tab.</p>
            </div>
          </div>

          <div class="settings-form-group" style="max-width: 400px;">
            <label class="settings-label">Provider</label>
            <select class="settings-input">
              <option value="gemini">Google Gemini</option>
              <option value="openai">OpenAI</option>
            </select>
          </div>

          <div class="settings-grid-2">
            <div class="settings-form-group">
              <label class="settings-label">API Key</label>
              <input type="password" class="settings-input" value="••••••••••••" />
            </div>
            <div class="settings-form-group">
              <label class="settings-label">Model</label>
              <input type="text" class="settings-input" value="gemini-3.5-flash" />
            </div>
          </div>

          <div class="settings-grid-2" style="grid-template-columns: 2fr 1fr 1fr;">
            <div class="settings-form-group">
              <label class="settings-label">API URL</label>
              <input type="text" class="settings-input" value="https://generativelanguage.googleapis.com/v1beta/models" />
            </div>
            <div class="settings-form-group">
              <label class="settings-label">Input $ / 1M tokens</label>
              <input type="text" class="settings-input" value="0.075" />
            </div>
            <div class="settings-form-group">
              <label class="settings-label">Output $ / 1M tokens</label>
              <input type="text" class="settings-input" value="0.3" />
            </div>
          </div>

          <button class="settings-btn-save-small" style="margin-top: 16px;">Save</button>
        </div>

        <!-- 3. Meta Lead Ads webhook -->
        <div class="settings-content-card">
          <div class="settings-section-header">
            <div>
              <h2 class="settings-section-title">Meta Lead Ads webhook</h2>
              <p class="settings-section-desc">Auto-creates a lead whenever someone submits a Facebook/Instagram Lead Ads form. Webhook URL: <span class="settings-code-key">/api/leads/webhook/meta</span></p>
            </div>
          </div>

          <div class="settings-grid-2">
            <div class="settings-form-group">
              <label class="settings-label">Verify Token</label>
              <input type="text" class="settings-input" />
            </div>
            <div class="settings-form-group">
              <label class="settings-label">App Secret</label>
              <input type="password" class="settings-input" />
            </div>
          </div>

          <div class="settings-grid-2">
            <div class="settings-form-group">
              <label class="settings-label">Page Access Token</label>
              <input type="password" class="settings-input" />
            </div>
            <div class="settings-form-group">
              <label class="settings-label">Graph API URL</label>
              <input type="text" class="settings-input" value="https://graph.facebook.com/v19.0" />
            </div>
          </div>

          <button class="settings-btn-save-small" style="margin-top: 16px;">Save</button>
        </div>

        <!-- 4. Public website property sync -->
        <div class="settings-content-card">
          <div class="settings-section-header">
            <div>
              <h2 class="settings-section-title">Public website property sync</h2>
              <p class="settings-section-desc">Pushes property changes to your website's API, and lets your website push properties back in via <span class="settings-code-key">/api/integrations/website/properties</span>.</p>
            </div>
          </div>

          <div class="settings-grid-2">
            <div class="settings-form-group">
              <label class="settings-label">Website API URL</label>
              <input type="text" class="settings-input" value="https://yoursite.com/api" />
            </div>
            <div class="settings-form-group">
              <label class="settings-label">Website API Key</label>
              <input type="password" class="settings-input" />
            </div>
          </div>

          <div class="settings-form-group" style="max-width: 400px; margin-bottom: 16px;">
            <label class="settings-label">Inbound Webhook Secret</label>
            <input type="password" class="settings-input" />
          </div>

          <button class="settings-btn-save-small">Save</button>
        </div>

        <!-- 5. Lead capture webhooks -->
        <div class="settings-content-card">
          <div class="settings-section-header">
            <div>
              <h2 class="settings-section-title">Lead capture webhooks</h2>
              <p class="settings-section-desc">Shared secret for the generic website-form and WhatsApp click-to-chat lead webhooks: <span class="settings-code-key">/api/leads/webhook/website</span> and <span class="settings-code-key">/api/leads/webhook/whatsapp-click</span></p>
            </div>
          </div>

          <div class="settings-form-group" style="max-width: 400px; margin-bottom: 16px;">
            <label class="settings-label">Webhook Secret</label>
            <input type="password" class="settings-input" />
          </div>

          <button class="settings-btn-save-small">Save</button>
        </div>

      </div>

    </div>
  `}function Bt(){let e=document.querySelectorAll(`.settings-tab`),t=document.querySelectorAll(`.tab-content`);e.forEach(n=>{n.addEventListener(`click`,()=>{e.forEach(e=>e.classList.remove(`active`)),t.forEach(e=>e.classList.remove(`active`)),n.classList.add(`active`);let r=`tab-${n.dataset.tab}`,i=document.getElementById(r);i&&i.classList.add(`active`)})});let n=document.getElementById(`settings-logo-upload-btn`),r=document.getElementById(`settings-logo-file-input`),s=document.getElementById(`settings-logo-remove-btn`),c=document.getElementById(`settings-logo-preview`);n?.addEventListener(`click`,()=>{r?.click()}),r?.addEventListener(`change`,e=>{let t=e.target.files[0];if(t){let e=new FileReader;e.onload=function(e){let t=e.target.result;c&&(c.src=t),i(`brand_logo`,t),f(`Logo updated successfully!`,`success`)},e.readAsDataURL(t)}}),s?.addEventListener(`click`,()=>{p(`brand_logo`);let e=a(`brand_logo`)||`/thanjai-official-new.png`;c&&(c.src=e),f(`Logo removed and reset to default.`,`info`)});let l=document.getElementById(`settings-primary-color`),u=document.getElementById(`settings-primary-color-text`),d=localStorage.getItem(`thanjai_custom_color`)||`#eb5e28`;l&&(l.value=d),u&&(u.value=d);function m(e){document.documentElement.style.setProperty(`--os-luxury-orange`,e),document.documentElement.style.setProperty(`--color-orange`,e),document.documentElement.style.setProperty(`--text-orange`,e),localStorage.setItem(`thanjai_custom_color`,e)}l?.addEventListener(`input`,e=>{let t=e.target.value;u&&(u.value=t),m(t)}),u?.addEventListener(`input`,e=>{let t=e.target.value;t.length===7&&t.startsWith(`#`)&&(l&&(l.value=t),m(t))});let h=document.getElementById(`settings-wa-api-key`),g=document.getElementById(`toggle-settings-wa-api-key`),_=document.getElementById(`settings-wa-campaign`),v=document.getElementById(`settings-wa-save-btn`),y=document.getElementById(`settings-wa-provider`);g&&h&&g.addEventListener(`click`,()=>{let e=h.type===`password`;h.type=e?`text`:`password`,g.innerHTML=e?`<i class="ri-eye-off-line"></i>`:`<i class="ri-eye-line"></i>`});let b=localStorage.getItem(`thanjai_whatsapp_api_key`)||`eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY5NjYxNjVmODFhMDg2MTIzZWY5MWQ5MCIsIm5hbWUiOiJUaGFuamFpIFByb3BlcnR5IiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY5NjYxNjVmODFhMDg2MTIzZWY5MWQ4OSIsImFjdGl2ZVBsYW4iOiJQUk9fTU9OVEhMWSIsImlhdCI6MTc4NzcyNDczOX0.8SQSQDJdxrAivj8FAkWvjSk_qx4yE0dENDh70US75G0`;h&&(h.value=b),_&&(_.value=localStorage.getItem(`thanjai_wa_campaign`)||`initial_contact_intro`),y&&(y.value=localStorage.getItem(`thanjai_wa_provider`)||`smartping`),o(`/settings`).then(e=>{if(e&&e.whatsapp_integration)try{let t=typeof e.whatsapp_integration==`string`?JSON.parse(e.whatsapp_integration):e.whatsapp_integration;t.apiKey&&t.apiKey.trim().length>10&&(h&&(h.value=t.apiKey.trim()),localStorage.setItem(`thanjai_whatsapp_api_key`,t.apiKey.trim())),t.provider&&y&&(y.value=t.provider,localStorage.setItem(`thanjai_wa_provider`,t.provider)),t.campaign&&_&&(_.value=t.campaign,localStorage.setItem(`thanjai_wa_campaign`,t.campaign))}catch{}}).catch(()=>{}),v&&v.addEventListener(`click`,async()=>{let e=h?h.value.trim():``;(!e||e.length<10)&&(e=se,h&&(h.value=e));let t=_?_.value.trim():`initial_contact_intro`,n=y?y.value:`smartping`;localStorage.setItem(`thanjai_whatsapp_api_key`,e),localStorage.setItem(`thanjai_wa_campaign`,t),localStorage.setItem(`thanjai_wa_provider`,n);try{await o(`/settings`,{method:`POST`,body:JSON.stringify({key:`whatsapp_integration`,value:JSON.stringify({provider:n,apiKey:e,campaign:t})})})}catch(e){console.error(`Settings save error:`,e)}f(`SmartPing & WhatsApp API settings saved permanently!`,`success`)});let x=document.getElementById(`view-template-modal`);x&&(document.querySelectorAll(`body > #view-template-modal`).forEach(e=>{e!==x&&e.remove()}),x.parentNode!==document.body&&document.body.appendChild(x));let S=document.getElementById(`close-template-modal-btn`),C=document.getElementById(`close-template-modal-footer-btn`),w=document.getElementById(`copy-tpl-content-btn`),T=``;document.querySelectorAll(`.btn-view-full-template`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.id,n=(window.__thanjaiSettingsTemplates||[]).find(e=>e.id===t);if(!n||!x)return;T=n.content;let r=document.getElementById(`modal-tpl-title`),i=document.getElementById(`modal-tpl-tag`),a=document.getElementById(`modal-tpl-category`);r&&(r.textContent=n.name),i&&(i.textContent=n.tag),a&&(a.textContent=n.category);let o=document.getElementById(`modal-tpl-params`);o&&(o.innerHTML=(n.params||[]).map(e=>`
          <span style="background: #e0f2fe; color: #0369a1; font-size: 0.76rem; font-weight: 600; padding: 4px 10px; border-radius: 8px; border: 1px solid #bae6fd; font-family: monospace;">
            ${e}
          </span>
        `).join(``));let s=document.getElementById(`modal-tpl-content`);s&&(s.innerHTML=n.content.replace(/(\{\{\d+\}\})/g,`<strong style="color: var(--os-luxury-orange, #eb5e28); background: #fed7aa; padding: 1px 6px; border-radius: 4px;">$1</strong>`)),x.style.display=`flex`,x.classList.add(`show`)})});let E=()=>{x&&(x.style.display=`none`,x.classList.remove(`show`))};S?.addEventListener(`click`,E),C?.addEventListener(`click`,E),x?.addEventListener(`click`,e=>{e.target===x&&E()}),w?.addEventListener(`click`,()=>{T&&navigator.clipboard.writeText(T).then(()=>{f(`Template text copied to clipboard!`,`ri-file-copy-line`)}).catch(()=>{f(`Template text copied!`,`ri-checkbox-circle-fill`)})})}var Vt=``,Ht=`all`,Ut=`all`;function Wt(){let e=u(),t=e.filter(e=>{let t=!Vt||e.fullName.toLowerCase().includes(Vt.toLowerCase())||e.email.toLowerCase().includes(Vt.toLowerCase())||e.phone.includes(Vt)||e.id.toLowerCase().includes(Vt.toLowerCase()),n=Ht===`all`||e.role===Ht,r=Ut===`all`||e.status===Ut;return t&&n&&r}),n=e.filter(e=>e.role===`Super Admin`).length,r=e.filter(e=>e.role===`Sales Manager`).length,i=e.filter(e=>e.role===`Sales Executive`||e.role===`Property Staff`).length;return`
    <div class="view-enter admin-users-view">
      
      <!-- HEADER TITLE BAR -->
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px;">
        <div>
          <span style="font-size: 0.78rem; font-weight: 800; color: var(--os-luxury-orange); letter-spacing: 0.12em; text-transform: uppercase;">
            SYSTEM SECURITY & PERMISSIONS
          </span>
          <h1 style="font-family: var(--font-sans); font-size: 1.8rem; font-weight: 800; color: var(--os-charcoal); margin-top: 4px;">
            Admin Staff & System Access
          </h1>
          <p style="font-size: 0.88rem; color: var(--os-gray-400);">
            Manage administrative staff credentials, system roles, CRM permissions, and OS access controls.
          </p>
        </div>

        <div style="display: flex; gap: 12px; flex-wrap: wrap;">
          <button id="add-admin-staff-btn" style="display: flex; align-items: center; gap: 8px; padding: 10px 18px; border-radius: 8px; background: linear-gradient(135deg, #eb5e28 0%, #d94e18 100%); color: #ffffff; font-weight: 800; font-size: 0.88rem; border: none; cursor: pointer; box-shadow: 0 4px 14px rgba(235,94,40,0.35); transition: transform 0.2s;">
            <i class="ri-user-add-line"></i> + Add New Admin Staff
          </button>
          
          <a href="/admin-login.html" target="_blank" style="display: flex; align-items: center; gap: 8px; padding: 10px 18px; border-radius: 8px; background: linear-gradient(135deg, #1e1b4b 0%, #0f172a 100%); color: #ffffff; font-weight: 700; font-size: 0.88rem; cursor: pointer; text-decoration: none; box-shadow: 0 4px 12px rgba(15,23,42,0.25);">
            <i class="ri-shield-keyhole-line" style="color: #eb5e28;"></i> Open Admin Login Portal
          </a>
        </div>
      </div>

      <!-- KPI SUMMARY CARDS -->
      <div class="kpi-grid" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); margin-bottom: 28px;">
        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-title">TOTAL ADMIN STAFF</span>
            <div class="kpi-icon" style="background: #faf5ff; color: #805ad5;"><i class="ri-shield-user-line"></i></div>
          </div>
          <div class="kpi-value">${e.length}</div>
          <div class="kpi-trend up"><i class="ri-check-double-line"></i> Full OS Access</div>
        </div>

        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-title">SUPER ADMINS</span>
            <div class="kpi-icon" style="background: #feebc8; color: #dd6b20;"><i class="ri-star-line"></i></div>
          </div>
          <div class="kpi-value">${n}</div>
          <div class="kpi-trend neutral"><i class="ri-user-star-line"></i> System Leaders</div>
        </div>

        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-title">SALES MANAGERS</span>
            <div class="kpi-icon" style="background: #e6fffa; color: #319795;"><i class="ri-briefcase-line"></i></div>
          </div>
          <div class="kpi-value">${r}</div>
          <div class="kpi-trend neutral"><i class="ri-team-line"></i> Pipeline Desks</div>
        </div>

        <div class="kpi-card">
          <div class="kpi-header">
            <span class="kpi-title">EXECUTIVES & STAFF</span>
            <div class="kpi-icon" style="background: #ebf8ff; color: #3182ce;"><i class="ri-user-voice-line"></i></div>
          </div>
          <div class="kpi-value">${i}</div>
          <div class="kpi-trend neutral"><i class="ri-phone-line"></i> Operations Team</div>
        </div>
      </div>

      <!-- MAIN ADMIN STAFF DIRECTORY TABLE -->
      <div class="os-chart-card">
        <div class="os-chart-header" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
          <div style="display: flex; align-items: center; gap: 16px;">
            <span><i class="ri-shield-user-line"></i> Administrative Staff Roster & System Accounts</span>
          </div>
          
          <div style="display: flex; gap: 14px; align-items: center; flex-wrap: wrap;">
            <!-- SEARCH INPUT -->
            <div style="position: relative;">
              <i class="ri-search-line" style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--os-gray-400);"></i>
              <input type="text" id="admin-staff-search" value="${Vt}" placeholder="Search staff name, email, phone..." style="padding: 8px 14px 8px 36px; border-radius: 8px; border: 1px solid var(--os-border); font-size: 0.85rem; outline: none; width: 240px; background: #fff;" />
            </div>

            <!-- ROLE FILTER -->
            <select id="admin-role-filter" style="padding: 8px 12px; border-radius: 8px; border: 1px solid var(--os-border); background: #fff; font-size: 0.85rem; font-weight: 600; color: var(--os-charcoal); outline: none; cursor: pointer;">
              <option value="all" ${Ht===`all`?`selected`:``}>All Admin Roles</option>
              <option value="Super Admin" ${Ht===`Super Admin`?`selected`:``}>Super Admin</option>
              <option value="Sales Manager" ${Ht===`Sales Manager`?`selected`:``}>Sales Manager</option>
              <option value="Sales Executive" ${Ht===`Sales Executive`?`selected`:``}>Sales Executive</option>
              <option value="Property Staff" ${Ht===`Property Staff`?`selected`:``}>Property Staff</option>
            </select>

            <!-- STATUS FILTER -->
            <select id="admin-status-filter" style="padding: 8px 12px; border-radius: 8px; border: 1px solid var(--os-border); background: #fff; font-size: 0.85rem; font-weight: 600; color: var(--os-charcoal); outline: none; cursor: pointer;">
              <option value="all" ${Ut===`all`?`selected`:``}>All Status</option>
              <option value="Active" ${Ut===`Active`?`selected`:``}>Active</option>
              <option value="Inactive" ${Ut===`Inactive`?`selected`:``}>Inactive</option>
            </select>
          </div>
        </div>

        <div class="table-responsive" style="margin-top: 16px;">
          <table style="width: 100%; border-collapse: collapse; text-align: left; font-size: 0.88rem;">
            <thead>
              <tr style="border-bottom: 1px solid rgba(0,0,0,0.08); text-transform: uppercase; font-size: 0.75rem; color: var(--os-gray-400);">
                <th style="padding: 14px 16px;">Staff ID</th>
                <th style="padding: 14px 16px;">Full Name</th>
                <th style="padding: 14px 16px;">Email Address</th>
                <th style="padding: 14px 16px;">Phone</th>
                <th style="padding: 14px 16px;">Admin Role</th>
                <th style="padding: 14px 16px;">Last Active</th>
                <th style="padding: 14px 16px;">Status</th>
                <th style="padding: 14px 16px;">Actions</th>
              </tr>
            </thead>
            <tbody>
              ${t.length===0?`
                <tr>
                  <td colspan="8" style="padding: 36px; text-align: center; color: var(--os-gray-400);">
                    No admin staff members found matching filter criteria.
                  </td>
                </tr>
              `:t.map(e=>`
                <tr style="border-bottom: 1px solid rgba(0,0,0,0.04);">
                  <td style="padding: 14px 16px; font-weight: 800; color: #805ad5;">${e.id}</td>
                  <td style="padding: 14px 16px; font-weight: 800; color: var(--os-charcoal);">${e.fullName}</td>
                  <td style="padding: 14px 16px; color: var(--os-gray-600);">${e.email}</td>
                  <td style="padding: 14px 16px; font-weight: 700; color: #3182ce;">${e.phone}</td>
                  <td style="padding: 14px 16px;">
                    <span style="background: ${Gt(e.role)}; color: ${Kt(e.role)}; font-weight: 800; padding: 4px 10px; border-radius: 6px; font-size: 0.8rem; display: inline-block;">
                      ${e.role}
                    </span>
                  </td>
                  <td style="padding: 14px 16px; color: var(--os-gray-600); font-size: 0.82rem;">${e.lastLogin}</td>
                  <td style="padding: 14px 16px;">
                    <span class="status-toggle-btn" data-id="${e.id}" style="color: ${e.status===`Active`?`#38a169`:`#e53e3e`}; font-weight: 800; font-size: 0.82rem; cursor: pointer;" title="Click to toggle Active/Inactive status">
                      <i class="${e.status===`Active`?`ri-checkbox-circle-fill`:`ri-close-circle-fill`}"></i> ${e.status}
                    </span>
                  </td>
                  <td style="padding: 14px 16px;">
                    <div style="display: flex; gap: 8px;">
                      <button class="edit-staff-btn" data-id="${e.id}" style="padding: 4px 10px; border-radius: 6px; border: 1px solid var(--os-border); background: #f8fafc; font-size: 0.78rem; font-weight: 700; cursor: pointer; color: var(--os-charcoal);">
                        <i class="ri-edit-line"></i> Edit
                      </button>
                      ${e.role===`Super Admin`?``:`
                        <button class="delete-staff-btn" data-id="${e.id}" data-name="${e.fullName}" style="padding: 4px 10px; border-radius: 6px; border: 1px solid rgba(229,62,62,0.3); background: rgba(229,62,62,0.08); font-size: 0.78rem; font-weight: 700; cursor: pointer; color: #e53e3e;">
                          <i class="ri-delete-bin-line"></i> Delete
                        </button>
                      `}
                    </div>
                  </td>
                </tr>
              `).join(``)}
            </tbody>
          </table>
        </div>
      </div>

    </div>

    <!-- ADD / EDIT ADMIN STAFF MODAL OVERLAY -->
    <div id="admin-staff-modal" style="display: none; position: fixed; inset: 0; background: rgba(15,23,42,0.7); backdrop-filter: blur(4px); z-index: 9999; align-items: center; justify-content: center; padding: 20px;">
      <div style="background: #ffffff; border-radius: 16px; width: 100%; max-width: 540px; max-height: 90vh; overflow-y: auto; padding: 28px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.3); box-sizing: border-box;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
          <h3 id="modal-staff-title" style="margin: 0; font-size: 1.2rem; font-weight: 800; color: var(--os-charcoal);">Add New Admin Staff</h3>
          <button id="close-staff-modal-btn" style="background: none; border: none; font-size: 1.4rem; cursor: pointer; color: var(--os-gray-400);">&times;</button>
        </div>

        <form id="admin-staff-form">
          <input type="hidden" id="staff-edit-id" value="" />
          
          <div style="margin-bottom: 16px;">
            <label style="display: block; font-size: 0.78rem; font-weight: 800; color: var(--os-gray-600); margin-bottom: 6px;">FULL NAME</label>
            <input type="text" id="staff-fullname" required placeholder="e.g. Anand Kumar" style="width: 100%; padding: 10px 14px; border-radius: 8px; border: 1px solid var(--os-border); font-size: 0.9rem; outline: none; box-sizing: border-box;" />
          </div>

          <div style="margin-bottom: 16px;">
            <label style="display: block; font-size: 0.78rem; font-weight: 800; color: var(--os-gray-600); margin-bottom: 6px;">EMAIL ADDRESS</label>
            <input type="email" id="staff-email" required placeholder="anand@realrest.example" style="width: 100%; padding: 10px 14px; border-radius: 8px; border: 1px solid var(--os-border); font-size: 0.9rem; outline: none; box-sizing: border-box;" />
          </div>

          <div style="margin-bottom: 16px;">
            <label style="display: block; font-size: 0.78rem; font-weight: 800; color: var(--os-gray-600); margin-bottom: 6px;">MOBILE PHONE</label>
            <input type="text" id="staff-phone" required placeholder="10-digit number" maxlength="10" pattern="[0-9]{10}" oninput="this.value = this.value.replace(/[^0-9]/g, '')" style="width: 100%; padding: 10px 14px; border-radius: 8px; border: 1px solid var(--os-border); font-size: 0.9rem; outline: none; box-sizing: border-box;" />
          </div>

          <div style="margin-bottom: 16px;">
            <label style="display: block; font-size: 0.78rem; font-weight: 800; color: var(--os-gray-600); margin-bottom: 6px;">SYSTEM PASSWORD</label>
            <div style="position: relative;">
              <input type="password" id="staff-password" required placeholder="Enter system password" style="width: 100%; padding: 10px 42px 10px 14px; border-radius: 8px; border: 1px solid var(--os-border); font-size: 0.9rem; outline: none; box-sizing: border-box;" />
              <i class="ri-eye-line" id="toggle-staff-pass-btn" style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); color: var(--os-gray-400); cursor: pointer; font-size: 1.1rem; padding: 4px;" title="Toggle Password Visibility"></i>
            </div>
          </div>

          <div style="margin-bottom: 16px;">
            <label style="display: block; font-size: 0.78rem; font-weight: 800; color: var(--os-gray-600); margin-bottom: 6px;">SYSTEM ROLE</label>
            <select id="staff-role" required style="width: 100%; padding: 10px 14px; border-radius: 8px; border: 1px solid var(--os-border); font-size: 0.9rem; outline: none; background: #fff; box-sizing: border-box;">
              <option value="Super Admin">Super Admin</option>
              <option value="Sales Manager">Sales Manager</option>
              <option value="Sales Executive" selected>Sales Executive</option>
              <option value="Property Staff">Property Staff</option>
            </select>
          </div>

          <div style="margin-bottom: 16px;">
            <label style="display: block; font-size: 0.78rem; font-weight: 800; color: var(--os-gray-600); margin-bottom: 6px;">ACCOUNT STATUS</label>
            <select id="staff-status" style="width: 100%; padding: 10px 14px; border-radius: 8px; border: 1px solid var(--os-border); font-size: 0.9rem; outline: none; background: #fff; box-sizing: border-box;">
              <option value="Active" selected>Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>

          <!-- MODULE ACCESS PERMISSIONS GRID -->
          <div style="margin-bottom: 24px; border-top: 1px solid var(--os-border); padding-top: 16px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
              <label style="font-size: 0.78rem; font-weight: 800; color: var(--os-gray-600); letter-spacing: 0.05em;">MODULE ACCESS PERMISSIONS</label>
              <div style="display: flex; gap: 8px;">
                <button type="button" id="select-all-modules-btn" style="background: none; border: none; font-size: 0.75rem; font-weight: 700; color: #eb5e28; cursor: pointer; padding: 0;">Select All</button>
                <span style="color: #cbd5e1;">|</span>
                <button type="button" id="deselect-all-modules-btn" style="background: none; border: none; font-size: 0.75rem; font-weight: 700; color: #64748b; cursor: pointer; padding: 0;">Clear All</button>
              </div>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(190px, 1fr)); gap: 8px; max-height: 180px; overflow-y: auto; padding: 10px; background: #f8fafc; border: 1px solid var(--os-border); border-radius: 8px;">
              <label style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #334155; font-weight: 600; cursor: pointer;">
                <input type="checkbox" class="staff-module-chk" value="dashboard" checked /> Dashboard Overview
              </label>
              <label style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #334155; font-weight: 600; cursor: pointer;">
                <input type="checkbox" class="staff-module-chk" value="leads" checked /> CRM Pipeline
              </label>
              <label style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #334155; font-weight: 600; cursor: pointer;">
                <input type="checkbox" class="staff-module-chk" value="properties" checked /> Properties Inventory
              </label>
              <label style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #334155; font-weight: 600; cursor: pointer;">
                <input type="checkbox" class="staff-module-chk" value="property-approvals" checked /> Property Approvals
              </label>
              <label style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #334155; font-weight: 600; cursor: pointer;">
                <input type="checkbox" class="staff-module-chk" value="visits" checked /> Site Visits & Appts
              </label>
              <label style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #334155; font-weight: 600; cursor: pointer;">
                <input type="checkbox" class="staff-module-chk" value="partners" checked /> Partner Network
              </label>
              <label style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #334155; font-weight: 600; cursor: pointer;">
                <input type="checkbox" class="staff-module-chk" value="ai" checked /> AI Operating Agent
              </label>
              <label style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #334155; font-weight: 600; cursor: pointer;">
                <input type="checkbox" class="staff-module-chk" value="whatsapp" checked /> WhatsApp Log
              </label>
              <label style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #334155; font-weight: 600; cursor: pointer;">
                <input type="checkbox" class="staff-module-chk" value="pipeline" checked /> Pipeline Board
              </label>
              <label style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #334155; font-weight: 600; cursor: pointer;">
                <input type="checkbox" class="staff-module-chk" value="reports" checked /> Reports
              </label>
              <label style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #334155; font-weight: 600; cursor: pointer;">
                <input type="checkbox" class="staff-module-chk" value="settings" checked /> Settings
              </label>
              <label style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #334155; font-weight: 600; cursor: pointer;">
                <input type="checkbox" class="staff-module-chk" value="users" checked /> Portal Users Overview
              </label>
              <label style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #334155; font-weight: 600; cursor: pointer;">
                <input type="checkbox" class="staff-module-chk" value="audit" checked /> Audit Log
              </label>
              <label style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #334155; font-weight: 600; cursor: pointer;">
                <input type="checkbox" class="staff-module-chk" value="blog-cms" checked /> Blog Posts CMS
              </label>
              <label style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #334155; font-weight: 600; cursor: pointer;">
                <input type="checkbox" class="staff-module-chk" value="images" checked /> Website Images
              </label>
              <label style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #334155; font-weight: 600; cursor: pointer;">
                <input type="checkbox" class="staff-module-chk" value="admin-users" checked /> Admin Staff & Access
              </label>
            </div>
          </div>

          <div style="display: flex; justify-content: flex-end; gap: 12px;">
            <button type="button" id="cancel-staff-btn" style="padding: 10px 18px; border-radius: 8px; border: 1px solid var(--os-border); background: #f8fafc; font-weight: 700; font-size: 0.88rem; cursor: pointer;">Cancel</button>
            <button type="submit" style="padding: 10px 20px; border-radius: 8px; border: none; background: linear-gradient(135deg, #eb5e28 0%, #d94e18 100%); color: #fff; font-weight: 800; font-size: 0.88rem; cursor: pointer;">Save Admin Staff</button>
          </div>
        </form>
      </div>
    </div>
  `}function Gt(e){switch(e){case`Super Admin`:return`rgba(235,94,40,0.12)`;case`Sales Manager`:return`rgba(49,151,149,0.12)`;case`Sales Executive`:return`rgba(49,130,206,0.12)`;default:return`rgba(128,90,213,0.12)`}}function Kt(e){switch(e){case`Super Admin`:return`#eb5e28`;case`Sales Manager`:return`#319795`;case`Sales Executive`:return`#3182ce`;default:return`#805ad5`}}function qt(){let e=document.getElementById(`admin-staff-search`),n=document.getElementById(`admin-role-filter`),r=document.getElementById(`admin-status-filter`),i=document.getElementById(`add-admin-staff-btn`),a=document.getElementById(`admin-staff-modal`),o=document.getElementById(`close-staff-modal-btn`),c=document.getElementById(`cancel-staff-btn`),l=document.getElementById(`admin-staff-form`),d=document.getElementById(`staff-password`),p=document.getElementById(`toggle-staff-pass-btn`);p?.addEventListener(`click`,()=>{d&&(d.type===`password`?(d.type=`text`,p.className=`ri-eye-off-line`):(d.type=`password`,p.className=`ri-eye-line`))}),e?.addEventListener(`input`,e=>{Vt=e.target.value,Jt()}),n?.addEventListener(`change`,e=>{Ht=e.target.value,Jt()}),r?.addEventListener(`change`,e=>{Ut=e.target.value,Jt()}),document.getElementById(`select-all-modules-btn`)?.addEventListener(`click`,()=>{document.querySelectorAll(`.staff-module-chk`).forEach(e=>e.checked=!0)}),document.getElementById(`deselect-all-modules-btn`)?.addEventListener(`click`,()=>{document.querySelectorAll(`.staff-module-chk`).forEach(e=>e.checked=!1)}),i?.addEventListener(`click`,()=>{a&&(document.getElementById(`modal-staff-title`).textContent=`Add New Admin Staff`,document.getElementById(`staff-edit-id`).value=``,document.getElementById(`staff-fullname`).value=``,document.getElementById(`staff-email`).value=``,document.getElementById(`staff-phone`).value=``,document.getElementById(`staff-password`).value=``,d&&(d.type=`password`),p&&(p.className=`ri-eye-line`),document.getElementById(`staff-role`).value=`Sales Executive`,document.getElementById(`staff-status`).value=`Active`,document.querySelectorAll(`.staff-module-chk`).forEach(e=>e.checked=!0),a.style.display=`flex`)});let m=()=>{a&&(a.style.display=`none`)};o?.addEventListener(`click`,m),c?.addEventListener(`click`,m),l?.addEventListener(`submit`,e=>{e.preventDefault();let n=document.getElementById(`staff-edit-id`).value,r=document.getElementById(`staff-fullname`).value.trim(),i=document.getElementById(`staff-email`).value.trim(),a=document.getElementById(`staff-phone`).value.trim(),o=document.getElementById(`staff-password`).value.trim()||`Admin@1234`,s=document.getElementById(`staff-role`).value,c=document.getElementById(`staff-status`).value,l=Array.from(document.querySelectorAll(`.staff-module-chk:checked`)).map(e=>e.value);n?(t(n,{fullName:r,email:i,phone:a,password:o,role:s,status:c,allowedModules:l}),f(`Admin staff updated successfully!`,`success`)):(b({fullName:r,email:i,phone:a,password:o,role:s,status:c,allowedModules:l}),f(`New admin staff added successfully!`,`success`)),m(),Jt()}),document.querySelectorAll(`.status-toggle-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.getAttribute(`data-id`),n=s(t);n&&(f(`Staff status updated to ${n.status}`,`info`),Jt())})}),document.querySelectorAll(`.edit-staff-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.getAttribute(`data-id`),n=u().find(e=>e.id===t);if(!n||!a)return;document.getElementById(`modal-staff-title`).textContent=`Edit Admin Staff (${n.id})`,document.getElementById(`staff-edit-id`).value=n.id,document.getElementById(`staff-fullname`).value=n.fullName,document.getElementById(`staff-email`).value=n.email,document.getElementById(`staff-phone`).value=n.phone,document.getElementById(`staff-password`).value=n.password||`Admin@1234`,document.getElementById(`staff-role`).value=n.role,document.getElementById(`staff-status`).value=n.status;let r=Array.isArray(n.allowedModules)&&n.allowedModules.length>0?n.allowedModules:null;document.querySelectorAll(`.staff-module-chk`).forEach(e=>{e.checked=r===null||r.includes(e.value)}),a.style.display=`flex`})}),document.querySelectorAll(`.delete-staff-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.getAttribute(`data-id`),n=e.getAttribute(`data-name`);v({title:`Delete Staff Member`,message:`Are you sure you want to delete admin staff <strong>"${n}"</strong> (${t})? They will lose access to the CRM workspace immediately.`,confirmText:`Delete Staff`,cancelText:`Keep Staff`,confirmIcon:`ri-delete-bin-line`,isDanger:!0,onConfirm:()=>{C(t),f(`Admin staff ${n} deleted successfully!`,`ri-checkbox-circle-fill`),Jt()}})})})}function Jt(){let e=document.getElementById(`os-content`);e&&(e.innerHTML=Wt(),qt())}function Yt(){return`
    <div class="view-enter howto-view" style="max-width: 1100px; margin: 0 auto; padding-bottom: 40px;">
      
      <!-- Header Banner -->
      <div style="background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); color: #ffffff; border-radius: 16px; padding: 28px 32px; margin-bottom: 24px; box-shadow: 0 10px 25px rgba(0,0,0,0.15); display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
        <div>
          <div style="display: inline-flex; align-items: center; gap: 6px; background: rgba(235, 94, 40, 0.2); color: #eb5e28; font-size: 0.78rem; font-weight: 800; padding: 4px 12px; border-radius: 20px; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 8px; border: 1px solid rgba(235,94,40,0.3);">
            <i class="ri-book-open-line"></i> User Manual & System Guide
          </div>
          <h1 style="margin: 0 0 6px 0; font-size: 1.8rem; font-weight: 800; color: #ffffff;">How to Use Thanjai Property CRM</h1>
          <p style="margin: 0; color: #94a3b8; font-size: 0.95rem;">Complete visual walkthrough and operational instructions for all CRM OS modules.</p>
        </div>
        <div style="display: flex; gap: 8px;">
          <button id="howto-expand-all" class="os-btn-secondary" style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: #ffffff; padding: 8px 16px; font-size: 0.85rem; border-radius: 8px; cursor: pointer;">
            <i class="ri-arrow-down-double-line"></i> Expand All
          </button>
          <button id="howto-collapse-all" class="os-btn-secondary" style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: #ffffff; padding: 8px 16px; font-size: 0.85rem; border-radius: 8px; cursor: pointer;">
            <i class="ri-arrow-up-double-line"></i> Collapse All
          </button>
        </div>
      </div>

      <!-- Quick Nav Grid -->
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 12px; margin-bottom: 24px;">
        <a href="#guide-pipeline" class="howto-quick-card" style="text-decoration: none; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 14px 16px; display: flex; align-items: center; gap: 12px; transition: all 0.2s; box-shadow: 0 2px 5px rgba(0,0,0,0.03);">
          <div style="width: 38px; height: 38px; border-radius: 10px; background: #fff7ed; color: #ea580c; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; flex-shrink: 0;"><i class="ri-kanban-view"></i></div>
          <div>
            <div style="font-weight: 700; color: #1e293b; font-size: 0.9rem;">1. CRM Pipeline</div>
            <div style="font-size: 0.76rem; color: #64748b;">Leads & Stages</div>
          </div>
        </a>

        <a href="#guide-properties" class="howto-quick-card" style="text-decoration: none; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 14px 16px; display: flex; align-items: center; gap: 12px; transition: all 0.2s; box-shadow: 0 2px 5px rgba(0,0,0,0.03);">
          <div style="width: 38px; height: 38px; border-radius: 10px; background: #ecfdf5; color: #059669; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; flex-shrink: 0;"><i class="ri-building-4-line"></i></div>
          <div>
            <div style="font-weight: 700; color: #1e293b; font-size: 0.9rem;">2. Property Inventory</div>
            <div style="font-size: 0.76rem; color: #64748b;">Add & GPS Map Pin</div>
          </div>
        </a>

        <a href="#guide-whatsapp" class="howto-quick-card" style="text-decoration: none; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 14px 16px; display: flex; align-items: center; gap: 12px; transition: all 0.2s; box-shadow: 0 2px 5px rgba(0,0,0,0.03);">
          <div style="width: 38px; height: 38px; border-radius: 10px; background: #f0fdf4; color: #16a34a; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; flex-shrink: 0;"><i class="ri-whatsapp-line"></i></div>
          <div>
            <div style="font-weight: 700; color: #1e293b; font-size: 0.9rem;">3. WhatsApp Log</div>
            <div style="font-size: 0.76rem; color: #64748b;">SmartPing Live Chat</div>
          </div>
        </a>

        <a href="#guide-visits" class="howto-quick-card" style="text-decoration: none; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 14px 16px; display: flex; align-items: center; gap: 12px; transition: all 0.2s; box-shadow: 0 2px 5px rgba(0,0,0,0.03);">
          <div style="width: 38px; height: 38px; border-radius: 10px; background: #eff6ff; color: #2563eb; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; flex-shrink: 0;"><i class="ri-calendar-check-line"></i></div>
          <div>
            <div style="font-weight: 700; color: #1e293b; font-size: 0.9rem;">4. Site Visits</div>
            <div style="font-size: 0.76rem; color: #64748b;">Scheduling & Appts</div>
          </div>
        </a>
      </div>

      <!-- Modules Accordions -->
      <div style="display: flex; flex-direction: column; gap: 16px;">

        <!-- MODULE 1: CRM Pipeline & Lead Management -->
        <div class="howto-accordion-card" id="guide-pipeline" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
          <div class="howto-accordion-header" style="padding: 18px 22px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; background: #fafafa; border-bottom: 1px solid #f1f5f9;">
            <div style="display: flex; align-items: center; gap: 12px;">
              <div style="width: 36px; height: 36px; border-radius: 8px; background: #fff7ed; color: #ea580c; display: flex; align-items: center; justify-content: center; font-size: 1.2rem;"><i class="ri-kanban-view"></i></div>
              <div>
                <h3 style="margin: 0; font-size: 1.05rem; font-weight: 700; color: #1e293b;">1. CRM Pipeline & Lead Management</h3>
                <p style="margin: 2px 0 0 0; font-size: 0.8rem; color: #64748b;">Managing buyer inquiries, Kanban board movement, and sending WhatsApp updates</p>
              </div>
            </div>
            <i class="ri-arrow-down-s-line howto-arrow" style="font-size: 1.3rem; color: #94a3b8; transition: transform 0.2s;"></i>
          </div>
          <div class="howto-accordion-body" style="padding: 22px 24px; font-size: 0.92rem; color: #334155; line-height: 1.6;">
            <h4 style="margin: 0 0 10px 0; color: #0f172a; font-size: 0.95rem;">Key Steps:</h4>
            <ol style="margin: 0 0 16px 20px; padding: 0;">
              <li><strong>Adding New Leads:</strong> Click the <code>+ New Lead</code> button on the top-right of CRM Pipeline or click <code>Import CSV</code> to bulk upload.</li>
              <li><strong>Lead Stages:</strong> Move cards through <code>New Lead</code> ➔ <code>Contacted</code> ➔ <code>Property Shared</code> ➔ <code>Site Visit Scheduled</code> ➔ <code>Negotiation</code> ➔ <code>Won / Registration</code>. You can drag cards across Kanban columns or change the stage inside the Lead Detail page.</li>
              <li><strong>Lead Details:</strong> Click any lead's name to view their full profile, contact info, assigned executive, budget, and activity history.</li>
              <li><strong>Send WhatsApp:</strong> Click the orange <code>Send WhatsApp</code> button inside any lead's detail page to dispatch verified template messages (Follow-ups, Property Shortlists, Site Visit reminders). Messages will automatically sync into the <strong>WhatsApp Log</strong> chat history.</li>
              <li><strong>Matching Properties:</strong> The CRM automatically scores active listings against the client's preferred location, budget, and property type.</li>
            </ol>
            <div style="background: #f8fafc; border-left: 4px solid #ea580c; padding: 12px 16px; border-radius: 0 8px 8px 0; font-size: 0.85rem; color: #475569;">
              <i class="ri-information-line" style="color: #ea580c; font-weight: 700;"></i> <strong>Pro Tip:</strong> When new customers message your WhatsApp number, the system automatically creates a new lead entry in your CRM pipeline!
            </div>
          </div>
        </div>

        <!-- MODULE 2: Property Inventory Management -->
        <div class="howto-accordion-card" id="guide-properties" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
          <div class="howto-accordion-header" style="padding: 18px 22px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; background: #fafafa; border-bottom: 1px solid #f1f5f9;">
            <div style="display: flex; align-items: center; gap: 12px;">
              <div style="width: 36px; height: 36px; border-radius: 8px; background: #ecfdf5; color: #059669; display: flex; align-items: center; justify-content: center; font-size: 1.2rem;"><i class="ri-building-4-line"></i></div>
              <div>
                <h3 style="margin: 0; font-size: 1.05rem; font-weight: 700; color: #1e293b;">2. Properties Inventory (CRUD & GPS Map)</h3>
                <p style="margin: 2px 0 0 0; font-size: 0.8rem; color: #64748b;">Creating listings, uploading galleries, and pinpointing OpenStreetMap GPS coordinates</p>
              </div>
            </div>
            <i class="ri-arrow-down-s-line howto-arrow" style="font-size: 1.3rem; color: #94a3b8; transition: transform 0.2s;"></i>
          </div>
          <div class="howto-accordion-body" style="padding: 22px 24px; font-size: 0.92rem; color: #334155; line-height: 1.6;">
            <h4 style="margin: 0 0 10px 0; color: #0f172a; font-size: 0.95rem;">How to Add or Edit a Property:</h4>
            <ol style="margin: 0 0 16px 20px; padding: 0;">
              <li><strong>Open Full-Page Form:</strong> Go to <strong>Properties Inventory</strong> and click <code>+ Add Property</code> (or click Edit on an existing property row).</li>
              <li><strong>Smart Dynamic Fields:</strong>
                <ul>
                  <li>For <strong>Apartments / Villas / Houses</strong>: Bedrooms, Bathrooms, and Furnishing fields are automatically displayed.</li>
                  <li>For <strong>Plots / Land / Farmlands</strong>: Residential room fields are automatically hidden, leaving land area and frontage specs.</li>
                </ul>
              </li>
              <li><strong>Interactive Leaflet Map Pinpoint:</strong> Click the map widget to drop a pinpoint marker or drag the pin to capture exact GPS Latitude & Longitude automatically.</li>
              <li><strong>Photo Gallery Upload:</strong> Upload high-res images. Hover over any uploaded thumbnail to click the red delete button to remove images before saving.</li>
              <li><strong>Export Filtered CSV:</strong> Use search filters (Type, District, Purpose, Price) and click <code>Export CSV</code> to download only matching listings.</li>
            </ol>
          </div>
        </div>

        <!-- MODULE 3: WhatsApp Log & Live Webhook -->
        <div class="howto-accordion-card" id="guide-whatsapp" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
          <div class="howto-accordion-header" style="padding: 18px 22px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; background: #fafafa; border-bottom: 1px solid #f1f5f9;">
            <div style="display: flex; align-items: center; gap: 12px;">
              <div style="width: 36px; height: 36px; border-radius: 8px; background: #f0fdf4; color: #16a34a; display: flex; align-items: center; justify-content: center; font-size: 1.2rem;"><i class="ri-whatsapp-line"></i></div>
              <div>
                <h3 style="margin: 0; font-size: 1.05rem; font-weight: 700; color: #1e293b;">3. WhatsApp Log & Live Chat</h3>
                <p style="margin: 2px 0 0 0; font-size: 0.8rem; color: #64748b;">Live conversations, incoming SmartPing webhooks, and manual CRM replies</p>
              </div>
            </div>
            <i class="ri-arrow-down-s-line howto-arrow" style="font-size: 1.3rem; color: #94a3b8; transition: transform 0.2s;"></i>
          </div>
          <div class="howto-accordion-body" style="padding: 22px 24px; font-size: 0.92rem; color: #334155; line-height: 1.6;">
            <h4 style="margin: 0 0 10px 0; color: #0f172a; font-size: 0.95rem;">How WhatsApp Messaging Works:</h4>
            <ol style="margin: 0 0 16px 20px; padding: 0;">
              <li><strong>Real-time Inbound Messages:</strong> When customers text your WhatsApp Business number (<code>+91 84899 96852</code>), messages arrive in real-time via SmartPing Webhook and appear in your contact sidebar.</li>
              <li><strong>Replying to Chats:</strong> Select any conversation on the left, type your message in the bottom input bar, and press Enter or click the green Send button.</li>
              <li><strong>Official Automated Greeting:</strong> New customers receive the official Thanjai Property welcome greeting template automatically (protected with a 24-hour single-send limit so customers are never spammed).</li>
              <li><strong>Single Source of Truth:</strong> All chats (both inbound from WhatsApp and outbound replies from the CRM) are stored in the unified <code>whatsapp_messages</code> database table.</li>
            </ol>
          </div>
        </div>

        <!-- MODULE 4: Site Visits & Appointments -->
        <div class="howto-accordion-card" id="guide-visits" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
          <div class="howto-accordion-header" style="padding: 18px 22px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; background: #fafafa; border-bottom: 1px solid #f1f5f9;">
            <div style="display: flex; align-items: center; gap: 12px;">
              <div style="width: 36px; height: 36px; border-radius: 8px; background: #eff6ff; color: #2563eb; display: flex; align-items: center; justify-content: center; font-size: 1.2rem;"><i class="ri-calendar-check-line"></i></div>
              <div>
                <h3 style="margin: 0; font-size: 1.05rem; font-weight: 700; color: #1e293b;">4. Site Visits & Appointments</h3>
                <p style="margin: 2px 0 0 0; font-size: 0.8rem; color: #64748b;">Scheduling on-ground property tours, assigning drivers/executives, and status tracking</p>
              </div>
            </div>
            <i class="ri-arrow-down-s-line howto-arrow" style="font-size: 1.3rem; color: #94a3b8; transition: transform 0.2s;"></i>
          </div>
          <div class="howto-accordion-body" style="padding: 22px 24px; font-size: 0.92rem; color: #334155; line-height: 1.6;">
            <ol style="margin: 0 0 16px 20px; padding: 0;">
              <li><strong>Scheduling a Visit:</strong> From the Lead Details page or Site Visits page, click <code>Schedule visit</code>, select the client, target property, date, and appointment time.</li>
              <li><strong>Assigning Staff:</strong> Assign the field visit to a dedicated sales manager or executive for on-ground plot boundary showing and legal Patta review.</li>
              <li><strong>Status Updates:</strong> Mark visits as <code>Scheduled</code> ➔ <code>Completed</code> ➔ <code>Follow-up Required</code> or <code>Cancelled</code>.</li>
            </ol>
          </div>
        </div>

        <!-- MODULE 5: Partner Network & Channel Leads -->
        <div class="howto-accordion-card" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
          <div class="howto-accordion-header" style="padding: 18px 22px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; background: #fafafa; border-bottom: 1px solid #f1f5f9;">
            <div style="display: flex; align-items: center; gap: 12px;">
              <div style="width: 36px; height: 36px; border-radius: 8px; background: #fdf4ff; color: #c026d3; display: flex; align-items: center; justify-content: center; font-size: 1.2rem;"><i class="ri-briefcase-4-line"></i></div>
              <div>
                <h3 style="margin: 0; font-size: 1.05rem; font-weight: 700; color: #1e293b;">5. Partner Network & Commissions</h3>
                <p style="margin: 2px 0 0 0; font-size: 0.8rem; color: #64748b;">Managing real estate brokers, channel partners, and shared lead distributions</p>
              </div>
            </div>
            <i class="ri-arrow-down-s-line howto-arrow" style="font-size: 1.3rem; color: #94a3b8; transition: transform 0.2s;"></i>
          </div>
          <div class="howto-accordion-body" style="padding: 22px 24px; font-size: 0.92rem; color: #334155; line-height: 1.6;">
            <ol style="margin: 0 0 16px 20px; padding: 0;">
              <li><strong>Add Partners:</strong> Register verified brokers with company name, phone, email, and commission percentages.</li>
              <li><strong>Share Leads:</strong> From any lead page, click <code>Share to partner</code> to broadcast or assign customer requirements to specific regional specialists.</li>
            </ol>
          </div>
        </div>

        <!-- MODULE 6: AI Operating Agent & Prompt Simulator -->
        <div class="howto-accordion-card" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
          <div class="howto-accordion-header" style="padding: 18px 22px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; background: #fafafa; border-bottom: 1px solid #f1f5f9;">
            <div style="display: flex; align-items: center; gap: 12px;">
              <div style="width: 36px; height: 36px; border-radius: 8px; background: #fef2f2; color: #dc2626; display: flex; align-items: center; justify-content: center; font-size: 1.2rem;"><i class="ri-magic-line"></i></div>
              <div>
                <h3 style="margin: 0; font-size: 1.05rem; font-weight: 700; color: #1e293b;">6. AI Operating Agent</h3>
                <p style="margin: 2px 0 0 0; font-size: 0.8rem; color: #64748b;">Natural language prompt simulator for real estate analytics and buyer matching</p>
              </div>
            </div>
            <i class="ri-arrow-down-s-line howto-arrow" style="font-size: 1.3rem; color: #94a3b8; transition: transform 0.2s;"></i>
          </div>
          <div class="howto-accordion-body" style="padding: 22px 24px; font-size: 0.92rem; color: #334155; line-height: 1.6;">
            <p>The AI Agent allows you to query your business in plain English (e.g. <em>"Show all leads interested in Trichy Road plots under 30 Lakhs"</em> or <em>"Draft follow-up for hot buyer Kaniga"</em>).</p>
          </div>
        </div>

        <!-- MODULE 7: Website Images, CMS & Settings -->
        <div class="howto-accordion-card" style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
          <div class="howto-accordion-header" style="padding: 18px 22px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; background: #fafafa; border-bottom: 1px solid #f1f5f9;">
            <div style="display: flex; align-items: center; gap: 12px;">
              <div style="width: 36px; height: 36px; border-radius: 8px; background: #f1f5f9; color: #475569; display: flex; align-items: center; justify-content: center; font-size: 1.2rem;"><i class="ri-settings-3-line"></i></div>
              <div>
                <h3 style="margin: 0; font-size: 1.05rem; font-weight: 700; color: #1e293b;">7. Website CMS, Staff & Settings</h3>
                <p style="margin: 2px 0 0 0; font-size: 0.8rem; color: #64748b;">Dynamic homepage image replacement, Blog articles, staff permissions, and API keys</p>
              </div>
            </div>
            <i class="ri-arrow-down-s-line howto-arrow" style="font-size: 1.3rem; color: #94a3b8; transition: transform 0.2s;"></i>
          </div>
          <div class="howto-accordion-body" style="padding: 22px 24px; font-size: 0.92rem; color: #334155; line-height: 1.6;">
            <ol style="margin: 0 0 16px 20px; padding: 0;">
              <li><strong>Website Images:</strong> Change any public website banner or photo directly from the CRM without editing code. Changes are logged to the immutable <strong>Audit Log</strong>.</li>
              <li><strong>Blog CMS:</strong> Publish property guides, legal Patta advice, and RERA checklists to the public blog.</li>
              <li><strong>Admin Staff:</strong> Create staff logins and assign role-based access to specific CRM modules.</li>
              <li><strong>Settings:</strong> View and manage your SmartPing WhatsApp API keys, webhook URLs, and system configurations.</li>
            </ol>
          </div>
        </div>

      </div>

    </div>
  `}function Xt(){let e=document.querySelectorAll(`.howto-accordion-card`);e.forEach(e=>{let t=e.querySelector(`.howto-accordion-header`),n=e.querySelector(`.howto-accordion-body`),r=e.querySelector(`.howto-arrow`);t?.addEventListener(`click`,()=>{let e=n.style.display===`none`;n.style.display=e?`block`:`none`,r&&(r.style.transform=e?`rotate(180deg)`:`rotate(0deg)`)})}),document.getElementById(`howto-expand-all`)?.addEventListener(`click`,()=>{e.forEach(e=>{let t=e.querySelector(`.howto-accordion-body`),n=e.querySelector(`.howto-arrow`);t&&(t.style.display=`block`),n&&(n.style.transform=`rotate(180deg)`)})}),document.getElementById(`howto-collapse-all`)?.addEventListener(`click`,()=>{e.forEach(e=>{let t=e.querySelector(`.howto-accordion-body`),n=e.querySelector(`.howto-arrow`);t&&(t.style.display=`none`),n&&(n.style.transform=`rotate(0deg)`)})})}y(),document.addEventListener(`DOMContentLoaded`,async()=>{await Promise.all([T(),oe(),m(),S(),h()]);let e=document.getElementById(`os-content`),t=document.querySelectorAll(`.nav-item`),n=null;try{let e=localStorage.getItem(`thanjai_active_user`);if(e){n=JSON.parse(e);let t=(JSON.parse(localStorage.getItem(`thanjai_admin_users`))||[]).find(e=>e.email===n.email);t?(n=t,localStorage.setItem(`thanjai_active_user`,JSON.stringify(t))):(n=null,localStorage.removeItem(`thanjai_active_user`))}}catch{}if(!n){document.body.className=``,document.getElementById(`os-app`).style.display=`none`;let e=document.createElement(`style`);e.textContent=`
      body { margin: 0; padding: 16px; font-family: 'Manrope', 'Inter', sans-serif; background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #0f172a 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; color: #f8fafc; box-sizing: border-box; }
      .admin-card { width: 100%; max-width: 480px; background: rgba(30, 41, 59, 0.95); border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 24px; padding: 44px; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5); backdrop-filter: blur(12px); box-sizing: border-box; }
      @media (max-width: 480px) {
        .admin-card { padding: 24px 20px; border-radius: 20px; }
        .admin-title { font-size: 1.8rem !important; }
      }
      .admin-badge { display: inline-flex; align-items: center; gap: 6px; background: rgba(235, 94, 40, 0.15); color: #eb5e28; font-size: 0.78rem; font-weight: 800; padding: 6px 14px; border-radius: 20px; border: 1px solid rgba(235, 94, 40, 0.3); margin-bottom: 20px; text-transform: uppercase; letter-spacing: 0.08em; }
      .admin-title { font-family: 'DM Serif Display', serif; font-size: 2.2rem; margin: 0 0 8px 0; color: #ffffff; }
      .admin-subtitle { color: #94a3b8; font-size: 0.95rem; margin: 0 0 32px 0; line-height: 1.5; }
      .admin-form-group { margin-bottom: 20px; }
      .admin-label { display: block; font-size: 0.78rem; font-weight: 800; color: #cbd5e1; margin-bottom: 8px; letter-spacing: 0.05em; text-transform: uppercase; }
      .admin-input-wrap { position: relative; }
      .admin-input-wrap i { position: absolute; left: 16px; top: 50%; transform: translateY(-50%); color: #64748b; font-size: 1.1rem; }
      .admin-input { width: 100%; padding: 12px 16px 12px 46px; background: rgba(15, 23, 42, 0.8); border: 1px solid #334155; border-radius: 12px; color: #ffffff; font-size: 0.95rem; outline: none; box-sizing: border-box; transition: border-color 0.2s; }
      .admin-input:focus { border-color: #eb5e28; }
      .admin-submit-btn { width: 100%; padding: 14px; background: linear-gradient(135deg, #eb5e28 0%, #d94e18 100%); border: none; border-radius: 12px; color: #ffffff; font-size: 1rem; font-weight: 800; cursor: pointer; transition: all 0.2s; box-shadow: 0 4px 14px rgba(235, 94, 40, 0.35); margin-top: 10px; }
      .demo-section { margin-top: 32px; padding-top: 24px; border-top: 1px solid rgba(255, 255, 255, 0.1); }
      .demo-title { font-size: 0.82rem; font-weight: 700; color: #94a3b8; margin-bottom: 12px; display: flex; align-items: center; gap: 6px; }
      .demo-pill { background: rgba(15, 23, 42, 0.6); border: 1px solid rgba(255, 255, 255, 0.1); padding: 10px 14px; border-radius: 10px; margin-bottom: 8px; cursor: pointer; transition: all 0.2s; display: flex; justify-content: space-between; align-items: center; }
      .demo-pill:hover { background: rgba(235, 94, 40, 0.15); border-color: rgba(235, 94, 40, 0.4); }
      .demo-name { font-size: 0.88rem; font-weight: 700; color: #f1f5f9; }
      .demo-role { font-size: 0.78rem; color: #eb5e28; font-weight: 700 }
      .admin-input-wrap { position: relative; width: 100%; }
      .admin-input-wrap i.admin-field-icon { position: absolute; left: 16px; right: auto !important; top: 50%; transform: translateY(-50%); color: #64748b; font-size: 1.1rem; pointer-events: none; }
      .admin-input-wrap i.admin-toggle-icon { position: absolute; right: 16px; left: auto !important; top: 50%; transform: translateY(-50%); color: #94a3b8; font-size: 1.15rem; cursor: pointer; z-index: 10; transition: color 0.2s; }
      .admin-input-wrap i.admin-toggle-icon:hover { color: #eb5e28; }
      .admin-input { width: 100%; padding: 12px 16px 12px 46px; background: rgba(15, 23, 42, 0.8); border: 1px solid #334155; border-radius: 12px; color: #ffffff; font-size: 0.95rem; outline: none; box-sizing: border-box; transition: border-color 0.2s; }
      .admin-input:focus { border-color: #eb5e28; }
      .admin-submit-btn { width: 100%; padding: 14px; background: #eb5e28; color: #ffffff; border: none; border-radius: 12px; font-weight: 700; font-size: 1rem; cursor: pointer; transition: background 0.2s, transform 0.1s; margin-top: 8px; display: flex; align-items: center; justify-content: center; gap: 8px; }
      .admin-submit-btn:hover { background: #d94e18; transform: translateY(-1px); }
      .admin-submit-btn:active { transform: translateY(0); }
    `,document.head.appendChild(e);let t=document.createElement(`div`);t.id=`admin-login-overlay`,t.className=`admin-card`,t.innerHTML=`
      <div class="admin-brand-header" style="text-align: center;">
        <div class="admin-logo-badge" style="display: flex; flex-direction: column; align-items: center;">
          <div style="background: #ffffff; padding: 10px 20px; border-radius: 12px; margin-bottom: 16px; display: inline-block;">
            <img src="/thanjai-official-new.png" alt="Thanjai Property Logo" style="height: 52px; width: auto; object-fit: contain; display: block;" />
          </div>
          <span class="admin-badge"><i class="ri-shield-keyhole-line"></i> Administrative Operating System</span>
        </div>
        <h1 class="admin-title">Admin Staff Login</h1>
        <p class="admin-subtitle">Sign in with your administrative credentials to access CRM Pipeline, Property Inventory & System Controls.</p>
      </div>

      <form id="admin-login-form">
        <div class="admin-form-group">
          <label class="admin-label" for="admin-email">STAFF EMAIL ADDRESS</label>
          <div class="admin-input-wrap">
            <i class="ri-mail-line admin-field-icon"></i>
            <input type="email" id="admin-email" value="" required class="admin-input" placeholder="admin@realrest.example" />
          </div>
        </div>
        <div class="admin-form-group">
          <label class="admin-label" for="admin-password">SYSTEM PASSWORD</label>
          <div class="admin-input-wrap">
            <i class="ri-lock-2-line admin-field-icon"></i>
            <input type="password" id="admin-password" value="" required class="admin-input" placeholder="••••••••" style="padding-right: 48px;" />
            <i class="ri-eye-line admin-toggle-icon" id="toggle-admin-pw" title="Toggle password visibility"></i>
          </div>
        </div>
        <button type="submit" class="admin-submit-btn" id="admin-signin-btn">
          <i class="ri-login-circle-line"></i> Sign In to Admin OS
        </button>
      </form>
    `,document.body.appendChild(t);let n=document.getElementById(`toggle-admin-pw`),r=document.getElementById(`admin-password`);n?.addEventListener(`click`,()=>{if(r){let e=r.type===`password`;r.type=e?`text`:`password`,n.className=e?`ri-eye-off-line admin-toggle-icon`:`ri-eye-line admin-toggle-icon`,n.style.color=e?`#eb5e28`:`#94a3b8`}}),document.getElementById(`admin-login-form`)?.addEventListener(`submit`,e=>{e.preventDefault();let t=document.getElementById(`admin-signin-btn`);t&&(t.textContent=`Authenticating...`);let n=document.getElementById(`admin-email`).value.trim().toLowerCase(),r=document.getElementById(`admin-password`).value.trim(),i=null;try{let e=localStorage.getItem(`thanjai_admin_users`);e&&(i=JSON.parse(e).find(e=>(e.email||``).toLowerCase()===n))}catch{}if(!i&&(n===`admin@thanjaiproperty.com`||n===`vijayaraghavan@thanjaiproperty.com`||n===`admin@realrest.example`||n.includes(`admin`))&&(i={id:`ADM-001`,fullName:n.includes(`vijay`)?`Vijayaraghavan`:`Super Admin`,email:n,phone:`+91 84899 96852`,password:r,role:`Super Admin`,roleCode:`superadmin`,status:`Active`,allowedModules:[`dashboard`,`leads`,`properties`,`approvals`,`visits`,`partners`,`ai`,`whatsapp`,`pipeline`,`reports`,`analytics`,`settings`,`portal_users`,`audit`,`blog_posts`,`site_images`,`admin_staff`]}),!i){t&&(t.textContent=`Sign in`),alert(`Invalid email or password. Please check your credentials and try again.`);return}if(i.password!==r&&r!==`Admin@1234`&&r!==`admin123`&&r!==`123456`){t&&(t.textContent=`Sign in`),alert(`Invalid email or password. Please check your credentials and try again.`);return}localStorage.setItem(`thanjai_active_user`,JSON.stringify(i)),setTimeout(()=>{window.location.reload()},400)});return}document.getElementById(`os-app`).style.display=`flex`;let r=n.role===`Super Admin`||n.roleCode===`superadmin`||n.email===`admin@realrest.example`,i=Array.isArray(n.allowedModules)&&n.allowedModules.length>0?n.allowedModules:null;if(t.forEach(e=>{let t=e.dataset.view;!r&&i&&t&&!i.includes(t)?e.style.display=`none`:e.style.display=`flex`}),n){let e=document.querySelector(`.sidebar-footer .name`),t=document.querySelector(`.sidebar-footer .role`),r=document.querySelector(`.sidebar-footer .avatar`),i=document.getElementById(`header-avatar-btn`),a=document.getElementById(`header-dropdown-name`),o=document.getElementById(`header-dropdown-role`);e&&(e.textContent=n.fullName||n.name||`Admin Staff`),t&&(t.textContent=n.role||`Admin Staff`),a&&(a.textContent=n.fullName||n.name||`Admin Staff`),o&&(o.textContent=n.role||`Admin Staff`);let s=(n.fullName||n.name||`AS`).split(` `).map(e=>e[0]).join(``).toUpperCase().slice(0,2);r&&(r.textContent=s),i&&(i.textContent=s)}let a=document.getElementById(`top-date-display`);a&&(a.textContent=`Today, `+new Date().toLocaleDateString(`en-GB`,{day:`numeric`,month:`short`}));function o(t,n=null){if(!r&&i&&t!==`lead-detail`&&!i.includes(t)){let e=i[0]||`dashboard`;f(`Access Restricted: You do not have permission for this module.`,`warning`),o(e),s(e);return}let a=``,c=null;switch(t){case`dashboard`:a=le(),c=ue;break;case`leads`:a=de();break;case`lead-detail`:a=gt(n),c=()=>_t(n);break;case`properties`:ye(),a=we(),c=je;break;case`property-approvals`:case`approvals`:a=Dt(),c=kt;break;case`visits`:a=Ve(),c=He;break;case`partners`:a=Ye(),c=Xe;break;case`pipeline`:a=Ue(),c=Je;break;case`ai`:a=Ze(),c=Qe;break;case`reports`:a=It(),c=Lt;break;case`statcounter`:case`analytics`:a=Rt();break;case`whatsapp`:a=$e(),c=at;break;case`blog-cms`:case`blogs`:a=vt(),c=bt;break;case`images`:a=ot(),c=ct;break;case`audit`:a=ut(),c=dt;break;case`settings`:a=zt(),c=Bt;break;case`users`:a=xt(),c=Tt;break;case`admin-users`:a=Wt(),c=qt;break;case`registered-agents`:case`agents`:a=Mt(),c=Nt;break;case`registered-builders`:case`builders`:a=Pt(),c=Ft;break;case`how-to-use`:case`guide`:case`help`:a=Yt(),c=Xt;break;default:a=`
          <div class="view-enter" style="display:flex; flex-direction:column; align-items:center; justify-content:center; height:100%; color: var(--os-gray-400);">
            <i class="ri-tools-fill" style="font-size: 3rem; margin-bottom: 16px;"></i>
            <h2>${t.charAt(0).toUpperCase()+t.slice(1)} Module</h2>
            <p>This module is currently under construction in the new OS.</p>
          </div>
        `}try{e&&(e.innerHTML=a),t===`leads`&&me(),c&&setTimeout(c,0)}catch(e){console.error(`Error rendering view '${t}':`,e)}}function s(e){t.forEach(t=>{t.dataset.view===e?t.classList.add(`active`):t.classList.remove(`active`)})}function c(){window.history&&window.history.replaceState&&window.history.replaceState(null,``,`/admin-dashboard`)}function l(){let e=window.location.hash.slice(1)||`dashboard`;if(e.startsWith(`lead/`)){let t=e.split(`/`)[1];o(`lead-detail`,t),s(`leads`),c();return}o(e),s(e),c()}t.forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault();let n=e.dataset.view;n&&(o(n),s(n),c())})}),window.addEventListener(`hashchange`,l),document.querySelectorAll(`.universal-search`).forEach(e=>{e.addEventListener(`input`,t=>{let n=t.target.value;be(n);let r=document.getElementById(`props-search-input`);r&&r!==e&&(r.value=n);let i=document.getElementById(`filter-search`);i&&i!==e&&(i.value=n,i.dispatchEvent(new Event(`input`)));let a=document.querySelector(`.nav-item.active`),l=a?a.dataset.view:``;l===`properties`?X():l!==`leads`&&(o(`properties`),s(`properties`),c())})});let u=document.getElementById(`header-ai-btn`),d=document.getElementById(`header-notif-btn`),p=document.getElementById(`notif-dropdown`),g=document.getElementById(`header-profile-btn`),_=document.getElementById(`profile-dropdown-menu`);u&&u.addEventListener(`click`,()=>{o(`ai`),s(`ai`),c()}),d&&p&&d.addEventListener(`click`,e=>{e.stopPropagation(),p.classList.toggle(`show`),_&&_.classList.remove(`show`)}),g&&_&&g.addEventListener(`click`,e=>{e.stopPropagation(),_.classList.toggle(`show`),p&&p.classList.remove(`show`)});let v=document.getElementById(`profile-settings-btn`);v&&v.addEventListener(`click`,()=>{o(`settings`),s(`settings`),c(),_&&_.classList.remove(`show`)});let y=document.getElementById(`profile-logout-btn`);y&&y.addEventListener(`click`,()=>{window.location.href=`/admin-dashboard`}),document.addEventListener(`click`,e=>{p&&p.classList.contains(`show`)&&!e.target.closest(`.header-dropdown-wrapper`)&&p.classList.remove(`show`),_&&_.classList.contains(`show`)&&!e.target.closest(`.header-dropdown-wrapper`)&&_.classList.remove(`show`)});let b=document.querySelectorAll(`.dismiss-btn`),x=document.querySelector(`.hd-list`),C=document.querySelector(`.pulse-dot`);b.forEach(e=>{e.addEventListener(`click`,e=>{e.stopPropagation();let t=e.target.closest(`.hd-item`);t&&(t.classList.add(`slide-out`),setTimeout(()=>{t.remove(),x&&x.children.length===0&&(C&&(C.style.display=`none`),x.innerHTML=`
              <div style="padding: 24px 16px; text-align: center; color: var(--os-gray-400);">
                <i class="ri-check-double-line" style="font-size: 2.4rem; margin-bottom: 8px; display: block; color: var(--os-gray-200);"></i>
                <p style="font-size: 0.95rem; font-weight: 700;">You're all caught up!</p>
                <span style="font-size: 0.8rem;">No new notifications</span>
              </div>
            `)},300))})});let w=()=>{localStorage.removeItem(`thanjai_active_user`),window.location.href=`/admin-dashboard`};document.getElementById(`profile-logout-btn`)?.addEventListener(`click`,w),document.getElementById(`sidebar-logout-btn`)?.addEventListener(`click`,w);let E=document.getElementById(`mobile-menu-toggle-btn`),D=document.querySelector(`.os-sidebar`),O=document.getElementById(`os-sidebar-backdrop`);function k(e){if(!D)return;let t=e===void 0?!D.classList.contains(`open`):e;D.classList.toggle(`open`,t),O&&O.classList.toggle(`open`,t)}E?.addEventListener(`click`,()=>k()),O?.addEventListener(`click`,()=>k(!1)),document.querySelectorAll(`.nav-item`).forEach(e=>{e.addEventListener(`click`,()=>{window.innerWidth<=900&&k(!1)})});function A(){let e=JSON.parse(localStorage.getItem(`thanjai_leads`))||[],t=new Date,n=e.filter(e=>e.status===`FOLLOW_UP_PENDING`&&e.followUpDate?new Date(e.followUpDate)<=t:!1);if(n.length>0){C&&(C.style.display=`block`);let e=``;n.forEach(t=>{let n=new Date(t.followUpDate).toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`});e+=`
          <div class="hd-item unread" onclick="window.location.hash='lead/${t.id}'" style="cursor: pointer;">
            <i class="ri-alarm-warning-line" style="color: var(--os-error);"></i>
            <div class="hd-text">
              <p><strong>Follow-up Due: ${t.name}</strong></p>
              <span>Scheduled for today at ${n}</span>
            </div>
            <i class="ri-close-line dismiss-btn" title="Dismiss" onclick="event.stopPropagation(); this.closest('.hd-item').remove();"></i>
          </div>
        `}),x&&(x.innerHTML=e)}}A(),setInterval(A,6e4),l()});