import{P as e,i as t,w as n}from"./toast-t8Itjw0g.js";import{a as r,i,l as a,s as o}from"./propertiesStore-B8Cags-l.js";var s=`thanjai_property_favorites`;function c(){try{let e=localStorage.getItem(s);return e?JSON.parse(e):[]}catch{return[]}}function l(e){return c().includes(e)}function u(e){let t=c(),n,r=!1;t.includes(e)?(n=t.filter(t=>t!==e),r=!1):(n=[...t,e],r=!0);try{localStorage.setItem(s,JSON.stringify(n))}catch(e){console.error(e)}return window.dispatchEvent(new CustomEvent(`favoritesUpdated`,{detail:{count:n.length,propertyId:e,isSavedNow:r}})),r}var d={rating:4.6,ratingMax:5,totalReviews:64,businessName:`ThanjaiProperty.com Real Estate in Thanjavur`,businessAddress:`Flat No B1, 2nd Floor, Sivasakthi Appartment, behind HDFC Bank, near New Bus Stand Road, Lakshmi Nagar, New Housing Unit, Thanjavur, Tamil Nadu 613005, India`,googleReviewUrl:`https://www.google.com/search?q=thanjai+property#lrd=0x3baab8d3e85bc13f:0xc3d4d30ebdebd25d,1,,,,`,categories:[{label:`plot purchase`,count:4},{label:`helpful team`,count:2},{label:`smooth transaction`,count:2},{label:`selling house`,count:4}]},f=[{id:`REV-001`,author_name:`vicky selvam`,author_role:`1 review • House Buyer`,rating:5,review_text:`I have purchased house through Thanjaiproperty they done the quality service and till patta conversion supported us. I strongly recommend to my friends and relatives. ...`,location:`Thanjavur`,source:`Google`,verified_google:!0,time_ago:`Edited 5 months ago`,avatar_color:`#eb5e28`,owner_reply:`Hi Vicky Selvam, thank you for your 5-star review and for trusting ThanjaiProperty.com for your home purchase. We're happy to know you had a smooth experience and that our team could support you through the entire process, including patta conversion. At ThanjaiProperty.com, we are committed to providing end-to-end real estate services in Thanjavur.`},{id:`REV-002`,author_name:`Karthik R`,author_role:`Plot purchase • Thanjavur`,rating:5,review_text:`Very good real estate service in Thanjavur. Transparent dealing and clear documents for our DTCP plot. Highly recommended.`,location:`Medical College Road, Thanjavur`,source:`Google`,verified_google:!0,time_ago:`4 months ago`,avatar_color:`#2563eb`,owner_reply:`Thank you Mr. Karthik for your valuable review and trust in ThanjaiProperty.com!`},{id:`REV-003`,author_name:`Balaji S`,author_role:`Local Guide • Helpful team`,rating:5,review_text:`Helped us find a good residential plot near Medical College Road. Very helpful team and smooth registration process.`,location:`Medical College Road`,source:`Google`,verified_google:!0,time_ago:`3 months ago`,avatar_color:`#059669`},{id:`REV-004`,author_name:`Mohamed Riyaz`,author_role:`Selling house • Thanjavur`,rating:5,review_text:`Good platform for buying and selling properties in Thanjavur. Quick response and trustworthy staff.`,location:`New Housing Unit, Thanjavur`,source:`Google`,verified_google:!0,time_ago:`6 months ago`,avatar_color:`#7c3aed`},{id:`REV-005`,author_name:`R. Sangeetha`,author_role:`Smooth transaction`,rating:5,review_text:`Proper legal guidance and patta verification done before booking. Overall well services provided by the team.`,location:`Trichy Road, Thanjavur`,source:`Google`,verified_google:!0,time_ago:`2 months ago`,avatar_color:`#d97706`},{id:`REV-006`,author_name:`Sundar Ramanathan`,author_role:`Plot purchase`,rating:5,review_text:`Purchased land through Thanjai Property. Very honest pricing and direct owner coordination without any hassle.`,location:`Kumbakonam Bypass`,source:`Google`,verified_google:!0,time_ago:`5 months ago`,avatar_color:`#0284c7`},{id:`REV-007`,author_name:`K. Anbarasan`,author_role:`1 review • Legal Support`,rating:5,review_text:`Best real estate consultancy in Thanjavur district. 100% legal document support and genuine assistance.`,location:`Pudukkottai Road, Thanjavur`,source:`Google`,verified_google:!0,time_ago:`1 year ago`,avatar_color:`#db2777`},{id:`REV-008`,author_name:`Manikandan D`,author_role:`Selling house`,rating:5,review_text:`Sold my property through ThanjaiProperty within 1 month. Good network of genuine buyers in Thanjavur.`,location:`Nanjikottai Road, Thanjavur`,source:`Google`,verified_google:!0,time_ago:`8 months ago`,avatar_color:`#0d9488`}],p=`thanjai_testimonials_v3`,m=`thanjai_testimonials_version`,h=`2.3`;function g(e){return{id:e.id||`REV-${Date.now()}-${Math.floor(Math.random()*1e3)}`,name:e.name||e.author_name||`Verified Client`,author_name:e.author_name||e.name||`Verified Client`,author_role:e.author_role||e.propertyType||`Property Buyer`,propertyType:e.propertyType||e.author_role||`Property Buyer`,rating:parseInt(e.rating||5,10),reviewText:e.reviewText||e.review_text||``,review_text:e.review_text||e.reviewText||``,location:e.location||`Thanjavur`,source:e.source||`Google`,verified_google:e.verified_google!==!1,time_ago:e.time_ago||`Recent`,avatar:e.avatar||null,avatar_color:e.avatar_color||`#eb5e28`,phone:e.phone||null,email:e.email||null,status:e.status||`Approved`,isFeatured:e.isFeatured===void 0?1:+!!e.isFeatured,owner_reply:e.owner_reply||null,createdAt:e.createdAt||new Date().toISOString()}}function _(){try{if(localStorage.getItem(m)!==h){localStorage.setItem(m,h);let e=f.map(g);return localStorage.setItem(p,JSON.stringify(e)),e}let e=localStorage.getItem(p);if(e){let t=JSON.parse(e);if(Array.isArray(t)&&t.length>0)return t.map(g)}}catch(e){console.warn(`[ReviewsStore] Error reading from storage:`,e)}let e=f.map(g);try{localStorage.setItem(p,JSON.stringify(e)),localStorage.setItem(m,h)}catch{}return e}var v=_();async function y(){try{let e=await fetch(`/api.php/reviews`);if(e.ok){let t=await e.json();if(Array.isArray(t)&&t.length>0){let e=x(),n=[...t.map(g)];e.forEach(e=>{n.some(t=>t.id===e.id||t.name===e.name&&t.reviewText===e.reviewText)||n.push(e)}),v=n,b(v),window.dispatchEvent(new CustomEvent(`reviewsUpdated`));return}}}catch(e){console.warn(`[ReviewsStore] Background sync notice:`,e)}}typeof window<`u`&&y();function b(e){try{localStorage.setItem(p,JSON.stringify(e))}catch(e){console.warn(`[ReviewsStore] Error saving to storage:`,e)}}function x(){return(!v||v.length===0)&&(v=_()),[...v]}function S(){return x().filter(e=>e.status===`Approved`)}function C(){let e=S(),t=Math.max(e.length,d.totalReviews);return{...d,totalReviews:t}}function w(e){let t=g(e),r=x();return r.unshift(t),v=r,b(v),fetch(`/api.php/reviews`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(t)}).catch(()=>{}),n({timestamp:new Date().toLocaleString(`en-IN`,{dateStyle:`medium`,timeStyle:`short`}),action:`Added Review (${t.name})`,module:`Reviews & Testimonials`,details:`Added ${t.rating}-star review by ${t.name} via ${t.source}.`}),window.dispatchEvent(new CustomEvent(`reviewsUpdated`,{detail:t})),t}function T(e,t){let n=x(),r=n.findIndex(t=>t.id===e);return r===-1?null:(n[r]=g({...n[r],...t}),v=n,b(v),fetch(`/api.php/reviews/${e}`,{method:`PUT`,headers:{"Content-Type":`application/json`},body:JSON.stringify(n[r])}).catch(()=>{}),window.dispatchEvent(new CustomEvent(`reviewsUpdated`,{detail:{id:e,review:n[r]}})),n[r])}function E(e){return v=x().filter(t=>t.id!==e),b(v),fetch(`/api.php/reviews/${e}`,{method:`DELETE`}).catch(()=>{}),window.dispatchEvent(new CustomEvent(`reviewsUpdated`,{detail:{id:e,action:`delete`}})),!0}function D(e){let t=x().find(t=>t.id===e);return t?T(e,{status:t.status===`Approved`?`Hidden`:`Approved`}):null}var O=`thanjai_blog_posts`,k=[{id:`cauvery-delta-farmlands`,slug:`cauvery-delta-farmlands`,title:`Agricultural Farmland Wealth: Cultivating Returns in Thanjavur Delta`,category:`Agricultural`,date:`28 Jul 2026`,author:`S. Vijayaraghavan`,authorRole:`Managing Director, Thanjai Property`,authorBio:`Leading strategic land acquisitions, premium gated communities, and NRI property concierge services across Tamil Nadu since 2009.`,authorSocial:`https://wa.me/919578311506`,authorAvatar:`https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=200&q=80`,image:`https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80`,excerpt:`Why premium Cauvery riverbed agricultural land in Thanjavur represents resilient generational wealth and high-yield organic agro-farming opportunities.`,metaTitle:`Agricultural Farmland Wealth in Thanjavur Delta | Thanjai Property`,metaDescription:`Why premium Cauvery riverbed agricultural land in Thanjavur represents resilient generational wealth and high-yield agro-farming opportunities.`,content:`<p class="blog-lead">The Cauvery delta region around Thanjavur, Kumbakonam, and Mannargudi has been revered for millennia as the rice bowl of Tamil Nadu, blessed with fertile alluvial soil and perennial river irrigation networks.</p>
<h2>1. Perennial Water Security & Soil Fertility</h2>
<p>Unlike seasonal rain-fed farm tracts, Cauvery delta agricultural parcels benefit from canal irrigation networks, ensuring multi-crop cycles annually (Kuruvai, Thaladi, and Samba).</p>
<h2>2. Tax-Free Agricultural Income & Land Wealth</h2>
<p>Agricultural revenue in India remains exempt from income tax, making managed farm estates an attractive legal tax-efficient investment vehicle for doctors, business leaders, and NRI investors.</p>`},{id:`contemporary-villas-architecture`,slug:`contemporary-villas-architecture`,title:`Modern Villa Architecture: Blending Dravidian Courtyards with Contemporary Luxury`,category:`Architecture`,date:`15 Jul 2026`,author:`Aishwarya R.`,authorRole:`Senior Legal & Patta Verification Specialist`,authorBio:`Over 12 years of hands-on expertise in Tamil Nadu revenue administration, 30-year parent document tracing, and DTCP layout sanctions across Thanjavur & Trichy.`,authorSocial:`https://wa.me/919578311506`,authorAvatar:`https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=200&q=80`,image:`https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80`,excerpt:`Exploring modern luxury villas in Chennai and Thanjavur featuring open-air courtyards, VRV climate control, double-height ceilings, and lush tropical courtyards.`,metaTitle:`Modern Villa Architecture & Dravidian Courtyards | Thanjai Property`,metaDescription:`Exploring modern luxury villas in Chennai and Thanjavur featuring open-air courtyards, VRV climate control, and lush tropical courtyards.`,content:`<p class="blog-lead">Traditional South Indian courtyard architecture (Thinnai & Mutram) is experiencing a revival in high-end villa designs across Chennai, Trichy, and Thanjavur.</p>
<h2>1. Climate-Responsive Passive Cooling</h2>
<p>Central open sky courtyards pull hot air upwards while allowing cool breezes to circulate through living quarters naturally, reducing air conditioning energy load by up to 30%.</p>
<h2>2. Floor-to-Ceiling Thermal Glass</h2>
<p>Pairing traditional timber columns with double-glazed low-E glass walls creates seamless indoor-outdoor living while maintaining indoor thermal comfort during peak summer months.</p>`},{id:`central-tn-commercial-hubs`,slug:`central-tn-commercial-hubs`,title:`Investing in Central Tamil Nadu: Trichy & Thanjavur Commercial Corridors`,category:`Market Guide`,date:`30 Jun 2026`,author:`Kavitha S.`,authorRole:`Senior Investment & Capital Growth Analyst`,authorBio:`Specialist in central Tamil Nadu high-growth corridors, highway commercial plots, and real estate portfolio asset allocation.`,authorSocial:`https://wa.me/919578311506`,authorAvatar:`https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=200&q=80`,image:`https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80`,excerpt:`Commercial real estate growth analysis along Thanjavur New Bus Stand, Medical College Road, and Trichy Thillai Nagar high streets.`,metaTitle:`Investing in Central Tamil Nadu Commercial Corridors | Thanjai Property`,metaDescription:`Commercial real estate growth analysis along Thanjavur New Bus Stand, Medical College Road, and Trichy Thillai Nagar high streets.`,content:`<p class="blog-lead">Central Tamil Nadu cities like Trichy and Thanjavur are benefiting from infrastructure expansions including airport upgrades and NH highway widening, fueling 12-15% annual commercial property appreciation.</p>
<h2>1. Retail Showrooms & High Street Demand</h2>
<p>Key arterial roads such as Medical College Road in Thanjavur and Cantonment in Trichy report near 100% occupancy for banking hubs, healthcare clinics, and retail brand outlets.</p>`},{id:`nri-property-buying-guide`,slug:`nri-property-buying-guide`,title:`NRI Real Estate Guide: Purchasing Property in Tamil Nadu Seamlessly`,category:`NRI Guide`,date:`12 Jun 2026`,author:`S. Vijayaraghavan`,authorRole:`Managing Director, Thanjai Property`,authorBio:`Leading strategic land acquisitions, premium gated communities, and NRI property concierge services across Tamil Nadu since 2009.`,authorSocial:`https://wa.me/919578311506`,authorAvatar:`https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=200&q=80`,image:`https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=1200&q=80`,excerpt:`Essential checklist for non-resident Indians acquiring luxury villas, farm plots, and commercial assets in Tamil Nadu with remote legal execution.`,metaTitle:`NRI Real Estate Guide in Tamil Nadu | Thanjai Property`,metaDescription:`Essential checklist for non-resident Indians acquiring luxury villas, farm plots, and commercial assets in Tamil Nadu with remote legal execution.`,content:`<p class="blog-lead">Non-Resident Indians (NRIs) can freely acquire residential and commercial properties in India under RBI FEMA guidelines without requiring prior RBI permission.</p>
<h2>1. Power of Attorney (POA) Execution</h2>
<p>NRIs residing in US, UK, UAE, or Singapore can register a Specific Power of Attorney (POA) attested by the Indian Consulate to allow trusted family members to handle registration on their behalf.</p>`}],A=null;async function j(){try{let t=await e(`/blog`);if(t&&Array.isArray(t)&&t.length>0)return A=t,P(A),window.dispatchEvent(new CustomEvent(`blogPostsUpdated`)),A;if(t&&Array.isArray(t)&&t.length===0){let t=N(),n=t&&t.length>0?t:k;A=n,P(n);for(let t of n)e(`/blog`,{method:`POST`,body:JSON.stringify(t)}).catch(()=>{});return window.dispatchEvent(new CustomEvent(`blogPostsUpdated`)),A}}catch{}return A===null&&(A=N()),A}function M(){return A===null&&(A=N()),A||[]}function N(){try{let e=localStorage.getItem(O);if(e!==null){let t=JSON.parse(e);if(Array.isArray(t)&&t.length>0)return t}}catch(e){console.error(`Error reading blog posts from localStorage`,e)}return P(k),k}function P(e){try{localStorage.setItem(O,JSON.stringify(e)),A=e}catch(e){console.error(`Error saving blog posts to localStorage`,e)}}function F(e){return M().find(t=>t.id===e||t.slug===e||String(t.id).toLowerCase()===String(e).toLowerCase())}async function I(t){let r=M(),i=(t.slug||t.title||`post-${Date.now()}`).toLowerCase().trim().replace(/[^a-z0-9]+/g,`-`).replace(/(^-|-$)+/g,``),a=new Date().toLocaleDateString(`en-IN`,{day:`2-digit`,month:`short`,year:`numeric`}),o={id:t.id||`blog-${i}-${Date.now().toString().slice(-4)}`,slug:i,title:t.title||`Untitled Article`,category:t.category||`Market Guide`,date:t.date||a,readTime:t.readTime||`5 min read`,author:t.author||`Thanjai Editorial Desk`,authorRole:t.authorRole||``,authorBio:t.authorBio||``,authorSocial:t.authorSocial||``,authorAvatar:t.authorAvatar||`https://ui-avatars.com/api/?name=${encodeURIComponent(t.author||`Thanjai Desk`)}&background=2A1808&color=F8F4EC`,image:t.image||`https://images.unsplash.com/photo-1524813686514-a57563d77965?auto=format&fit=crop&w=1200&q=80`,excerpt:t.excerpt||`Article published on Thanjai Property Journal.`,metaTitle:t.metaTitle||(t.title?`${t.title} | Thanjai Property`:`Thanjai Property Legal Journal`),metaDescription:t.metaDescription||t.excerpt||`Expert real estate guides and market insights from Thanjai Property.`,content:t.content||`<p class="blog-lead">${t.excerpt||`Welcome to this article.`}</p>`};r.unshift(o),P(r),n({timestamp:new Date().toLocaleString(`en-IN`,{dateStyle:`medium`,timeStyle:`short`}),action:`Published Blog Article (${o.id})`,module:`Blog CMS`,details:`Published article "${o.title}" under ${o.category}.`}),window.dispatchEvent(new CustomEvent(`blogPostsUpdated`,{detail:{action:`add`,post:o}}));try{await e(`/blog`,{method:`POST`,body:JSON.stringify(o)})}catch(e){console.warn(`API sync for new blog post failed:`,e.message)}return o}async function L(t,r){let i=M(),a=i.findIndex(e=>e.id===t||e.slug===t);if(a===-1)return!1;let o=i[a],s={...o,...r,id:o.id,slug:r.slug||o.slug||o.id};i[a]=s,P(i),n({timestamp:new Date().toLocaleString(`en-IN`,{dateStyle:`medium`,timeStyle:`short`}),action:`Updated Blog Article (${o.id})`,module:`Blog CMS`,details:`Updated details for article "${s.title}".`}),window.dispatchEvent(new CustomEvent(`blogPostsUpdated`,{detail:{action:`update`,post:s}}));try{await e(`/blog/${o.id}`,{method:`PUT`,body:JSON.stringify(s)})}catch(e){console.error(`Failed to sync updated blog post to API`,e)}return s}async function R(t){let r=M(),i=r.find(e=>String(e.id)===String(t));if(!i)return!1;P(r.filter(e=>String(e.id)!==String(t))),n({timestamp:new Date().toLocaleString(`en-IN`,{dateStyle:`medium`,timeStyle:`short`}),action:`Deleted Blog Article (${t})`,module:`Blog CMS`,details:`Deleted article "${i.title}".`}),window.dispatchEvent(new CustomEvent(`blogPostsUpdated`,{detail:{action:`delete`,id:t}}));try{await e(`/blog/${t}`,{method:`DELETE`})}catch(e){console.error(`Failed to sync deleted blog post to API`,e)}return!0}function z(){P(k),e(`/blog/reset`,{method:`DELETE`}).catch(()=>{});for(let t of k)e(`/blog`,{method:`POST`,body:JSON.stringify(t)}).catch(()=>{});n({timestamp:new Date().toLocaleString(`en-IN`,{dateStyle:`medium`,timeStyle:`short`}),action:`Reset Blog CMS Catalog`,module:`Blog CMS`,details:`Restored factory seed blog articles in database and dashboard.`}),window.dispatchEvent(new CustomEvent(`blogPostsUpdated`,{detail:{action:`reset`}}))}var B=`eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY5NjYxNjVmODFhMDg2MTIzZWY5MWQ5MCIsIm5hbWUiOiJUaGFuamFpIFByb3BlcnR5IiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY5NjYxNjVmODFhMDg2MTIzZWY5MWQ4OSIsImFjdGl2ZVBsYW4iOiJQUk9fTU9OVEhMWSIsImlhdCI6MTc4NzcyNDczOX0.8SQSQDJdxrAivj8FAkWvjSk_qx4yE0dENDh70US75G0`;function V(){let e=typeof localStorage<`u`?localStorage.getItem(`thanjai_whatsapp_api_key`):``;return e&&e.trim().length>10?e.trim():B}async function H({campaignName:t,destination:n,userName:r,templateParams:i,media:a,messageText:o,leadId:s}){let c=`+91`+String(n||``).replace(/\D/g,``).slice(-10),l=V(),u=a||{url:`https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80`,filename:`thanjai-property.jpg`},d=(i||[]).map(e=>String(e)),f=!1;try{let n=await e(`/send_whatsapp`,{method:`POST`,body:JSON.stringify({campaignName:t,destination:c,userName:r||`Customer`,leadId:s,messageText:o,templateParams:d,media:u,apiKey:l})});n&&(n.success===!0||n.success===`true`)&&(f=!0)}catch(e){console.warn(`Backend relay notice:`,e)}if(!f)try{let e=await(await fetch(`https://backend.api-wa.co/campaign/smartping/api/v2`,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify({apiKey:l,campaignName:t,destination:c,userName:r||`Customer`,templateParams:d,media:u})})).json();(e.status===`success`||e.success===`true`||e.submitted_message_id)&&(f=!0)}catch{}return f}function U(e){if(!e)return``;let t=l(e.id),n=r(e.size),a=Array.isArray(e.specs)&&e.specs.length>0?[...e.specs]:[];!a.some(e=>e.label.toLowerCase()===`area`)&&n&&a.unshift({label:`Plot / Land Area`,value:n}),e.builtUpArea&&a.push({label:`Built-up Area`,value:e.builtUpArea}),!a.some(e=>e.label.toLowerCase()===`facing`)&&(e.facing||e.address)&&a.push({label:`Facing`,value:e.facing||e.address}),e.approval&&a.push({label:`Approval Status`,value:e.approval}),e.road&&e.road!==`Other / Outside Road`&&a.push({label:`Road Corridor`,value:e.road}),e.taluk&&a.push({label:`Taluk`,value:e.taluk}),e.furnishing&&e.furnishing!==`Not specified`&&a.push({label:`Furnishing`,value:e.furnishing}),e.floor&&a.push({label:`Floor`,value:e.floor}),e.district&&a.push({label:`District`,value:e.district});let o=Array.isArray(e.images)?e.images.filter(Boolean):[],s=[...new Set(o)],c=s.length>0?s:[`/default-property.jpg`],u=[],d=e.videoUrl||e.videos;if(Array.isArray(d))u=d.filter(Boolean);else if(typeof d==`string`&&d.trim()){if(d.trim().startsWith(`[`)&&d.trim().endsWith(`]`))try{let e=JSON.parse(d);Array.isArray(e)&&(u=e)}catch{u=d.split(/[\n,]+/)}else u=d.split(/[\n,]+/)}u=u.map(e=>typeof e==`string`?e.trim():``).filter(Boolean);let f=String(e.adType||e.ad_type||``).toLowerCase()===`paid`,p=f?e.ownerName||`Verified Owner`:`Thanjai Property`,m=f&&e.ownerPhone||`8489996852`,h=String(m).replace(/[^0-9]/g,``),g=h.length===10?`91${h}`:h.startsWith(`91`)?h:`918489996852`;return`
    <div class="modal-overlay active" id="property-details-modal-overlay" style="position: fixed; inset: 0; z-index: 9999999; background: rgba(15, 23, 42, 0.85); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px); display: flex; align-items: center; justify-content: center; padding: 20px; opacity: 1; visibility: visible; transition: all 0.3s ease;">
      <div class="property-modal-card" style="background: #ffffff; width: 100%; max-width: 1040px; max-height: 90vh; border-radius: 20px; overflow-y: auto; position: relative; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.4); font-family: 'Manrope', 'Plus Jakarta Sans', sans-serif;">
        
        <!-- Close Button -->
        <button class="modal-close-btn" id="close-prop-modal-btn" title="Close Modal" style="position: absolute; top: 16px; right: 16px; z-index: 100; background: #ffffff; border: 1px solid #e2e8f0; width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.4rem; color: #1e293b; cursor: pointer; box-shadow: 0 4px 12px rgba(0,0,0,0.15);">
          <i class="ri-close-line"></i>
        </button>

        <!-- Gallery Section -->
        <div style="display: grid; grid-template-columns: 1fr 140px; gap: 12px; padding: 24px 24px 0 24px; max-height: 280px; box-sizing: border-box;">
          <div id="modal-gallery-media-viewport" style="position: relative; height: 256px; border-radius: 14px; overflow: hidden; background: #0f172a;">
            <img src="${c[0]}" alt="${e.title}" id="modal-main-gallery-img" style="width: 100%; height: 100%; object-fit: cover; display: block;" />
            <div style="position: absolute; bottom: 12px; left: 12px; display: flex; gap: 8px; z-index: 5;">
              <span style="background: rgba(15,23,42,0.85); color: #ffffff; padding: 4px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; display: inline-flex; align-items: center; gap: 5px;">
                <i class="ri-image-line"></i> ${c.length} High-Res Photos
              </span>
              <span style="background: #ea580c; color: #ffffff; padding: 4px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.04em;">${e.tag||e.categoryLabel||e.type||`Property`}</span>
            </div>

            <div style="position: absolute; top: 12px; right: 12px; display: flex; gap: 6px; z-index: 5;">
              <button class="card-favorite-btn ${t?`saved`:``}" id="modal-save-fav-btn" title="Bookmark Property" style="width: 34px; height: 34px; border-radius: 50%; background: #ffffff; border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; font-size: 1.05rem; color: #ea580c; box-shadow: 0 2px 8px rgba(0,0,0,0.15);">
                <i class="${t?`ri-heart-fill`:`ri-heart-line`}"></i>
              </button>
            </div>
          </div>

          <div style="display: flex; flex-direction: column; gap: 8px; max-height: 256px; overflow-y: auto;">
            ${c.slice(0,4).map((e,t)=>`
              <img src="${e}" alt="Thumbnail ${t+1}" class="modal-thumb" data-type="image" data-src="${e}" style="width: 100%; height: 58px; object-fit: cover; border-radius: 8px; cursor: pointer; display: block; border: 1px solid #e2e8f0;" />
            `).join(``)}
            ${u.map((e,t)=>`
              <div class="modal-thumb" data-type="video" data-src="${e}" style="width: 100%; height: 58px; display: flex; flex-direction: column; align-items: center; justify-content: center; background: #0f172a; color: #fff; cursor: pointer; border-radius: 8px;">
                <i class="ri-play-circle-fill" style="color: #ea580c; font-size: 1.2rem;"></i>
                <span style="font-size: 0.58rem; font-weight: 800;">VIDEO ${u.length>1?t+1:``}</span>
              </div>
            `).join(``)}
          </div>
        </div>

        <!-- Property Detail Main Content -->
        <div style="padding: 24px 28px 28px 28px;">
          
          <!-- Category Badge & ID Line -->
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px; flex-wrap: wrap;">
            <span style="background: #fff7ed; color: #ea580c; border: 1px solid #ffedd5; padding: 4px 12px; border-radius: 6px; font-size: 0.75rem; font-weight: 800; text-transform: uppercase; letter-spacing: 0.05em;">
              ${e.type||e.categoryLabel||`PROPERTY`}
            </span>
            <span style="font-size: 0.8rem; font-weight: 800; color: #64748b; letter-spacing: 0.05em;">
              # ID: ${e.id}
            </span>
          </div>

          <!-- Title & Asking Price Header Box (Matching Website Detail Page) -->
          <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 24px; flex-wrap: wrap; margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid #f1f5f9;">
            
            <!-- Left: Title & Location -->
            <div style="flex: 1; min-width: 280px;">
              <h1 class="font-serif" style="font-size: 2rem; color: #0f172a; line-height: 1.25; margin: 0 0 10px 0; font-weight: 800;">
                ${e.title}
              </h1>
              <div style="display: flex; align-items: center; gap: 8px; font-size: 0.95rem; color: #64748b;">
                <a href="${e.latitude&&e.longitude?`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(e.latitude)},${encodeURIComponent(e.longitude)}`:`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent([e.location,e.district,`Tamil Nadu`].filter(Boolean).join(`, `))}`}" target="_blank" rel="noopener noreferrer" style="color: #ea580c; text-decoration: none; display: inline-flex; align-items: center; gap: 6px; font-weight: 600;" title="Open Location on Google Maps">
                  <i class="ri-map-pin-2-fill"></i>
                  <span>${i(e.location,e.district)}</span>
                  <i class="ri-external-link-line" style="font-size: 0.85rem;"></i>
                </a>
              </div>
            </div>

            <!-- Right: Website Asking Price Card -->
            <div style="background: #fff7ed; border: 1px solid #ffedd5; border-radius: 16px; padding: 16px 24px; text-align: center; min-width: 240px; box-shadow: 0 4px 12px rgba(234,88,12,0.06);">
              <div style="font-size: 0.725rem; font-weight: 800; color: #9a3412; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 2px;">
                ASKING PRICE
              </div>
              <div class="font-serif" style="font-size: 2.25rem; color: #ea580c; font-weight: 800; line-height: 1.1;">
                ${e.priceFormatted||`₹ ${e.price}`}
              </div>
              <div style="font-size: 0.725rem; color: #166534; font-weight: 700; margin-top: 4px; display: inline-flex; align-items: center; gap: 4px;">
                <i class="ri-shield-check-fill"></i> 100% Verified Ownership & Clear Patta Title
              </div>
            </div>
          </div>

          <!-- Editorial Property Facts Cards Grid -->
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 14px; margin-bottom: 28px;">
            ${n?`
              <div style="background: #fff7ed; border: 1px solid #ffedd5; padding: 14px; border-radius: 12px; text-align: center;">
                <div style="font-size: 1.15rem; font-weight: 800; color: #ea580c;">${n}</div>
                <div style="font-size: 0.7rem; font-weight: 800; color: #9a3412; text-transform: uppercase; letter-spacing: 0.05em; margin-top: 2px;">TOTAL AREA</div>
              </div>
            `:``}
            ${e.facing||e.address?`
              <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 14px; border-radius: 12px; text-align: center;">
                <div style="font-size: 1.15rem; font-weight: 800; color: #0f172a;">${e.facing||e.address}</div>
                <div style="font-size: 0.7rem; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.05em; margin-top: 2px;">FACING / LOCATION</div>
              </div>
            `:``}
            ${e.approval?`
              <div style="background: #f0fdf4; border: 1px solid #dcfce7; padding: 14px; border-radius: 12px; text-align: center;">
                <div style="font-size: 1.15rem; font-weight: 800; color: #166534;">${e.approval}</div>
                <div style="font-size: 0.7rem; font-weight: 800; color: #15803d; text-transform: uppercase; letter-spacing: 0.05em; margin-top: 2px;">APPROVAL</div>
              </div>
            `:``}
            ${e.bedrooms?`
              <div style="background: #eff6ff; border: 1px solid #dbeafe; padding: 14px; border-radius: 12px; text-align: center;">
                <div style="font-size: 1.15rem; font-weight: 800; color: #1e40af;">${e.bedrooms} BHK</div>
                <div style="font-size: 0.7rem; font-weight: 800; color: #1d4ed8; text-transform: uppercase; letter-spacing: 0.05em; margin-top: 2px;">BEDROOMS</div>
              </div>
            `:``}
            ${e.bathrooms?`
              <div style="background: #faf5ff; border: 1px solid #f3e8ff; padding: 14px; border-radius: 12px; text-align: center;">
                <div style="font-size: 1.15rem; font-weight: 800; color: #6b21a8;">${e.bathrooms}</div>
                <div style="font-size: 0.7rem; font-weight: 800; color: #7e22ce; text-transform: uppercase; letter-spacing: 0.05em; margin-top: 2px;">BATHROOMS</div>
              </div>
            `:``}
          </div>

          <!-- Description / Overview -->
          ${e.description?`
            <div style="margin-bottom: 28px;">
              <h3 class="font-serif" style="font-size: 1.35rem; color: #0f172a; margin-bottom: 12px; border-bottom: 2px solid #ffedd5; padding-bottom: 6px; font-weight: 800;">Property Overview</h3>
              <p style="color: #334155; font-size: 0.98rem; line-height: 1.7; white-space: pre-line; margin: 0;">
                ${e.description}
              </p>
            </div>
          `:``}

          <!-- Key Technical Specifications Grid -->
          ${a.length>0?`
            <div style="margin-bottom: 28px;">
              <h3 class="font-serif" style="font-size: 1.35rem; color: #0f172a; margin-bottom: 14px; border-bottom: 2px solid #ffedd5; padding-bottom: 6px; font-weight: 800;">Key Technical Specifications</h3>
              <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 14px; background: #f8fafc; padding: 20px; border-radius: 14px; border: 1px solid #e2e8f0;">
                ${a.map(e=>`
                  <div style="display: flex; flex-direction: column;">
                    <span style="font-size: 0.725rem; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.05em;">${e.label}</span>
                    <span style="font-size: 0.95rem; font-weight: 700; color: #0f172a; margin-top: 2px;">${e.value}</span>
                  </div>
                `).join(``)}
              </div>
            </div>
          `:``}

          <!-- Verified Seller Desk Card (Matching Website Detail Page) -->
          <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 16px; padding: 20px 24px; display: flex; justify-content: space-between; align-items: center; gap: 20px; flex-wrap: wrap;">
            <div>
              <div style="font-size: 0.725rem; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 4px;">
                VERIFIED PROPERTY SELLER / SPECIALIST
              </div>
              <h4 style="font-size: 1.1rem; font-weight: 800; color: #0f172a; margin: 0 0 2px 0;">
                ${p}
              </h4>
              <div style="font-size: 0.8rem; color: ${f?`#166534`:`#ea580c`}; font-weight: 700;">
                ${f?`👑 Direct Owner Listing • 0% Brokerage`:`🛡️ Executive Real Estate Advisory Desk`}
              </div>
            </div>

            <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
              <a href="tel:${m}" style="background: #0f172a; color: #ffffff; padding: 10px 18px; border-radius: 10px; text-decoration: none; font-size: 0.88rem; font-weight: 700; display: inline-flex; align-items: center; gap: 6px;">
                <i class="ri-phone-fill"></i> Call Seller (${m})
              </a>
              <a href="https://wa.me/${g}?text=Hi%20${encodeURIComponent(p)},%20I%20am%20interested%20in%20property%20${encodeURIComponent(e.title)}%20(ID:%20${e.id})" target="_blank" style="background: #25D366; color: #ffffff; padding: 10px 18px; border-radius: 10px; text-decoration: none; font-size: 0.88rem; font-weight: 700; display: inline-flex; align-items: center; gap: 6px;">
                <i class="ri-whatsapp-line" style="font-size: 1.1rem;"></i> WhatsApp Chat
              </a>
            </div>
          </div>

        </div>
      </div>
    </div>
  `}function W(n,r){let i=document.getElementById(`property-details-modal-overlay`);document.getElementById(`close-prop-modal-btn`)?.addEventListener(`click`,()=>{i?.classList.remove(`active`),setTimeout(r,300)}),i?.addEventListener(`click`,e=>{e.target===i&&(i.classList.remove(`active`),setTimeout(r,300))});function o(e){if(!e)return``;let t=e.trim(),n=t.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/|youtube\.com\/shorts\/)([^"&?\/\s]{11})/i);return n&&n[1]?{type:`iframe`,url:`https://www.youtube.com/embed/${n[1]}?autoplay=1&rel=0`}:/facebook\.com|fb\.watch|fb\.com/i.test(t)?{type:`iframe`,url:`https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(t)}&show_text=0&width=560&autoplay=1`}:/\.(mp4|webm|ogg|mov)(\?.*)?$/i.test(t)||t.startsWith(`data:video/`)?{type:`video`,url:t}:{type:`iframe`,url:t}}document.querySelectorAll(`.modal-thumb`).forEach(e=>{e.addEventListener(`click`,()=>{let t=document.getElementById(`modal-gallery-media-viewport`);if(!t)return;let r=e.dataset.type||`image`,i=e.dataset.src;if(r===`image`)t.innerHTML=`
          <img src="${i}" alt="${n.title}" class="gallery-main-img" id="modal-main-gallery-img" style="width:100%; height:100%; object-fit:cover;" />
          <div style="position: absolute; bottom: 16px; left: 16px; display: flex; gap: 8px;">
            <span class="badge badge-dark">
              <i class="ri-image-line"></i> ${images.length} High-Res Photos
            </span>
            <span class="badge badge-orange">${n.tag||n.categoryLabel}</span>
          </div>
          <div style="position: absolute; top: 16px; right: 16px; display: flex; gap: 8px;">
            <button class="card-favorite-btn ${saved?`saved`:``}" id="modal-save-fav-btn" title="Bookmark Property">
              <i class="${saved?`ri-heart-fill`:`ri-heart-line`}"></i>
            </button>
            <button class="card-favorite-btn" id="modal-share-btn" title="Share Property">
              <i class="ri-share-line"></i>
            </button>
          </div>
        `;else{let e=o(i);t.innerHTML=`
          <div style="width:100%; height:100%; background:#000; display:flex; align-items:center; justify-content:center;">
            ${e.type===`video`?`
              <video src="${e.url}" controls autoplay style="width:100%; height:100%; object-fit:contain;"></video>
            `:`
              <iframe src="${e.url}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen style="width:100%; height:100%; border:0;"></iframe>
            `}
          </div>
          <div style="position: absolute; top: 16px; left: 16px;">
            <span class="badge badge-orange"><i class="ri-play-circle-fill"></i> Property Video Tour</span>
          </div>
        `}})}),document.getElementById(`modal-save-fav-btn`)?.addEventListener(`click`,()=>{let e=u(n.id);t(e?`Property saved to collection!`:`Property removed from collection`,`ri-heart-fill`)}),document.getElementById(`modal-share-btn`)?.addEventListener(`click`,()=>{navigator.clipboard&&(navigator.clipboard.writeText(window.location.href),t(`Property link copied to clipboard!`,`ri-file-copy-line`))}),document.getElementById(`modal-schedule-btn`)?.addEventListener(`click`,()=>{window.dispatchEvent(new CustomEvent(`openScheduleModal`,{detail:{propertyId:n.id,propertyTitle:n.title}}))}),document.getElementById(`modal-enquiry-form`)?.addEventListener(`submit`,async o=>{o.preventDefault();let s=document.getElementById(`modal-enquiry-name`),c=document.getElementById(`modal-enquiry-phone`),l=document.getElementById(`modal-enquiry-submit-btn`),u=s?.value.trim(),d=c?.value.trim();if(!u||!d)return;l&&(l.disabled=!0,l.innerHTML=`<i class="ri-loader-4-line ri-spin"></i> Submitting...`);let f=d.replace(/\D/g,``),p=f.length===10?`+91${f}`:d.startsWith(`+`)?d:`+${f}`,m=`L-${Date.now()}`,h=`Customer inquiry for property "${n.title}" (ID: ${n.id}) - Price: ${n.priceFormatted||`₹`+n.price}, Location: ${n.location||`Thanjavur`}`,g={id:m,name:u,phone:p,mobile:p,email:``,type:n.categoryLabel||n.type||`Residential`,location:n.location||n.district||`Thanjavur`,budget:n.priceFormatted||String(n.price),stage:`New Lead`,source:`Property Inquiry`,date:new Date().toISOString().split(`T`)[0],assignedTo:`Unassigned`,priority:`High`,propertyId:n.id,timeline:[{type:`whatsapp_incoming`,date:new Date().toISOString(),message:`📩 ${h}`,note:h},{type:`whatsapp`,date:new Date().toISOString(),message:`🤖 Auto-sent WhatsApp Welcome Intro to ${u} (${p})`,note:`Campaign: initial_contact_intro`}]};try{a(n.id)}catch{}try{let e=JSON.parse(localStorage.getItem(`thanjai_leads`))||[];e.unshift(g),localStorage.setItem(`thanjai_leads`,JSON.stringify(e)),window.dispatchEvent(new Event(`storage`))}catch{}try{await e(`/leads`,{method:`POST`,body:JSON.stringify(g)})}catch{}try{await e(`/whatsapp_incoming`,{method:`POST`,body:JSON.stringify({from_phone:p,from_name:u,message:`[Property Inquiry] ${n.title} (ID: ${n.id}) | Location: ${n.location||n.district||`Thanjavur`} | Price: ${n.priceFormatted||`₹`+n.price}`,message_type:`text`})}),await e(`/whatsapp_logs`,{method:`POST`,body:JSON.stringify({id:`WA-${Date.now()}`,leadId:m,phone:p,sender:`Super Admin`,recipientName:u,message:`Hello ${u}, Thank you for your interest in Thanjai Property! We have received your inquiry for "${n.title}". Our property advisors will assist you shortly. Official Desk: +91 84899 96852.`,type:`outbound`})})}catch{}try{let e=n.images&&n.images.length>0&&n.images[0].startsWith(`http`)?n.images[0]:`https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80`;await H({campaignName:`initial_contact_intro`,destination:p,userName:u,leadId:m,templateParams:[u,n.location||n.district||`Thanjavur`,n.title,`+91 84899 96852`],media:{url:e,filename:`property.jpg`}})}catch{}t(`Enquiry received! We've sent a WhatsApp confirmation to ${p}.`,`ri-checkbox-circle-fill`),i?.classList.remove(`active`),setTimeout(r,300)})}function G(n){if(!n)return;let r=document.getElementById(`global-inquiry-form-modal-container`);r||(r=document.createElement(`div`),r.id=`global-inquiry-form-modal-container`,document.body.appendChild(r)),r.innerHTML=`
    <div class="modal-overlay active" id="direct-prop-inquiry-modal-overlay" style="position: fixed; inset: 0; background: rgba(0,0,0,0.65); backdrop-filter: blur(5px); display: flex; align-items: center; justify-content: center; z-index: 99999; padding: 20px;">
      <div style="width: 100%; max-width: 500px; padding: 36px; border-radius: 20px; background: #ffffff; box-shadow: 0 20px 40px rgba(0,0,0,0.25); position: relative; animation: pageFadeIn 0.3s ease;">
        <button id="close-direct-inquiry-modal-btn" style="position: absolute; top: 18px; right: 18px; background: #f1f5f9; border: none; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.3rem; color: #475569; cursor: pointer;">
          <i class="ri-close-line"></i>
        </button>

        <div style="margin-bottom: 20px;">
          <span style="font-size: 0.75rem; font-weight: 800; color: #ea580c; text-transform: uppercase; letter-spacing: 0.08em; background: #fff7ed; padding: 4px 10px; border-radius: 8px; border: 1px solid #ffedd5;">PROPERTY INQUIRY FORM</span>
          <h2 class="font-serif" style="font-size: 1.5rem; color: #1e293b; margin-top: 10px; margin-bottom: 4px;">
            Inquire About Property
          </h2>
          <p style="font-size: 0.9rem; color: #ea580c; font-weight: 700; margin: 0; display: flex; align-items: center; gap: 6px;">
            <i class="ri-building-line"></i> ${n.title} (ID: ${n.id})
          </p>
        </div>

        <form id="direct-property-inquiry-form">
          <div style="display: flex; flex-direction: column; gap: 14px;">
            <div>
              <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #334155; margin-bottom: 6px;"><i class="ri-user-line" style="color: #ea580c;"></i> Full Name *</label>
              <input type="text" id="dpi-name" required placeholder="Enter your name" style="width: 100%; padding: 12px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 0.95rem; outline: none;" />
            </div>

            <div>
              <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #334155; margin-bottom: 6px;"><i class="ri-phone-line" style="color: #ea580c;"></i> Mobile Number *</label>
              <input type="tel" id="dpi-phone" required placeholder="10-digit mobile number" maxlength="10" pattern="[0-9]{10}" oninput="this.value = this.value.replace(/[^0-9]/g, '')" style="width: 100%; padding: 12px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 0.95rem; outline: none;" />
            </div>

            <div>
              <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #334155; margin-bottom: 6px;"><i class="ri-mail-line" style="color: #ea580c;"></i> Email Address (Optional)</label>
              <input type="email" id="dpi-email" placeholder="name@example.com" style="width: 100%; padding: 12px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 0.95rem; outline: none;" />
            </div>

            <div>
              <label style="display: block; font-size: 0.85rem; font-weight: 600; color: #334155; margin-bottom: 6px;"><i class="ri-chat-3-line" style="color: #ea580c;"></i> Requirement / Question (Optional)</label>
              <textarea id="dpi-message" rows="3" placeholder="Tell us your preferences..." style="width: 100%; padding: 12px; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 0.95rem; outline: none; resize: vertical;"></textarea>
            </div>

            <button type="submit" id="dpi-submit-btn" style="padding: 14px; font-size: 1rem; font-weight: 800; width: 100%; margin-top: 6px; background: #ea580c; color: #ffffff; border: none; border-radius: 10px; cursor: pointer; box-shadow: 0 4px 12px rgba(234,88,12,0.3);">
              <i class="ri-send-plane-fill"></i> SUBMIT PROPERTY INQUIRY
            </button>
          </div>
        </form>
      </div>
    </div>
  `;let i=document.getElementById(`close-direct-inquiry-modal-btn`),o=document.getElementById(`direct-prop-inquiry-modal-overlay`),s=document.getElementById(`direct-property-inquiry-form`),c=()=>{r&&(r.innerHTML=``)};i?.addEventListener(`click`,c),o?.addEventListener(`click`,e=>{e.target===o&&c()}),s?.addEventListener(`submit`,async r=>{r.preventDefault();let i=document.getElementById(`dpi-name`)?.value.trim(),o=document.getElementById(`dpi-phone`)?.value.trim(),s=document.getElementById(`dpi-email`)?.value.trim()||``,l=document.getElementById(`dpi-message`)?.value.trim()||``,u=document.getElementById(`dpi-submit-btn`);if(!i||!o)return;u&&(u.disabled=!0,u.innerHTML=`<i class="ri-loader-4-line ri-spin"></i> Submitting...`);let d=o.replace(/\D/g,``),f=d.length===10?`+91${d}`:`+${d}`,p=`L-${Date.now()}`,m=`Property Inquiry for "${n.title}" (ID: ${n.id}) - Price: ${n.priceFormatted||`₹`+n.price}. Note: ${l||`No additional note`}`,h={id:p,name:i,phone:f,mobile:f,email:s,type:n.categoryLabel||n.type||`Residential`,location:n.location||n.district||`Thanjavur`,budget:n.priceFormatted||String(n.price),stage:`New Lead`,source:`Property Inquiry`,date:new Date().toISOString().split(`T`)[0],assignedTo:`Unassigned`,priority:`High`,propertyId:n.id,propertyMatch:n.id,timeline:[{type:`whatsapp_incoming`,date:new Date().toISOString(),message:`📩 ${m}`,note:m},{type:`whatsapp`,date:new Date().toISOString(),message:`🤖 Auto-sent WhatsApp Welcome Intro to ${i} (${f})`,note:`Campaign: initial_contact_intro`}]};try{a(n.id)}catch{}try{let e=JSON.parse(localStorage.getItem(`thanjai_leads`))||[];e.unshift(h),localStorage.setItem(`thanjai_leads`,JSON.stringify(e)),window.dispatchEvent(new Event(`storage`))}catch{}try{await e(`/leads`,{method:`POST`,body:JSON.stringify(h)})}catch{}try{let e=n.images&&n.images.length>0&&n.images[0].startsWith(`http`)?n.images[0]:`https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80`;await H({campaignName:`initial_contact_intro`,destination:f,userName:i,leadId:p,templateParams:[i,n.location||n.district||`Thanjavur`,n.title,`+91 84899 96852`],media:{url:e,filename:`property.jpg`}})}catch{}t(`Inquiry received for Property ${n.id}! WhatsApp confirmation sent.`,`ri-checkbox-circle-fill`),c()})}function K(e){if(!e)return;let t=o(e);if(!t){let n=getProperties();t=n.find(t=>t.title&&t.title.toLowerCase().includes(String(e).toLowerCase()))||n[0]}t||={id:e,title:`Inquired Property Portfolio (${e})`,type:`Residential Plot`,category:`plots`,categoryLabel:`Residential Property`,priceFormatted:`Contact Advisory Desk`,location:`Thanjavur`,district:`Thanjavur`,description:`Customer submitted an inquiry for Property ID ${e}. Connect directly with client for details.`,features:[`Verified Listing Inquiry`,`Prime Location`,`Advisory Desk Assistance`],images:[`https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80`]};let n=document.getElementById(`global-property-modal-container`);n||(n=document.createElement(`div`),n.id=`global-property-modal-container`,document.body.appendChild(n)),n.innerHTML=U(t),W(t,()=>{n.innerHTML=``})}document.addEventListener(`click`,e=>{let t=e.target.closest(`.prop-id-badge`);if(t){e.stopPropagation(),e.preventDefault();let n=t.getAttribute(`data-propid`);n&&K(n)}},!0);var q=`thanjai_popups_store`,J=null;async function Y(){try{let t=await e(`/popups`);if(t&&Array.isArray(t))return J=t.map(e=>({...e,highlights:typeof e.highlights==`string`?JSON.parse(e.highlights||`[]`):e.highlights||[]})),localStorage.setItem(q,JSON.stringify(J)),window.dispatchEvent(new CustomEvent(`popupsUpdated`)),J}catch(e){console.warn(`API error fetching popups, fallback to local cache`,e)}let t=localStorage.getItem(q);if(t)try{return J=JSON.parse(t),J}catch{}return J=[],localStorage.setItem(q,JSON.stringify(J)),J}function X(){if(Array.isArray(J))return J;let e=localStorage.getItem(q);if(e)try{return J=JSON.parse(e),J}catch{}return J=[],J}async function Z(t){let r=X(),i={id:`POP-`+Date.now(),title:t.title||`New Announcement`,subtitle:t.subtitle||``,type:t.type||`festival`,badge:t.badge||`PROMOTIONAL`,image:t.image||``,highlights:Array.isArray(t.highlights)?t.highlights:[],ctaText:t.ctaText||`Claim Offer on WhatsApp`,ctaType:t.ctaType||`whatsapp`,ctaValue:t.ctaValue||`+91 84899 96852`,startDate:t.startDate||``,endDate:t.endDate||``,delaySeconds:parseInt(t.delaySeconds)||3,frequency:t.frequency||`once_session`,status:t.status||`Active`,createdAt:new Date().toISOString()};r.unshift(i),J=r,localStorage.setItem(q,JSON.stringify(r));try{await e(`/popups`,{method:`POST`,body:JSON.stringify(i)})}catch(e){console.error(`Failed to sync new popup to API:`,e)}return n({action:`Created Promotion Popup (${i.title})`,module:`Marketing Popups`,details:`Created new ${i.type} banner popup titled "${i.title}".`}),window.dispatchEvent(new CustomEvent(`popupsUpdated`)),i}async function Q(t,r){let i=X(),a=i.findIndex(e=>e.id===t);if(a===-1)return null;i[a]={...i[a],...r},J=i,localStorage.setItem(q,JSON.stringify(i));try{await e(`/popups`,{method:`POST`,body:JSON.stringify(i[a])})}catch(e){console.error(`Failed to update popup in API:`,e)}return n({action:`Updated Promotion Popup (${i[a].title})`,module:`Marketing Popups`,details:`Updated popup "${i[a].title}" (Status: ${i[a].status}).`}),window.dispatchEvent(new CustomEvent(`popupsUpdated`)),i[a]}async function $(t){let r=X(),i=r.find(e=>e.id===t);r=r.filter(e=>e.id!==t),J=r,localStorage.setItem(q,JSON.stringify(r));try{await e(`/popups/${t}`,{method:`DELETE`})}catch(e){console.error(`Failed to delete popup from API:`,e)}return i&&n({action:`Deleted Promotion Popup (${i.title})`,module:`Marketing Popups`,details:`Removed popup "${i.title}" (ID: ${t}).`}),window.dispatchEvent(new CustomEvent(`popupsUpdated`)),!0}function ee(){let e=X(),t=new Date;return e.filter(e=>{if(e.status!==`Active`)return!1;if(e.startDate){let n=new Date(e.startDate);if(t<n)return!1}if(e.endDate){let n=new Date(e.endDate);if(n.setHours(23,59,59,999),t>n)return!1}return!0})}export{C,c as D,T as E,S,D as T,j as _,Y as a,w as b,G as c,B as d,H as f,M as g,F as h,X as i,K as l,R as m,$ as n,Q as o,I as p,ee as r,W as s,Z as t,U as u,z as v,x as w,E as x,L as y};