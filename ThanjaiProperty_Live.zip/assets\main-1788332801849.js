import{O as e,P as t,i as n,k as r,o as i,w as a}from"./toast-1788332801849.js";import{a as o,c as s,i as c,l,o as u,t as d,u as f}from"./propertiesStore-1788332801849.js";import{_ as p,a as m,b as h,c as g,g as _,h as v,r as y,s as ee,u as te}from"./popupsStore-1788332801849.js";function b(t=`home`,n){h().length;let r=e(`brand_logo`),a=i();return`
    <header class="header-wrapper" id="main-header">
      <div class="container">
        <nav class="nav-container">
          <!-- Brand Logo -->
          <a href="/" class="brand-logo-link nav-route-link" data-route="home" id="nav-brand-logo">
            <img src="${r}" alt="Thanjai Property Real Estate Since 2009" class="brand-logo-img" />
          </a>

          <!-- Desktop Navigation Links (5 Core Pages) -->
          <ul class="nav-links">
            <li>
              <a href="/" class="nav-link nav-route-link ${t===`home`?`active`:``}" data-route="home">Home</a>
            </li>
            <li>
              <a href="/our-story" class="nav-link nav-route-link ${t===`our-story`?`active`:``}" data-route="our-story">Our Story</a>
            </li>
            <li>
              <a href="/find-your-property" class="nav-link nav-route-link ${t===`discover`?`active`:``}" data-route="discover">Find Your Property</a>
            </li>
            <li>
              <a href="/blog" class="nav-link nav-route-link ${t===`blog`?`active`:``}" data-route="blog">Blog</a>
            </li>
            <li>
              <a href="/contact-us" class="nav-link nav-route-link ${t===`contact`?`active`:``}" data-route="contact">Contact Us</a>
            </li>
          </ul>

          <!-- Action Buttons (Matching Screenshot 1) -->
          <div class="nav-actions" style="display: flex; align-items: center; gap: 10px;">
            ${(()=>{if(a){let e=a.roleCode&&(a.roleCode.includes(`admin`)||a.roleCode.includes(`manager`)||a.roleCode.includes(`executive`)||a.roleCode.includes(`staff`));return`
                  <a href="${e?`/admin-dashboard`:`/user-dashboard`}" class="nav-login-btn" id="nav-account-btn" title="View Workspace">
                    <i class="${e?`ri-dashboard-3-line`:`ri-user-3-line`}"></i>
                    <span>${e?`Admin Dashboard`:`My Account`}</span>
                  </a>
                `}return`
                  <a href="/user-login" class="nav-login-btn" id="nav-login-btn" title="Sign In to your Account">
                    <i class="ri-user-3-line"></i>
                    <span>Login</span>
                  </a>
                `})()}

            <a href="${a?`/user-dashboard`:`/user-register`}" class="nav-post-property-btn" id="nav-post-property-btn" title="Add New Property for Sale or Rent">
              <i class="ri-home-4-line"></i>
              <span>Add New Property</span>
            </a>



            <button class="mobile-menu-toggle" id="mobile-menu-btn" aria-label="Toggle Menu">
              <i class="ri-menu-4-line"></i>
            </button>
          </div>
        </nav>
      </div>

      <!-- Mobile Navigation Drawer -->
      <div class="mobile-menu-overlay" id="mobile-menu-overlay" style="
        display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.6); backdrop-filter: blur(8px); z-index: 9998;
      "></div>
      
      <div class="mobile-menu-drawer" id="mobile-menu-drawer" style="
        position: fixed; top: 0; right: -300px; width: 280px; height: 100vh; background: #2A1808; color: #ffffff;
        z-index: 9999; padding: 30px 24px; display: flex; flex-direction: column; transition: right 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        box-shadow: -10px 0 30px rgba(0,0,0,0.3);
      ">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 36px;">
          <img src="${r}" style="height: 40px; background: #fff; padding: 4px 8px; border-radius: 6px;" />
          <button id="close-mobile-menu-btn" style="background: none; border: none; color: #fff; font-size: 1.5rem; cursor: pointer;">
            <i class="ri-close-line"></i>
          </button>
        </div>

        <ul style="list-style: none; display: flex; flex-direction: column; gap: 18px; font-size: 1.1rem; font-weight: 600;">
          <li><a href="/" class="mobile-nav-link nav-route-link ${t===`home`?`active`:``}" data-route="home" style="color: #fff; text-decoration: none;">Home</a></li>
          <li><a href="/our-story" class="mobile-nav-link nav-route-link ${t===`our-story`?`active`:``}" data-route="our-story" style="color: #fff; text-decoration: none;">Our Story</a></li>
          <li><a href="/find-your-property" class="mobile-nav-link nav-route-link ${t===`discover`?`active`:``}" data-route="discover" style="color: #fff; text-decoration: none;">Find Your Property</a></li>
          <li><a href="/blog" class="mobile-nav-link nav-route-link ${t===`blog`?`active`:``}" data-route="blog" style="color: #fff; text-decoration: none;">Blog</a></li>
          <li><a href="/contact-us" class="mobile-nav-link nav-route-link ${t===`contact`?`active`:``}" data-route="contact" style="color: #fff; text-decoration: none;">Contact Us</a></li>
        </ul>

        <!-- Mobile Drawer Action Buttons -->
        <div style="display: flex; flex-direction: column; gap: 12px; margin-top: 28px; margin-bottom: 20px;">
          ${(()=>{if(a){let e=a.roleCode&&(a.roleCode.includes(`admin`)||a.roleCode.includes(`manager`)||a.roleCode.includes(`executive`)||a.roleCode.includes(`staff`));return`
                <a href="${e?`/admin-dashboard`:`/user-dashboard`}" class="mobile-drawer-btn" style="display: flex; align-items: center; justify-content: center; gap: 8px; padding: 12px 20px; border-radius: 30px; border: 1.5px solid rgba(255,255,255,0.3); background: rgba(255,255,255,0.1); color: #fff; text-decoration: none; font-weight: 700; font-size: 0.95rem;">
                  <i class="${e?`ri-dashboard-3-line`:`ri-user-3-line`}"></i>
                  <span>${e?`Admin Dashboard`:`My Account`}</span>
                </a>
              `}return`
                <a href="/user-login" class="mobile-drawer-btn" style="display: flex; align-items: center; justify-content: center; gap: 8px; padding: 12px 20px; border-radius: 30px; border: 1.5px solid rgba(255,255,255,0.3); background: rgba(255,255,255,0.1); color: #fff; text-decoration: none; font-weight: 700; font-size: 0.95rem;">
                  <i class="ri-user-3-line"></i>
                  <span>Login</span>
                </a>
              `})()}

          <a href="${a?`/user-dashboard`:`/user-register`}" class="mobile-drawer-btn" style="display: flex; align-items: center; justify-content: center; gap: 8px; padding: 12px 20px; border-radius: 30px; background: #E52E3D; color: #fff; text-decoration: none; font-weight: 700; font-size: 0.95rem; box-shadow: 0 4px 14px rgba(229,46,61,0.4);">
            <i class="ri-home-4-line"></i>
            <span>Add New Property</span>
          </a>
        </div>

        <div style="margin-top: auto; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1); font-size: 0.85rem; color: rgba(255,255,255,0.7);">
          <div style="margin-bottom: 6px;"><i class="ri-phone-line" style="color: var(--color-orange, #eb5e28);"></i> +91 94431 25009</div>
          <div>Thanjavur, Tamil Nadu</div>
        </div>
      </div>
    </header>
  `}function ne(e,t){let n=document.getElementById(`main-header`),r=()=>{window.scrollY>20?n?.classList.add(`scrolled`):n?.classList.remove(`scrolled`)};window.addEventListener(`scroll`,r,{passive:!0}),r(),document.getElementById(`saved-properties-btn`)?.addEventListener(`click`,t),document.querySelectorAll(`.nav-route-link`).forEach(t=>{t.addEventListener(`click`,n=>{n.preventDefault();let r=t.dataset.route;r&&e&&(l(),e(r))})});let i=document.getElementById(`mobile-menu-btn`),a=document.getElementById(`close-mobile-menu-btn`),o=document.getElementById(`mobile-menu-overlay`),s=document.getElementById(`mobile-menu-drawer`);function c(){o&&(o.style.display=`block`),s&&(s.style.right=`0px`)}function l(){o&&(o.style.display=`none`),s&&(s.style.right=`-300px`)}i?.addEventListener(`click`,c),a?.addEventListener(`click`,l),o?.addEventListener(`click`,l)}function re(){return`
    <section class="hero-section" id="hero">
      <!-- Hero Background Image & Gradient -->
      <div class="hero-bg-container">
        <img 
          src="${e(`hero_bg`)}" 
          alt="Thanjai Property Luxury Villa" 
          class="hero-bg-image" 
          id="hero-parallax-img"
        />
        <div class="hero-gradient-overlay"></div>
      </div>

      <!-- Hero Text Content -->
      <div class="container hero-content">
        <div class="hero-eyebrow-pill">
          <i class="ri-shield-star-line" style="color: var(--color-orange)"></i>
          <span>THANJAI PROPERTY • SINCE 2009</span>
          <i class="ri-shield-star-line" style="color: var(--color-orange)"></i>
        </div>
        
        <h1 class="heading-display-light hero-title">
          Find a Property That<br>Fits Your Future.
        </h1>


      </div>

      <!-- 2. Floating Luxury Property Search Panel -->
      <div class="container search-panel-wrapper">
        <div class="floating-search-card">
          
          <!-- Top Bar: Tiny Eyebrow + Segmented Control Tabs -->
          <div class="search-panel-topbar">
            <div class="search-eyebrow-text">
              <i class="ri-sparkles-fill" style="color: var(--color-orange)"></i>
              <span>FIND YOUR PERFECT PROPERTY</span>
            </div>

            <!-- Segmented Control Tabs (BUY / RENT / SELL) -->
            <div class="segmented-tabs" id="hero-search-tabs">
              <button class="segmented-tab-btn active" data-purpose="buy">
                <i class="ri-home-heart-line"></i> BUY
              </button>
              <button class="segmented-tab-btn" data-purpose="rent">
                <i class="ri-key-2-line"></i> RENT
              </button>
              <button class="segmented-tab-btn" data-purpose="sell">
                <i class="ri-price-tag-3-line"></i> SELL
              </button>
            </div>
          </div>

          <!-- Single Unified Horizontal Search Bar -->
          <form id="hero-search-form" class="search-bar-unified" onsubmit="return false;">
            <input type="hidden" id="search-location" value="all" />
            <input type="hidden" id="search-type" value="all" />
            <input type="hidden" id="search-budget" value="all" />

            <!-- Field 1: LOCATION -->
            <div class="search-field-pill custom-dropdown" id="dropdown-location">
              <div class="search-field-inner custom-dropdown-trigger">
                <div class="field-icon-wrap">
                  <i class="ri-map-pin-2-fill"></i>
                </div>
                <div class="field-info">
                  <span class="field-label">LOCATION</span>
                  <span class="field-val selected-text">All Tamil Nadu Locations</span>
                </div>
                <i class="ri-arrow-down-s-line chevron-icon"></i>
              </div>

              <div class="custom-dropdown-menu">
                <div class="dropdown-item active" data-value="all" data-label="All Tamil Nadu Locations">
                  <span>All Tamil Nadu Locations</span>
                  <i class="ri-check-line check-icon"></i>
                </div>
                <div class="dropdown-item" data-value="Thanjavur" data-label="Thanjavur">
                  <span>Thanjavur</span>
                  <i class="ri-check-line check-icon"></i>
                </div>
                <div class="dropdown-item" data-value="Trichy" data-label="Trichy">
                  <span>Trichy</span>
                  <i class="ri-check-line check-icon"></i>
                </div>
                <div class="dropdown-item" data-value="Madurai" data-label="Madurai">
                  <span>Madurai</span>
                  <i class="ri-check-line check-icon"></i>
                </div>
                <div class="dropdown-item" data-value="Chennai" data-label="Chennai">
                  <span>Chennai</span>
                  <i class="ri-check-line check-icon"></i>
                </div>
                <div class="dropdown-item" data-value="Coimbatore" data-label="Coimbatore">
                  <span>Coimbatore</span>
                  <i class="ri-check-line check-icon"></i>
                </div>
                <div class="dropdown-item" data-value="Kumbakonam" data-label="Kumbakonam">
                  <span>Kumbakonam</span>
                  <i class="ri-check-line check-icon"></i>
                </div>
              </div>
            </div>

            <div class="search-field-divider"></div>

            <!-- Field 2: PROPERTY TYPE -->
            <div class="search-field-pill custom-dropdown" id="dropdown-type">
              <div class="search-field-inner custom-dropdown-trigger">
                <div class="field-icon-wrap">
                  <i class="ri-building-4-fill"></i>
                </div>
                <div class="field-info">
                  <span class="field-label">PROPERTY TYPE</span>
                  <span class="field-val selected-text">All Property Types</span>
                </div>
                <i class="ri-arrow-down-s-line chevron-icon"></i>
              </div>

              <div class="custom-dropdown-menu">
                <div class="dropdown-item active" data-value="all" data-label="All Property Types">
                  <span>All Property Types</span>
                  <i class="ri-check-line check-icon"></i>
                </div>
                <div class="dropdown-item" data-value="villas" data-label="Luxury Villas">
                  <span>Luxury Villas</span>
                  <i class="ri-check-line check-icon"></i>
                </div>
                <div class="dropdown-item" data-value="houses" data-label="Independent Houses">
                  <span>Independent Houses</span>
                  <i class="ri-check-line check-icon"></i>
                </div>
                <div class="dropdown-item" data-value="apartments" data-label="Modern Apartments">
                  <span>Modern Apartments</span>
                  <i class="ri-check-line check-icon"></i>
                </div>
                <div class="dropdown-item" data-value="plots" data-label="Residential Plots">
                  <span>Residential Plots</span>
                  <i class="ri-check-line check-icon"></i>
                </div>
                <div class="dropdown-item" data-value="agricultural" data-label="Agricultural Farmland">
                  <span>Agricultural Farmland</span>
                  <i class="ri-check-line check-icon"></i>
                </div>
                <div class="dropdown-item" data-value="commercial" data-label="Commercial Spaces">
                  <span>Commercial Spaces</span>
                  <i class="ri-check-line check-icon"></i>
                </div>
              </div>
            </div>

            <div class="search-field-divider"></div>

            <!-- Field 3: BUDGET -->
            <div class="search-field-pill custom-dropdown" id="dropdown-budget">
              <div class="search-field-inner custom-dropdown-trigger">
                <div class="field-icon-wrap">
                  <i class="ri-bank-card-fill"></i>
                </div>
                <div class="field-info">
                  <span class="field-label">BUDGET</span>
                  <span class="field-val selected-text">Any Price</span>
                </div>
                <i class="ri-arrow-down-s-line chevron-icon"></i>
              </div>

              <div class="custom-dropdown-menu" style="padding: 20px; width: 280px; left: -100px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 12px;">
                  <span style="font-size: 0.85rem; font-weight: 700; color: #4a5568; text-transform: uppercase;">Max Budget</span>
                  <span id="slider-val-display" style="font-size: 0.9rem; font-weight: 800; color: #eb5e28;">Any Price</span>
                </div>
                <input type="range" id="budget-slider" min="0" max="500" step="10" value="0" style="width: 100%; accent-color: #eb5e28; cursor: pointer; height: 6px; border-radius: 4px; background: #e2e8f0; outline: none;">
                <div style="display: flex; justify-content: space-between; font-size: 0.75rem; color: #718096; margin-top: 10px; font-weight: 600;">
                  <span>Any</span>
                  <span>1Cr</span>
                  <span>3Cr</span>
                  <span>5Cr+</span>
                </div>
              </div>
            </div>

            <!-- Search Submit Button -->
            <button type="submit" class="btn btn-primary search-submit-btn-unified" id="hero-search-submit">
              <i class="ri-search-2-line" style="font-size: 1.25rem;"></i>
              <span>Search Properties</span>
            </button>
          </form>
        </div>
      </div>
    </section>
  `}function ie(e){let t=document.getElementById(`hero-parallax-img`);window.addEventListener(`scroll`,()=>{if(t&&window.scrollY<1e3){let e=window.scrollY;t.style.transform=`scale(${1.05+e*3e-4}) translateY(${e*.15}px)`}});let n=document.querySelectorAll(`#hero-search-tabs .segmented-tab-btn`),r=`buy`;n.forEach(e=>{e.addEventListener(`click`,()=>{n.forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`),r=e.dataset.purpose||`buy`,r===`sell`&&(i()?window.location.href=`/user-dashboard.html`:window.location.href=`/login.html#register`)})});let a=document.querySelectorAll(`.custom-dropdown`);a.forEach(e=>{let t=e.querySelector(`.custom-dropdown-trigger`),n=e.id.replace(`dropdown-`,`search-`),r=document.getElementById(n),i=e.querySelector(`.selected-text`),o=e.querySelectorAll(`.dropdown-item`);t?.addEventListener(`click`,t=>{t.stopPropagation(),a.forEach(t=>{t!==e&&t.classList.remove(`open`)}),e.classList.toggle(`open`)}),o.forEach(t=>{t.addEventListener(`click`,n=>{n.stopPropagation(),o.forEach(e=>e.classList.remove(`active`)),t.classList.add(`active`);let a=t.dataset.value,s=t.dataset.label;r&&(r.value=a),i&&(i.textContent=s),e.classList.remove(`open`)})})});let o=document.getElementById(`budget-slider`),s=document.getElementById(`slider-val-display`),c=document.getElementById(`search-budget`),l=document.querySelector(`#dropdown-budget .selected-text`);o&&(o.addEventListener(`input`,e=>{let t=parseInt(e.target.value);if(t===0)s.textContent=`Any Price`,l.textContent=`Any Price`,c.value=`all`;else{let e=t<100?`Upto ₹ ${t} Lakhs`:`Upto ₹ ${(t/100).toFixed(1)} Cr`;s.textContent=e,l.textContent=e,c.value=(t*1e5).toString()}}),o.parentElement.addEventListener(`click`,e=>e.stopPropagation())),document.addEventListener(`click`,()=>{a.forEach(e=>e.classList.remove(`open`))}),document.getElementById(`hero-search-form`)?.addEventListener(`submit`,t=>{t.preventDefault();let n=document.getElementById(`search-location`)?.value||`all`,i=document.getElementById(`search-type`)?.value||`all`,a=document.getElementById(`search-budget`)?.value||`all`;e({purpose:r,location:n,type:i,budget:a}),document.getElementById(`discovery`)?.scrollIntoView({behavior:`smooth`})})}function ae(){let t=e(`post_cta_bg`)||`https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=80`;return e(`showcase_bg`),`
    <section class="editorial-section" id="promote-land-section" style="padding: 90px 0; background: #faf8f5;">
      <div class="container" style="position: relative; z-index: 2;">
        
        <!-- 1. Editorial Header for Land Owners & Sellers -->
        <div class="editorial-intro-container" style="display: flex; flex-direction: column; align-items: center; text-align: center; max-width: 900px; margin: 0 auto 48px auto;">
          <!-- Top Eyebrow Bar -->
          <div class="editorial-top-eyebrow-bar" style="justify-content: center; margin-bottom: 24px;">
            <div class="editorial-eyebrow-wrap" style="gap: 8px;">
              <span class="eyebrow eyebrow-center" style="color: var(--color-orange); font-weight: 800; letter-spacing: 0.12em;">SELL YOUR PROPERTY TO THE RIGHT AUDIENCE</span>
            </div>
          </div>

          <!-- Main Centered Content -->
          <h2 class="heading-display-light editorial-main-title" style="margin-bottom: 12px; font-size: 3.5rem;">
            Sell Your Property Faster to Genuine Buyers
          </h2>
          <div style="font-size: 1.15rem; font-weight: 700; color: #eb5e28; margin-bottom: 24px;">List for Free & Connect with Thousands of Active Seekers</div>
          
          <p class="editorial-desc-text" style="font-size: 1.1rem; line-height: 1.7; color: #555; max-width: 800px; margin-bottom: 40px;">
            Looking to sell your house, plot, farmland, or commercial space? List your property on Thanjai Property for free. We showcase your property with clear details, verified Patta support, and zero listing fees to connect you directly with genuine local and NRI buyers across Tamil Nadu.
          </p>

          <!-- Integrated Horizontal Stats Bar -->
          <div class="editorial-integrated-stats-bar" style="width: 100%; border-top: 1px solid rgba(0,0,0,0.08); padding-top: 24px; justify-content: center; gap: 40px;">
            <div class="editorial-inline-stats" style="gap: 40px;">
              <div class="inline-stat-item" style="flex-direction: column; align-items: center; gap: 4px;">
                <div class="stat-num-wrap">
                  <span class="stat-num" style="font-size: 1.8rem;">100%</span>
                </div>
                <span class="stat-lbl" style="text-align: center;">Zero Listing Fees</span>
              </div>

              <div class="inline-stat-sep" style="height: 40px;"></div>

              <div class="inline-stat-item" style="flex-direction: column; align-items: center; gap: 4px;">
                <div class="stat-num-wrap">
                  <span class="stat-num" style="font-size: 1.8rem;">10k+</span>
                </div>
                <span class="stat-lbl" style="text-align: center;">Active Buyers & NRIs</span>
              </div>

              <div class="inline-stat-sep" style="height: 40px;"></div>

              <div class="inline-stat-item" style="flex-direction: column; align-items: center; gap: 4px;">
                <div class="stat-num-wrap">
                  <span class="stat-num" style="font-size: 1.8rem;">Since 2009</span>
                </div>
                <span class="stat-lbl" style="text-align: center;">Legal Patta Verification</span>
              </div>
            </div>
          </div>
        </div>

        <!-- 2. Asymmetric Showcase: Left Seller Spotlight Card + Right Seller Benefits -->
        <div class="editorial-asymmetric-showcase">
          
          <!-- LEFT 65%: PROMOTIONAL LAND & PROPERTY SPOTLIGHT BANNER -->
          <div class="editorial-hero-slider-wrap explore-seller-banner" style="height: 100%; min-height: 480px; border-radius: 24px; overflow: hidden; position: relative;">
            <img src="${t}" alt="Promote Land with Thanjai Property" style="width: 100%; height: 100%; object-fit: cover;" />
            <div style="position: absolute; inset: 0; background: linear-gradient(180deg, rgba(0,0,0,0.15) 0%, rgba(42,24,8,0.85) 100%);"></div>

            <div style="position: absolute; top: 24px; left: 24px; z-index: 2;">
              <span class="badge badge-orange" style="font-size: 0.8rem; font-weight: 800;">
                <i class="ri-rocket-fill"></i> ALL PROPERTY SELLER DESK
              </span>
            </div>

            <!-- Floating White/Glass Action Box -->
            <div class="explore-seller-card" style="
              position: absolute; bottom: 24px; left: 24px; right: 24px;
              background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(12px);
              border-radius: 20px; padding: 28px; border: 1px solid rgba(255,255,255,0.4);
              box-shadow: 0 10px 30px rgba(0,0,0,0.15); z-index: 3;
            ">
              <h3 style="font-family: var(--font-serif); font-size: 1.45rem; font-weight: 700; color: #1a1a1a; margin-bottom: 8px; line-height: 1.25;">
                Do You Have a Property to Sell in Tamil Nadu?
              </h3>
              <p style="font-size: 0.9rem; color: #555; line-height: 1.5; margin-bottom: 18px;">
                Share your property details in just 60 seconds. Our expert team will verify the documents and present your listing to verified, ready-to-buy seekers.
              </p>

              <button class="btn btn-primary post-land-trigger-btn" style="padding: 12px 18px; font-size: 0.92rem; border-radius: 10px; width: 100%; justify-content: center; text-align: center; white-space: normal; line-height: 1.35; word-break: break-word;">
                <i class="ri-add-circle-line" style="font-size: 1.2rem; flex-shrink: 0;"></i>
                <span>Click here to Sell / Promote your Property Now</span>
              </button>
            </div>
          </div>



        </div>

      </div>
    </section>
  `}function oe(){document.querySelectorAll(`.post-land-trigger-btn`).forEach(e=>{e.addEventListener(`click`,e=>{e.preventDefault(),i()?window.location.href=`/user-dashboard.html`:window.location.href=`/login.html#register`})})}function se(e){return o(e)}function ce(e,t,n){return`
    <section class="home-property-showcase-section" style="padding: 90px 0; background: #ffffff;">
      <div class="container">
        
        <!-- Header -->
        <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 48px; flex-wrap: wrap; gap: 20px;">
          <div>
            <span class="eyebrow" style="color: var(--color-orange, #eb5e28); font-weight: 800; letter-spacing: 0.12em;">FEATURED & LATEST OPPORTUNITIES</span>
            <h2 class="heading-section" style="margin-top: 10px;">
              Featured Properties
            </h2>
            <div style="font-size: 1rem; font-weight: 700; color: #4a5568; margin-top: 4px;">Explore Property Opportunities Worth Your Attention</div>
          </div>
          <p style="max-width: 520px; color: var(--color-text-muted, #666); font-size: 0.95rem; line-height: 1.6;">
            Explore handpicked properties across Tamil Nadu. Find houses, villas, plots, farmlands, and commercial spaces with verified prices, clear sizes, and exact locations.
          </p>
        </div>

        <!-- Asymmetric Editorial Showcase Grid (4 Properties) -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 28px; margin-bottom: 50px;">
          ${e.slice(0,4).map((e,t)=>`
            <div class="editorial-prop-card hover-lift" data-id="${e.id}" style="
              background: #ffffff;
              border-radius: 20px;
              overflow: hidden;
              border: 1px solid rgba(0,0,0,0.08);
              box-shadow: 0 6px 20px rgba(0,0,0,0.04);
              display: flex;
              flex-direction: column;
              cursor: pointer;
            ">
              <div style="position: relative; width: 100%; height: 260px; overflow: hidden; background: #111;">
                <img src="${e.images[0]}" alt="${e.title}" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.4s ease;" />
                <div style="position: absolute; inset: 0; background: linear-gradient(180deg, rgba(0,0,0,0.2) 0%, rgba(0,0,0,0.65) 100%);"></div>
                
                <span class="badge badge-orange" style="position: absolute; top: 18px; left: 18px; font-weight: 700;">
                  ${e.categoryLabel}
                </span>

                <div style="position: absolute; bottom: 18px; left: 18px; right: 18px; color: #ffffff;">
                  <div style="font-family: var(--font-serif); font-size: 1.5rem; font-weight: 700; color: #ffffff;">
                    ${e.priceFormatted}
                  </div>
                </div>
              </div>

              <div style="padding: 24px; display: flex; flex-direction: column; flex: 1;">
                <h3 style="font-family: var(--font-serif); font-size: 1.25rem; font-weight: 700; color: #1a1a1a; margin-bottom: 8px;">
                  ${e.title}
                </h3>

                <div style="display: flex; align-items: center; gap: 6px; font-size: 0.88rem; color: #666; margin-bottom: 16px;">
                  <i class="ri-map-pin-2-line" style="color: var(--color-orange, #eb5e28);"></i>
                  <span>${c(e.location,e.district)}</span>
                </div>

                <div style="display: flex; gap: 14px; padding-top: 14px; border-top: 1px solid rgba(0,0,0,0.06); font-size: 0.85rem; color: #555; margin-top: auto; flex-wrap: wrap;">
                  ${e.size?`<span><i class="ri-ruler-2-line"></i> ${se(e.size)}</span>`:``}
                  ${e.facing?`<span><i class="ri-compass-3-line"></i> ${e.facing}</span>`:``}
                  ${e.bedrooms?`<span><i class="ri-hotel-bed-line"></i> ${e.bedrooms} BHK</span>`:e.approval?`<span><i class="ri-shield-check-line"></i> ${e.approval}</span>`:``}
                </div>

                <button class="btn btn-outline-dark" style="margin-top: 20px; width: 100%; border-radius: 10px; font-size: 0.9rem;">
                  <span>Explore Property</span>
                  <i class="ri-arrow-right-line"></i>
                </button>
              </div>
            </div>
          `).join(``)}
        </div>

        <!-- Big CTA Button to Discover -->
        <div style="text-align: center;">
          <button class="btn btn-primary" id="showcase-discover-all-btn" style="padding: 16px 40px; font-size: 1.05rem; border-radius: 12px;">
            <i class="ri-compass-3-line" style="font-size: 1.25rem;"></i>
            <span>View More Properties</span>
          </button>
        </div>

      </div>
    </section>
  `}function le(e,t){let n=document.getElementById(`showcase-discover-all-btn`);n&&n.addEventListener(`click`,e=>{e.preventDefault(),t&&t()}),document.querySelectorAll(`.editorial-prop-card`).forEach(t=>{t.addEventListener(`click`,n=>{n.preventDefault();let r=t.dataset.id;r&&e&&e(r)})})}var x=[{id:`medical_college_road`,markerId:1,name:`Medical College Road`,zone:`Arterial`,category:`Arterial`,isOuterLocation:!1,latitude:10.7574,longitude:79.1079,zoom:15,searchQuery:`Medical College Road, Thanjavur, Tamil Nadu, India`,districtLabel:`Thanjavur`,priceFrom:`₹ 2.3 Lakhs / Cent`,propertyType:`Residential`,areaPotential:`High Appreciation`,approval:`DTCP Approved`,tagline:`Healthcare Corridor & Premium Residential Hub`,locationImage:`https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=1200&q=80`,imageAlt:`Medical College Road, Thanjavur, Tamil Nadu`,popularAreas:[`Sarafojinagar`,`Easwari Nagar`,`EVP Nagar`,`Sundaram Nagar`],description:`Prime residential corridor in Thanjavur near Thanjavur Medical College with high appreciation, multi-speciality hospitals, and DTCP approved layouts.`},{id:`trichy_road`,markerId:2,name:`Trichy Road`,zone:`Arterial`,category:`Arterial`,isOuterLocation:!1,latitude:10.7781,longitude:79.1381,zoom:14,searchQuery:`Trichy Road, Thanjavur, Tamil Nadu, India`,districtLabel:`Thanjavur`,priceFrom:`₹ 2.8 Lakhs / Cent`,propertyType:`Commercial & Residential`,areaPotential:`Fast Commercial Growth`,approval:`DTCP & RERA`,tagline:`Major Commercial Highway & Gated Villas`,locationImage:`https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=1200&q=80`,imageAlt:`Trichy Road (NH 83) Highway Corridor, Thanjavur`,popularAreas:[`Thanjavur Junction`,`New Bus Stand Bypass`,`Pillaiyarpatti`,`NH 83 Corridor`],description:`High-traffic commercial artery (NH 83) connecting Thanjavur to Trichy, ideal for retail spaces, commercial land, and gated communities.`},{id:`pudukkottai_road`,markerId:3,name:`Pudukkottai Road`,zone:`Arterial`,category:`Arterial`,isOuterLocation:!1,latitude:10.765,longitude:79.125,zoom:14,searchQuery:`Pudukkottai Road, Thanjavur, Tamil Nadu, India`,districtLabel:`Thanjavur`,priceFrom:`₹ 2.1 Lakhs / Cent`,propertyType:`Residential & Plots`,areaPotential:`High Rental Yield`,approval:`DTCP Approved`,tagline:`Educational Belt & Residential Plot Layouts`,locationImage:`https://images.unsplash.com/photo-1541829070764-84a7d30dd3f3?auto=format&fit=crop&w=1200&q=80`,imageAlt:`Pudukkottai Road Educational Corridor, Thanjavur`,popularAreas:[`Parisutham Nagar`,`Yagappa Nagar`,`Tamil University Sector`,`Air Force Gate`],description:`Rapidly developing institutional zone opposite Tamil University featuring premium house sites, schools, and quiet family neighborhoods.`},{id:`madhakottai_road`,markerId:4,name:`Madhakottai Road`,zone:`Residential`,category:`Residential`,isOuterLocation:!1,latitude:10.7521,longitude:79.1124,zoom:15,searchQuery:`Madhakottai Road, Thanjavur, Tamil Nadu, India`,districtLabel:`Thanjavur`,priceFrom:`₹ 2.1 Lakhs / Cent`,propertyType:`Residential & Villas`,areaPotential:`Rapid Expansion`,approval:`DTCP Approved`,tagline:`Rapid Urban Expansion & Modern Villas`,locationImage:`https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80`,imageAlt:`Madhakottai Road Residential Corridor, Thanjavur`,popularAreas:[`Raja Serfoji Govt College Area`,`Madhakottai Junction`,`Holy Cross Extension`],description:`Fastest-growing residential expansion zone near Raja Serfoji Government College featuring contemporary villa developments and clear Patta plots.`},{id:`nanjikottai_road`,markerId:5,name:`Nanjikottai Road`,zone:`Residential`,category:`Residential`,isOuterLocation:!1,latitude:10.7453,longitude:79.1289,zoom:15,searchQuery:`Nanjikottai Road, Thanjavur, Tamil Nadu, India`,districtLabel:`Thanjavur`,priceFrom:`₹ 2.4 Lakhs / Cent`,propertyType:`Residential Enclaves`,areaPotential:`Established Prime`,approval:`DTCP Approved`,tagline:`Serene Residential Enclaves & Townhouses`,locationImage:`https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80`,imageAlt:`Nanjikottai Road Residential Enclave, Thanjavur`,popularAreas:[`Nanjikottai Junction`,`EB Colony`,`Kuberan Nagar`,`Vasantham City`],description:`Established peaceful residential corridor with excellent groundwater, top schools, and independent homes south of Thanjavur city.`},{id:`villar_road`,markerId:6,name:`Villar Road`,zone:`Suburban`,category:`Suburban`,isOuterLocation:!1,latitude:10.733,longitude:79.15,zoom:14,searchQuery:`Villar Road, Thanjavur, Tamil Nadu, India`,districtLabel:`Thanjavur Taluk`,priceFrom:`₹ 1.6 Lakhs / Cent`,propertyType:`Suburban Plots & Farmlands`,areaPotential:`High ROI Potential`,approval:`DTCP & Patta`,tagline:`Suburban Growth & Investment Plot Layouts`,locationImage:`https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80`,imageAlt:`Villar Road Agricultural & Suburban Layouts, Thanjavur`,popularAreas:[`Vilar Panchayat`,`Nanjikottai Bypass Area`,`Kaveri Layout`],description:`High-potential suburban investment corridor in Vilar area offering budget-friendly residential and agricultural land opportunities, PIN 613006.`},{id:`pattukottai_bypass`,markerId:7,name:`Pattukottai Bypass`,zone:`Bypass`,category:`Bypass`,isOuterLocation:!0,latitude:10.4236,longitude:79.3195,zoom:13,searchQuery:`Pattukottai Bypass, Pattukkottai, Thanjavur district, Tamil Nadu, India`,districtLabel:`Pattukkottai, Thanjavur District`,priceFrom:`₹ 1.2 Lakhs / Cent`,propertyType:`Commercial & Highway Plots`,areaPotential:`Commercial Hub`,approval:`DTCP Approved`,tagline:`Pattukkottai Town Bypass & Highway Frontage`,locationImage:`https://images.unsplash.com/photo-1541888946425-d0fbb186a5b7?auto=format&fit=crop&w=1200&q=80`,imageAlt:`Pattukkottai Bypass Highway Corridor, Thanjavur District`,popularAreas:[`Pattukkottai Town Centre`,`Bypass Junction`,`Highway Commercial Belt`],description:`Strategic bypass road skirting Pattukkottai town in Thanjavur district — prime frontage for warehouses, commercial showrooms, and highway plots.`},{id:`mariyamman_kovil_road`,markerId:8,name:`Mariyamman Kovil Road`,zone:`Heritage`,category:`Suburban`,isOuterLocation:!1,latitude:10.7854,longitude:79.1895,zoom:15,searchQuery:`Mariyamman Kovil Road, Thanjavur, Tamil Nadu, India`,districtLabel:`Thanjavur`,priceFrom:`₹ 1.8 Lakhs / Cent`,propertyType:`Heritage & Residential`,areaPotential:`Cultural Heritage`,approval:`Clear Patta`,tagline:`Heritage & Temple Neighborhood Corridor`,locationImage:`https://images.unsplash.com/photo-1602621585695-a25e8d81f7e1?auto=format&fit=crop&w=1200&q=80`,imageAlt:`Punnainallur Mariyamman Temple Road Corridor, Thanjavur`,popularAreas:[`Punnainallur`,`Mariamman Temple Road`,`Kovil Bypass`,`Sri Rama Nagar`],description:`Culturally rich residential belt near Punnainallur Mariyamman Temple (~5 km east of Thanjavur) with traditional independent homes, PIN 613501.`},{id:`srinivasapuram`,markerId:9,name:`Srinivasapuram`,zone:`Residential`,category:`Residential`,isOuterLocation:!1,latitude:10.7861,longitude:79.1268,zoom:15,searchQuery:`Srinivasapuram, Thanjavur, Tamil Nadu, India`,districtLabel:`Thanjavur`,priceFrom:`₹ 2.9 Lakhs / Cent`,propertyType:`Upscale Housing`,areaPotential:`Ultra Luxury`,approval:`DTCP Approved`,tagline:`Established Upscale Neighborhood & Individual Houses`,locationImage:`https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80`,imageAlt:`Srinivasapuram Upscale Residential Avenue, Thanjavur`,popularAreas:[`Srinivasapuram Main Road`,`Bankers Colony`,`Court Road Link`],description:`Prestigious central Thanjavur residential colony featuring luxury independent residences and excellent civic infrastructure.`},{id:`reddipalayam_road`,markerId:10,name:`Reddipalayam Road`,zone:`Residential`,category:`Residential`,isOuterLocation:!1,latitude:10.762,longitude:79.105,zoom:15,searchQuery:`Reddipalayam Road, Thanjavur, Tamil Nadu, India`,districtLabel:`Thanjavur`,priceFrom:`₹ 1.9 Lakhs / Cent`,propertyType:`Gated Layouts`,areaPotential:`Emerging Layouts`,approval:`DTCP & RERA`,tagline:`Gated Community & Modern Layouts`,locationImage:`https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1200&q=80`,imageAlt:`Reddipalayam Road Gated Community Layout, Thanjavur`,popularAreas:[`Reddipalayam Junction`,`Eashwari Nagar`,`Cauvery Nagar`,`PIN 613009`],description:`Well-planned residential sector in western Thanjavur with RERA-approved house sites and modern gated community projects near Medical College area.`},{id:`kumbakonam_bypass`,markerId:11,name:`Kumbakonam Bypass`,zone:`Bypass`,category:`Bypass`,isOuterLocation:!0,latitude:10.9621,longitude:79.3912,zoom:13,searchQuery:`Kumbakonam Bypass, Kumbakonam, Thanjavur district, Tamil Nadu, India`,districtLabel:`Kumbakonam, Thanjavur District`,priceFrom:`₹ 2.5 Lakhs / Cent`,propertyType:`Highway & Agro Assets`,areaPotential:`Strategic Asset`,approval:`DTCP & Patta`,tagline:`Delta Highway & Strategic Land Assets`,locationImage:`https://images.unsplash.com/photo-1589939705384-5185137a7f0f?auto=format&fit=crop&w=1200&q=80`,imageAlt:`Kumbakonam Bypass Highway Corridor, Thanjavur District`,popularAreas:[`Kumbakonam Town Bypass`,`Papanasam Highway`,`Delta Agro Belts`],description:`Major bypass road in Kumbakonam town, Thanjavur district — popular for commercial investments and farmlands along the Thanjavur–Kumbakonam corridor.`}].map(t=>({...t,get matchingProperties(){try{return u().filter(e=>{let n=(e.road||``).toLowerCase().trim(),r=(e.district||``).toLowerCase().trim(),i=(e.location||``).toLowerCase().trim(),a=(e.area||e.address||``).toLowerCase().trim(),o=(e.taluk||``).toLowerCase().trim(),s=(e.title||``).toLowerCase().trim(),c=t.name.toLowerCase().trim(),l=t.id.replace(/_/g,` `).toLowerCase().trim();return n&&(n===c||n===l||n.includes(c)||c.includes(n))?!0:i.includes(c)||r.includes(c)||a.includes(c)||o.includes(c)||s.includes(c)||i.includes(l)})}catch{return[]}},get propertiesCount(){return this.matchingProperties.length},get hasProperties(){return this.propertiesCount>0},get count(){let e=this.propertiesCount;return e===0?`0 Properties`:e===1?`1 Property`:`${e} Active Listings`},get image(){return e(`loc_corridor_${t.id}`)||t.locationImage}})),S=null,C=[],w=`medical_college_road`;function ue(){return`
    <section class="locations-section" id="locations" style="padding: 50px 0 60px; background: #faf8f5;">
      <div class="container">
        
        <!-- Section Header -->
        <div style="margin-bottom: 22px;">
          <span class="eyebrow" style="color: var(--color-orange, #eb5e28); font-weight: 800; font-size: 0.8rem; letter-spacing: 0.12em; text-transform: uppercase;">
            EXPLORE PRIME LOCATIONS
          </span>
          <h2 class="heading-section" style="margin-top: 4px; font-size: clamp(1.8rem, 3vw, 2.4rem); color: #1a1a1a; font-family: var(--font-serif);">
            Find Properties in <span style="color: #eb5e28;">Thanjavur</span>
          </h2>
          <p style="font-size: 0.92rem; color: #5a6578; margin-top: 4px; max-width: 650px;">
            Explore the most sought-after locations in and around Thanjavur.
          </p>
        </div>

        <!-- Category Filter Pills -->
        <div style="display: flex; gap: 10px; overflow-x: auto; padding-bottom: 6px; margin-bottom: 20px; scrollbar-width: none;" id="corridor-filter-pills">
          <button class="corridor-pill-btn active" data-category="all" style="
            background: #eb5e28; color: #ffffff; border: 1px solid #eb5e28; padding: 8px 18px; border-radius: 30px;
            font-size: 0.85rem; font-weight: 700; cursor: pointer; white-space: nowrap; transition: all 0.25s ease; box-shadow: 0 4px 12px rgba(235,94,40,0.25);
          ">All Locations</button>

          <button class="corridor-pill-btn" data-category="Arterial" style="
            background: #ffffff; color: #4a5568; border: 1px solid #e2e8f0; padding: 8px 18px; border-radius: 30px;
            font-size: 0.85rem; font-weight: 700; cursor: pointer; white-space: nowrap; transition: all 0.25s ease;
          ">Arterial Roads</button>

          <button class="corridor-pill-btn" data-category="Residential" style="
            background: #ffffff; color: #4a5568; border: 1px solid #e2e8f0; padding: 8px 18px; border-radius: 30px;
            font-size: 0.85rem; font-weight: 700; cursor: pointer; white-space: nowrap; transition: all 0.25s ease;
          ">Residential Roads</button>

          <button class="corridor-pill-btn" data-category="Bypass" style="
            background: #ffffff; color: #4a5568; border: 1px solid #e2e8f0; padding: 8px 18px; border-radius: 30px;
            font-size: 0.85rem; font-weight: 700; cursor: pointer; white-space: nowrap; transition: all 0.25s ease;
          ">Bypass Roads</button>

          <button class="corridor-pill-btn" data-category="Suburban" style="
            background: #ffffff; color: #4a5568; border: 1px solid #e2e8f0; padding: 8px 18px; border-radius: 30px;
            font-size: 0.85rem; font-weight: 700; cursor: pointer; white-space: nowrap; transition: all 0.25s ease;
          ">Heritage & Suburban</button>
        </div>

        <!-- Main Explorer Split Layout (Exact Same Height) -->
        <div class="location-explorer-layout" style="display: flex; gap: 24px; flex-wrap: wrap; align-items: stretch;">
          
          <!-- LEFT: REAL LEAFLET MAP -->
          <div class="location-map-card" style="flex: 1 1 480px; height: 550px; background: #e2e8f0; border-radius: 22px; overflow: hidden; border: 1px solid #e2e8f0; box-shadow: 0 10px 30px rgba(0,0,0,0.06); position: relative; box-sizing: border-box;">
            <div id="thanjavur-explorer-map" style="width: 100%; height: 100%; z-index: 1;"></div>
            
            <!-- Re-center Control Button -->
            <button id="explorer-recenter-btn" style="
              position: absolute; bottom: 18px; left: 18px; z-index: 400;
              background: #ffffff; color: #1a1a1a; border: 1px solid #cbd5e0;
              padding: 8px 15px; border-radius: 24px; font-size: 0.82rem; font-weight: 700;
              cursor: pointer; box-shadow: 0 4px 14px rgba(0,0,0,0.12);
              display: inline-flex; align-items: center; gap: 6px; transition: all 0.25s ease;
            ">
              <i class="ri-focus-3-line" style="color: #eb5e28; font-size: 1rem;"></i>
              <span>Re-center</span>
            </button>
          </div>

          <!-- RIGHT: SELECTED LOCATION INFORMATION PANEL -->
          <div class="location-panel-card" style="flex: 1 1 440px; height: 550px; max-height: 550px; background: #ffffff; border-radius: 22px; padding: 22px 24px; border: 1px solid #e2e8f0; box-shadow: 0 10px 30px rgba(0,0,0,0.06); display: flex; flex-direction: column; justify-content: space-between; box-sizing: border-box; overflow-y: auto;" id="selected-location-panel">
            ${T(x.find(e=>e.id===w)||x[0])}
          </div>

        </div>

      </div>
    </section>
  `}function T(e){if(!e)return``;let t=e.matchingProperties||[],n=t.length>0,r=t.length;return`
    <div class="panel-fade-in" style="display: flex; flex-direction: column; justify-content: space-between; height: 100%; gap: 12px;">
      
      <!-- Top Badges Row -->
      <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 6px;">
        <div style="display: flex; align-items: center; gap: 6px;">
          <span style="background: rgba(235,94,40,0.12); color: #eb5e28; font-size: 0.72rem; font-weight: 800; padding: 3px 10px; border-radius: 20px; text-transform: uppercase; letter-spacing: 0.04em;">
            ${e.zone} ROAD
          </span>
          <span style="background: #f7fafc; color: #4a5568; border: 1px solid #e2e8f0; font-size: 0.72rem; font-weight: 800; padding: 3px 8px; border-radius: 20px;">
            PIN #${e.markerId}
          </span>
        </div>
        <span style="font-size: 0.78rem; font-weight: 700; color: ${n?`#2f855a`:`#718096`}; display: inline-flex; align-items: center; gap: 5px;">
          <span style="width: 7px; height: 7px; border-radius: 50%; background: ${n?`#38a169`:`#a0aec0`}; display: inline-block;"></span>
          ${n?`${r} Active Listings`:`Upcoming Corridor`}
        </span>
      </div>

      <!-- Real Location Photograph Banner (Large 220px) -->
      <div style="width: 100%; height: 210px; border-radius: 16px; overflow: hidden; position: relative; background: #e2e8f0; box-shadow: 0 4px 12px rgba(0,0,0,0.06); flex-shrink: 0;">
        <img 
          src="${e.image}" 
          alt="${e.imageAlt||e.name}" 
          class="location-hero-photo"
          style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.4s ease;"
          onerror="this.src='https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=1200&q=80';"
        />
      </div>

      <!-- Location Heading & Subtitle (Clean without description/metrics) -->
      <div>
        <h3 style="font-family: var(--font-serif); font-size: 1.55rem; font-weight: 700; color: #1a1a1a; margin: 0 0 3px 0; line-height: 1.2;">
          ${e.name}
        </h3>
        <div style="font-size: 0.85rem; font-weight: 600; color: #718096; display: flex; align-items: center; gap: 4px;">
          <i class="ri-map-pin-line" style="color: #eb5e28;"></i>
          <span>${e.districtLabel||`Thanjavur`}, Tamil Nadu</span>
        </div>
      </div>

      <!-- Available Listings or Clean No-Properties State -->
      <div>
        ${n?`
          <!-- REAL AVAILABLE PROPERTIES -->
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
            <span style="font-size: 0.7rem; font-weight: 800; color: #718096; text-transform: uppercase; letter-spacing: 0.04em;">AVAILABLE LISTINGS PREVIEW</span>
            <a href="javascript:void(0)" class="explorer-view-all-link" data-location="${e.name}" style="font-size: 0.76rem; font-weight: 800; color: #eb5e28; text-decoration: none;">
              View All (${r})
            </a>
          </div>

          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(85px, 1fr)); gap: 8px; margin-bottom: 12px;">
            ${t.slice(0,4).map(t=>`
              <div class="explorer-prop-thumb-card" data-prop-id="${t.id}" data-location="${e.name}" style="
                background: #ffffff; border-radius: 8px; overflow: hidden; border: 1px solid #e2e8f0; cursor: pointer;
                transition: all 0.2s ease; box-shadow: 0 2px 5px rgba(0,0,0,0.03);
              " title="${t.title}">
                <div style="width: 100%; height: 46px; overflow: hidden;">
                  <img src="${t.images[0]}" alt="${t.title}" style="width: 100%; height: 100%; object-fit: cover;" />
                </div>
                <div style="padding: 4px 6px;">
                  <div style="font-size: 0.65rem; font-weight: 700; color: #2d3748; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${t.title}</div>
                  <div style="font-size: 0.65rem; font-weight: 800; color: #eb5e28; margin-top: 1px;">${t.priceFormatted}</div>
                </div>
              </div>
            `).join(``)}
          </div>

          <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            <button class="btn btn-primary explorer-view-props-btn" data-location="${e.name}" style="
              flex: 2 1 180px; padding: 11px 16px; border-radius: 10px; font-size: 0.88rem; font-weight: 700;
              display: inline-flex; align-items: center; justify-content: center; gap: 6px;
              background: #eb5e28; color: #ffffff; border: none; cursor: pointer; box-shadow: 0 4px 12px rgba(235,94,40,0.22);
            ">
              <span>View Properties in ${e.name}</span>
              <i class="ri-arrow-right-line"></i>
            </button>

            <button class="explorer-directions-btn" data-lat="${e.latitude}" data-lng="${e.longitude}" style="
              flex: 1 1 120px; padding: 11px 14px; border-radius: 10px; font-size: 0.88rem; font-weight: 700;
              display: inline-flex; align-items: center; justify-content: center; gap: 5px;
              background: #ffffff; color: #2d3748; border: 1px solid #cbd5e0; cursor: pointer; transition: all 0.2s ease;
            ">
              <i class="ri-navigation-line" style="color: #eb5e28;"></i>
              <span>Get Directions</span>
            </button>
          </div>
        `:`
          <!-- ACCURATE NO PROPERTY STATE -->
          <div style="background: #faf8f5; border-radius: 14px; padding: 16px 14px; border: 1px dashed #cbd5e0; text-align: center;">
            <div style="width: 36px; height: 36px; border-radius: 50%; background: rgba(235,94,40,0.1); color: #eb5e28; display: flex; align-items: center; justify-content: center; font-size: 1.15rem; margin: 0 auto 6px auto;">
              <i class="ri-map-pin-time-line"></i>
            </div>
            <h4 style="font-size: 0.95rem; font-weight: 800; color: #1a1a1a; margin: 0 0 3px 0;">No Active Properties Right Now</h4>
            <p style="font-size: 0.78rem; color: #666; line-height: 1.4; margin: 0 0 12px 0;">
              We are currently preparing new verified Patta layouts in <strong>${e.name}</strong>. Want to be notified when listings go live?
            </p>
            <div style="display: flex; gap: 8px; flex-wrap: wrap;">
              <button class="explorer-notify-btn" data-location="${e.name}" style="flex: 1; background: #eb5e28; color: #ffffff; border: none; padding: 9px 10px; border-radius: 8px; font-size: 0.8rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 5px; box-shadow: 0 4px 10px rgba(235,94,40,0.2);">
                <i class="ri-notification-3-line"></i> Notify Me
              </button>
              <button class="explorer-talk-btn" data-location="${e.name}" style="flex: 1; background: #ffffff; color: #2d3748; border: 1px solid #cbd5e0; padding: 9px 10px; border-radius: 8px; font-size: 0.8rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 5px;">
                <i class="ri-customer-service-2-line"></i> Talk to Us
              </button>
              <button class="explorer-directions-btn" data-lat="${e.latitude}" data-lng="${e.longitude}" style="flex: 1; background: #ffffff; color: #2d3748; border: 1px solid #cbd5e0; padding: 9px 10px; border-radius: 8px; font-size: 0.8rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 5px;">
                <i class="ri-navigation-line" style="color: #eb5e28;"></i> Directions
              </button>
            </div>
          </div>
        `}
      </div>

    </div>
  `}function de(e){fe(e);let t=document.querySelectorAll(`.corridor-pill-btn`);t.forEach(n=>{n.addEventListener(`click`,()=>{t.forEach(e=>{e.style.background=`#ffffff`,e.style.color=`#4a5568`,e.style.border=`1px solid #e2e8f0`,e.style.boxShadow=`none`,e.classList.remove(`active`)}),n.style.background=`#eb5e28`,n.style.color=`#ffffff`,n.style.border=`1px solid #eb5e28`,n.style.boxShadow=`0 4px 12px rgba(235,94,40,0.25)`,n.classList.add(`active`),pe(n.dataset.category,e)})}),document.getElementById(`explorer-recenter-btn`)?.addEventListener(`click`,()=>{E()}),window.addEventListener(`siteImagesUpdated`,()=>{let t=x.find(e=>e.id===w),n=document.getElementById(`selected-location-panel`);n&&t&&(n.innerHTML=T(t),O(e))}),O(e)}function fe(e){!document.getElementById(`thanjavur-explorer-map`)||typeof L>`u`||(S&&=(S.remove(),null),C=[],S=L.map(`thanjavur-explorer-map`,{zoomControl:!0,scrollWheelZoom:!1,center:[10.765,79.13],zoom:13}),L.tileLayer(`https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png`,{maxZoom:18,attribution:`&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>`}).addTo(S),x.forEach(t=>{let n=t.id===w,r=L.divIcon({className:`custom-map-pin-wrapper`,html:`
        <div class="clean-map-marker ${n?`active-marker`:``}" data-id="${t.id}" style="
          display: inline-flex; align-items: center; gap: 5px;
          background: ${n?`#eb5e28`:`#ffffff`};
          color: ${n?`#ffffff`:`#1a1a1a`};
          padding: 3px 8px 3px 5px; border-radius: 20px;
          border: 1px solid ${n?`#eb5e28`:`#d2d6dc`};
          box-shadow: ${n?`0 6px 16px rgba(235,94,40,0.45)`:`0 2px 6px rgba(0,0,0,0.14)`};
          cursor: pointer; transition: all 0.25s ease; white-space: nowrap; font-family: var(--font-sans, sans-serif);
        ">
          <span style="
            width: 20px; height: 20px; border-radius: 50%;
            background: ${n?`#ffffff`:`#e53e3e`};
            color: ${n?`#eb5e28`:`#ffffff`};
            font-size: 0.7rem; font-weight: 800; display: inline-flex;
            align-items: center; justify-content: center; flex-shrink: 0;
          ">${t.markerId}</span>
          <span style="font-size: 0.72rem; font-weight: 700; letter-spacing: -0.01em;">${t.name}</span>
        </div>
      `,iconSize:[110,28],iconAnchor:[55,14]}),i=L.marker([t.latitude,t.longitude],{icon:r,zIndexOffset:n?1e3:100}).addTo(S);i.on(`click`,()=>D(t.id,e)),C.push({id:t.id,category:t.category,marker:i,loc:t})}),E(),setTimeout(()=>{S&&(S.invalidateSize(),E())},250),setTimeout(()=>{S&&S.invalidateSize()},750),window.addEventListener(`resize`,()=>{S&&S.invalidateSize()}))}function E(){if(!S)return;S.invalidateSize();let e=C.filter(e=>!e.loc.isOuterLocation).map(e=>e.marker);if(e.length>0){let t=L.featureGroup(e);S.fitBounds(t.getBounds(),{padding:[70,70],maxZoom:14,animate:!0,duration:1})}else S.setView([10.765,79.13],13)}function D(e,t){w=e;let n=x.find(t=>t.id===e);if(!n)return;S&&S.flyTo([n.latitude,n.longitude],n.zoom||14,{animate:!0,duration:1.2});let r=document.getElementById(`selected-location-panel`);r&&(r.innerHTML=T(n),O(t)),C.forEach(t=>{let n=t.id===e;t.marker.setZIndexOffset(n?1e3:100);let r=document.querySelector(`.clean-map-marker[data-id="${t.id}"]`);if(r){r.style.background=n?`#eb5e28`:`#ffffff`,r.style.color=n?`#ffffff`:`#1a1a1a`,r.style.borderColor=n?`#eb5e28`:`#d2d6dc`,r.style.boxShadow=n?`0 6px 16px rgba(235,94,40,0.45)`:`0 2px 6px rgba(0,0,0,0.14)`;let e=r.querySelector(`span:first-child`);e&&(e.style.background=n?`#ffffff`:`#e53e3e`,e.style.color=n?`#eb5e28`:`#ffffff`)}})}function pe(e,t){let n=[],r=!1,i=null;if(C.forEach(t=>{e===`all`||t.category===e||e===`Suburban`&&(t.category===`Suburban`||t.loc.zone===`Heritage`||t.loc.category===`Heritage`)?(S.hasLayer(t.marker)||t.marker.addTo(S),n.push(t),t.id===w&&(r=!0),i||=t.loc):S.hasLayer(t.marker)&&S.removeLayer(t.marker)}),S&&n.length>0){if(e===`all`)E();else{let e=L.featureGroup(n.map(e=>e.marker));S.fitBounds(e.getBounds(),{padding:[60,60],maxZoom:14,animate:!0,duration:1})}}e!==`all`&&!r&&i&&D(i.id,t)}function O(e){let t=document.getElementById(`selected-location-panel`);t&&(t.querySelectorAll(`.explorer-view-props-btn, .explorer-view-all-link`).forEach(t=>{t.addEventListener(`click`,t=>{let n=t.currentTarget.dataset.location;n&&e&&(e(n),document.getElementById(`discovery`)?.scrollIntoView({behavior:`smooth`}))})}),t.querySelectorAll(`.explorer-directions-btn`).forEach(e=>{e.addEventListener(`click`,e=>{let t=e.currentTarget.dataset.lat,n=e.currentTarget.dataset.lng;t&&n&&window.open(`https://www.google.com/maps/dir/?api=1&destination=${t},${n}`,`_blank`)})}),t.querySelector(`.explorer-notify-btn`)?.addEventListener(`click`,e=>{let t=e.currentTarget.dataset.location;window.dispatchEvent(new CustomEvent(`openScheduleModal`,{detail:{location:t,note:`Notify me when properties go live in ${t}`}}))}),t.querySelector(`.explorer-talk-btn`)?.addEventListener(`click`,()=>{window.location.href=`#contact-us`}),t.querySelectorAll(`.explorer-prop-thumb-card`).forEach(t=>{t.addEventListener(`click`,t=>{let n=t.currentTarget.dataset.location;e&&(e(n||`Thanjavur`),document.getElementById(`discovery`)?.scrollIntoView({behavior:`smooth`}))})}))}var k=[{id:`villas`,name:`Luxury Villas`,unitSingular:`Villa`,unitPlural:`Properties`,defaultImage:`/images/tn_villas.jpg`,description:`Architectural estates & private courtyard residences`},{id:`houses`,name:`Independent Houses`,unitSingular:`House`,unitPlural:`Properties`,defaultImage:`/images/tn_houses.jpg`,description:`Independent homes with custom floor layouts`},{id:`apartments`,name:`Modern Apartments`,unitSingular:`Apartment`,unitPlural:`Properties`,defaultImage:`/images/tn_apartments.jpg`,description:`High-rise apartments & luxury penthouses`},{id:`plots`,name:`Residential Plots`,unitSingular:`Plot`,unitPlural:`Plots`,defaultImage:`/images/tn_plots.jpg`,description:`DTCP & RERA approved villa layout plots`},{id:`agricultural`,name:`Agricultural Land`,unitSingular:`Farm`,unitPlural:`Farms`,defaultImage:`/images/tn_agricultural.jpg`,description:`Fertile Kaveri delta coconut & paddy farmlands`},{id:`commercial`,name:`Commercial Spaces`,unitSingular:`Space`,unitPlural:`Spaces`,defaultImage:`/images/tn_commercial.jpg`,description:`Showrooms, prime retail plots & corporate offices`}].map(t=>({...t,get count(){try{let e=u().filter(e=>e.category===t.id).length;return e===0?`0 ${t.unitPlural}`:e===1?`1 ${t.unitSingular}`:`${e} ${t.unitPlural}`}catch{return`0 ${t.unitPlural}`}},get image(){return e(`cat_`+t.id)||t.defaultImage}}));function me(){return`
    <section class="categories-section" id="categories">
      <div class="container">
        <!-- Section Header -->
        <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 36px; flex-wrap: wrap; gap: 20px;">
          <div style="max-width: 720px;">
            <span class="eyebrow">DISCOVER BY NEED</span>
            <h2 class="heading-section" style="margin-top: 12px;">
              Discover Properties Based on What You Actually Need
            </h2>
            <p style="color: var(--color-text-muted, #666); font-size: 0.95rem; margin-top: 8px; line-height: 1.6;">
              Every real estate aspiration is unique. Whether you are creating a family home, acquiring fertile farmland, or securing a strategic commercial asset, discover verified properties tailored to your vision.
            </p>
          </div>

          <!-- Left & Right Arrow Buttons -->
          <div style="display: flex; gap: 12px;">
            <button class="view-btn" id="cat-scroll-left" title="Scroll Left" style="width: 44px; height: 44px; border-radius: 50%; box-shadow: var(--shadow-sm); cursor: pointer;">
              <i class="ri-arrow-left-line" style="font-size: 1.25rem;"></i>
            </button>
            <button class="view-btn" id="cat-scroll-right" title="Scroll Right" style="width: 44px; height: 44px; border-radius: 50%; box-shadow: var(--shadow-sm); cursor: pointer;">
              <i class="ri-arrow-right-line" style="font-size: 1.25rem;"></i>
            </button>
          </div>
        </div>

        <!-- Marquee Carousel Wrapper (Scrollbar Hidden) -->
        <div class="categories-marquee-wrapper" id="categories-marquee-wrapper">
          <div class="categories-track-marquee" id="categories-marquee-track">
            ${[...k,...k,...k].map(e=>`
              <div class="category-visual-tile" data-category="${e.id}">
                <img src="${e.image}" alt="${e.name}" class="category-tile-img" />
                <div class="category-tile-content">
                  <span class="badge badge-orange" style="width: fit-content; margin-bottom: 8px;">
                    ${e.count}
                  </span>
                  <h3 class="font-serif" style="font-size: 1.5rem; color: var(--color-white); margin-bottom: 4px;">
                    ${e.name}
                  </h3>
                  <p style="font-size: 0.8125rem; color: rgba(255, 255, 255, 0.75);">
                    ${e.description}
                  </p>
                </div>
              </div>
            `).join(``)}
          </div>
        </div>
      </div>
    </section>
  `}function he(e){let t=document.getElementById(`categories-marquee-wrapper`),n=!1,r=!1;function i(){if(t&&!n&&!r){t.scrollLeft+=.8;let e=t.scrollWidth/3;t.scrollLeft>=e*2?t.scrollLeft-=e:t.scrollLeft<=0&&(t.scrollLeft+=e)}requestAnimationFrame(i)}requestAnimationFrame(i),t?.addEventListener(`mouseenter`,()=>{n=!0}),t?.addEventListener(`mouseleave`,()=>{n=!1}),document.getElementById(`cat-scroll-left`)?.addEventListener(`click`,e=>{e.preventDefault(),t&&(r=!0,t.scrollBy({left:-340,behavior:`smooth`}),setTimeout(()=>{r=!1},1500))}),document.getElementById(`cat-scroll-right`)?.addEventListener(`click`,e=>{e.preventDefault(),t&&(r=!0,t.scrollBy({left:340,behavior:`smooth`}),setTimeout(()=>{r=!1},1500))}),document.querySelectorAll(`.category-visual-tile`).forEach(t=>{t.addEventListener(`click`,()=>{let n=t.dataset.category;n&&(e(n),document.getElementById(`discovery`)?.scrollIntoView({behavior:`smooth`}))})})}function ge(){return`
    <!-- Dark Luxury Statement & Metrics -->
    <section class="dark-luxury-section">
      <div class="container">
        <div class="dark-luxury-inner">
          <span class="eyebrow eyebrow-center eyebrow-dark">WHY THANJAI PROPERTY?</span>
          
          <h2 class="heading-display-light" style="margin-top: 16px;">
            Local Understanding.<br>Wider Property Access.
          </h2>

          <div class="orange-divider-line"></div>

          <p style="color: rgba(255, 255, 255, 0.85); font-size: 1.05rem; max-width: 780px; margin: 0 auto; line-height: 1.7;">
            Location drives property value. We combine on-the-ground local expertise with verified listings across Tamil Nadu, making it easy to find land and homes that fit your goals.
          </p>

          <!-- Key Metrics Counter Grid -->
          <div class="stats-grid" id="luxury-stats-grid">
            <div class="stat-box">
              <div class="stat-number" data-target="38" data-suffix="">38</div>
              <div class="stat-label">Districts Covered</div>
            </div>
            <div class="stat-box">
              <div class="stat-number" data-target="2500" data-suffix="+" data-format="comma">2,500+</div>
              <div class="stat-label">Verified Listings</div>
            </div>
            <div class="stat-box">
              <div class="stat-number" data-target="100" data-suffix="%">100%</div>
              <div class="stat-label">Transparent Process</div>
            </div>
            <div class="stat-box">
              <div class="stat-number" data-target="10000" data-suffix="+" data-format="k">10k+</div>
              <div class="stat-label">Satisfied Buyers & NRIs</div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Trust Pillars Section -->
    <section class="trust-section" id="trust-section">
      <div class="container">

        <!-- Heading Block -->
        <div class="trust-heading-block" id="trust-heading-block">
          <div class="trust-eyebrow-row" style="justify-content: center; margin-bottom: 16px;">
            <span class="eyebrow eyebrow-center">OUR CORE VALUES</span>
          </div>
          <h2 class="heading-section trust-main-heading">
            Built Around the Real Needs of the Property Market
          </h2>
        </div>

        <!-- Cards Grid -->
        <div class="trust-pillars-grid" id="trust-pillars-grid">

          <!-- Card 01 -->
          <div class="trust-pillar-card trust-card-reveal" data-delay="0">
            <div class="pillar-bg-number" aria-hidden="true">01</div>
            <div class="pillar-icon-wrap">
              <i class="ri-map-pin-2-line pillar-icon"></i>
            </div>
            <div class="pillar-content">
              <h3 class="pillar-title">38-DISTRICT SEARCH</h3>
              <p class="pillar-desc">
                Explore property opportunities across all 38 districts of Tamil Nadu through location, taluk, and budget-based search.
              </p>
            </div>
            <div class="pillar-accent-line"></div>
          </div>

          <!-- Card 02 -->
          <div class="trust-pillar-card trust-card-reveal" data-delay="120">
            <div class="pillar-bg-number" aria-hidden="true">02</div>
            <div class="pillar-icon-wrap">
              <i class="ri-shield-check-line pillar-icon"></i>
            </div>
            <div class="pillar-content">
              <h3 class="pillar-title">VERIFIED LISTINGS & LEGAL</h3>
              <p class="pillar-desc">
                Listings reviewed for completeness and authenticity with legal partner support for sale deed drafting, EC verification, and SRO coordination.
              </p>
            </div>
            <div class="pillar-accent-line"></div>
          </div>

          <!-- Card 03 -->
          <div class="trust-pillar-card trust-card-reveal" data-delay="240">
            <div class="pillar-bg-number" aria-hidden="true">03</div>
            <div class="pillar-icon-wrap">
              <i class="ri-global-line pillar-icon"></i>
            </div>
            <div class="pillar-content">
              <h3 class="pillar-title">NRI ASSISTANCE & FAIRS</h3>
              <p class="pillar-desc">
                Dedicated overseas buyer assistance with virtual property viewing, documentation support, transaction coordination, and transparent pricing.
              </p>
            </div>
            <div class="pillar-accent-line"></div>
          </div>

        </div>

        <!-- FREQUENTLY ASKED QUESTIONS ACCORDION SECTION -->
        <div style="margin-top: 80px; background: #faf8f5; border-radius: 24px; padding: 40px; border: 1px solid rgba(0,0,0,0.06);">
          <div style="text-align: center; max-width: 640px; margin: 0 auto 36px auto;">
            <span class="eyebrow eyebrow-center" style="color: var(--color-orange); font-weight: 800; letter-spacing: 0.12em;">FREQUENTLY ASKED QUESTIONS</span>
            <h2 style="font-family: var(--font-serif); font-size: 2.1rem; font-weight: 800; color: #1a1a1a; margin-top: 8px;">
              Everything You Need to Know
            </h2>
            <p style="color: #666; font-size: 0.95rem; margin-top: 6px;">Click on any question below to expand and study the details.</p>
          </div>

          <div class="faq-accordion-container" style="max-width: 860px; margin: 0 auto; display: flex; flex-direction: column; gap: 14px;">
            
            <!-- Question 1 -->
            <div class="faq-accordion-item active" style="background: #ffffff; border: 1px solid rgba(0,0,0,0.08); border-radius: 16px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.02); transition: all 0.3s ease;">
              <button class="faq-accordion-header" style="width: 100%; padding: 20px 24px; background: transparent; border: none; font-size: 1.05rem; font-weight: 700; color: #1a1a1a; text-align: left; display: flex; justify-content: space-between; align-items: center; cursor: pointer; gap: 16px;">
                <span>1. What types of properties are available on Thanjai Property?</span>
                <div class="faq-icon-wrap" style="width: 32px; height: 32px; border-radius: 50%; background: #eb5e28; color: #ffffff; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease; flex-shrink: 0;">
                  <i class="ri-subtract-line" style="font-size: 1.1rem;"></i>
                </div>
              </button>
              <div class="faq-accordion-body" style="padding: 0 24px 20px 24px; max-height: 500px; overflow: hidden; transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);">
                <p style="font-size: 0.95rem; color: #4a5568; line-height: 1.7; margin: 0;">Thanjai Property lists residential houses, villas, apartments, plots, agricultural land, commercial spaces, industrial land, buildings, warehouses, commercial offices, showrooms and farm-related properties across Tamil Nadu.</p>
              </div>
            </div>

            <!-- Question 2 -->
            <div class="faq-accordion-item" style="background: #ffffff; border: 1px solid rgba(0,0,0,0.08); border-radius: 16px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.02); transition: all 0.3s ease;">
              <button class="faq-accordion-header" style="width: 100%; padding: 20px 24px; background: transparent; border: none; font-size: 1.05rem; font-weight: 700; color: #1a1a1a; text-align: left; display: flex; justify-content: space-between; align-items: center; cursor: pointer; gap: 16px;">
                <span>2. Can I search for properties by district?</span>
                <div class="faq-icon-wrap" style="width: 32px; height: 32px; border-radius: 50%; background: #f0f4f8; color: #2d3748; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease; flex-shrink: 0;">
                  <i class="ri-add-line" style="font-size: 1.1rem;"></i>
                </div>
              </button>
              <div class="faq-accordion-body" style="padding: 0 24px 0 24px; max-height: 0; overflow: hidden; transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);">
                <p style="font-size: 0.95rem; color: #4a5568; line-height: 1.7; margin: 0;">Yes. Property seekers can browse properties by district, with the platform currently supporting searches across all 38 districts of Tamil Nadu.</p>
              </div>
            </div>

            <!-- Question 3 -->
            <div class="faq-accordion-item" style="background: #ffffff; border: 1px solid rgba(0,0,0,0.08); border-radius: 16px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.02); transition: all 0.3s ease;">
              <button class="faq-accordion-header" style="width: 100%; padding: 20px 24px; background: transparent; border: none; font-size: 1.05rem; font-weight: 700; color: #1a1a1a; text-align: left; display: flex; justify-content: space-between; align-items: center; cursor: pointer; gap: 16px;">
                <span>3. Can I search by budget?</span>
                <div class="faq-icon-wrap" style="width: 32px; height: 32px; border-radius: 50%; background: #f0f4f8; color: #2d3748; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease; flex-shrink: 0;">
                  <i class="ri-add-line" style="font-size: 1.1rem;"></i>
                </div>
              </button>
              <div class="faq-accordion-body" style="padding: 0 24px 0 24px; max-height: 0; overflow: hidden; transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);">
                <p style="font-size: 0.95rem; color: #4a5568; line-height: 1.7; margin: 0;">Yes. The property search interface includes budget ranges, allowing users to narrow property results according to their preferred price range.</p>
              </div>
            </div>

            <!-- Question 4 -->
            <div class="faq-accordion-item" style="background: #ffffff; border: 1px solid rgba(0,0,0,0.08); border-radius: 16px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.02); transition: all 0.3s ease;">
              <button class="faq-accordion-header" style="width: 100%; padding: 20px 24px; background: transparent; border: none; font-size: 1.05rem; font-weight: 700; color: #1a1a1a; text-align: left; display: flex; justify-content: space-between; align-items: center; cursor: pointer; gap: 16px;">
                <span>4. Can I search by taluk?</span>
                <div class="faq-icon-wrap" style="width: 32px; height: 32px; border-radius: 50%; background: #f0f4f8; color: #2d3748; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease; flex-shrink: 0;">
                  <i class="ri-add-line" style="font-size: 1.1rem;"></i>
                </div>
              </button>
              <div class="faq-accordion-body" style="padding: 0 24px 0 24px; max-height: 0; overflow: hidden; transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);">
                <p style="font-size: 0.95rem; color: #4a5568; line-height: 1.7; margin: 0;">Yes. The advanced property search includes both district and taluk filters, helping users narrow their search to a more specific location.</p>
              </div>
            </div>

            <!-- Question 5 -->
            <div class="faq-accordion-item" style="background: #ffffff; border: 1px solid rgba(0,0,0,0.08); border-radius: 16px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.02); transition: all 0.3s ease;">
              <button class="faq-accordion-header" style="width: 100%; padding: 20px 24px; background: transparent; border: none; font-size: 1.05rem; font-weight: 700; color: #1a1a1a; text-align: left; display: flex; justify-content: space-between; align-items: center; cursor: pointer; gap: 16px;">
                <span>5. Can I sell my property through Thanjai Property?</span>
                <div class="faq-icon-wrap" style="width: 32px; height: 32px; border-radius: 50%; background: #f0f4f8; color: #2d3748; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease; flex-shrink: 0;">
                  <i class="ri-add-line" style="font-size: 1.1rem;"></i>
                </div>
              </button>
              <div class="faq-accordion-body" style="padding: 0 24px 0 24px; max-height: 0; overflow: hidden; transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);">
                <p style="font-size: 0.95rem; color: #4a5568; line-height: 1.7; margin: 0;">Yes. Property owners can post their properties by adding relevant information and images through the Post Property option. Basic property listing is currently offered free of charge.</p>
              </div>
            </div>

            <!-- Question 6 -->
            <div class="faq-accordion-item" style="background: #ffffff; border: 1px solid rgba(0,0,0,0.08); border-radius: 16px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.02); transition: all 0.3s ease;">
              <button class="faq-accordion-header" style="width: 100%; padding: 20px 24px; background: transparent; border: none; font-size: 1.05rem; font-weight: 700; color: #1a1a1a; text-align: left; display: flex; justify-content: space-between; align-items: center; cursor: pointer; gap: 16px;">
                <span>6. How are property listings reviewed?</span>
                <div class="faq-icon-wrap" style="width: 32px; height: 32px; border-radius: 50%; background: #f0f4f8; color: #2d3748; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease; flex-shrink: 0;">
                  <i class="ri-add-line" style="font-size: 1.1rem;"></i>
                </div>
              </button>
              <div class="faq-accordion-body" style="padding: 0 24px 0 24px; max-height: 0; overflow: hidden; transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);">
                <p style="font-size: 0.95rem; color: #4a5568; line-height: 1.7; margin: 0;">All property listings are reviewed for authenticity by our team, and seller details are verified before publication. We also provide legal assistance to help buyers verify Patta and title deeds.</p>
              </div>
            </div>

            <!-- Question 7 -->
            <div class="faq-accordion-item" style="background: #ffffff; border: 1px solid rgba(0,0,0,0.08); border-radius: 16px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.02); transition: all 0.3s ease;">
              <button class="faq-accordion-header" style="width: 100%; padding: 20px 24px; background: transparent; border: none; font-size: 1.05rem; font-weight: 700; color: #1a1a1a; text-align: left; display: flex; justify-content: space-between; align-items: center; cursor: pointer; gap: 16px;">
                <span>7. Does Thanjai Property assist NRI property buyers?</span>
                <div class="faq-icon-wrap" style="width: 32px; height: 32px; border-radius: 50%; background: #f0f4f8; color: #2d3748; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease; flex-shrink: 0;">
                  <i class="ri-add-line" style="font-size: 1.1rem;"></i>
                </div>
              </button>
              <div class="faq-accordion-body" style="padding: 0 24px 0 24px; max-height: 0; overflow: hidden; transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);">
                <p style="font-size: 0.95rem; color: #4a5568; line-height: 1.7; margin: 0;">Yes. The platform provides dedicated NRI assistance covering areas such as legal documentation, virtual property viewing and transaction management.</p>
              </div>
            </div>

            <!-- Question 8 -->
            <div class="faq-accordion-item" style="background: #ffffff; border: 1px solid rgba(0,0,0,0.08); border-radius: 16px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.02); transition: all 0.3s ease;">
              <button class="faq-accordion-header" style="width: 100%; padding: 20px 24px; background: transparent; border: none; font-size: 1.05rem; font-weight: 700; color: #1a1a1a; text-align: left; display: flex; justify-content: space-between; align-items: center; cursor: pointer; gap: 16px;">
                <span>8. Is legal support available for property registration?</span>
                <div class="faq-icon-wrap" style="width: 32px; height: 32px; border-radius: 50%; background: #f0f4f8; color: #2d3748; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease; flex-shrink: 0;">
                  <i class="ri-add-line" style="font-size: 1.1rem;"></i>
                </div>
              </button>
              <div class="faq-accordion-body" style="padding: 0 24px 0 24px; max-height: 0; overflow: hidden; transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);">
                <p style="font-size: 0.95rem; color: #4a5568; line-height: 1.7; margin: 0;">Thanjai Property states that its legal partners assist with sale deed drafting, EC verification and coordination of the registration process at the Sub-Registrar office.</p>
              </div>
            </div>

            <!-- Question 9 -->
            <div class="faq-accordion-item" style="background: #ffffff; border: 1px solid rgba(0,0,0,0.08); border-radius: 16px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.02); transition: all 0.3s ease;">
              <button class="faq-accordion-header" style="width: 100%; padding: 20px 24px; background: transparent; border: none; font-size: 1.05rem; font-weight: 700; color: #1a1a1a; text-align: left; display: flex; justify-content: space-between; align-items: center; cursor: pointer; gap: 16px;">
                <span>9. Can I find properties for rent?</span>
                <div class="faq-icon-wrap" style="width: 32px; height: 32px; border-radius: 50%; background: #f0f4f8; color: #2d3748; display: flex; align-items: center; justify-content: center; transition: all 0.3s ease; flex-shrink: 0;">
                  <i class="ri-add-line" style="font-size: 1.1rem;"></i>
                </div>
              </button>
              <div class="faq-accordion-body" style="padding: 0 24px 0 24px; max-height: 0; overflow: hidden; transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1);">
                <p style="font-size: 0.95rem; color: #4a5568; line-height: 1.7; margin: 0;">Yes. Thanjai Property provides rental property search options across multiple Tamil Nadu districts.</p>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  `}function _e(){let e=document.querySelectorAll(`.faq-accordion-item`);e.forEach(t=>{t.querySelector(`.faq-accordion-header`)?.addEventListener(`click`,()=>{let n=t.classList.contains(`active`);if(e.forEach(e=>{e.classList.remove(`active`);let t=e.querySelector(`.faq-accordion-body`),n=e.querySelector(`.faq-icon-wrap i`),r=e.querySelector(`.faq-icon-wrap`);t&&(t.style.maxHeight=`0`,t.style.paddingBottom=`0`),n&&(n.className=`ri-add-line`),r&&(r.style.background=`#f0f4f8`,r.style.color=`#2d3748`)}),!n){t.classList.add(`active`);let e=t.querySelector(`.faq-accordion-body`),n=t.querySelector(`.faq-icon-wrap i`),r=t.querySelector(`.faq-icon-wrap`);e&&(e.style.maxHeight=e.scrollHeight+40+`px`,e.style.paddingBottom=`20px`),n&&(n.className=`ri-subtract-line`),r&&(r.style.background=`#eb5e28`,r.style.color=`#ffffff`)}})});let t=document.getElementById(`luxury-stats-grid`);if(!t)return;let n=t.querySelectorAll(`.stat-number[data-target]`),r=!1;function i(e,t){return t===`k`?e>=1e3?Math.floor(e/1e3)+`k`:e:t===`comma`?e.toLocaleString(`en-IN`):e}function a(e){let t=parseInt(e.dataset.target,10),n=e.dataset.suffix||``,r=e.dataset.format||``,a=performance.now();function o(s){let c=s-a,l=Math.min(c/1800,1),u=1-(1-l)**3;e.textContent=i(Math.floor(u*t),r)+n,l<1?requestAnimationFrame(o):e.textContent=i(t,r)+n}requestAnimationFrame(o)}let o=new IntersectionObserver(e=>{e.forEach(e=>{e.isIntersecting&&!r&&(r=!0,n.forEach((e,t)=>{setTimeout(()=>a(e),t*150)}),o.disconnect())})},{threshold:.3});o.observe(t);let s=window.matchMedia(`(prefers-reduced-motion: reduce)`).matches,c=document.getElementById(`trust-heading-block`),l=document.querySelectorAll(`.trust-card-reveal`);if(s){c&&c.classList.add(`trust-heading-visible`),l.forEach(e=>e.classList.add(`trust-card-visible`));return}if(c){let e=new IntersectionObserver(t=>{t.forEach(t=>{t.isIntersecting&&(c.classList.add(`trust-heading-visible`),e.disconnect())})},{threshold:.2});e.observe(c)}let u=new IntersectionObserver(e=>{e.forEach(e=>{e.isIntersecting&&(l.forEach(e=>{let t=parseInt(e.dataset.delay||`0`,10);setTimeout(()=>e.classList.add(`trust-card-visible`),t)}),u.disconnect())})},{threshold:.15}),d=document.getElementById(`trust-pillars-grid`);d&&u.observe(d)}function ve(e,t){return`
    <section class="blog-home-section" id="home-blog-section" style="padding: 90px 0; background: #faf8f5; border-top: 1px solid rgba(0,0,0,0.05);">
      <div class="container">
        
        <!-- Section Header -->
        <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 44px; flex-wrap: wrap; gap: 20px;">
          <div>
            <span class="eyebrow" style="color: var(--color-orange, #eb5e28); font-weight: 800; letter-spacing: 0.12em;">REAL-ESTATE INSIGHTS</span>
            <h2 class="heading-section" style="margin-top: 10px;">
              Real-Estate Insights for Better Property Decisions
            </h2>
            <div style="font-size: 0.95rem; font-weight: 700; color: #4a5568; margin-top: 4px;">Learn Before You Buy, Sell or Invest</div>
          </div>
        </div>

        <!-- 3 Cards Grid -->
        <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 28px;">
          ${_().slice(0,3).map(e=>`
            <article class="blog-card hover-lift" data-id="${e.id}" data-slug="${e.slug||``}" style="
              background: #ffffff;
              border-radius: 16px;
              overflow: hidden;
              border: 1px solid rgba(0,0,0,0.07);
              box-shadow: 0 4px 18px rgba(0,0,0,0.03);
              display: flex;
              flex-direction: column;
              cursor: pointer;
              transition: transform 0.3s ease, box-shadow 0.3s ease;
            ">
              <div style="position: relative; width: 100%; aspect-ratio: 16/9; overflow: hidden; background: #1a1a1a;">
                <img src="${e.image}" alt="${e.title}" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.4s ease;" />
                <span class="badge badge-orange" style="position: absolute; top: 16px; left: 16px; font-size: 0.75rem;">
                  ${e.category}
                </span>
              </div>

              <div style="padding: 24px; display: flex; flex-direction: column; flex: 1;">
                <div style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #777; margin-bottom: 12px;">
                  <i class="ri-calendar-line" style="color: #eb5e28;"></i>
                  <span>Published on ${e.date}</span>
                </div>

                <h3 style="font-family: var(--font-serif); font-size: 1.25rem; font-weight: 700; color: #1a1a1a; line-height: 1.4; margin-bottom: 12px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                  ${e.title}
                </h3>

                <p style="font-size: 0.9rem; color: #666; line-height: 1.6; margin-bottom: 20px; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;">
                  ${e.excerpt}
                </p>

                <div style="margin-top: auto; display: flex; align-items: center; gap: 6px; font-weight: 700; font-size: 0.88rem; color: var(--color-orange, #eb5e28);">
                  <span>Read Article</span>
                  <i class="ri-arrow-right-line" style="transition: transform 0.2s;"></i>
                </div>
              </div>
            </article>
          `).join(``)}
        </div>

        <div style="text-align: center; margin-top: 48px;">
          <button class="btn btn-brown explore-blog-nav-btn" id="home-explore-blog-btn" style="display: inline-flex; align-items: center; gap: 8px; padding: 14px 32px; font-size: 1.05rem; border-radius: 12px;">
            <span>Explore All Articles</span>
            <i class="ri-arrow-right-line"></i>
          </button>
        </div>
      </div>
    </section>
  `}function ye(e,t){document.getElementById(`home-explore-blog-btn`)?.addEventListener(`click`,e),document.querySelectorAll(`.blog-card`).forEach(e=>{e.addEventListener(`click`,()=>{let n=e.dataset.slug||e.dataset.id;n&&t&&t(n)})})}function be(e){return`
    <section class="home-contact-banner-section" style="padding: 90px 0; background: linear-gradient(135deg, #1c1007 0%, #2a1808 60%, #150b04 100%); color: #ffffff;">
      <div class="container">
        <div style="
          background: rgba(255, 255, 255, 0.04); border: 1px solid rgba(255, 255, 255, 0.12);
          border-radius: 24px; padding: 48px; display: flex; justify-content: space-between;
          align-items: center; flex-wrap: wrap; gap: 30px; backdrop-filter: blur(10px);
        ">
          <div style="max-width: 680px;">
            <span class="eyebrow eyebrow-dark" style="margin-bottom: 12px; display: inline-block;">
              <i class="ri-search-eye-line" style="color: var(--color-orange, #eb5e28);"></i> YOUR PROPERTY SEARCH STARTS HERE
            </span>
            <h2 class="heading-display-light" style="font-size: clamp(1.8rem, 3.5vw, 2.6rem); margin-bottom: 14px; color: #ffffff;">
              Search With Purpose.<br>Explore With Confidence.
            </h2>
            <p style="color: rgba(255, 255, 255, 0.85); font-size: 1.02rem; line-height: 1.65; margin: 0;">
              Whether you are looking for your first home, a residential plot, agricultural land, an apartment, a villa, a commercial property or an investment opportunity, the right starting point is a property search built around your needs across Tamil Nadu.
            </p>
          </div>

          <div style="display: flex; gap: 16px; flex-wrap: wrap;">
            <button class="btn btn-primary" id="home-banner-contact-btn" style="padding: 16px 36px; font-size: 1rem; border-radius: 12px;">
              <span>Go to Contact Page</span>
              <i class="ri-arrow-right-line"></i>
            </button>
          </div>
        </div>
      </div>
    </section>
  `}function xe(e){document.getElementById(`home-banner-contact-btn`)?.addEventListener(`click`,e)}function A(){return`
    <footer class="footer-section">
      <div class="container">
        <div class="footer-grid">
          
          <!-- Col 1: ABOUT THANJAI PROPERTY -->
          <div>
            <h4 class="footer-col-title">ABOUT THANJAI PROPERTY</h4>
            
            <a href="/" class="footer-logo nav-route-link" data-route="home" style="display: inline-block; margin-bottom: 18px;">
              <img src="${e(`brand_logo`)}" alt="Thanjai Property Logo" style="height: 64px; max-width: 100%; width: auto; background: #ffffff; border-radius: 10px; padding: 6px 14px; display: block; box-shadow: 0 4px 12px rgba(0,0,0,0.15);" />
            </a>

            <p style="color: rgba(255, 255, 255, 0.78); font-size: 0.92rem; line-height: 1.75; margin-bottom: 16px; text-align: justify;">
              Thanjai Property is a leading real estate consultancy and land promoter in Thanjavur, helping you buy, sell, and rent residential, agricultural, and commercial properties across Tamil Nadu. Explore handpicked properties across Tamil Nadu. Find houses, villas, plots, farmlands, and commercial spaces with verified prices, clear sizes, and exact locations.
            </p>

          </div>

          <!-- Col 2: OUR OFFICE -->
          <div>
            <h4 class="footer-col-title">OUR OFFICE</h4>
            
            <div style="color: var(--color-orange, #eb5e28); font-weight: 700; font-size: 0.95rem; margin-bottom: 12px; text-transform: uppercase;">
              THANJAI PROPERTY
            </div>

            <div style="display: flex; flex-direction: column; gap: 8px; font-size: 0.9375rem; color: rgba(255, 255, 255, 0.7); line-height: 1.6;">
              <span>Flat No B1, 2nd Floor, Sivasakthi Apartment,</span>
              <span>Raja Nagar, Behind HDFC Bank, Near New Bus Stand,</span>
              <span>Thanjavur - 613005</span>
            </div>
          </div>

          <!-- Col 3: OVERVIEW -->
          <div>
            <h4 class="footer-col-title">OVERVIEW</h4>
            <ul class="footer-links-list">
              <li><a href="/our-story" class="nav-route-link" data-route="our-story">Our Story</a></li>
              <li><a href="/find-your-property" class="nav-route-link" data-route="discover">Find Your Property</a></li>
              <li><a href="/blog" class="nav-route-link" data-route="blog">Blog</a></li>
              <li><a href="/contact" class="nav-route-link" data-route="contact">Contact Us</a></li>
              <li><a href="/privacy-policy" class="nav-route-link" data-route="privacy">Privacy Policy</a></li>
              <li><a href="/terms-of-use" class="nav-route-link" data-route="terms">Terms of Use</a></li>
            </ul>
          </div>

          <!-- Col 4: OUR SOCIAL MEDIA -->
          <div>
            <h4 class="footer-col-title">OUR SOCIAL MEDIA</h4>
            <ul class="footer-social-list">
              <li>
                <a href="https://www.facebook.com/profile.php?id=100063582174179" target="_blank" rel="noopener noreferrer" class="social-link" title="Follow Thanjai Property on Facebook">
                  <i class="ri-facebook-fill"></i> Facebook
                </a>
              </li>
              <li>
                <a href="https://x.com/thanjaiproperty" target="_blank" rel="noopener noreferrer" class="social-link" title="Follow Thanjai Property on X (Twitter)">
                  <i class="ri-twitter-x-fill"></i> Twitter (X)
                </a>
              </li>
              <li>
                <a href="https://www.youtube.com/channel/UCfAePuCC2OaNrgVT8Ix5xww?view_as=subscriber" target="_blank" rel="noopener noreferrer" class="social-link" title="Subscribe to Thanjai Property YouTube Channel">
                  <i class="ri-youtube-fill"></i> YouTube
                </a>
              </li>
              <li>
                <a href="https://www.linkedin.com/in/thanjai-property-9812422b/" target="_blank" rel="noopener noreferrer" class="social-link" title="Connect with Thanjai Property on LinkedIn">
                  <i class="ri-linkedin-fill"></i> LinkedIn
                </a>
              </li>
            </ul>
          </div>

        </div>

        <div class="footer-bottom">
          <div>© 2009–2026 Thanjai Property Real Estate. All rights reserved.</div>
        </div>
      </div>
    </footer>
  `}function j(){return``}var Se={init:()=>{}};function Ce(){return`
    <div class="modal-overlay active" id="post-property-modal-overlay">
      <div class="property-modal-card" style="max-width: 680px; padding: 40px;">
        <button class="modal-close-btn" id="close-post-modal-btn">
          <i class="ri-close-line"></i>
        </button>

        <div style="margin-bottom: 24px;">
          <span class="eyebrow">SUBMIT YOUR PROPERTY</span>
          <h2 class="font-serif" style="font-size: 2rem; color: var(--color-brown); margin-top: 6px;">
            List Your Property on Thanjai Property
          </h2>
          <p style="font-size: 0.875rem; color: var(--color-text-muted);">
            Reach verified buyers and high-net-worth investors across Tamil Nadu.
          </p>
        </div>

        <form id="post-property-form" onsubmit="return false;">
          <div style="display: flex; flex-direction: column; gap: 20px;">
            <div class="search-field-group">
              <label class="search-field-label"><i class="ri-pencil-line"></i> Property Title</label>
              <input type="text" id="post-title" required placeholder="e.g. 3BHK Luxury Villa with Garden" class="search-input" />
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
              <div class="search-field-group">
                <label class="search-field-label"><i class="ri-price-tag-3-line"></i> Purpose</label>
                <select id="post-purpose" class="search-select">
                  <option value="buy">For Sale</option>
                  <option value="rent">For Rent</option>
                </select>
              </div>

              <div class="search-field-group">
                <label class="search-field-label"><i class="ri-building-line"></i> Category</label>
                <select id="post-category" class="search-select">
                  <option value="Villa">Luxury Villa</option>
                  <option value="Townhouse">Independent House</option>
                  <option value="Apartment">Apartment / Flat</option>
                  <option value="Plot">Residential Plot</option>
                  <option value="Plot">Agricultural Farmland</option>
                  <option value="Office">Commercial Space</option>
                </select>
              </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
              <div class="search-field-group">
                <label class="search-field-label"><i class="ri-map-pin-line"></i> City / District</label>
                <select id="post-city" class="search-select">
                  <option value="Thanjavur">Thanjavur</option>
                  <option value="Trichy">Trichy</option>
                  <option value="Madurai">Madurai</option>
                  <option value="Chennai">Chennai</option>
                  <option value="Coimbatore">Coimbatore</option>
                  <option value="Kumbakonam">Kumbakonam</option>
                </select>
              </div>

              <div class="search-field-group">
                <label class="search-field-label"><i class="ri-money-rupee-circle-line"></i> Expected Price (₹)</label>
                <input type="number" id="post-price" required placeholder="e.g. 7500000" class="search-input" />
              </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
              <div class="search-field-group">
                <label class="search-field-label"><i class="ri-user-3-line"></i> Owner Full Name</label>
                <input type="text" id="post-owner-name" required placeholder="Your Name" class="search-input" />
              </div>

              <div class="search-field-group">
                <label class="search-field-label"><i class="ri-phone-line"></i> Mobile Phone (+91)</label>
                <input type="tel" id="post-owner-phone" required placeholder="10-digit number" maxlength="10" pattern="[0-9]{10}" oninput="this.value = this.value.replace(/[^0-9]/g, '')" class="search-input" />
              </div>
            </div>

            <!-- Upload Area Simulation -->
            <div style="border: 2px dashed var(--color-border); border-radius: var(--radius-md); padding: 24px; text-align: center; background: var(--color-cream-light);">
              <i class="ri-image-add-line" style="font-size: 2.25rem; color: var(--color-orange);"></i>
              <div style="font-size: 0.875rem; font-weight: 700; color: var(--color-brown); margin-top: 8px;">Upload Property Photos</div>
              <div style="font-size: 0.75rem; color: var(--color-text-muted);">Standard high-resolution photos attached automatically</div>
            </div>

            <button type="submit" class="btn btn-primary" style="padding: 16px; font-size: 1rem; width: 100%;">
              <i class="ri-send-plane-fill"></i> SUBMIT PROPERTY LISTING
            </button>
          </div>
        </form>
      </div>
    </div>
  `}function we(e){let t=document.getElementById(`post-property-modal-overlay`);document.getElementById(`close-post-modal-btn`)?.addEventListener(`click`,()=>{t?.classList.remove(`active`),setTimeout(e,300)}),t?.addEventListener(`click`,n=>{n.target===t&&(t.classList.remove(`active`),setTimeout(e,300))}),document.getElementById(`post-property-form`)?.addEventListener(`submit`,r=>{r.preventDefault();let i=document.getElementById(`post-title`)?.value.trim(),a=document.getElementById(`post-category`)?.value||`Villa`,o=document.getElementById(`post-purpose`)?.value||`buy`,s=document.getElementById(`post-city`)?.value||`Thanjavur`,c=document.getElementById(`post-price`)?.value,l=document.getElementById(`post-owner-name`)?.value.trim(),u=document.getElementById(`post-owner-phone`)?.value.trim(),f=d({title:i||`Submitted Property`,type:a,category:o===`rent`?`Rent`:`Sale`,location:`${s}, Tamil Nadu`,district:s,price:parseFloat(c)||0,ownerName:l||`Property Owner`,ownerPhone:u||``,listedBy:l||`Website Submission`,status:`Pending Approval`,approvalStatus:`Pending Approval`,availability:`Pending`});n(`Success! Property ${f.id} submitted for review.`,`ri-checkbox-circle-fill`),t?.classList.remove(`active`),setTimeout(e,300)})}function Te(e={}){let t=e.propertyTitle||`Luxury Property Visit`;return`
    <div class="modal-overlay active" id="schedule-visit-modal-overlay">
      <div class="property-modal-card" style="max-width: 540px; padding: 40px;">
        <button class="modal-close-btn" id="close-schedule-modal-btn">
          <i class="ri-close-line"></i>
        </button>

        <div style="margin-bottom: 24px;">
          <span class="eyebrow">PRIVATE SITE TOUR</span>
          <h2 class="font-serif" style="font-size: 1.85rem; color: var(--color-brown); margin-top: 6px;">
            Schedule a Private Visit
          </h2>
          <p style="font-size: 0.875rem; color: var(--color-orange); font-weight: 700;">
            ${t}
          </p>
        </div>

        <form id="schedule-visit-form">
          <input type="hidden" id="sv-prop-title" value="${t}" />
          <input type="hidden" id="sv-prop-id" value="${e.propertyId||``}" />
          <div style="display: flex; flex-direction: column; gap: 16px;">
            <div class="search-field-group">
              <label class="search-field-label"><i class="ri-user-line"></i> Your Full Name</label>
              <input type="text" id="sv-name" required placeholder="Enter name" class="search-input" />
            </div>

            <div class="search-field-group">
              <label class="search-field-label"><i class="ri-phone-line"></i> Phone Number</label>
              <input type="tel" id="sv-phone" required placeholder="10-digit number" maxlength="10" pattern="[0-9]{10}" oninput="this.value = this.value.replace(/[^0-9]/g, '')" class="search-input" />
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
              <div class="search-field-group">
                <label class="search-field-label"><i class="ri-calendar-line"></i> Preferred Date</label>
                <input type="date" id="sv-date" required class="search-input" />
              </div>

              <div class="search-field-group">
                <label class="search-field-label"><i class="ri-time-line"></i> Time Slot</label>
                <select id="sv-slot" class="search-select">
                  <option value="10:00 AM - 12:00 PM">Morning (10 AM - 12 PM)</option>
                  <option value="02:00 PM - 04:00 PM">Afternoon (2 PM - 4 PM)</option>
                  <option value="04:00 PM - 06:00 PM">Evening (4 PM - 6 PM)</option>
                </select>
              </div>
            </div>

            <button type="submit" id="sv-submit-btn" class="btn btn-brown" style="padding: 14px; font-size: 1rem; width: 100%; margin-top: 8px;">
              <i class="ri-calendar-check-line"></i> CONFIRM VISIT SCHEDULE
            </button>
          </div>
        </form>
      </div>
    </div>
  `}function Ee(e){let r=document.getElementById(`schedule-visit-modal-overlay`);document.getElementById(`close-schedule-modal-btn`)?.addEventListener(`click`,()=>{r?.classList.remove(`active`),setTimeout(e,300)}),r?.addEventListener(`click`,t=>{t.target===r&&(r.classList.remove(`active`),setTimeout(e,300))}),document.getElementById(`schedule-visit-form`)?.addEventListener(`submit`,async i=>{i.preventDefault();let a=document.getElementById(`sv-name`)?.value.trim(),o=document.getElementById(`sv-phone`)?.value.trim(),s=document.getElementById(`sv-date`)?.value,c=document.getElementById(`sv-slot`)?.value,u=document.getElementById(`sv-prop-title`)?.value||`Luxury Property`,d=document.getElementById(`sv-prop-id`)?.value||``,f=document.getElementById(`sv-submit-btn`);if(!a||!o||!s)return;f&&(f.disabled=!0,f.innerHTML=`<i class="ri-loader-4-line ri-spin"></i> Scheduling...`);let p=o.replace(/\D/g,``),m=p.length===10?`+91${p}`:`+${p}`,h=`L-${Date.now()}`,g=`SV-${Date.now()}`,_={id:h,name:a,phone:m,mobile:m,email:``,type:`Site Visit`,location:`Thanjavur`,budget:`Site Tour Requested`,stage:`Site Visit Scheduled`,source:`Property Inquiry`,date:new Date().toISOString().split(`T`)[0],assignedTo:`Unassigned`,priority:`High`,propertyId:d,timeline:[{type:`whatsapp_incoming`,date:new Date().toISOString(),message:`📅 Site visit booked for "${u}" on ${s} (${c})`,note:`Site Visit: ${s} ${c}`},{type:`whatsapp`,date:new Date().toISOString(),message:`🤖 Auto-sent WhatsApp Visit Confirmation to ${a} (${m})`,note:`Campaign: stage_site_visit_scheduled`}]};if(d)try{l(d)}catch{}try{let e=JSON.parse(localStorage.getItem(`thanjai_leads`))||[];e.unshift(_),localStorage.setItem(`thanjai_leads`,JSON.stringify(e)),window.dispatchEvent(new Event(`storage`))}catch{}try{await t(`/leads`,{method:`POST`,body:JSON.stringify(_)})}catch{}try{await t(`/site_visits`,{method:`POST`,body:JSON.stringify({id:g,leadId:h,clientName:a,clientPhone:m,propertyName:u,propertyId:d,visitDate:s,visitTime:c,status:`Scheduled`,notes:`Booked via website schedule visit modal`})})}catch{}let v=`Hello ${a}, Your site visit for "${u}" has been scheduled for ${s} (${c}). Our field manager will assist you with plot boundaries, layout review, and Patta verification. Official Desk: +91 84899 96852.`;try{await t(`/whatsapp_logs`,{method:`POST`,body:JSON.stringify({id:`WA-${Date.now()}`,leadId:h,phone:m,sender:`Super Admin`,recipientName:a,message:v,type:`outbound`})})}catch{}try{await t(`/send_whatsapp`,{method:`POST`,body:JSON.stringify({campaignName:`stage_site_visit_scheduled`,destination:m,userName:a,leadId:h,templateParams:[a,u,`${s} (${c})`,`our Location Manager at +91 84899 96852`]})})}catch{}n(`Tour Scheduled! We've sent WhatsApp confirmation to ${m}.`,`ri-calendar-check-line`),r?.classList.remove(`active`),setTimeout(e,300)})}function De(){if(window.matchMedia(`(hover: none) and (pointer: coarse)`).matches||document.getElementById(`thanjai-cursor-dot`))return;let e=document.createElement(`style`);e.id=`thanjai-building-cursor-styles`,e.textContent=`
    /* Luxury Architectural Building Cursor */
    #thanjai-cursor-dot {
      position: fixed;
      top: 0;
      left: 0;
      width: 7px;
      height: 7px;
      background: #eb5e28;
      border-radius: 50%;
      pointer-events: none;
      z-index: 9999999;
      transform: translate(-50%, -50%);
      transition: transform 0.08s ease, opacity 0.2s ease, width 0.2s ease, height 0.2s ease;
      box-shadow: 0 0 10px rgba(235, 94, 40, 0.7);
      opacity: 0;
    }

    #thanjai-cursor-building {
      position: fixed;
      top: 0;
      left: 0;
      width: 38px;
      height: 38px;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.88);
      border: 1.5px solid rgba(235, 94, 40, 0.55);
      backdrop-filter: blur(6px);
      -webkit-backdrop-filter: blur(6px);
      pointer-events: none;
      z-index: 9999998;
      transform: translate(-50%, -50%);
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 4px 18px rgba(235, 94, 40, 0.22), inset 0 0 8px rgba(235, 94, 40, 0.08);
      transition: width 0.25s cubic-bezier(0.16, 1, 0.3, 1), 
                  height 0.25s cubic-bezier(0.16, 1, 0.3, 1), 
                  background 0.25s ease, 
                  border-color 0.25s ease,
                  box-shadow 0.25s ease,
                  opacity 0.25s ease;
      opacity: 0;
    }

    #thanjai-cursor-building svg {
      width: 20px;
      height: 20px;
      fill: #eb5e28;
      transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1), fill 0.2s ease;
      filter: drop-shadow(0 1px 2px rgba(235, 94, 40, 0.3));
    }

    /* Hover on Interactive Elements */
    body.cursor-hover #thanjai-cursor-dot {
      width: 0;
      height: 0;
      opacity: 0;
    }

    body.cursor-hover #thanjai-cursor-building {
      width: 52px;
      height: 52px;
      background: rgba(235, 94, 40, 0.92);
      border-color: #eb5e28;
      box-shadow: 0 8px 24px rgba(235, 94, 40, 0.45);
      transform: translate(-50%, -50%) rotate(-4deg);
    }

    body.cursor-hover #thanjai-cursor-building svg {
      fill: #ffffff;
      transform: scale(1.2);
      filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.2));
    }

    /* Mouse Down Active Click */
    body.cursor-active #thanjai-cursor-building {
      width: 32px;
      height: 32px;
      transform: translate(-50%, -50%) scale(0.85);
      background: #eb5e28;
      box-shadow: 0 2px 10px rgba(235, 94, 40, 0.6);
    }

    body.cursor-active #thanjai-cursor-building svg {
      fill: #ffffff;
      transform: scale(0.9);
    }

    /* Luxury Spark Particles */
    .thanjai-spark {
      position: fixed;
      pointer-events: none;
      z-index: 9999996;
      border-radius: 50%;
      transform: translate(-50%, -50%);
      animation: sparkDisperse var(--duration, 0.65s) cubic-bezier(0.16, 1, 0.3, 1) forwards;
    }

    .thanjai-spark-star {
      position: fixed;
      pointer-events: none;
      z-index: 9999996;
      transform: translate(-50%, -50%);
      animation: starSpark var(--duration, 0.75s) cubic-bezier(0.16, 1, 0.3, 1) forwards;
    }

    @keyframes sparkDisperse {
      0% {
        opacity: 1;
        transform: translate(-50%, -50%) scale(1) translate(0, 0);
      }
      100% {
        opacity: 0;
        transform: translate(-50%, -50%) scale(0.1) translate(var(--tx, 0px), var(--ty, 0px));
      }
    }

    @keyframes starSpark {
      0% {
        opacity: 1;
        transform: translate(-50%, -50%) scale(0.4) rotate(0deg) translate(0, 0);
      }
      50% {
        opacity: 0.9;
        transform: translate(-50%, -50%) scale(1.1) rotate(60deg) translate(calc(var(--tx, 0px) * 0.5), calc(var(--ty, 0px) * 0.5));
      }
      100% {
        opacity: 0;
        transform: translate(-50%, -50%) scale(0) rotate(140deg) translate(var(--tx, 0px), var(--ty, 0px));
      }
    }

    /* Hide on touch/mobile */
    @media (hover: none) and (pointer: coarse) {
      #thanjai-cursor-dot,
      #thanjai-cursor-building,
      .thanjai-spark,
      .thanjai-spark-star {
        display: none !important;
      }
    }
  `,document.head.appendChild(e);let t=document.createElement(`div`);t.id=`thanjai-cursor-dot`;let n=document.createElement(`div`);n.id=`thanjai-cursor-building`,n.innerHTML=`
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 2L2 7v15h20V7L12 2zm0 2.24L19.5 8H4.5L12 4.24zM4 10h3v3H4v-3zm0 5h3v3H4v-3zm5-5h3v3H9v-3zm0 5h3v3H9v-3zm5-5h3v3h-3v-3zm0 5h3v3h-3v-3zm5-5h2v8h-2v-8zM4 20h16v1H4v-1z"/>
    </svg>
  `,document.body.appendChild(t),document.body.appendChild(n);let r=window.innerWidth/2,i=window.innerHeight/2,a=r,o=i,s=!1,c=0,l=r,u=i,d=[`#eb5e28`,`#f59e0b`,`#fbbf24`,`#ffedd5`,`#f97316`],f=(e,t,n=!1)=>{let r=document.createElement(`div`),i=Math.random()>.45,a=d[Math.floor(Math.random()*d.length)],o=n?.55+Math.random()*.3:.45+Math.random()*.3,s=Math.random()*Math.PI*2,c=n?20+Math.random()*45:10+Math.random()*25,l=`${Math.cos(s)*c}px`,u=`${Math.sin(s)*c}px`;if(i)r.className=`thanjai-spark-star`,r.innerHTML=`
        <svg width="12" height="12" viewBox="0 0 24 24" fill="${a}">
          <path d="M12 0L14.5 9.5L24 12L14.5 14.5L12 24L9.5 14.5L0 12L9.5 9.5L12 0Z"/>
        </svg>
      `;else{r.className=`thanjai-spark`;let e=3+Math.floor(Math.random()*4);r.style.width=`${e}px`,r.style.height=`${e}px`,r.style.background=a,r.style.boxShadow=`0 0 6px ${a}`}r.style.left=`${e}px`,r.style.top=`${t}px`,r.style.setProperty(`--tx`,l),r.style.setProperty(`--ty`,u),r.style.setProperty(`--duration`,`${o}s`),document.body.appendChild(r),setTimeout(()=>{r.remove()},o*1e3+50)},p=(e,t)=>{let n=7+Math.floor(Math.random()*4);for(let r=0;r<n;r++)f(e,t,!0)};window.addEventListener(`mousemove`,e=>{r=e.clientX,i=e.clientY,t.style.left=`${r}px`,t.style.top=`${i}px`,s||(s=!0,t.style.opacity=`1`,n.style.opacity=`1`);let a=performance.now();Math.hypot(r-l,i-u)>16&&a-c>35&&(f(r+(Math.random()*6-3),i+(Math.random()*6-3)),c=a,l=r,u=i)},{passive:!0});let m=()=>{a+=(r-a)*.2,o+=(i-o)*.2,n.style.left=`${a.toFixed(2)}px`,n.style.top=`${o.toFixed(2)}px`,requestAnimationFrame(m)};requestAnimationFrame(m),window.addEventListener(`mousedown`,e=>{document.body.classList.add(`cursor-active`),p(e.clientX,e.clientY)}),window.addEventListener(`mouseup`,()=>{document.body.classList.remove(`cursor-active`)}),document.addEventListener(`mouseleave`,()=>{t.style.opacity=`0`,n.style.opacity=`0`,s=!1}),document.addEventListener(`mouseenter`,()=>{t.style.opacity=`1`,n.style.opacity=`1`,s=!0});let h=`a, button, input, select, textarea, [role="button"], .prop-card, .category-card, .btn, .view-btn, .fav-btn, .clickable`;document.addEventListener(`mouseover`,e=>{e.target.closest(h)&&document.body.classList.add(`cursor-hover`)}),document.addEventListener(`mouseout`,e=>{e.target.closest(h)&&document.body.classList.remove(`cursor-hover`)})}var M=[],N=0,P=!1;function Oe(){let e=document.getElementById(`frontend-promo-popup-modal`);e||(e=document.createElement(`div`),e.id=`frontend-promo-popup-modal`,e.style.cssText=`
      position: fixed;
      inset: 0;
      z-index: 100000;
      background: rgba(15, 23, 42, 0.75);
      backdrop-filter: blur(6px);
      display: none;
      align-items: center;
      justify-content: center;
      padding: 16px;
      opacity: 0;
      transition: opacity 0.35s ease;
    `,e.innerHTML=`
      <div id="promo-popup-card" style="
        background: #ffffff;
        border-radius: 20px;
        max-width: 440px;
        width: 100%;
        overflow: hidden;
        box-shadow: 0 25px 50px -12px rgba(0,0,0,0.35);
        transform: translateY(20px) scale(0.95);
        transition: transform 0.35s cubic-bezier(0.16, 1, 0.3, 1);
        position: relative;
        border: 1px solid rgba(255, 255, 255, 0.2);
      ">
        <!-- Close Button -->
        <button id="promo-popup-close-btn" style="
          position: absolute;
          top: 14px;
          right: 14px;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: rgba(0, 0, 0, 0.5);
          color: #ffffff;
          border: none;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          z-index: 10;
          font-size: 1.1rem;
          transition: background 0.2s, transform 0.2s;
        ">
          ✕
        </button>

        <!-- Top Banner Image & Glowing Badge -->
        <div style="position: relative; height: 180px; background: #0f172a; overflow: hidden;">
          <img id="promo-popup-img" src="" alt="Offer" style="width: 100%; height: 100%; object-fit: cover;" />
          
          <span id="promo-popup-badge" style="
            position: absolute;
            top: 14px;
            left: 14px;
            background: #eb5e28;
            color: #ffffff;
            font-size: 0.74rem;
            font-weight: 800;
            padding: 5px 14px;
            border-radius: 20px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            letter-spacing: 0.5px;
            text-transform: uppercase;
          ">
            🎉 FESTIVE OFFER
          </span>
        </div>

        <!-- Popup Body -->
        <div style="padding: 20px 22px 24px 22px;">
          <h2 id="promo-popup-title" style="
            color: #0f172a;
            font-size: 1.25rem;
            font-weight: 800;
            margin: 0 0 8px 0;
            line-height: 1.35;
            font-family: 'DM Serif Display', Georgia, serif;
          "></h2>

          <p id="promo-popup-subtitle" style="
            font-size: 0.88rem;
            color: #64748b;
            margin: 0 0 16px 0;
            line-height: 1.5;
          "></p>

          <div id="promo-popup-highlights" style="
            background: #f8fafc;
            border: 1px solid #f1f5f9;
            border-radius: 12px;
            padding: 12px 14px;
            margin-bottom: 18px;
            display: flex;
            flex-direction: column;
            gap: 8px;
          "></div>

          <!-- CTA Button -->
          <button id="promo-popup-cta-btn" style="
            width: 100%;
            background: #eb5e28;
            color: #ffffff;
            border: none;
            padding: 12px 18px;
            border-radius: 12px;
            font-size: 0.92rem;
            font-weight: 700;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            cursor: pointer;
            box-shadow: 0 8px 20px rgba(235,94,40,0.35);
            transition: transform 0.2s, background 0.2s;
          ">
            <i id="promo-popup-cta-icon" class="ri-whatsapp-fill" style="font-size: 1.1rem;"></i>
            <span id="promo-popup-cta-text">Claim Offer on WhatsApp</span>
          </button>
        </div>
      </div>
    `,document.body.appendChild(e),document.getElementById(`promo-popup-close-btn`)?.addEventListener(`click`,R),e.addEventListener(`click`,t=>{t.target===e&&R()})),F(),window.addEventListener(`popupsUpdated`,()=>{F()})}function F(){let e=y();if(!e||e.length===0||(M=e.filter(e=>{let t=e.frequency||`once_session`;if(t===`every_load`)return!0;if(t===`once_day`){let t=localStorage.getItem(`thanjai_popup_last_seen_${e.id}`);return!(t&&Date.now()-parseInt(t,10)<864e5)}return!sessionStorage.getItem(`thanjai_dismissed_popup_${e.id}`)}),M.length===0))return;N=0;let t=(M[0].delaySeconds||3)*1e3;setTimeout(()=>{P||I(0)},t)}function I(e){if(e>=M.length)return;let t=M[e],n=document.getElementById(`frontend-promo-popup-modal`),r=document.getElementById(`promo-popup-card`);if(!n||!r)return;let i=document.getElementById(`promo-popup-img`),a=document.getElementById(`promo-popup-badge`),o=document.getElementById(`promo-popup-title`),s=document.getElementById(`promo-popup-subtitle`),c=document.getElementById(`promo-popup-highlights`),l=document.getElementById(`promo-popup-cta-btn`),u=document.getElementById(`promo-popup-cta-text`),d=document.getElementById(`promo-popup-cta-icon`);if(i&&(i.src=t.image||`https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80`),a&&(a.textContent=t.badge||`PROMOTION`),o&&(o.textContent=t.title),s&&(s.textContent=t.subtitle||``),c){let e=Array.isArray(t.highlights)?t.highlights:[];e.length>0?(c.style.display=`flex`,c.innerHTML=e.map(e=>`
        <div style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #334155;">
          <i class="ri-checkbox-circle-fill" style="color: #10b981; font-size: 0.95rem;"></i>
          <span style="line-height: 1.3;">${e}</span>
        </div>
      `).join(``)):c.style.display=`none`}u&&(u.textContent=t.ctaText||`Claim Offer on WhatsApp`),d&&(d.className=t.ctaType===`whatsapp`?`ri-whatsapp-fill`:t.ctaType===`site_visit`?`ri-calendar-check-fill`:t.ctaType===`call`?`ri-phone-fill`:`ri-arrow-right-up-line`),l&&(l.onclick=()=>{ke(t),R()}),n.style.display=`flex`,setTimeout(()=>{n.style.opacity=`1`,r.style.transform=`translateY(0) scale(1)`,P=!0},30)}function ke(e){if(Ae(e),e.ctaType===`whatsapp`){let t=(e.ctaValue||`+918489996852`).replace(/[^0-9]/g,``),n=encodeURIComponent(`Hello Thanjai Property, I am interested in your offer: "${e.title}". Please share complete project details and price.`);window.open(`https://wa.me/${t}?text=${n}`,`_blank`)}else if(e.ctaType===`call`){let t=e.ctaValue||`+918489996852`;window.location.href=`tel:${t}`}else if(e.ctaType===`site_visit`){let e=document.getElementById(`schedule-visit-modal`);e?(e.classList.add(`show`),e.style.display=`flex`):window.location.hash=`#contact`}else if(e.ctaType===`link`){let t=e.ctaValue||`#discover`;t.startsWith(`#`)||t.startsWith(`/`)?window.location.href=t:window.open(t,`_blank`)}}async function Ae(e){try{let n={id:`L-POP-${Date.now()}`,name:`Website Visitor (${e.badge||`Offer`})`,phone:e.ctaType===`whatsapp`?`WhatsApp Lead`:e.ctaType===`call`?`Phone Inquiry`:`Website Lead`,mobile:``,email:``,type:e.type||`Promotional Offer`,location:`Thanjavur`,budget:`Campaign Inquiry`,stage:`New`,source:`Website Popup (${e.title})`,date:new Date().toISOString().split(`T`)[0],assignedTo:`Unassigned`,priority:`High`,notes:`Engaged with popup: "${e.title}" | CTA Action: ${e.ctaText}`,timeline:[{type:`popup_click`,date:new Date().toISOString(),message:`🎯 User clicked CTA "${e.ctaText}" on popup offer "${e.title}"`,note:`Campaign Type: ${e.type}`}]},r=JSON.parse(localStorage.getItem(`thanjai_leads`))||[];r.unshift(n),localStorage.setItem(`thanjai_leads`,JSON.stringify(r)),window.dispatchEvent(new Event(`storage`)),await t(`/leads`,{method:`POST`,body:JSON.stringify(n)})}catch(e){console.warn(`Could not record popup lead in CRM:`,e)}}function R(){let e=document.getElementById(`frontend-promo-popup-modal`),t=document.getElementById(`promo-popup-card`);if(!e||!t)return;let n=M[N];n&&(sessionStorage.setItem(`thanjai_dismissed_popup_${n.id}`,`true`),localStorage.setItem(`thanjai_popup_last_seen_${n.id}`,Date.now().toString())),e.style.opacity=`0`,t.style.transform=`translateY(20px) scale(0.95)`,setTimeout(()=>{e.style.display=`none`,P=!1,N++,N<M.length&&setTimeout(()=>{I(N)},1500)},350)}function je(t){let n=e(`leader_founder`),r=e(`leader_partner`);return`
    <div class="page-view view-enter story-page">
      
      <!-- 1. EDITORIAL HERO -->
      <section class="story-hero" style="
        position: relative;
        padding: 130px 0 90px 0;
        background: linear-gradient(135deg, #1c1007 0%, #2a1808 60%, #150b04 100%);
        color: #ffffff;
        overflow: hidden;
      ">
        <div style="
          position: absolute; inset: 0;
          background-image: url('${e(`our_story_hero_bg`)}');
          background-size: cover; background-position: center; opacity: 0.22;
        "></div>

        <div class="container" style="position: relative; z-index: 2; max-width: 900px; text-align: center;">
          <div style="
            display: inline-flex; align-items: center; gap: 8px; padding: 6px 16px; border-radius: 30px;
            background: rgba(235, 94, 40, 0.15); border: 1px solid rgba(235, 94, 40, 0.4);
            color: var(--color-orange, #eb5e28); font-size: 0.8rem; font-weight: 800; letter-spacing: 0.12em; margin-bottom: 24px;
          ">
            <i class="ri-shield-star-line"></i> OUR STORY
          </div>

          <h1 class="heading-display-light" style="font-size: clamp(2.5rem, 5vw, 4.2rem); margin-bottom: 24px; color: #ffffff; line-height: 1.15;">
            Connecting People With<br>the Right Property.
          </h1>

          <p style="font-size: clamp(1.05rem, 2vw, 1.25rem); color: rgba(255, 255, 255, 0.88); line-height: 1.7; font-weight: 400; max-width: 820px; margin: 0 auto 36px auto;">
            Founded in Thanjavur in 2009, Thanjai Property simplifies real estate discovery across Tamil Nadu. Backed by deep local expertise, we connect buyers, sellers, and investors with verified residential, agricultural, and commercial properties tailored to their long-term goals.
          </p>
        </div>
      </section>

      <!-- 2. PHILOSOPHY & JOURNEY SECTION -->
      <section style="padding: 90px 0; background: #ffffff;">
        <div class="container">
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 60px; align-items: center; margin-bottom: 80px;">
            <div>
              <span class="eyebrow" style="color: var(--color-orange, #eb5e28); font-weight: 800; letter-spacing: 0.12em;">OUR PHILOSOPHY</span>
              <h2 class="heading-section" style="margin-top: 12px; margin-bottom: 20px;">
                Where Local Knowledge Meets Modern Property Search.
              </h2>
              <p style="font-size: 1.05rem; color: #555; line-height: 1.75; margin-bottom: 24px;">
                We believe finding the right property goes beyond just location and price. It demands accurate data, clear communication, and an eye for future potential. By combining on-the-ground market expertise with modern digital search, we make every step of your property journey seamless, transparent, and informed.
              </p>

              <!-- 3 Philosophy Value Cards -->
              <div style="display: flex; flex-direction: column; gap: 16px;">
                <div style="background: #faf8f5; border-left: 4px solid #eb5e28; padding: 16px 20px; border-radius: 0 12px 12px 0;">
                  <strong style="font-size: 1rem; color: #1a1a1a; display: block; margin-bottom: 4px;">Trust</strong>
                  <span style="font-size: 0.9rem; color: #555; line-height: 1.5;">Sound property decisions start with honest guidance, verified documentation, and complete transparency.</span>
                </div>
                <div style="background: #faf8f5; border-left: 4px solid #eb5e28; padding: 16px 20px; border-radius: 0 12px 12px 0;">
                  <strong style="font-size: 1rem; color: #1a1a1a; display: block; margin-bottom: 4px;">Local Expertise</strong>
                  <span style="font-size: 0.9rem; color: #555; line-height: 1.5;">Deeply rooted in Thanjavur with a growing footprint across Tamil Nadu, we provide sharp insights into micro-markets and emerging corridors.</span>
                </div>
                <div style="background: #faf8f5; border-left: 4px solid #eb5e28; padding: 16px 20px; border-radius: 0 12px 12px 0;">
                  <strong style="font-size: 1rem; color: #1a1a1a; display: block; margin-bottom: 4px;">Long-Term Value</strong>
                  <span style="font-size: 0.9rem; color: #555; line-height: 1.5;">We look beyond the single transaction, focusing on properties that protect your capital and support your future lifestyle or investment goals.</span>
                </div>
              </div>
            </div>

            <div style="position: relative;">
              <div style="
                border-radius: 24px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.12);
                border: 1px solid rgba(0,0,0,0.06);
              ">
                <img src="${e(`our_philosophy_img`)}" alt="Thanjai Heritage Architecture" style="width: 100%; height: auto; display: block;" />
              </div>
              <div class="story-since-badge" style="
                position: absolute; bottom: -24px; left: -24px; background: #2A1808; color: #F8F4EC;
                padding: 24px 28px; border-radius: 16px; max-width: 280px; box-shadow: 0 10px 30px rgba(0,0,0,0.2);
              ">
                <div style="font-family: var(--font-serif); font-size: 2.2rem; font-weight: 700; color: var(--color-orange, #eb5e28);">Since 2009</div>
                <div style="font-size: 0.85rem; font-weight: 600; opacity: 0.9; text-transform: uppercase; letter-spacing: 0.05em; margin-top: 2px;">
                  17+ Years of Dedicated Real Estate Service
                </div>
              </div>
            </div>
          </div>

          <!-- OUR JOURNEY SECTION (INTERACTIVE 3-STEP GROWTH MILESTONE ROADMAP) -->
          <div style="background: linear-gradient(135deg, #1C1007 0%, #2A1808 60%, #150B04 100%); border-radius: 28px; padding: 50px 40px; color: #ffffff; position: relative; overflow: hidden; box-shadow: 0 20px 50px rgba(0,0,0,0.15);">
            <div style="position: absolute; inset: 0; opacity: 0.1; background-image: radial-gradient(#eb5e28 1px, transparent 1px); background-size: 24px 24px;"></div>

            <div style="position: relative; z-index: 2;">
              <div style="text-align: center; max-width: 720px; margin: 0 auto 48px auto;">
                <span class="eyebrow" style="color: var(--color-orange, #eb5e28); font-weight: 800; letter-spacing: 0.15em; font-size: 0.8rem;">OUR JOURNEY</span>
                <h2 style="font-family: var(--font-serif); font-size: 2.2rem; font-weight: 800; color: #ffffff; margin-top: 8px; margin-bottom: 14px;">
                  From Thanjavur to Tamil Nadu
                </h2>
                <p style="font-size: 1rem; color: rgba(255,255,255,0.85); line-height: 1.65; margin: 0;">
                  What started in Thanjavur has grown into a wider property platform serving property seekers across Tamil Nadu. Our journey continues with one purpose: making property discovery easier, clearer and more connected.
                </p>
              </div>

              <!-- 3-Step Growth Milestone Roadmap Grid -->
              <div style="position: relative; display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 28px;">
                
                <!-- Step 1: 2009 -->
                <div class="hover-lift" style="
                  background: rgba(255,255,255,0.06); border: 1px solid rgba(235,94,40,0.4);
                  border-radius: 20px; padding: 28px 24px; backdrop-filter: blur(10px);
                  position: relative; transition: all 0.35s ease;
                ">
                  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 18px;">
                    <span style="background: #eb5e28; color: #ffffff; font-size: 0.8rem; font-weight: 800; padding: 4px 14px; border-radius: 20px; letter-spacing: 0.05em;">
                      2009
                    </span>
                    <i class="ri-flag-2-line" style="font-size: 1.5rem; color: #eb5e28;"></i>
                  </div>
                  <h3 style="font-family: var(--font-serif); font-size: 1.3rem; font-weight: 700; color: #ffffff; margin-bottom: 8px;">Founding Roots in Thanjavur</h3>
                  <p style="font-size: 0.88rem; color: rgba(255,255,255,0.8); line-height: 1.6; margin: 0;">
                    Started with a simple vision to make property discovery transparent, accessible and reliable with 100% legal Patta verification.
                  </p>
                </div>

                <!-- Step 2: 2018 -->
                <div class="hover-lift" style="
                  background: rgba(255,255,255,0.06); border: 1px solid rgba(56,161,105,0.4);
                  border-radius: 20px; padding: 28px 24px; backdrop-filter: blur(10px);
                  position: relative; transition: all 0.35s ease;
                ">
                  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 18px;">
                    <span style="background: #38a169; color: #ffffff; font-size: 0.8rem; font-weight: 800; padding: 4px 14px; border-radius: 20px; letter-spacing: 0.05em;">
                      2018
                    </span>
                    <i class="ri-compass-3-line" style="font-size: 1.5rem; color: #38a169;"></i>
                  </div>
                  <h3 style="font-family: var(--font-serif); font-size: 1.3rem; font-weight: 700; color: #ffffff; margin-bottom: 8px;">Regional Footprint Expansion</h3>
                  <p style="font-size: 0.88rem; color: rgba(255,255,255,0.8); line-height: 1.6; margin: 0;">
                    Extended property services across key growth corridors including Trichy, Madurai, Kumbakonam, and the Cauvery Delta region.
                  </p>
                </div>

                <!-- Step 3: 2026 Today -->
                <div class="hover-lift" style="
                  background: rgba(255,255,255,0.06); border: 1px solid rgba(128,90,213,0.4);
                  border-radius: 20px; padding: 28px 24px; backdrop-filter: blur(10px);
                  position: relative; transition: all 0.35s ease;
                ">
                  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 18px;">
                    <span style="background: #805ad5; color: #ffffff; font-size: 0.8rem; font-weight: 800; padding: 4px 14px; border-radius: 20px; letter-spacing: 0.05em;">
                      2026 TODAY
                    </span>
                    <i class="ri-global-line" style="font-size: 1.5rem; color: #805ad5;"></i>
                  </div>
                  <h3 style="font-family: var(--font-serif); font-size: 1.3rem; font-weight: 700; color: #ffffff; margin-bottom: 8px;">Pan-Tamil Nadu Digital Ecosystem</h3>
                  <p style="font-size: 0.88rem; color: rgba(255,255,255,0.8); line-height: 1.6; margin: 0;">
                    Serving property seekers across all 38 districts of Tamil Nadu with multi-category search, NRI desk, and real-estate insights.
                  </p>
                </div>

              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- 3. MEET OUR LEADERSHIP SECTION (CLASSIC & PREMIER EXECUTIVE DESIGN) -->
      <section style="padding: 100px 0; background: linear-gradient(135deg, #1C1007 0%, #2A1808 60%, #150B04 100%); color: #ffffff; position: relative; overflow: hidden;">
        <div style="position: absolute; inset: 0; opacity: 0.12; background-image: radial-gradient(#eb5e28 1px, transparent 1px); background-size: 28px 28px;"></div>
        <div class="container" style="position: relative; z-index: 2;">
          
          <div style="text-align: center; max-width: 800px; margin: 0 auto 60px auto;">
            <span class="eyebrow" style="color: var(--color-orange, #eb5e28); font-weight: 800; letter-spacing: 0.15em; font-size: 0.82rem; text-transform: uppercase;">
              MEET OUR LEADERSHIP
            </span>
            <h2 style="font-family: var(--font-serif, 'DM Serif Display', serif); font-size: clamp(2.2rem, 4vw, 3.4rem); margin-top: 10px; color: #ffffff; line-height: 1.25;">
              Experience Behind Every<br>Property Journey
            </h2>
            <p style="color: rgba(255,255,255,0.85); font-size: 1.08rem; margin-top: 14px; line-height: 1.6;">
              Our leadership brings together real-estate understanding, local knowledge and a strong focus on customer trust.
            </p>
          </div>
          <div style="width: 100%; display: flex; justify-content: space-evenly; gap: 40px; flex-wrap: wrap; align-items: stretch;">
            
            <!-- MANAGING DIRECTOR CARD (ADMINISTRATIVE & LEGAL GOVERNANCE) -->
            <div class="story-leader-card hover-lift" style="
              width: 100%; max-width: 420px; flex: 1 1 360px;
              background: linear-gradient(180deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0.03) 100%);
              border: 1px solid rgba(235,94,40,0.35); border-radius: 28px; padding: 30px 24px;
              backdrop-filter: blur(16px); box-shadow: 0 20px 50px rgba(0,0,0,0.4);
              display: flex; flex-direction: column; justify-content: space-between; text-align: center;
              transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
            ">
              <div>
                <!-- Centered Photo Frame (Blended Studio Backdrop + Uniform 24px Corner Radius) -->
                <div style="
                  width: 100%; aspect-ratio: 1 / 1; margin: 0 auto 20px auto;
                  border-radius: 24px; overflow: hidden; background: #000000;
                  border: 2.5px solid #eb5e28; box-shadow: 0 12px 30px rgba(0,0,0,0.5); position: relative;
                ">
                  <img src="${n}" alt="S. Vijayaraghavan" style="width: 100%; height: 100%; object-fit: cover; object-position: top center; display: block; border-radius: 24px; mix-blend-mode: lighten;" onerror="this.src='/images/vijayaraghavan.jpg'" />
                  <div style="position: absolute; inset: 0; background: radial-gradient(ellipse at 50% 35%, transparent 45%, rgba(0,0,0,0.85) 90%, #000000 100%); pointer-events: none;"></div>
                </div>

                <!-- Centered Name & Role -->
                <div style="margin-bottom: 14px;">
                  <h3 style="font-family: var(--font-serif); font-size: 1.75rem; font-weight: 700; color: #ffffff; line-height: 1.25; margin-bottom: 6px;">S. Vijayaraghavan</h3>
                  <p style="font-size: 0.92rem; color: #eb5e28; font-weight: 800; margin: 0; text-transform: uppercase; letter-spacing: 0.05em;">Managing Director</p>
                </div>

                <!-- Justified Bio Text -->
                <p style="font-size: 0.92rem; color: rgba(255,255,255,0.85); line-height: 1.75; margin-bottom: 22px; text-align: justify; text-justify: inter-word;">
                  S. Vijayaraghavan has been instrumental in shaping the vision of Thanjai Property since its foundation in 2009. He oversees operations, corporate governance, legal title verification, and Patta clearance standards, ensuring every transaction delivers unmatched legal security and transparency for property buyers across Tamil Nadu.
                </p>
              </div>

              <div style="padding-top: 16px; border-top: 1px solid rgba(255,255,255,0.12); display: flex; gap: 10px; flex-wrap: wrap;">
                <a href="tel:+919578311506" style="flex: 1; background: rgba(255,255,255,0.12); color: #fff; padding: 12px 16px; border-radius: 12px; font-size: 0.88rem; font-weight: 700; text-decoration: none; text-align: center; display: inline-flex; align-items: center; justify-content: center; gap: 6px;">
                  <i class="ri-phone-line"></i> +91 95783 11506
                </a>
                <a href="https://wa.me/919578311506" target="_blank" style="flex: 1; background: #25D366; color: #fff; padding: 12px 16px; border-radius: 12px; font-size: 0.88rem; font-weight: 700; text-decoration: none; text-align: center; display: inline-flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 14px rgba(37,211,102,0.3);">
                  <i class="ri-whatsapp-line"></i> WhatsApp
                </a>
              </div>
            </div>

            <!-- CO-PARTNER CARD (SALES & MARKETING LEADERSHIP) -->
            <div class="story-leader-card hover-lift" style="
              width: 100%; max-width: 420px; flex: 1 1 360px;
              background: linear-gradient(180deg, rgba(255,255,255,0.08) 0%, rgba(255,255,255,0.03) 100%);
              border: 1px solid rgba(56,161,105,0.35); border-radius: 28px; padding: 30px 24px;
              backdrop-filter: blur(16px); box-shadow: 0 20px 50px rgba(0,0,0,0.4);
              display: flex; flex-direction: column; justify-content: space-between; text-align: center;
              transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
            ">
              <div>
                <!-- Centered Photo Frame (Blended Studio Backdrop + Uniform 24px Corner Radius) -->
                <div style="
                  width: 100%; aspect-ratio: 1 / 1; margin: 0 auto 20px auto;
                  border-radius: 24px; overflow: hidden; background: #000000;
                  border: 2.5px solid #38a169; box-shadow: 0 12px 30px rgba(0,0,0,0.5); position: relative;
                ">
                  <img src="${r}" alt="Radhakrishnan" style="width: 100%; height: 100%; object-fit: cover; object-position: top center; display: block; border-radius: 24px; mix-blend-mode: lighten;" onerror="this.src='/images/radhakrishnan.jpg'" />
                  <div style="position: absolute; inset: 0; background: radial-gradient(ellipse at 50% 35%, transparent 45%, rgba(0,0,0,0.85) 90%, #000000 100%); pointer-events: none;"></div>
                </div>

                <!-- Centered Name & Role -->
                <div style="margin-bottom: 14px;">
                  <h3 style="font-family: var(--font-serif); font-size: 1.75rem; font-weight: 700; color: #ffffff; line-height: 1.25; margin-bottom: 6px;">G. Radhakrishnan</h3>
                  <p style="font-size: 0.92rem; color: #38a169; font-weight: 800; margin: 0; text-transform: uppercase; letter-spacing: 0.05em;">Managing Partner</p>
                </div>

                <!-- Justified Bio Text -->
                <p style="font-size: 0.92rem; color: rgba(255,255,255,0.85); line-height: 1.75; margin-bottom: 22px; text-align: justify; text-justify: inter-word;">
                  G. Radhakrishnan leads strategic sales, investor relations, and property advisory across Tamil Nadu. Bringing a dynamic, customer-centric approach, he connects homebuyers, plot investors, and NRI clients with prime real estate opportunities through personalized property matching, curated site visits, and actionable market insights.
                </p>
              </div>

              <div style="padding-top: 16px; border-top: 1px solid rgba(255,255,255,0.12); display: flex; gap: 10px; flex-wrap: wrap;">
                <a href="tel:+919585777772" style="flex: 1; background: rgba(255,255,255,0.12); color: #fff; padding: 12px 16px; border-radius: 12px; font-size: 0.88rem; font-weight: 700; text-decoration: none; text-align: center; display: inline-flex; align-items: center; justify-content: center; gap: 6px;">
                  <i class="ri-phone-line"></i> +91 95857 77772
                </a>
                <a href="https://wa.me/919585777772" target="_blank" style="flex: 1; background: #25D366; color: #fff; padding: 12px 16px; border-radius: 12px; font-size: 0.88rem; font-weight: 700; text-decoration: none; text-align: center; display: inline-flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 14px rgba(37,211,102,0.3);">
                  <i class="ri-whatsapp-line"></i> WhatsApp
                </a>
              </div>
            </div>

          </div>

        </div>
      </section>

      <!-- 4. OUR THANJAVUR FOOTPRINT SECTION (UNIQUE ZONAL CORRIDOR DIRECTORY) -->
      <section style="padding: 95px 0; background: #faf8f5; border-top: 1px solid rgba(0,0,0,0.05);">
        <div class="container">
          <div style="text-align: center; max-width: 800px; margin: 0 auto 55px auto;">
            <span class="eyebrow" style="color: var(--color-orange, #eb5e28); font-weight: 800; letter-spacing: 0.12em;">PRIMARY OPERATIONS HUB — THANJAVUR</span>
            <h2 class="heading-section" style="margin-top: 12px; font-size: clamp(2rem, 3.5vw, 2.8rem);">
              Our Local Footprint Across Thanjavur
            </h2>
            <p style="color: #666; font-size: 1.05rem; margin-top: 12px; line-height: 1.65;">
              Since 2009, Thanjai Property has maintained an unmatched local presence across Thanjavur. Explore our verified property footprint categorized by strategic growth corridors.
            </p>
          </div>

          <!-- ZONAL CLUSTERS (11 INDIVIDUAL LOCATION CARDS IN ZIG-ZAG TIMELINE) -->
          <div class="story-zigzag-timeline" style="position: relative; max-width: 1040px; margin: 0 auto;">
            
            <!-- Central Vertical Spine Line -->
            <div class="timeline-center-spine"></div>

            ${[{num:1,name:`Medical College Road`,category:`Arterial Corridor`,accent:`#eb5e28`,icon:`ri-hospital-line`,desc:`Healthcare & Premium Residential Hub • Multi-specialty hospitals & DTCP layouts`},{num:2,name:`Trichy Road`,category:`Arterial Highway`,accent:`#eb5e28`,icon:`ri-road-map-line`,desc:`Major Commercial Highway & Gated Villas • Direct connectivity to Trichy (NH 83)`},{num:3,name:`Pudukkottai Road`,category:`Educational Belt`,accent:`#eb5e28`,icon:`ri-book-open-line`,desc:`Educational Belt & Residential Plot Layouts • Schools & Tamil University sector`},{num:4,name:`Madhakottai Road`,category:`Prime Residential`,accent:`#38a169`,icon:`ri-home-4-line`,desc:`Rapid Urban Expansion & Modern Villas • Contemporary villa developments`},{num:5,name:`Nanjikottai Road`,category:`Residential Enclave`,accent:`#38a169`,icon:`ri-community-line`,desc:`Serene Residential Enclaves & Townhouses • Top schools & sweet groundwater`},{num:6,name:`Villar Road`,category:`Suburban Growth`,accent:`#3182ce`,icon:`ri-plant-line`,desc:`Suburban Growth & Investment Plot Layouts • Budget-friendly house sites`},{num:7,name:`Pattukottai Bypass`,category:`Ring Road Bypass`,accent:`#805ad5`,icon:`ri-compass-3-line`,desc:`Ring Road Outer Corridor & Commercial Land • Prime highway frontage`},{num:8,name:`Mariyamman Kovil Road`,category:`Heritage Corridor`,accent:`#d69e2e`,icon:`ri-ancient-gate-line`,desc:`Heritage & Temple Neighborhood Corridor • Near Punnainallur Temple`},{num:9,name:`Srinivasapuram`,category:`Upscale Residential`,accent:`#38a169`,icon:`ri-building-line`,desc:`Established Upscale Neighborhood • Luxury independent homes & civic layout`},{num:10,name:`Reddipalayam Road`,category:`Modern Residential`,accent:`#38a169`,icon:`ri-home-gear-line`,desc:`Gated Community & Modern Layouts • RERA approved house sites`},{num:11,name:`Kumbakonam Bypass`,category:`Delta Highway`,accent:`#3182ce`,icon:`ri-map-pin-line`,desc:`Delta Highway & Strategic Land Assets • Thanjavur to Kumbakonam link`}].map((e,t)=>t%2==0?`
                  <div class="zigzag-row left-row">
                    <div class="zigzag-card-container">
                      <div class="zigzag-box hover-lift" style="
                        background: #ffffff; border-radius: 18px; padding: 20px 22px;
                        border: 1px solid #e2e8f0; border-left: 5px solid ${e.accent};
                        box-shadow: 0 8px 24px rgba(0,0,0,0.04); position: relative;
                      ">
                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; flex-wrap: wrap; gap: 8px;">
                          <div style="display: flex; align-items: center; gap: 10px;">
                            <div style="width: 32px; height: 32px; border-radius: 8px; background: ${e.accent}18; color: ${e.accent}; display: flex; align-items: center; justify-content: center; font-size: 1.1rem;">
                              <i class="${e.icon}"></i>
                            </div>
                            <h3 style="font-family: var(--font-serif); font-size: 1.15rem; font-weight: 800; color: #1a1a1a; margin: 0;">${e.num}. ${e.name}</h3>
                          </div>
                          <span class="badge" style="background: ${e.accent}15; color: ${e.accent}; font-size: 0.72rem; font-weight: 800; padding: 3px 10px; border-radius: 14px;">${e.category}</span>
                        </div>
                        <p style="font-size: 0.83rem; color: #555; line-height: 1.5; margin: 0 0 10px 0;">${e.desc}</p>
                        <div style="display: flex; align-items: center; justify-content: space-between;">
                          <span style="font-size: 0.72rem; font-weight: 700; color: #38a169; background: rgba(56,161,105,0.1); padding: 3px 8px; border-radius: 6px; display: inline-flex; align-items: center; gap: 4px;">
                            <i class="ri-checkbox-circle-fill"></i> Clear Patta Assured
                          </span>
                          <span style="font-size: 0.75rem; font-weight: 700; color: var(--color-orange); cursor: pointer;" class="story-explore-loc-link" data-loc="${e.name}">
                            View Area <i class="ri-arrow-right-line" style="vertical-align: middle;"></i>
                          </span>
                        </div>
                      </div>
                      <div class="zigzag-arrow-pointer to-right" style="border-left-color: ${e.accent};"></div>
                    </div>

                    <div class="zigzag-node-badge" style="border-color: ${e.accent}; color: ${e.accent};">
                      <span class="node-num" style="font-weight: 800; font-size: 0.95rem;">${e.num}</span>
                    </div>

                    <div class="zigzag-spacer"></div>
                  </div>
                `:`
                  <div class="zigzag-row right-row">
                    <div class="zigzag-spacer"></div>

                    <div class="zigzag-node-badge" style="border-color: ${e.accent}; color: ${e.accent};">
                      <span class="node-num" style="font-weight: 800; font-size: 0.95rem;">${e.num}</span>
                    </div>

                    <div class="zigzag-card-container">
                      <div class="zigzag-arrow-pointer to-left" style="border-right-color: ${e.accent};"></div>
                      <div class="zigzag-box hover-lift" style="
                        background: #ffffff; border-radius: 18px; padding: 20px 22px;
                        border: 1px solid #e2e8f0; border-left: 5px solid ${e.accent};
                        box-shadow: 0 8px 24px rgba(0,0,0,0.04); position: relative;
                      ">
                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; flex-wrap: wrap; gap: 8px;">
                          <div style="display: flex; align-items: center; gap: 10px;">
                            <div style="width: 32px; height: 32px; border-radius: 8px; background: ${e.accent}18; color: ${e.accent}; display: flex; align-items: center; justify-content: center; font-size: 1.1rem;">
                              <i class="${e.icon}"></i>
                            </div>
                            <h3 style="font-family: var(--font-serif); font-size: 1.15rem; font-weight: 800; color: #1a1a1a; margin: 0;">${e.num}. ${e.name}</h3>
                          </div>
                          <span class="badge" style="background: ${e.accent}15; color: ${e.accent}; font-size: 0.72rem; font-weight: 800; padding: 3px 10px; border-radius: 14px;">${e.category}</span>
                        </div>
                        <p style="font-size: 0.83rem; color: #555; line-height: 1.5; margin: 0 0 10px 0;">${e.desc}</p>
                        <div style="display: flex; align-items: center; justify-content: space-between;">
                          <span style="font-size: 0.72rem; font-weight: 700; color: #38a169; background: rgba(56,161,105,0.1); padding: 3px 8px; border-radius: 6px; display: inline-flex; align-items: center; gap: 4px;">
                            <i class="ri-checkbox-circle-fill"></i> Clear Patta Assured
                          </span>
                          <span style="font-size: 0.75rem; font-weight: 700; color: var(--color-orange); cursor: pointer;" class="story-explore-loc-link" data-loc="${e.name}">
                            View Area <i class="ri-arrow-right-line" style="vertical-align: middle;"></i>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                `).join(``)}

          </div>

          <div style="text-align: center; margin-top: 50px;">
            <button class="btn btn-primary story-explore-districts-btn" style="padding: 16px 40px; border-radius: 12px; font-size: 1rem; box-shadow: 0 6px 20px rgba(235,94,40,0.3);">
              <i class="ri-map-pin-line" style="font-size: 1.2rem;"></i>
              <span>View More Properties</span>
            </button>
          </div>
        </div>
      </section>

      <!-- 5. OUR PORTFOLIO PILLARS SECTION (EDITORIAL NUMBERED TIMELINE DECK 01, 02, 03, 04) -->
      <section style="padding: 100px 0; background: linear-gradient(180deg, #ffffff 0%, #FAF6F0 100%); border-top: 1px solid rgba(0,0,0,0.06); position: relative;">
        <div class="container">
          <div style="text-align: center; max-width: 680px; margin: 0 auto 65px auto;">
            <span class="eyebrow" style="color: var(--color-orange, #eb5e28); font-weight: 800; letter-spacing: 0.12em;">OUR PORTFOLIO PILLARS</span>
            <h2 class="heading-section" style="margin-top: 12px; font-size: clamp(2rem, 3.5vw, 2.8rem);">
              What We Look for in a Property
            </h2>
            <p style="color: #666; font-size: 1.05rem; margin-top: 12px; line-height: 1.65;">
              Every property evaluation focuses on four core standards.
            </p>
          </div>

          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 32px;">
            
            <!-- Pillar 01 -->
            <div class="hover-lift" style="
              background: #ffffff; padding: 36px 30px; border-radius: 24px;
              border: 1px solid rgba(0,0,0,0.08); box-shadow: 0 10px 30px rgba(0,0,0,0.04);
              position: relative; overflow: hidden; transition: all 0.4s ease;
            ">
              <div style="position: absolute; top: 0; left: 0; right: 0; height: 5px; background: linear-gradient(90deg, #eb5e28 0%, #dd6b20 100%);"></div>
              
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
                <div style="
                  width: 52px; height: 52px; border-radius: 50%; background: rgba(235,94,40,0.12);
                  color: #eb5e28; display: flex; align-items: center; justify-content: center;
                  font-family: var(--font-serif); font-size: 1.4rem; font-weight: 800; border: 1px solid rgba(235,94,40,0.3);
                ">
                  01
                </div>
                <i class="ri-map-pin-user-line" style="font-size: 1.8rem; color: #eb5e28;"></i>
              </div>

              <h3 style="font-family: var(--font-serif); font-size: 1.35rem; font-weight: 700; color: #1a1a1a; margin-bottom: 12px;">
                Thoughtful Locations
              </h3>
              <p style="font-size: 0.93rem; color: #555; line-height: 1.65; margin: 0;">
                We focus on locations that offer accessibility, convenience and relevance to the property's intended purpose.
              </p>
            </div>

            <!-- Pillar 02 -->
            <div class="hover-lift" style="
              background: #ffffff; padding: 36px 30px; border-radius: 24px;
              border: 1px solid rgba(0,0,0,0.08); box-shadow: 0 10px 30px rgba(0,0,0,0.04);
              position: relative; overflow: hidden; transition: all 0.4s ease;
            ">
              <div style="position: absolute; top: 0; left: 0; right: 0; height: 5px; background: linear-gradient(90deg, #dd6b20 0%, #d69e2e 100%);"></div>
              
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
                <div style="
                  width: 52px; height: 52px; border-radius: 50%; background: rgba(221,107,32,0.12);
                  color: #dd6b20; display: flex; align-items: center; justify-content: center;
                  font-family: var(--font-serif); font-size: 1.4rem; font-weight: 800; border: 1px solid rgba(221,107,32,0.3);
                ">
                  02
                </div>
                <i class="ri-compasses-2-line" style="font-size: 1.8rem; color: #dd6b20;"></i>
              </div>

              <h3 style="font-family: var(--font-serif); font-size: 1.35rem; font-weight: 700; color: #1a1a1a; margin-bottom: 12px;">
                Exceptional Design
              </h3>
              <p style="font-size: 0.93rem; color: #555; line-height: 1.65; margin: 0;">
                We value residential spaces that combine practical planning, functionality and modern living requirements.
              </p>
            </div>

            <!-- Pillar 03 -->
            <div class="hover-lift" style="
              background: #ffffff; padding: 36px 30px; border-radius: 24px;
              border: 1px solid rgba(0,0,0,0.08); box-shadow: 0 10px 30px rgba(0,0,0,0.04);
              position: relative; overflow: hidden; transition: all 0.4s ease;
            ">
              <div style="position: absolute; top: 0; left: 0; right: 0; height: 5px; background: linear-gradient(90deg, #38a169 0%, #319795 100%);"></div>
              
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
                <div style="
                  width: 52px; height: 52px; border-radius: 50%; background: rgba(56,161,105,0.12);
                  color: #38a169; display: flex; align-items: center; justify-content: center;
                  font-family: var(--font-serif); font-size: 1.4rem; font-weight: 800; border: 1px solid rgba(56,161,105,0.3);
                ">
                  03
                </div>
                <i class="ri-shield-check-line" style="font-size: 1.8rem; color: #38a169;"></i>
              </div>

              <h3 style="font-family: var(--font-serif); font-size: 1.35rem; font-weight: 700; color: #1a1a1a; margin-bottom: 12px;">
                Legal & Documentation
              </h3>
              <p style="font-size: 0.93rem; color: #555; line-height: 1.65; margin: 0;">
                Property information, ownership records, approvals and documentation are important parts of an informed property decision.
              </p>
            </div>

            <!-- Pillar 04 -->
            <div class="hover-lift" style="
              background: #ffffff; padding: 36px 30px; border-radius: 24px;
              border: 1px solid rgba(0,0,0,0.08); box-shadow: 0 10px 30px rgba(0,0,0,0.04);
              position: relative; overflow: hidden; transition: all 0.4s ease;
            ">
              <div style="position: absolute; top: 0; left: 0; right: 0; height: 5px; background: linear-gradient(90deg, #805ad5 0%, #6b46c1 100%);"></div>
              
              <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
                <div style="
                  width: 52px; height: 52px; border-radius: 50%; background: rgba(128,90,213,0.12);
                  color: #805ad5; display: flex; align-items: center; justify-content: center;
                  font-family: var(--font-serif); font-size: 1.4rem; font-weight: 800; border: 1px solid rgba(128,90,213,0.3);
                ">
                  04
                </div>
                <i class="ri-line-chart-line" style="font-size: 1.8rem; color: #805ad5;"></i>
              </div>

              <h3 style="font-family: var(--font-serif); font-size: 1.35rem; font-weight: 700; color: #1a1a1a; margin-bottom: 12px;">
                Long-Term Potential
              </h3>
              <p style="font-size: 0.93rem; color: #555; line-height: 1.65; margin: 0;">
                We look beyond today's transaction and consider how a property can support future lifestyle, business or investment goals.
              </p>
            </div>
          </div>
        </div>
      </section>

      <!-- 6. OUR COMMITMENT & CLOSING CTA -->
      <section style="padding: 100px 0; background: #2A1808; color: #ffffff; text-align: center;">
        <div class="container" style="max-width: 840px;">
          <span class="eyebrow eyebrow-dark" style="margin-bottom: 16px;">OUR COMMITMENT</span>
          <h2 class="heading-display-light" style="font-size: clamp(2rem, 4vw, 3.2rem); margin-bottom: 20px; color: #ffffff;">
            Built on Trust. Driven by Property Expertise.
          </h2>
          <p style="color: rgba(255,255,255,0.85); font-size: 1.08rem; line-height: 1.7; margin-bottom: 40px;">
            At Thanjai Property, our commitment is simple — provide a property discovery experience that is clear, convenient and customer-focused. Whether you are buying a home, searching for land, investing in property or selling an existing asset, we aim to help you move forward with better information and greater confidence.
          </p>

          <div style="background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.15); border-radius: 24px; padding: 36px; margin-top: 20px;">
            <h3 style="font-family: var(--font-serif); font-size: 1.6rem; color: #ffffff; margin-bottom: 10px;">READY TO FIND YOUR PROPERTY?</h3>
            <p style="color: rgba(255,255,255,0.8); font-size: 1rem; margin-bottom: 24px;">Your Next Property Could Be Closer Than You Think. Explore residential properties, plots, agricultural land and commercial opportunities across Tamil Nadu.</p>
            
            <div style="display: flex; justify-content: center; gap: 16px; flex-wrap: wrap;">
              <button class="btn btn-primary story-discover-btn" id="story-cta-discover-btn" style="padding: 14px 32px; font-size: 1rem; border-radius: 12px;">
                <span>Explore Properties</span>
                <i class="ri-arrow-right-line"></i>
              </button>
              <button class="btn btn-outline-light" id="story-cta-post-btn" style="padding: 14px 32px; font-size: 1rem; border-radius: 12px; color: #fff; border: 1px solid rgba(255,255,255,0.4);">
                <i class="ri-add-circle-line"></i> Post Your Property
              </button>
            </div>
          </div>
        </div>
      </section>

    </div>
  `}function Me(e){document.getElementById(`story-cta-discover-btn`)?.addEventListener(`click`,e),document.querySelectorAll(`.story-explore-districts-btn`).forEach(t=>{t.addEventListener(`click`,e)}),document.querySelectorAll(`.story-explore-loc-link`).forEach(t=>{t.addEventListener(`click`,t=>{let n=t.currentTarget.dataset.loc;n&&e?e(n):e&&e()})}),document.getElementById(`story-cta-post-btn`)?.addEventListener(`click`,()=>{window.location.href=`/user-dashboard.html`})}function z(e){return o(e)}function Ne(e,t,n){let r=s();if(e.selectedPropertyId){let t=r.find(t=>t.id===e.selectedPropertyId);if(t)return Fe(t,n)}let i=Ie(e);return`
    <div class="page-view view-enter discover-page">
      
      <!-- HERO -->
      <section style="
        padding: 120px 0 60px 0;
        background: linear-gradient(135deg, #1c1007 0%, #2a1808 60%, #150b04 100%);
        color: #ffffff; text-align: center; position: relative; overflow: hidden;
      ">
        <div class="container" style="max-width: 800px; position: relative; z-index: 2;">
          <span class="badge badge-orange" style="font-weight: 800; letter-spacing: 0.12em; margin-bottom: 16px;">
            FIND YOUR PROPERTY
          </span>
          <h1 class="heading-display-light" style="font-size: clamp(2.2rem, 4.5vw, 3.8rem); color: #ffffff; margin-bottom: 12px;">
            Find Your Next Property in Tamil Nadu
          </h1>
          <div style="font-size: 1.05rem; font-weight: 700; color: rgba(255,255,255,0.9); margin-bottom: 14px;">Search Houses, Plots, Agricultural Land & Commercial Spaces</div>
          <p style="font-size: 1.02rem; color: rgba(255, 255, 255, 0.85); line-height: 1.65; max-width: 720px; margin: 0 auto;">
            Explore real estate listings across Tamil Nadu. Use location, budget, and property type filters to narrow your search and find properties that match your requirements.
          </p>
        </div>
      </section>

      <!-- SEARCH & MULTI-FILTER BAR -->
      <section style="padding: 40px 0; background: #faf8f5; border-bottom: 1px solid rgba(0,0,0,0.06);">
        <div class="container">
          
          <div class="discover-filter-card" style="
            background: #ffffff; padding: 24px; border-radius: 20px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.05); border: 1px solid rgba(0,0,0,0.08);
            display: flex; flex-direction: column; gap: 20px;
          ">
            <!-- Row 1: Keyword Search -->
            <div style="position: relative; width: 100%;">
              <i class="ri-search-2-line" style="position: absolute; left: 18px; top: 50%; transform: translateY(-50%); color: var(--color-orange, #eb5e28); font-size: 1.25rem;"></i>
              <input 
                type="text" 
                id="discover-search-input" 
                value="${e.keyword||``}" 
                placeholder="Search by property title, location, district, or keyword (e.g. Villa, Thanjavur, Plot)..." 
                style="
                  width: 100%; padding: 16px 20px 16px 52px; font-size: 1rem; border-radius: 12px;
                  border: 1px solid #cbd5e0; background: #fdfbf7; outline: none; transition: border-color 0.2s;
                "
              />
            </div>

            <!-- Row 2: Select Filter Dropdowns -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 14px;">
              
              <!-- Property Type -->
              <div>
                <label style="font-size: 0.75rem; font-weight: 800; text-transform: uppercase; color: #555; display: block; margin-bottom: 6px; letter-spacing: 0.05em;">Property Type</label>
                <select id="filter-type" style="width: 100%; padding: 12px 14px; font-size: 0.9rem; border-radius: 10px; border: 1px solid #cbd5e0; background: #fff; outline: none;">
                  <option value="all" ${e.type===`all`?`selected`:``}>All Property Types</option>
                  <option value="villas" ${e.type===`villas`?`selected`:``}>Luxury Villas</option>
                  <option value="houses" ${e.type===`houses`?`selected`:``}>Independent Houses</option>
                  <option value="apartments" ${e.type===`apartments`?`selected`:``}>Modern Apartments</option>
                  <option value="plots" ${e.type===`plots`?`selected`:``}>Residential Plots</option>
                  <option value="agricultural" ${e.type===`agricultural`?`selected`:``}>Agricultural Farmland</option>
                  <option value="commercial" ${e.type===`commercial`?`selected`:``}>Commercial Spaces</option>
                </select>
              </div>

              <!-- Location -->
              <div>
                <label style="font-size: 0.75rem; font-weight: 800; text-transform: uppercase; color: #555; display: block; margin-bottom: 6px; letter-spacing: 0.05em;">Location</label>
                <select id="filter-location" style="width: 100%; padding: 12px 14px; font-size: 0.9rem; border-radius: 10px; border: 1px solid #cbd5e0; background: #fff; outline: none;">
                  <option value="all" ${e.location===`all`?`selected`:``}>All Tamil Nadu Locations</option>
                  <option value="Thanjavur" ${e.location===`Thanjavur`?`selected`:``}>Thanjavur</option>
                  <option value="Trichy" ${e.location===`Trichy`?`selected`:``}>Trichy</option>
                  <option value="Madurai" ${e.location===`Madurai`?`selected`:``}>Madurai</option>
                  <option value="Chennai" ${e.location===`Chennai`?`selected`:``}>Chennai</option>
                  <option value="Coimbatore" ${e.location===`Coimbatore`?`selected`:``}>Coimbatore</option>
                  <option value="Kumbakonam" ${e.location===`Kumbakonam`?`selected`:``}>Kumbakonam</option>
                </select>
              </div>

              <!-- Purpose (Buy / Rent) -->
              <div>
                <label style="font-size: 0.75rem; font-weight: 800; text-transform: uppercase; color: #555; display: block; margin-bottom: 6px; letter-spacing: 0.05em;">Purpose</label>
                <select id="filter-purpose" style="width: 100%; padding: 12px 14px; font-size: 0.9rem; border-radius: 10px; border: 1px solid #cbd5e0; background: #fff; outline: none;">
                  <option value="all" ${e.purpose===`all`?`selected`:``}>Buy & Rent</option>
                  <option value="buy" ${e.purpose===`buy`?`selected`:``}>Buy Only</option>
                  <option value="rent" ${e.purpose===`rent`?`selected`:``}>Rent Only</option>
                </select>
              </div>

              <!-- Budget Range -->
              <div>
                <label style="font-size: 0.75rem; font-weight: 800; text-transform: uppercase; color: #555; display: block; margin-bottom: 6px; letter-spacing: 0.05em;">Max Budget</label>
                <select id="filter-budget" style="width: 100%; padding: 12px 14px; font-size: 0.9rem; border-radius: 10px; border: 1px solid #cbd5e0; background: #fff; outline: none;">
                  <option value="all" ${e.budget===`all`?`selected`:``}>Any Price</option>
                  <option value="5000000" ${e.budget===`5000000`?`selected`:``}>Upto ₹ 50 Lakhs</option>
                  <option value="15000000" ${e.budget===`15000000`?`selected`:``}>Upto ₹ 1.5 Cr</option>
                  <option value="30000000" ${e.budget===`30000000`?`selected`:``}>Upto ₹ 3.0 Cr</option>
                  <option value="50000000" ${e.budget===`50000000`?`selected`:``}>Upto ₹ 5.0 Cr</option>
                  ${e.budget!==`all`&&![`5000000`,`15000000`,`30000000`,`50000000`].includes(String(e.budget))?`<option value="${e.budget}" selected>Upto ₹ ${(Number(e.budget)/1e7).toFixed(1)} Cr</option>`:``}
                </select>
              </div>

            </div>
          </div>

        </div>
      </section>

      <!-- PROPERTY RESULTS SECTION -->
      <section style="padding: 60px 0 90px 0; background: #ffffff;">
        <div class="container">
          
          <!-- Results Count & Active Filters Indicator -->
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; flex-wrap: wrap; gap: 16px;">
            <div style="font-size: 1.1rem; font-weight: 700; color: #1a1a1a;">
              Showing <span style="color: var(--color-orange, #eb5e28);">${i.length}</span> ${i.length===1?`property`:`properties`}
            </div>

            ${Le(e)?`
              <button class="os-btn-secondary" id="clear-all-filters-btn" style="font-size: 0.85rem; padding: 6px 16px; border-radius: 20px; color: #e53e3e;">
                <i class="ri-close-circle-line"></i> Clear Filters
              </button>
            `:``}
          </div>

          <!-- Cards Grid or Empty State -->
          ${i.length>0?`
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(340px, 1fr)); gap: 32px;">
              ${i.map(e=>`
                <div class="discover-prop-card hover-lift" data-id="${e.id}" style="
                  background: #ffffff; border-radius: 20px; overflow: hidden;
                  border: 1px solid rgba(0,0,0,0.08); box-shadow: 0 4px 18px rgba(0,0,0,0.04);
                  display: flex; flex-direction: column; cursor: pointer; transition: all 0.3s ease;
                ">
                  <div style="position: relative; width: 100%; height: 240px; overflow: hidden; background: #111;">
                    <img src="${e.images[0]}" alt="${e.title}" style="width: 100%; height: 100%; object-fit: cover;" />
                    
                    <span class="badge badge-orange" style="position: absolute; top: 16px; left: 16px; font-weight: 700;">
                      ${e.categoryLabel}
                    </span>

                    <span class="badge badge-dark" style="position: absolute; top: 16px; right: 16px; text-transform: uppercase;">
                      ${e.purpose===`rent`?`For Rent`:`For Sale`}
                    </span>
                  </div>

                  <div style="padding: 24px; display: flex; flex-direction: column; flex: 1;">
                    <div style="font-family: var(--font-serif); font-size: 1.4rem; font-weight: 700; color: var(--color-orange, #eb5e28); margin-bottom: 6px;">
                      ${e.priceFormatted}
                    </div>

                    <h3 style="font-family: var(--font-serif); font-size: 1.2rem; font-weight: 700; color: #1a1a1a; margin-bottom: 8px;">
                      ${e.title}
                    </h3>

                    <div style="display: flex; align-items: center; gap: 6px; font-size: 0.88rem; color: #666; margin-bottom: 16px;">
                      <i class="ri-map-pin-2-line" style="color: var(--color-orange, #eb5e28);"></i>
                      <span>${c(e.location,e.district)}</span>
                    </div>

                    ${e.description?`
                      <p style="font-size: 0.88rem; color: #666; line-height: 1.5; margin-bottom: 20px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                        ${e.description}
                      </p>
                    `:``}

                    <div style="display: flex; gap: 14px; padding-top: 14px; border-top: 1px solid rgba(0,0,0,0.06); font-size: 0.85rem; color: #555; margin-top: auto; flex-wrap: wrap;">
                      ${e.size?`<span><i class="ri-ruler-2-line"></i> ${z(e.size)}</span>`:``}
                      ${e.facing?`<span><i class="ri-compass-3-line"></i> ${e.facing}</span>`:``}
                      ${e.bedrooms?`<span><i class="ri-hotel-bed-line"></i> ${e.bedrooms} BHK</span>`:e.approval?`<span><i class="ri-shield-check-line"></i> ${e.approval}</span>`:``}
                    </div>

                    <button class="btn btn-outline-dark" style="margin-top: 20px; width: 100%; border-radius: 10px; font-size: 0.9rem;">
                      <span>View Property Details</span>
                      <i class="ri-arrow-right-line"></i>
                    </button>
                  </div>
                </div>
              `).join(``)}
            </div>
          `:`
            <!-- Empty State -->
            <div style="
              text-align: center; padding: 80px 20px; background: #faf8f5; border-radius: 24px;
              border: 1px dashed #cbd5e0; max-width: 580px; margin: 0 auto;
            ">
              <i class="ri-search-eye-line" style="font-size: 3.5rem; color: #a0aec0; margin-bottom: 16px; display: block;"></i>
              <h3 style="font-family: var(--font-serif); font-size: 1.5rem; color: #2d3748; margin-bottom: 10px;">
                No properties found
              </h3>
              <p style="color: #718096; font-size: 0.95rem; margin-bottom: 24px; line-height: 1.6;">
                We couldn't find any properties matching your current filter selections. Try adjusting your search query or location filters.
              </p>
              <button class="btn btn-primary" id="empty-clear-filters-btn" style="padding: 12px 28px; border-radius: 10px;">
                <i class="ri-refresh-line"></i> Clear All Filters
              </button>
            </div>
          `}

        </div>
      </section>

    </div>
  `}var B=0;function V(e){if(!e)return[];let t=[];if(Array.isArray(e))t=e;else if(typeof e==`string`){let n=e.trim();if(n.startsWith(`[`)&&n.endsWith(`]`))try{let e=JSON.parse(n);t=Array.isArray(e)?e:[n]}catch{t=n.split(/[\n,]+/)}else t=n.split(/[\n,]+/)}return t.map(e=>typeof e==`string`?e.trim():``).filter(Boolean)}function Pe(e){if(!e||typeof e!=`string`)return null;let t=e.trim();if(!t)return null;let n=t.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/|youtube\.com\/shorts\/)([^"&?\/\s]{11})/i);return n&&n[1]?{type:`youtube`,embedUrl:`https://www.youtube.com/embed/${n[1]}?autoplay=1&rel=0`}:/facebook\.com|fb\.watch|fb\.com/i.test(t)?{type:`facebook`,embedUrl:`https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(t)}&show_text=0&width=560&autoplay=1`}:/\.(mp4|webm|ogg|mov)(\?.*)?$/i.test(t)||t.startsWith(`data:video/`)?{type:`file`,url:t}:{type:`iframe`,url:t}}function Fe(e,t){let n=Array.isArray(e.images)?e.images.filter(Boolean):[],r=[...new Set(n)],i=r.length>0?r:[`/default-property.jpg`],a=V(e.videoUrl||e.videos),o=i.map((e,t)=>({type:`image`,url:e,index:t+1,total:i.length}));a.forEach((e,t)=>{o.push({type:`video`,url:e,index:t+1,total:a.length})}),B>=o.length&&(B=0);let l=o[B]||o[0],u=l.type===`video`,d=u?Pe(l.url):null;return`
    <div class="page-view view-enter property-detail-page" style="padding-top: 110px; padding-bottom: 90px; background: #faf8f5;">
      <div class="container" style="max-width: 1140px;">
        
        <!-- Back Navigation & Action Header -->
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 16px;">
          <button class="os-btn-secondary" id="back-to-discover-btn" style="font-size: 0.9rem; padding: 10px 20px; border-radius: 10px; font-weight: 700; background: #ffffff; border: 1px solid #E2E8F0; color: #4A5568; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
            <i class="ri-arrow-left-line" style="color: #eb5e28;"></i> Back to Find Your Property
          </button>

          <div style="display: flex; gap: 10px; align-items: center;">
            ${e.approval?`
              <span style="background: #E6FFFA; color: #234E52; font-weight: 800; padding: 6px 14px; border-radius: 20px; font-size: 0.8rem; display: inline-flex; align-items: center; gap: 6px; border: 1px solid #B2F5EA;">
                <i class="ri-checkbox-circle-fill" style="color: #38A169;"></i> ${e.approval}
              </span>
            `:``}
          </div>
        </div>

        <!-- MAIN LUXURY CARD CONTAINER -->
        <div style="background: #ffffff; border-radius: 24px; overflow: hidden; border: 1px solid rgba(0,0,0,0.08); box-shadow: 0 16px 48px rgba(0,0,0,0.06);">
          
          <!-- STATE-OF-THE-ART HERO MEDIA VIEWPORT (500px) WITH CAROUSEL ARROWS -->
          <div style="width: 100%; position: relative;">
            <div style="width: 100%; height: 500px; background: #0f172a; overflow: hidden; position: relative; display: flex; align-items: center; justify-content: center;">
              ${u?`
                ${d?.type===`youtube`||d?.type===`facebook`||d?.type===`iframe`?`
                  <iframe src="${d.embedUrl||d.url}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen style="width: 100%; height: 100%; border: 0; background: #000;"></iframe>
                `:`
                  <video src="${d?.url||l.url}" controls autoplay style="width: 100%; height: 100%; object-fit: contain; background: #000;"></video>
                `}
              `:`
                <img id="detail-hero-img" src="${l.url}" alt="${e.title}" style="width: 100%; height: 100%; object-fit: cover; transition: opacity 0.3s ease;" />
              `}

              <!-- Top Left Counter Badge -->
              <div style="position: absolute; top: 20px; left: 20px; background: rgba(0,0,0,0.75); color: #ffffff; font-size: 0.82rem; font-weight: 700; padding: 6px 16px; border-radius: 20px; backdrop-filter: blur(6px); display: flex; align-items: center; gap: 6px; z-index: 10;">
                <i class="${u?`ri-movie-line`:`ri-image-line`}" style="color: #eb5e28;"></i>
                <span id="detail-photo-counter">${u?a.length>1?`Property Video ${l.index} of ${a.length}`:`Property Video Tour`:`Photo ${B+1} of ${i.length}`}</span>
              </div>

              <!-- Top Right Status Badge -->
              <span style="position: absolute; top: 20px; right: 20px; background: #eb5e28; color: #ffffff; font-size: 0.8rem; font-weight: 800; padding: 6px 16px; border-radius: 20px; z-index: 10; box-shadow: 0 4px 14px rgba(0,0,0,0.25); letter-spacing: 0.05em; text-transform: uppercase;">
                ${e.purpose===`rent`?`FOR RENT`:`FOR SALE`}
              </span>

              <!-- Left/Right Carousel Swipe Arrows -->
              ${o.length>1?`
                <button id="detail-prev-photo-btn" title="Previous media" style="
                  position: absolute; left: 20px; top: 50%; transform: translateY(-50%); width: 48px; height: 48px; border-radius: 50%;
                  background: rgba(0,0,0,0.65); color: #ffffff; border: 1px solid rgba(255,255,255,0.3); font-size: 1.5rem;
                  display: flex; align-items: center; justify-content: center; cursor: pointer; backdrop-filter: blur(8px);
                  box-shadow: 0 4px 16px rgba(0,0,0,0.4); z-index: 10; transition: all 0.2s ease;
                ">
                  <i class="ri-arrow-left-s-line"></i>
                </button>

                <button id="detail-next-photo-btn" title="Next media" style="
                  position: absolute; right: 20px; top: 50%; transform: translateY(-50%); width: 48px; height: 48px; border-radius: 50%;
                  background: rgba(0,0,0,0.65); color: #ffffff; border: 1px solid rgba(255,255,255,0.3); font-size: 1.5rem;
                  display: flex; align-items: center; justify-content: center; cursor: pointer; backdrop-filter: blur(8px);
                  box-shadow: 0 4px 16px rgba(0,0,0,0.4); z-index: 10; transition: all 0.2s ease;
                ">
                  <i class="ri-arrow-right-s-line"></i>
                </button>
              `:``}
            </div>

            <!-- Thumbnail Selector Bar Below Hero Image -->
            ${o.length>1?`
              <div style="display: flex; gap: 12px; overflow-x: auto; padding: 16px 20px; background: #1A202C; scrollbar-width: thin; scrollbar-color: #eb5e28 #2D3748;">
                ${o.map((e,t)=>`
                  <div class="detail-thumb-item" data-index="${t}" style="
                    width: 96px; height: 68px; border-radius: 10px; overflow: hidden; flex-shrink: 0; cursor: pointer;
                    border: 2px solid ${t===B?`#eb5e28`:`transparent`};
                    opacity: ${t===B?`1`:`0.6`}; transition: all 0.2s ease;
                    position: relative; background: #111;
                  ">
                    ${e.type===`image`?`
                      <img src="${e.url}" style="width: 100%; height: 100%; object-fit: cover;" />
                    `:`
                      <div style="width: 100%; height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center; background: linear-gradient(135deg, #2d3748 0%, #1a202c 100%); color: #ffffff;">
                        <i class="ri-play-circle-fill" style="font-size: 1.8rem; color: #eb5e28;"></i>
                        <span style="font-size: 0.65rem; font-weight: 800; letter-spacing: 0.05em; margin-top: 2px;">VIDEO ${a.length>1?e.index:``}</span>
                      </div>
                    `}
                  </div>
                `).join(``)}
              </div>
            `:``}
          </div>

          <!-- MAIN PROPERTY DETAILS BODY CONTENT -->
          <div style="padding: 40px;">
            
            <!-- Title & Price Header Row -->
            <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 24px; margin-bottom: 32px; padding-bottom: 24px; border-bottom: 1px solid #EDF2F7;">
              <div style="flex: 1; min-width: 280px;">
                <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px; flex-wrap: wrap;">
                  <span class="badge badge-orange" style="font-size: 0.82rem; font-weight: 800; letter-spacing: 0.08em; display: inline-block;">
                    ${e.categoryLabel||e.type||`Property`}
                  </span>
                  <span style="font-size: 0.82rem; font-weight: 800; letter-spacing: 0.08em; text-transform: uppercase; color: #718096; background: #EDF2F7; padding: 4px 10px; border-radius: 8px; display: inline-flex; align-items: center; gap: 4px; border: 1px solid #E2E8F0;">
                    <i class="ri-hashtag" style="color: #eb5e28; font-size: 0.9rem;"></i> ID: ${e.id}
                  </span>
                </div>
                <h1 style="font-family: var(--font-serif); font-size: clamp(1.8rem, 3.5vw, 2.6rem); font-weight: 800; color: #1A202C; margin-bottom: 10px; line-height: 1.25;">
                  ${e.title}
                </h1>
                <div style="display: flex; align-items: center; gap: 8px; font-size: 1.05rem; color: #4A5568; font-weight: 600;">
                  <a href="${e.latitude&&e.longitude?`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(e.latitude)},${encodeURIComponent(e.longitude)}`:`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent([e.location,e.district,`Tamil Nadu`].filter(Boolean).join(`, `))}`}" target="_blank" rel="noopener noreferrer" style="color: #4A5568; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; transition: color 0.2s ease;" onmouseover="this.style.color='#eb5e28'" onmouseout="this.style.color='#4A5568'" title="Open Location on Google Maps">
                    <i class="ri-map-pin-2-fill" style="color: #eb5e28; font-size: 1.2rem;"></i>
                    <span>${c(e.location,e.district)}</span>
                    <i class="ri-external-link-line" style="font-size: 0.85rem; color: #a0aec0;"></i>
                  </a>
                </div>
              </div>

              <div style="background: #FFF5F2; padding: 20px 28px; border-radius: 16px; border: 1px solid #FFD0C2; text-align: right; min-width: 220px;">
                <span style="font-size: 0.8rem; color: #718096; text-transform: uppercase; font-weight: 800; letter-spacing: 0.05em; display: block; margin-bottom: 4px;">Asking Price</span>
                <div style="font-family: var(--font-serif); font-size: 2.5rem; font-weight: 800; color: #eb5e28; line-height: 1;">
                  ${e.priceFormatted||`₹ `+e.price}
                </div>
                <span style="font-size: 0.78rem; color: #4A5568; font-weight: 700; display: block; margin-top: 6px;">
                  100% Verified Ownership & Clear Patta Title
                </span>
              </div>
            </div>

            <!-- KEY SPECIFICATIONS GRID -->
            <div style="
              display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 16px;
              padding: 24px; background: #F8FAFC; border-radius: 16px; border: 1px solid #E2E8F0; margin-bottom: 36px;
            ">
              ${e.size?`
                <div>
                  <span style="font-size: 0.75rem; color: #718096; text-transform: uppercase; font-weight: 800; display: block; margin-bottom: 4px;">Total Area</span>
                  <strong style="font-size: 1.05rem; color: #1A202C;"><i class="ri-ruler-2-line" style="color: #eb5e28;"></i> ${z(e.size)}</strong>
                </div>
              `:``}

              ${e.facing||e.address?`
                <div>
                  <span style="font-size: 0.75rem; color: #718096; text-transform: uppercase; font-weight: 800; display: block; margin-bottom: 4px;">Facing</span>
                  <strong style="font-size: 1.05rem; color: #1A202C;"><i class="ri-compass-3-line" style="color: #eb5e28;"></i> ${e.facing||e.address}</strong>
                </div>
              `:``}

              ${e.approval?`
                <div>
                  <span style="font-size: 0.75rem; color: #718096; text-transform: uppercase; font-weight: 800; display: block; margin-bottom: 4px;">Approval Status</span>
                  <strong style="font-size: 1.05rem; color: #1A202C;"><i class="ri-shield-check-line" style="color: #38A169;"></i> ${e.approval}</strong>
                </div>
              `:``}

              ${e.road&&e.road!==`Other / Outside Road`?`
                <div>
                  <span style="font-size: 0.75rem; color: #718096; text-transform: uppercase; font-weight: 800; display: block; margin-bottom: 4px;">Road Corridor</span>
                  <strong style="font-size: 1.05rem; color: #1A202C;"><i class="ri-road-map-line" style="color: #eb5e28;"></i> ${e.road}</strong>
                </div>
              `:``}

              ${e.taluk?`
                <div>
                  <span style="font-size: 0.75rem; color: #718096; text-transform: uppercase; font-weight: 800; display: block; margin-bottom: 4px;">Taluk</span>
                  <strong style="font-size: 1.05rem; color: #1A202C;"><i class="ri-government-line" style="color: #eb5e28;"></i> ${e.taluk}</strong>
                </div>
              `:``}

              ${e.district?`
                <div>
                  <span style="font-size: 0.75rem; color: #718096; text-transform: uppercase; font-weight: 800; display: block; margin-bottom: 4px;">District</span>
                  <strong style="font-size: 1.05rem; color: #1A202C;"><i class="ri-map-pin-line" style="color: #eb5e28;"></i> ${e.district}</strong>
                </div>
              `:``}

              ${e.bedrooms?`
                <div>
                  <span style="font-size: 0.75rem; color: #718096; text-transform: uppercase; font-weight: 800; display: block; margin-bottom: 4px;">Bedrooms</span>
                  <strong style="font-size: 1.05rem; color: #1A202C;"><i class="ri-hotel-bed-line" style="color: #eb5e28;"></i> ${e.bedrooms} BHK</strong>
                </div>
              `:``}

              ${e.bathrooms?`
                <div>
                  <span style="font-size: 0.75rem; color: #718096; text-transform: uppercase; font-weight: 800; display: block; margin-bottom: 4px;">Bathrooms</span>
                  <strong style="font-size: 1.05rem; color: #1A202C;"><i class="ri-drop-line" style="color: #eb5e28;"></i> ${e.bathrooms} Baths</strong>
                </div>
              `:``}

              ${e.furnishing&&e.furnishing!==`Not specified`?`
                <div>
                  <span style="font-size: 0.75rem; color: #718096; text-transform: uppercase; font-weight: 800; display: block; margin-bottom: 4px;">Furnishing</span>
                  <strong style="font-size: 1.05rem; color: #1A202C;"><i class="ri-armchair-line" style="color: #eb5e28;"></i> ${e.furnishing}</strong>
                </div>
              `:``}
            </div>

            <!-- POSTER / OWNER INFORMATION CARD -->
            ${(()=>{let t=String(e.adType||e.ad_type||e.adTier||e.listingPlan||``).toLowerCase().trim()===`paid`,n=t?e.ownerName||`Verified Owner`:`Thanjai Property`,r=t?e.ownerPhone||e.inquiryPhone||`8489996852`:e.inquiryPhone||`8489996852`,i=String(r).replace(/[^0-9]/g,``),a=i.length===10?`+91 ${i}`:i.startsWith(`91`)&&i.length===12?`+${i}`:`+91 ${r}`,o=i.startsWith(`91`)&&i.length===12?i:i.length===10?`91${i}`:`918489996852`;return`
                <div style="background: #FAF8F5; padding: 20px 24px; border-radius: 16px; border: 1px solid #E7E0D8; margin-bottom: 36px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
                  <div>
                    <span style="font-size: 0.78rem; font-weight: 800; color: #718096; text-transform: uppercase; letter-spacing: 0.05em; display: block; margin-bottom: 4px;">Verified Property Seller / Specialist:</span>
                    <strong style="font-size: 1.1rem; color: #1A202C;">${n}</strong>
                    <div style="font-size: 0.75rem; font-weight: 700; color: ${t?`#38A169`:`#eb5e28`}; margin-top: 2px;">
                      ${t?`👑 Direct Owner Listing • 0% Brokerage`:`🛡️ Executive Real Estate Advisory Desk`}
                    </div>
                  </div>

                  <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                    <a href="tel:${a.replace(/\s+/g,``)}" style="background: #ffffff; border: 1px solid #CBD5E0; color: #2D3748; padding: 10px 18px; border-radius: 10px; font-weight: 700; font-size: 0.88rem; text-decoration: none; display: inline-flex; align-items: center; gap: 6px;">
                      <i class="ri-phone-line" style="color: #eb5e28;"></i> ${t?`Call Owner (${a})`:`Call Seller (${a})`}
                    </a>
                    <a href="${t?`https://wa.me/${o}?text=Hi%20${encodeURIComponent(n)},%20I%20am%20interested%20in%20your%20property%20${encodeURIComponent(e.title)}%20(ID:%20${encodeURIComponent(e.id)})`:`https://wa.me/${o}?text=Hello%20Thanjai%20Property,%20I%20am%20interested%20in%20${encodeURIComponent(e.title)}%20(ID:%20${encodeURIComponent(e.id)})`}" target="_blank" style="background: #25D366; color: #ffffff; border: none; padding: 10px 18px; border-radius: 10px; font-weight: 700; font-size: 0.88rem; text-decoration: none; display: inline-flex; align-items: center; gap: 6px; box-shadow: 0 4px 12px rgba(37,211,102,0.25);">
                      <i class="ri-whatsapp-line"></i> ${t?`WhatsApp Owner`:`WhatsApp Chat`}
                    </a>
                    <a href="mailto:vijayaraghavan@thanjaiproperty.com?subject=Inquiry%20for%20${encodeURIComponent(e.title)}" style="background: #1a1a1a; color: #ffffff; border: none; padding: 10px 18px; border-radius: 10px; font-weight: 700; font-size: 0.88rem; text-decoration: none; display: inline-flex; align-items: center; gap: 6px;">
                      <i class="ri-mail-line" style="color: #eb5e28;"></i> Email Us
                    </a>
                  </div>
                </div>
              `})()}

            <!-- DESCRIPTION OVERVIEW -->
            ${e.description?`
              <div style="margin-bottom: 40px;">
                <h3 style="font-family: var(--font-serif); font-size: 1.4rem; font-weight: 800; margin-bottom: 14px; color: #1A202C;">Property Overview</h3>
                <p style="font-size: 1.05rem; color: #4A5568; line-height: 1.7; margin: 0; white-space: pre-line;">
                  ${e.description}
                </p>
              </div>
            `:``}

            <!-- KEY FEATURES & AMENITIES GRID -->
            ${e.features&&e.features.length>0?`
              <div style="margin-bottom: 40px;">
                <h3 style="font-family: var(--font-serif); font-size: 1.4rem; font-weight: 800; margin-bottom: 18px; color: #1A202C;">Key Highlights & Amenities</h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 14px;">
                  ${e.features.map(e=>`
                    <div style="display: flex; align-items: center; gap: 10px; font-size: 0.95rem; font-weight: 700; color: #2D3748; background: #FAF8F5; padding: 14px 18px; border-radius: 12px; border: 1px solid #E7E0D8;">
                      <i class="ri-checkbox-circle-fill" style="color: #38A169; font-size: 1.2rem;"></i>
                      <span>${e}</span>
                    </div>
                  `).join(``)}
                </div>
              </div>
            `:``}

            <!-- LUXURY ADVISORY & SITE VISIT CTA BANNER -->
            <div style="
              padding: 36px; background: linear-gradient(135deg, #1C1007 0%, #2A1808 100%); color: #ffffff; border-radius: 20px;
              display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 24px; box-shadow: 0 12px 30px rgba(0,0,0,0.15);
            ">
              <div>
                <h3 style="font-family: var(--font-serif); font-size: 1.75rem; color: #ffffff; margin-bottom: 6px; font-weight: 800;">
                  Interested in visiting this property?
                </h3>
                <p style="color: rgba(255,255,255,0.85); font-size: 0.98rem; margin: 0;">
                  Schedule a private site tour or connect directly with our senior property advisory desk.
                </p>
              </div>

              <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                <button class="btn btn-primary" id="detail-enquire-btn" style="padding: 14px 32px; font-size: 1rem; border-radius: 12px; font-weight: 800;">
                  <i class="ri-mail-send-line"></i> Enquire Now
                </button>
              </div>
            </div>

            <!-- RELATED / SIMILAR PROPERTIES SECTION -->
            ${(()=>{let t=String(e.id||``).trim().toLowerCase(),n=String(e.title||``).trim().toLowerCase(),r=s().filter(e=>{if(!e)return!1;let r=String(e.id||``).trim().toLowerCase(),i=String(e.title||``).trim().toLowerCase();return r!==t&&i!==n}),i=new Set([`for`,`sale`,`in`,`near`,`the`,`a`,`an`,`and`,`at`,`with`,`to`,`of`,`on`,`is`,`new`,`tp`]),a=(e.title+` `+(e.description||``)+` `+(e.category||``)+` `+(e.type||``)+` `+(e.road||``)+` `+(e.taluk||``)+` `+(e.area||``)).toLowerCase().replace(/[^a-z0-9\s]/g,` `).split(/\s+/).filter(e=>e.length>2&&!i.has(e)),o=new Set(a),c=r.map(t=>{let n=0,r=(t.title||``).toLowerCase(),i=(t.description||``).toLowerCase(),a=(r+` `+i+` `+(t.category||``)+` `+(t.type||``)+` `+(t.road||``)+` `+(t.taluk||``)+` `+(t.area||``)).toLowerCase();return e.road&&e.road!==`Other / Outside Road`&&t.road&&t.road===e.road&&(n+=35),e.category&&t.category&&e.category.toLowerCase()===t.category.toLowerCase()&&(n+=30),e.type&&t.type&&e.type.toLowerCase()===t.type.toLowerCase()&&(n+=25),o.forEach(e=>{r.includes(e)?n+=15:a.includes(e)&&(n+=8)}),e.taluk&&t.taluk&&e.taluk.toLowerCase()===t.taluk.toLowerCase()&&(n+=20),e.area&&t.area&&(e.area.toLowerCase().includes(t.area.toLowerCase())||t.area.toLowerCase().includes(e.area.toLowerCase()))&&(n+=20),e.district&&t.district&&e.district.toLowerCase()===t.district.toLowerCase()&&(n+=10),{property:t,score:n}});c.sort((e,t)=>t.score-e.score);let l=new Set,u=[];for(let e of c){let r=e.property,i=String(r.id||``).trim().toLowerCase(),a=String(r.title||``).trim().toLowerCase();if(i!==t&&a!==n&&(!l.has(i)&&!l.has(a)&&(l.add(i),l.add(a),u.push(r)),u.length>=3))break}return u.length===0?``:`
                <div style="margin-top: 50px;">
                  <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 24px; flex-wrap: wrap; gap: 12px;">
                    <div>
                      <span style="font-size: 0.8rem; font-weight: 800; color: #eb5e28; text-transform: uppercase; letter-spacing: 0.08em; display: block; margin-bottom: 4px;">EXPLORE MORE OPTIONS</span>
                      <h3 style="font-family: var(--font-serif); font-size: 1.8rem; font-weight: 800; color: #1A202C; margin: 0;">
                        Similar Properties in this Location & Category
                      </h3>
                    </div>
                    <button id="view-all-similar-btn" style="background: none; border: none; padding: 0; color: #eb5e28; font-weight: 700; font-size: 0.92rem; cursor: pointer; display: inline-flex; align-items: center; gap: 6px;">
                      View All Listings <i class="ri-arrow-right-line"></i>
                    </button>
                  </div>

                  <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px;">
                    ${u.map(e=>{let t=e.images&&e.images[0]?e.images[0]:`/default-property.jpg`,n=e.area||e.location||e.district||`Thanjavur`;return`
                        <div class="property-card discover-prop-card related-prop-card" data-id="${e.id}" style="background: #ffffff; border-radius: 16px; border: 1px solid #E2E8F0; overflow: hidden; box-shadow: 0 4px 16px rgba(0,0,0,0.04); display: flex; flex-direction: column; transition: transform 0.2s ease, box-shadow 0.2s ease; cursor: pointer;">
                          <div style="height: 180px; position: relative; overflow: hidden;">
                            <img src="${t}" alt="${e.title}" style="width: 100%; height: 100%; object-fit: cover;" />
                            <span style="position: absolute; top: 12px; left: 12px; background: rgba(0,0,0,0.7); color: #fff; padding: 4px 10px; border-radius: 6px; font-size: 0.72rem; font-weight: 800; text-transform: uppercase;">
                              ${e.categoryLabel||e.type||`Property`}
                            </span>
                            ${e.road&&e.road!==`Other / Outside Road`?`
                              <span style="position: absolute; bottom: 10px; left: 12px; background: #eb5e28; color: #fff; padding: 3px 8px; border-radius: 4px; font-size: 0.68rem; font-weight: 700;">
                                <i class="ri-road-map-line"></i> ${e.road}
                              </span>
                            `:``}
                          </div>
                          <div style="padding: 16px 18px; display: flex; flex-direction: column; flex: 1;">
                            <div style="font-size: 1.15rem; font-weight: 800; color: #eb5e28; margin-bottom: 4px;">
                              ${e.priceFormatted||`₹ `+(e.price||0).toLocaleString(`en-IN`)}
                            </div>
                            <h4 style="font-size: 0.98rem; font-weight: 700; color: #1A202C; margin: 0 0 6px 0; line-height: 1.35; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                              ${e.title}
                            </h4>
                            <p style="font-size: 0.8rem; color: #718096; margin: 0 0 12px 0; display: flex; align-items: center; gap: 4px;">
                              <i class="ri-map-pin-line" style="color: #eb5e28;"></i> ${n}
                            </p>
                            <div style="margin-top: auto; padding-top: 10px; border-top: 1px solid #EDF2F7; display: flex; justify-content: space-between; align-items: center; font-size: 0.8rem; color: #4A5568; font-weight: 700;">
                              <span>${e.size?z(e.size):`Prime Plot`}</span>
                              <span style="color: #eb5e28; display: inline-flex; align-items: center; gap: 2px;">
                                Details <i class="ri-arrow-right-s-line"></i>
                              </span>
                            </div>
                          </div>
                        </div>
                      `}).join(``)}
                  </div>
                </div>
              `})()}

          </div>

        </div>

      </div>
    </div>
  `}function Ie(e){return s().filter(t=>{if(!t)return!1;let n=(t.title||``).toLowerCase(),r=(t.location||``).toLowerCase(),i=(t.district||``).toLowerCase(),a=(t.categoryLabel||``).toLowerCase(),o=(t.type||``).toLowerCase(),s=(t.category||``).toLowerCase();if(e.keyword&&e.keyword.trim()!==``){let t=e.keyword.toLowerCase().trim(),c=n.includes(t),l=r.includes(t),u=i.includes(t),d=a.includes(t)||s.includes(t)||o.includes(t);if(!c&&!l&&!u&&!d)return!1}if(e.type&&e.type!==`all`){let t=e.type.toLowerCase();if(!(s===t||o.includes(t)||a.includes(t)))return!1}if(e.location&&e.location!==`all`){let t=e.location.toLowerCase();if(!(r.includes(t)||i.includes(t)))return!1}if(e.purpose&&e.purpose!==`all`&&t.purpose!==e.purpose)return!1;if(e.budget&&e.budget!==`all`){let n=t.price||0,r=Number(e.budget);if(isNaN(r)&&(e.budget===`under-50l`?r=5e6:e.budget===`50l-1.5cr`?r=15e6:e.budget===`1.5cr-3cr`?r=3e7:e.budget===`above-3cr`&&(r=9999e6)),r>0&&n>r)return!1}return!0})}function Le(e){return!!(e.keyword&&e.keyword.trim()!==``||e.type&&e.type!==`all`||e.location&&e.location!==`all`||e.purpose&&e.purpose!==`all`||e.budget&&e.budget!==`all`)}function Re(e,t,n,r){let i=document.getElementById(`back-to-discover-btn`);i&&i.addEventListener(`click`,()=>{B=0,n(null)});let a=e.selectedPropertyId?s().find(t=>t.id===e.selectedPropertyId):null,o=document.getElementById(`detail-enquire-btn`);o&&a&&o.addEventListener(`click`,e=>{e.preventDefault(),g(a)});let c=a&&Array.isArray(a.images)?a.images.filter(Boolean):[],l=a?V(a.videoUrl||a.videos):[],u=Math.max(1,c.length+l.length);document.getElementById(`detail-prev-photo-btn`)?.addEventListener(`click`,()=>{u>1&&(B=(B-1+u)%u,t(e))}),document.getElementById(`detail-next-photo-btn`)?.addEventListener(`click`,()=>{u>1&&(B=(B+1)%u,t(e))}),document.querySelectorAll(`.detail-thumb-item`).forEach(n=>{n.addEventListener(`click`,()=>{let r=parseInt(n.dataset.index,10);isNaN(r)||(B=r,t(e))})}),document.getElementById(`discover-search-input`)?.addEventListener(`input`,n=>{e.keyword=n.target.value,t(e)}),document.getElementById(`filter-type`)?.addEventListener(`change`,n=>{e.type=n.target.value,t(e)}),document.getElementById(`filter-location`)?.addEventListener(`change`,n=>{e.location=n.target.value,t(e)}),document.getElementById(`filter-purpose`)?.addEventListener(`change`,n=>{e.purpose=n.target.value,t(e)}),document.getElementById(`filter-budget`)?.addEventListener(`change`,n=>{e.budget=n.target.value,t(e)}),[document.getElementById(`clear-all-filters-btn`),document.getElementById(`empty-clear-filters-btn`)].forEach(n=>{n?.addEventListener(`click`,()=>{e.keyword=``,e.type=`all`,e.location=`all`,e.purpose=`all`,e.budget=`all`,t(e)})}),document.getElementById(`view-all-similar-btn`)?.addEventListener(`click`,e=>{e.preventDefault(),n&&(B=0,window.scrollTo({top:0,behavior:`smooth`}),n(null))}),document.querySelectorAll(`.discover-prop-card, .related-prop-card`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault();let r=e.dataset.id;r&&n&&(B=0,window.scrollTo({top:0,behavior:`smooth`}),n(r))})})}function ze(e,t,n){let r=_();if(e.selectedPostId){let t=v(e.selectedPostId);if(t)return Ve(t,n,r)}let i=He(e,r),a=i[0]||r[0],o=i.length>1?i.slice(1):[];return`
    <div class="page-view view-enter blog-page">
      
      <!-- HERO -->
      <section style="
        padding: 120px 0 60px 0;
        background: linear-gradient(135deg, #1c1007 0%, #2a1808 60%, #150b04 100%);
        color: #ffffff; text-align: center; position: relative; overflow: hidden;
      ">
        <div class="container" style="max-width: 800px; position: relative; z-index: 2;">
          <span class="badge badge-orange" style="font-weight: 800; letter-spacing: 0.12em; margin-bottom: 16px;">
            REAL-ESTATE INSIGHTS
          </span>
          <h1 class="heading-display-light" style="font-size: clamp(2.2rem, 4.5vw, 3.8rem); color: #ffffff; margin-bottom: 12px;">
            Real-Estate Insights & Property Guides
          </h1>
          <div style="font-size: 1.05rem; font-weight: 700; color: rgba(255,255,255,0.9); margin-bottom: 14px;">Learn Before You Buy, Sell or Invest</div>
          <p style="font-size: 1.02rem; color: rgba(255, 255, 255, 0.85); line-height: 1.65; max-width: 720px; margin: 0 auto;">
            Read property guides, legal tips, local market insights and real-estate checklists to make informed property decisions across Tamil Nadu.
          </p>
        </div>
      </section>

      <!-- SEARCH BAR -->
      <section style="padding: 24px 0; background: #faf8f5; border-bottom: 1px solid rgba(0,0,0,0.06);">
        <div class="container" style="display: flex; justify-content: flex-end; align-items: center;">
          <!-- Search Input -->
          <div style="position: relative; width: 100%; max-width: 380px;">
            <i class="ri-search-line" style="position: absolute; left: 16px; top: 50%; transform: translateY(-50%); color: #718096; font-size: 1.05rem;"></i>
            <input 
              type="text" 
              id="blog-search-input" 
              value="${e.keyword||``}" 
              placeholder="Search articles or topics..." 
              style="
                width: 100%; padding: 11px 42px 11px 44px; font-size: 0.92rem; border-radius: 24px;
                border: 1px solid #cbd5e0; background: #ffffff; outline: none; transition: border-color 0.2s;
                box-shadow: 0 2px 6px rgba(0,0,0,0.03);
              "
            />
            ${e.keyword?`
              <button id="clear-blog-search-btn" title="Clear search" style="position: absolute; right: 14px; top: 50%; transform: translateY(-50%); background: none; border: none; cursor: pointer; color: #a0aec0; font-size: 1.1rem; display: flex; align-items: center; padding: 0;">
                <i class="ri-close-circle-fill"></i>
              </button>
            `:``}
          </div>
        </div>
      </section>

      <!-- ARTICLES CATALOG CONTAINER -->
      <section style="padding: 60px 0 90px 0; background: #ffffff;">
        <div class="container" style="max-width: 1140px;">
          
          ${i.length>0?`
            
            <!-- FEATURED MAIN ARTICLE BANNER -->
            ${a?`
              <article class="featured-blog-card hover-lift" data-id="${a.id}" data-slug="${a.slug||``}" style="
                background: #ffffff; border-radius: 24px; overflow: hidden;
                border: 1px solid rgba(0,0,0,0.08); box-shadow: 0 12px 36px rgba(0,0,0,0.06);
                display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
                margin-bottom: 50px; cursor: pointer; transition: all 0.3s ease;
              ">
                <div style="position: relative; aspect-ratio: 16/9; background: #0f172a; overflow: hidden; align-self: center; border-radius: 16px; margin: 24px; width: calc(100% - 48px); box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
                  <img src="${a.image}" alt="${a.title}" style="width: 100%; height: 100%; object-fit: cover; object-position: center;" />
                  <span class="badge badge-orange featured-cat-badge" style="position: absolute; top: 16px; left: 16px; font-weight: 800; letter-spacing: 0.05em; max-width: calc(100% - 32px); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: inline-block; font-size: 0.78rem; padding: 4px 12px; z-index: 2; box-shadow: 0 4px 12px rgba(0,0,0,0.15);">
                    FEATURED • ${a.category}
                  </span>
                </div>

                <div style="padding: 24px 32px; display: flex; flex-direction: column; justify-content: center;">
                  <div style="display: flex; align-items: center; gap: 8px; font-size: 0.85rem; color: #718096; font-weight: 700; margin-bottom: 16px;">
                    <i class="ri-calendar-line" style="color: #eb5e28;"></i>
                    <span>Published on ${a.date}</span>
                  </div>

                  <h2 style="font-family: var(--font-serif); font-size: clamp(1.5rem, 2.8vw, 2rem); font-weight: 800; color: #1A202C; line-height: 1.3; margin-bottom: 12px;">
                    ${a.title}
                  </h2>

                  <p style="font-size: 0.96rem; color: #4A5568; line-height: 1.6; margin-bottom: 16px; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;">
                    ${a.excerpt}
                  </p>

                  <div style="display: flex; align-items: center; justify-content: flex-end; margin-top: auto; padding-top: 20px; border-top: 1px solid #EDF2F7;">
                    <div style="font-size: 0.88rem; color: #eb5e28; font-weight: 800; display: inline-flex; align-items: center; gap: 6px;">
                      Read Article <i class="ri-arrow-right-line"></i>
                    </div>
                  </div>
                </div>
              </article>
            `:``}

            <!-- PREMIER GRID FOR ALL REMAINING ARTICLES -->
            ${o.length>0?`
              <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(330px, 1fr)); gap: 32px;">
                ${o.map(e=>`
                  <article class="blog-card hover-lift" data-id="${e.id}" data-slug="${e.slug||``}" style="
                    background: #ffffff; border-radius: 20px; overflow: hidden;
                    border: 1px solid rgba(0,0,0,0.08); box-shadow: 0 6px 20px rgba(0,0,0,0.04);
                    display: flex; flex-direction: column; cursor: pointer; transition: all 0.3s ease;
                  ">
                    <div style="position: relative; width: 100%; aspect-ratio: 16/9; max-height: 220px; overflow: hidden; background: #0f172a;">
                      <img src="${e.image}" alt="${e.title}" style="width: 100%; height: 100%; object-fit: cover; object-position: center;" />
                      <span class="badge badge-orange" style="position: absolute; top: 16px; left: 16px; font-size: 0.75rem; font-weight: 800;">
                        ${e.category}
                      </span>
                    </div>

                    <div style="padding: 24px; display: flex; flex-direction: column; flex: 1;">
                      <div style="display: flex; align-items: center; gap: 8px; font-size: 0.82rem; color: #718096; font-weight: 700; margin-bottom: 12px;">
                        <i class="ri-calendar-line" style="color: #eb5e28;"></i>
                        <span>Published on ${e.date}</span>
                      </div>

                      <h3 style="font-family: var(--font-serif); font-size: 1.3rem; font-weight: 800; color: #1A202C; line-height: 1.4; margin-bottom: 12px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                        ${e.title}
                      </h3>

                      <p style="font-size: 0.92rem; color: #4A5568; line-height: 1.6; margin-bottom: 24px; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;">
                        ${e.excerpt}
                      </p>

                      <div style="margin-top: auto; display: flex; align-items: center; justify-content: flex-end; padding-top: 16px; border-top: 1px solid #F1F5F9;">
                        <div style="font-weight: 800; font-size: 0.88rem; color: #eb5e28; display: inline-flex; align-items: center; gap: 4px;">
                          Read Article <i class="ri-arrow-right-line"></i>
                        </div>
                      </div>
                    </div>
                  </article>
                `).join(``)}
              </div>
            `:``}

          `:`
            <!-- Empty State -->
            <div style="text-align: center; padding: 70px 20px; background: #faf8f5; border-radius: 20px; max-width: 500px; margin: 0 auto; border: 1px dashed #CBD5E0;">
              <i class="ri-file-search-line" style="font-size: 3.5rem; color: #a0aec0; margin-bottom: 14px; display: block;"></i>
              <h3 style="font-family: var(--font-serif); font-size: 1.5rem; color: #2d3748; margin-bottom: 8px;">No articles found</h3>
              <p style="color: #718096; font-size: 0.95rem; margin-bottom: 20px;">Try selecting another category filter or keyword query.</p>
              <button class="btn btn-primary" id="reset-blog-filter-btn" style="padding: 10px 24px; font-size: 0.88rem; font-weight: 800;">
                Show All Articles
              </button>
            </div>
          `}

        </div>
      </section>

    </div>
  `}function Be(e){let t=(e||``).toLowerCase();return t.includes(`aishwarya`)?{role:`Senior Legal & Patta Verification Specialist`,bio:`Over 12 years of hands-on expertise in Tamil Nadu revenue administration, 30-year parent document tracing, and DTCP layout sanctions across Thanjavur & Trichy.`}:t.includes(`kavitha`)?{role:`Senior Investment & Capital Growth Analyst`,bio:`Specialist in central Tamil Nadu high-growth corridors, highway commercial plots, and real estate portfolio asset allocation.`}:t.includes(`vijay`)||t.includes(`ragavan`)?{role:`Managing Director, Thanjai Property`,bio:`Leading strategic land acquisitions, premium gated communities, and NRI property concierge services across Tamil Nadu since 2009.`}:{role:`Editorial Contributor & Property Specialist`,bio:`Dedicated real estate analyst at Thanjai Property, providing verified market intelligence and statutory compliance guidance for buyers and investors.`}}function Ve(e,t,n){let r=(n||_()).filter(t=>t.id!==e.id&&t.slug!==e.slug).slice(0,3),i=Be(e.author);e.authorRole||i.role,e.authorBio||i.bio,e.authorSocial;let a=e.content||`<p class="blog-lead">${e.excerpt}</p>`,o=[],s=/<(h[2-6])([^>]*)>(.*?)<\/\1>/gi,c,l=0;for(;(c=s.exec(a))!==null;){let e=c[1].toLowerCase(),t=c[3].replace(/<[^>]+>/g,``).trim();if(!t)continue;l++;let n=t.toLowerCase().replace(/[^a-z0-9]+/g,`-`).replace(/(^-|-$)+/g,``)||`section-${l}`;o.push({level:e,text:t,id:n})}let u=a.replace(/<(h[2-6])([^>]*)>(.*?)<\/\1>/gi,(e,t,n,r)=>`<${t} id="${r.replace(/<[^>]+>/g,``).trim().toLowerCase().replace(/[^a-z0-9]+/g,`-`).replace(/(^-|-$)+/g,``)||`section`}"${n} style="scroll-margin-top: 110px;">${r}</${t}>`),d=()=>{let e=0;return o.map(t=>{let n=t.text.replace(/^\d+[\.\)\-\s]+/,``).trim();return t.level===`h2`?(e++,`
          <li style="margin-top: 14px; margin-bottom: 8px;">
            <a href="#${t.id}" class="toc-link toc-h2" style="color: #1a202c; text-decoration: none; font-weight: 800; font-size: 0.92rem; display: flex; align-items: flex-start; gap: 8px; transition: all 0.2s ease;">
              <span style="color: #eb5e28; font-weight: 800; min-width: 20px;">${e}.</span>
              <span>${n}</span>
            </a>
          </li>
        `):t.level===`h3`?`
          <li style="margin-bottom: 6px; padding-left: 28px; border-left: 2px solid #EDF2F7; margin-left: 8px;">
            <a href="#${t.id}" class="toc-link toc-h3" style="color: #4a5568; text-decoration: none; font-weight: 600; font-size: 0.85rem; display: inline-block; transition: all 0.2s ease;">
              <i class="ri-corner-down-right-line" style="color: #a0aec0; margin-right: 4px; font-size: 0.75rem;"></i>${n}
            </a>
          </li>
        `:`
          <li style="margin-bottom: 4px; padding-left: ${t.level===`h4`?`38px`:`48px`}; border-left: 2px solid #F1F5F9; margin-left: 8px;">
            <a href="#${t.id}" class="toc-link toc-sub" style="color: #718096; text-decoration: none; font-weight: 500; font-size: 0.8rem; display: inline-block; transition: all 0.2s ease;">
              • ${n}
            </a>
          </li>
        `}).join(``)},f=o.length>0?`
    <aside class="desktop-toc-sidebar" style="width: 280px; flex-shrink: 0;">
       <div style="position: sticky; top: 110px; background: #ffffff; padding: 22px; border-radius: 20px; border: 1px solid rgba(0,0,0,0.08); box-shadow: 0 12px 36px rgba(0,0,0,0.05); max-height: calc(100vh - 140px); overflow-y: auto;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 2px solid #eb5e28;">
            <h3 style="font-family: var(--font-serif); font-size: 1.15rem; color: #1a202c; font-weight: 800; margin: 0; display: flex; align-items: center; gap: 8px;">
              <i class="ri-list-check-2" style="color: #eb5e28;"></i> Table of Contents
            </h3>
            <span style="font-size: 0.75rem; font-weight: 800; color: #eb5e28; background: rgba(235,94,40,0.1); padding: 3px 8px; border-radius: 12px;">${o.length} items</span>
          </div>
          <ul style="list-style: none; padding: 0; margin: 0; line-height: 1.5;">
            ${d()}
          </ul>
       </div>
    </aside>
  `:``,p=o.length>0?`
    <div class="mobile-toc-box" style="margin-bottom: 32px; background: #faf8f5; border: 1px solid #e2e8f0; border-radius: 14px; padding: 18px 20px;">
      <details>
        <summary style="font-family: var(--font-serif); font-size: 1.15rem; font-weight: 800; color: #1a202c; cursor: pointer; display: flex; align-items: center; justify-content: space-between; user-select: none;">
          <span style="display: flex; align-items: center; gap: 8px;"><i class="ri-list-check-2" style="color: #eb5e28;"></i> Table of Contents (${o.length} sections)</span>
          <i class="ri-arrow-down-s-line" style="color: #eb5e28; font-size: 1.25rem;"></i>
        </summary>
        <ul style="list-style: none; padding: 14px 0 0 0; margin: 0; border-top: 1px solid #e2e8f0; margin-top: 12px;">
          ${d()}
        </ul>
      </details>
    </div>
  `:``;return`
    <div class="page-view view-enter article-detail-page" style="padding-top: 110px; padding-bottom: 90px; background: #faf8f5;">
      <div class="container" style="max-width: 1420px; margin: 0 auto; padding: 0 20px;">
        
        <!-- Back Navigation Button -->
        <button class="os-btn-secondary" id="back-to-blog-btn" style="margin-bottom: 24px; font-size: 0.9rem; padding: 10px 20px; border-radius: 10px; font-weight: 700; background: #ffffff; border: 1px solid #E2E8F0; color: #4A5568; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
          <i class="ri-arrow-left-line" style="color: #eb5e28;"></i> Back to Blog & Legal Journal
        </button>

        <!-- 3-Column Layout: Advisory Pitch (Left) + Main Article (Center) + Table of Contents (Right) -->
        <div class="article-page-three-col" style="display: flex; gap: 28px; align-items: flex-start; position: relative;">
          
          <!-- LEFT COLUMN: Sticky Confidential Legal & Property Advisory Desk Form -->
          <aside class="desktop-advisory-sidebar" style="width: 290px; flex-shrink: 0;">
            <div style="position: sticky; top: 110px; background: #ffffff; padding: 22px; border-radius: 20px; border: 1px solid rgba(0,0,0,0.08); box-shadow: 0 12px 36px rgba(0,0,0,0.05);">
              <div style="margin-bottom: 14px; padding-bottom: 12px; border-bottom: 2px solid #eb5e28;">
                <div style="display: flex; align-items: center; gap: 6px; font-size: 0.74rem; font-weight: 800; color: #eb5e28; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 4px;">
                  <i class="ri-shield-check-line"></i> Confidential Advisory
                </div>
                <h3 style="font-family: var(--font-serif); font-size: 1.15rem; color: #1a202c; font-weight: 800; margin: 0; line-height: 1.3;">
                  Direct Property & Legal Consultation
                </h3>
                <p style="font-size: 0.76rem; color: #718096; margin: 4px 0 0 0;">
                  Direct response from S. Vijayaraghavan (MD) & Senior Legal Desk
                </p>
              </div>

              <form id="blog-advisory-form" style="display: flex; flex-direction: column; gap: 11px;">
                <input type="hidden" id="baf-article-title" value="${e.title}" />
                <div>
                  <label style="font-size: 0.75rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 4px;">Your Full Name *</label>
                  <input type="text" id="baf-name" required placeholder="e.g. Anand Kumar" style="width: 100%; padding: 8px 12px; font-size: 0.85rem; border-radius: 8px; border: 1px solid #cbd5e0;" />
                </div>

                <div>
                  <label style="font-size: 0.75rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 4px;">Phone / WhatsApp *</label>
                  <input type="tel" id="baf-phone" required pattern="[0-9]{10}" maxlength="10" placeholder="10-digit mobile number" style="width: 100%; padding: 8px 12px; font-size: 0.85rem; border-radius: 8px; border: 1px solid #cbd5e0;" oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
                </div>

                <div>
                  <label style="font-size: 0.75rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 4px;">Email Address</label>
                  <input type="email" id="baf-email" placeholder="you@example.com" style="width: 100%; padding: 8px 12px; font-size: 0.85rem; border-radius: 8px; border: 1px solid #cbd5e0;" />
                </div>

                <div>
                  <label style="font-size: 0.75rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 4px;">Requirement Type</label>
                  <select id="baf-requirement" style="width: 100%; padding: 8px 10px; font-size: 0.82rem; border-radius: 8px; border: 1px solid #cbd5e0; background: #fff; font-weight: 600; color: #2d3748;">
                    <option value="Patta & Title Verification">Patta & Title Deed Verification</option>
                    <option value="DTCP / Layout Plots Buying">DTCP Approved Layout Plots</option>
                    <option value="Luxury Villa Consultation">Luxury Villa / House Consultation</option>
                    <option value="Agricultural Farmland">Cauvery Delta Farmland</option>
                    <option value="NRI Property Advisory">NRI Land & Power of Attorney</option>
                    <option value="General Property Brief">General Property Advisory</option>
                  </select>
                </div>

                <div>
                  <label style="font-size: 0.75rem; font-weight: 700; color: #4a5568; display: block; margin-bottom: 4px;">Specific Query (Optional)</label>
                  <textarea id="baf-message" rows="2" placeholder="Brief requirements or survey #..." style="width: 100%; padding: 8px 12px; font-size: 0.82rem; border-radius: 8px; border: 1px solid #cbd5e0; font-family: inherit;"></textarea>
                </div>

                <button type="submit" id="baf-submit-btn" style="background: #eb5e28; color: #ffffff; padding: 10px 16px; border: none; border-radius: 10px; font-size: 0.88rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 12px rgba(235,94,40,0.25); transition: all 0.2s ease;">
                  <span>Request Consultation</span>
                  <i class="ri-arrow-right-line"></i>
                </button>

                <div id="baf-success-msg" style="display: none; background: #f0fff4; border: 1px solid #c6f6d5; border-radius: 8px; padding: 10px; text-align: center;">
                  <i class="ri-checkbox-circle-fill" style="color: #38a169; font-size: 1.2rem;"></i>
                  <div style="font-size: 0.82rem; font-weight: 800; color: #22543d; margin-top: 2px;">Consultation Requested!</div>
                  <div style="font-size: 0.74rem; color: #2f855a;">S. Vijayaraghavan & senior team will reach out directly.</div>
                </div>

                <div style="display: flex; align-items: center; justify-content: center; gap: 4px; font-size: 0.72rem; color: #a0aec0; margin-top: 2px;">
                  <i class="ri-lock-line"></i> 100% Confidential • vijayaraghavan@thanjaiproperty.com
                </div>
              </form>
            </div>
          </aside>

          <!-- CENTER COLUMN: Main White Blog Article Box -->
          <article style="
            flex: 1; min-width: 0;
            background: #ffffff; border-radius: 24px; overflow: hidden;
            border: 1px solid rgba(0,0,0,0.08); box-shadow: 0 16px 48px rgba(0,0,0,0.06);
          ">
            <!-- Article Header -->
            <div style="padding: 40px 44px 24px 44px;">
              <span class="badge badge-orange" style="font-size: 0.82rem; font-weight: 800; letter-spacing: 0.08em; margin-bottom: 16px; display: inline-block;">
                ${e.category}
              </span>

              <h1 style="font-family: var(--font-serif); font-size: clamp(1.85rem, 3.5vw, 2.6rem); font-weight: 800; color: #1A202C; line-height: 1.25; margin-bottom: 20px;">
                ${e.title}
              </h1>

              <div style="display: flex; align-items: center; justify-content: flex-start; padding-bottom: 20px; border-bottom: 1px solid #EDF2F7;">
                <div style="font-size: 0.88rem; color: #718096; font-weight: 700; display: flex; align-items: center; gap: 6px;">
                  <i class="ri-calendar-check-line" style="color: #eb5e28; font-size: 1.05rem;"></i>
                  <span>Published on ${e.date}</span>
                </div>
              </div>
            </div>

            <!-- Featured Image Banner (Consistent 16/9 Ratio without Distortion) -->
            <div style="width: calc(100% - 56px); aspect-ratio: 16/9; max-height: 440px; overflow: hidden; background: #0f172a; position: relative; margin: 16px auto 28px auto; border-radius: 18px; box-shadow: 0 10px 36px rgba(0,0,0,0.08);">
              <img src="${e.image}" alt="${e.title}" style="width: 100%; height: 100%; object-fit: cover; object-position: center; display: block;" />
            </div>

            <!-- Article Content Body -->
            <div style="padding: 0 44px 36px 44px;">
              <div class="article-body-text" style="font-size: 1.08rem; color: #2D3748; line-height: 1.85;">
                <style>
                  .article-body-text h1, .article-body-text h2, .article-body-text h3, .article-body-text h4, .article-body-text h5, .article-body-text h6 {
                    font-family: var(--font-serif, serif);
                    color: #1a202c;
                    margin-top: 1.5em;
                    margin-bottom: 0.5em;
                    line-height: 1.3;
                    font-weight: 800;
                  }
                  .article-body-text h1 { font-size: 2.1rem; }
                  .article-body-text h2 { font-size: 1.7rem; }
                  .article-body-text h3 { font-size: 1.4rem; }
                  .article-body-text h4 { font-size: 1.22rem; }
                  .article-body-text h5 { font-size: 1.12rem; }
                  .article-body-text h6 { font-size: 1.02rem; }
                  .article-body-text p { margin-bottom: 1.2em; line-height: 1.8; }
                  .article-body-text a { color: #eb5e28; text-decoration: underline; font-weight: 700; word-break: break-word; }
                  .article-body-text a:hover { color: #c84919; }
                  .article-body-text table, .article-body-text .blog-table {
                    width: 100%;
                    border-collapse: collapse;
                    margin: 24px 0;
                    font-size: 0.95rem;
                    border: 1px solid #cbd5e0;
                    border-radius: 8px;
                    overflow: hidden;
                  }
                  .article-body-text th {
                    background: #f7fafc;
                    border: 1px solid #cbd5e0;
                    padding: 12px 16px;
                    font-weight: 800;
                    color: #1a202c;
                    text-align: left;
                  }
                  .article-body-text td {
                    border: 1px solid #cbd5e0;
                    padding: 12px 16px;
                    color: #2d3748;
                  }
                  .article-body-text tr:nth-child(even) {
                    background: #faf8f5;
                  }
                  .article-body-text ul, .article-body-text ol {
                    margin-bottom: 1.4em;
                    padding-left: 24px;
                  }
                  .article-body-text li {
                    margin-bottom: 0.4em;
                    line-height: 1.7;
                  }
                  .article-body-text blockquote {
                    border-left: 4px solid #eb5e28;
                    padding: 14px 20px;
                    margin: 24px 0;
                    background: #faf8f5;
                    font-style: italic;
                    color: #4a5568;
                    border-radius: 0 10px 10px 0;
                  }
                </style>
                ${p}
                ${u}
              </div>
            </div>

            <!-- Bottom Senior Advisory CTA -->
            <div style="padding: 36px 44px; background: linear-gradient(135deg, #1C1007 0%, #2A1808 100%); color: #ffffff; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 24px; box-shadow: 0 12px 30px rgba(0,0,0,0.15);">
              <div>
                <h3 style="font-family: var(--font-serif); font-size: 1.55rem; color: #ffffff; margin-bottom: 6px; font-weight: 800;">
                  Need Legal Title Guidance or Private Consultation?
                </h3>
                <p style="color: rgba(255,255,255,0.85); font-size: 0.94rem; margin: 0;">
                  Speak directly with S. Vijayaraghavan (MD) & senior Patta legal verification specialists.
                </p>
              </div>
              <button class="btn btn-primary" id="article-contact-btn" style="padding: 12px 28px; font-size: 0.95rem; font-weight: 800;">
                <i class="ri-mail-send-line"></i> Contact Advisory Desk
              </button>
            </div>
          </article>

          <!-- RIGHT COLUMN: Sticky Table of Contents Sidebar -->
          ${f}
        </div>

        <style>
          .toc-link:hover {
            color: #eb5e28 !important;
            transform: translateX(4px);
          }
          @media (max-width: 1199px) {
            .desktop-advisory-sidebar, .desktop-toc-sidebar { display: none !important; }
            .article-page-three-col { display: block !important; }
          }
          @media (min-width: 1200px) {
            .mobile-toc-box { display: none !important; }
          }
        </style>

        <!-- Related Articles Grid -->
        ${r.length>0?`
          <div style="margin-top: 60px;">
            <h3 style="font-family: var(--font-serif); font-size: 1.6rem; font-weight: 800; margin-bottom: 24px; color: #1A202C;">
              Related Articles & Legal Guides
            </h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 28px;">
              ${r.map(e=>`
                <article class="blog-card hover-lift" data-id="${e.id}" data-slug="${e.slug||``}" style="
                  background: #ffffff; border-radius: 20px; overflow: hidden;
                  border: 1px solid rgba(0,0,0,0.08); box-shadow: 0 4px 18px rgba(0,0,0,0.04);
                  display: flex; flex-direction: column; cursor: pointer; transition: all 0.3s ease;
                ">
                  <div style="position: relative; width: 100%; aspect-ratio: 16/9; max-height: 200px; overflow: hidden; background: #0f172a;">
                    <img src="${e.image}" alt="${e.title}" style="width: 100%; height: 100%; object-fit: cover; object-position: center;" />
                    <span class="badge badge-orange" style="position: absolute; top: 12px; left: 12px; font-size: 0.72rem; font-weight: 800;">
                      ${e.category}
                    </span>
                  </div>
                  <div style="padding: 20px; display: flex; flex-direction: column; flex: 1;">
                    <div style="display: flex; align-items: center; gap: 6px; font-size: 0.78rem; color: #718096; margin-bottom: 8px;">
                      <i class="ri-calendar-line" style="color: #eb5e28;"></i>
                      <span>${e.date}</span>
                    </div>
                    <h4 style="font-family: var(--font-serif); font-size: 1.15rem; font-weight: 800; color: #1A202C; margin-bottom: 10px; line-height: 1.35;">
                      ${e.title}
                    </h4>
                    <span style="font-size: 0.85rem; color: #eb5e28; font-weight: 800; margin-top: auto; display: inline-flex; align-items: center; gap: 4px;">
                      Read Guide <i class="ri-arrow-right-line"></i>
                    </span>
                  </div>
                </article>
              `).join(``)}
            </div>
          </div>
        `:``}

      </div>
    </div>
  `}function He(e,t){let n=t||_();if(!e.keyword||e.keyword.trim()===``)return n;let r=e.keyword.toLowerCase().trim();return n.filter(e=>{let t=(e.title||``).toLowerCase().includes(r),n=(e.excerpt||``).toLowerCase().includes(r),i=(e.category||``).toLowerCase().includes(r),a=(e.author||``).toLowerCase().includes(r),o=(e.authorRole||``).toLowerCase().includes(r),s=(e.content||``).replace(/<[^>]+>/g,``).toLowerCase().includes(r);return t||n||i||a||o||s})}function Ue(e,t,r,i){document.getElementById(`back-to-blog-btn`)?.addEventListener(`click`,()=>{r(null)}),document.getElementById(`article-contact-btn`)?.addEventListener(`click`,i);let o=document.getElementById(`blog-search-input`);if(o){if(e.keyword){o.focus();let e=o.value.length;o.setSelectionRange(e,e)}o.addEventListener(`input`,n=>{e.keyword=n.target.value,t(e)})}document.getElementById(`clear-blog-search-btn`)?.addEventListener(`click`,()=>{e.keyword=``,t(e)}),document.getElementById(`reset-blog-filter-btn`)?.addEventListener(`click`,()=>{e.keyword=``,t(e)}),document.querySelectorAll(`.blog-card, .featured-blog-card`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.slug||e.dataset.id;t&&r&&r(t)})});let s=document.getElementById(`blog-advisory-form`);s?.addEventListener(`submit`,e=>{e.preventDefault();let t=document.getElementById(`baf-name`)?.value.trim(),r=document.getElementById(`baf-phone`)?.value.trim(),i=document.getElementById(`baf-email`)?.value.trim(),o=document.getElementById(`baf-requirement`)?.value||`General Property Brief`,c=document.getElementById(`baf-message`)?.value.trim()||``,l=document.getElementById(`baf-article-title`)?.value||`Blog Article`,u=document.getElementById(`baf-submit-btn`),d=document.getElementById(`baf-success-msg`);if(!t||!r){n(`Please provide your name and 10-digit phone number.`,`ri-alert-line`);return}u&&(u.disabled=!0,u.innerHTML=`<span>Submitting...</span> <i class="ri-loader-4-line"></i>`);let f={id:`L-`+Math.floor(1e3+Math.random()*9e3),name:t,mobile:r,email:i||``,type:o,source:`Blog Legal Advisory Desk`,date:new Date().toISOString().split(`T`)[0],status:`new`,owner:`S. Vijayaraghavan (MD)`,notes:`Direct Advisory Inquiry from blog: "${l}". Requirement: ${o}. Message: ${c||`None`}. Routed to: vijayaraghavan@thanjaiproperty.com`,timestamp:Date.now()};try{let e=JSON.parse(localStorage.getItem(`thanjai_leads`))||[];e.unshift(f),localStorage.setItem(`thanjai_leads`,JSON.stringify(e)),a({timestamp:new Date().toLocaleString(`en-IN`,{dateStyle:`medium`,timeStyle:`short`}),user:`Website Visitor`,action:`New Lead Captured (${f.id})`,module:`Blog Advisory Desk`,details:`Inquiry from ${t} (${r}) on "${l}". Destination: vijayaraghavan@thanjaiproperty.com`}),window.dispatchEvent(new CustomEvent(`leadsUpdated`,{detail:{lead:f}})),window.dispatchEvent(new Event(`storage`))}catch(e){console.error(`Error saving lead from blog:`,e)}u&&(u.disabled=!1,u.innerHTML=`<span>Request Consultation</span> <i class="ri-arrow-right-line"></i>`),s.reset(),d&&(d.style.display=`block`,setTimeout(()=>{d.style.display=`none`},7e3)),n(`Consultation request sent to S. Vijayaraghavan Desk!`,`ri-checkbox-circle-fill`)})}function We(){return e(`contact_bg`),`
    <section class="contact-section" id="contact" style="background: #FAF6F0; padding-bottom: 80px;">

      <!-- ═══════════════════════════════════════════════════════════════ -->
      <!-- BREADCRUMB & PAGE HERO HEADER                                   -->
      <!-- ═══════════════════════════════════════════════════════════════ -->
      <div style="background: #2A1808; color: #FFFFFF; padding: 48px 0 40px; position: relative; overflow: hidden; margin-bottom: 40px;">
        <div style="position: absolute; inset: 0; opacity: 0.15; background-image: radial-gradient(#eb5e28 1px, transparent 1px); background-size: 24px 24px;"></div>
        <div class="container" style="position: relative; z-index: 2;">
          <div style="font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.15em; color: var(--color-orange, #eb5e28); margin-bottom: 10px; font-weight: 800;">
            CONTACT US
          </div>
          <h1 style="font-family: var(--font-serif, 'DM Serif Display', serif); font-size: clamp(2.2rem, 4vw, 3.2rem); font-weight: 400; line-height: 1.15; margin-bottom: 12px;">
            Get in Touch With Thanjai Property
          </h1>
          <p style="font-size: 1.05rem; color: rgba(255,255,255,0.85); max-width: 720px; line-height: 1.65;">
            Whether you are searching for a residential house, plot, agricultural land or commercial space, or looking to sell your property, our team is ready to assist you. Reach out to us with your requirements or inquiries.
          </p>
        </div>
      </div>

      <!-- ═══════════════════════════════════════════════════════════════ -->
      <!-- SECTION 1 — HERO INQUIRY FORM + OFFICIAL OFFICE & TEAM PANEL   -->
      <!-- ═══════════════════════════════════════════════════════════════ -->
      <div class="contact-body" id="contact-form-area">
        <div class="container">
          <div class="contact-body-grid">

            <!-- LEFT: Editorial Property Brief Form -->
            <div class="contact-form-col" id="contact-form-col">

              <div class="contact-form-editorial-header" style="margin-bottom: 24px;">
                <span class="contact-form-step-label" style="font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.12em; color: #eb5e28; font-weight: 700; display: block; margin-bottom: 6px;">
                  01 — YOUR PROPERTY BRIEF
                </span>
                <h2 class="contact-form-heading" style="font-family: var(--font-serif, 'DM Serif Display', serif); font-size: clamp(1.5rem, 3vw, 1.8rem); color: #1a1a1a; margin-bottom: 8px;">
                  Tell us what you're looking for.
                </h2>
                <p class="contact-form-subtext" style="font-size: 0.92rem; color: #666;">
                  Share your requirements and our local specialists will curate handpicked verified properties for you.
                </p>
              </div>

              <form class="contact-form" id="contact-form" novalidate style="display: flex; flex-direction: column; gap: 20px;">

                <!-- Row 1: Name & Phone -->
                <div class="cf-row">
                  <div class="cf-field">
                    <label class="cf-label" for="cf-name" style="font-size: 0.82rem; font-weight: 700; color: #333; display: block; margin-bottom: 6px;">Full Name *</label>
                    <div class="cf-input-wrap" style="position: relative;">
                      <i class="ri-user-3-line cf-icon" style="position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #888;"></i>
                      <input type="text" id="cf-name" name="name" class="cf-input" placeholder="Your full name" required style="width: 100%; padding: 12px 14px 12px 42px; border-radius: 10px; border: 1px solid #d1d5db; font-size: 0.92rem; box-sizing: border-box;" />
                    </div>
                  </div>
                  <div class="cf-field">
                    <label class="cf-label" for="cf-phone" style="font-size: 0.82rem; font-weight: 700; color: #333; display: block; margin-bottom: 6px;">Phone / WhatsApp *</label>
                    <div class="cf-input-wrap" style="position: relative;">
                      <i class="ri-phone-line cf-icon" style="position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #888;"></i>
                      <input type="tel" id="cf-phone" name="phone" class="cf-input" placeholder="e.g. 9578311506" required maxlength="10" pattern="[0-9]{10}" style="width: 100%; padding: 12px 14px 12px 42px; border-radius: 10px; border: 1px solid #d1d5db; font-size: 0.92rem; box-sizing: border-box;" oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
                    </div>
                  </div>
                </div>

                <!-- Row 2: Email & Property Interest -->
                <div class="cf-row">
                  <div class="cf-field">
                    <label class="cf-label" for="cf-email" style="font-size: 0.82rem; font-weight: 700; color: #333; display: block; margin-bottom: 6px;">Email Address</label>
                    <div class="cf-input-wrap" style="position: relative;">
                      <i class="ri-mail-line cf-icon" style="position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #888;"></i>
                      <input type="email" id="cf-email" name="email" class="cf-input" placeholder="you@example.com" style="width: 100%; padding: 12px 14px 12px 42px; border-radius: 10px; border: 1px solid #d1d5db; font-size: 0.92rem; box-sizing: border-box;" />
                    </div>
                  </div>
                  <div class="cf-field" style="position: relative; z-index: 10;">
                    <label class="cf-label" for="cf-interest" style="font-size: 0.82rem; font-weight: 700; color: #333; display: block; margin-bottom: 6px;">Property Purpose / Type</label>
                    <div class="custom-select-wrapper" id="custom-property-type" style="position: relative;">
                      <input type="hidden" name="interest" id="cf-interest" value="">
                      <div class="cf-input cf-input-wrap custom-select-trigger" id="custom-select-trigger" style="width: 100%; padding: 12px 14px 12px 42px; border-radius: 10px; border: 1px solid #d1d5db; font-size: 0.92rem; background: #fff; cursor: pointer; display: flex; align-items: center; justify-content: space-between; box-sizing: border-box;">
                        <i class="ri-home-4-line cf-icon" style="position: absolute; left: 14px; color: #888;"></i>
                        <span class="custom-select-text" id="custom-select-text" style="color: #666;">Select requirement</span>
                        <i class="ri-arrow-down-s-line cf-select-arrow" style="color: #888;"></i>
                      </div>
                      <div class="custom-select-options" style="display: none; position: absolute; top: 100%; left: 0; right: 0; background: #fff; border: 1px solid #e5e7eb; border-radius: 10px; box-shadow: 0 10px 25px rgba(0,0,0,0.15); z-index: 50; margin-top: 4px; overflow: hidden;">
                        <div class="custom-option" data-value="villa" style="padding: 10px 16px; cursor: pointer; font-size: 0.9rem;" onmouseenter="this.style.background='#f7fafc'" onmouseleave="this.style.background='transparent'">Luxury Villa</div>
                        <div class="custom-option" data-value="apartment" style="padding: 10px 16px; cursor: pointer; font-size: 0.9rem;" onmouseenter="this.style.background='#f7fafc'" onmouseleave="this.style.background='transparent'">Apartment / Flat</div>
                        <div class="custom-option" data-value="plot" style="padding: 10px 16px; cursor: pointer; font-size: 0.9rem;" onmouseenter="this.style.background='#f7fafc'" onmouseleave="this.style.background='transparent'">Residential Plot (DTCP / RERA)</div>
                        <div class="custom-option" data-value="farm" style="padding: 10px 16px; cursor: pointer; font-size: 0.9rem;" onmouseenter="this.style.background='#f7fafc'" onmouseleave="this.style.background='transparent'">Agricultural Farmland</div>
                        <div class="custom-option" data-value="commercial" style="padding: 10px 16px; cursor: pointer; font-size: 0.9rem;" onmouseenter="this.style.background='#f7fafc'" onmouseleave="this.style.background='transparent'">Commercial Space / Land</div>
                        <div class="custom-option" data-value="sell" style="padding: 10px 16px; cursor: pointer; font-size: 0.9rem;" onmouseenter="this.style.background='#f7fafc'" onmouseleave="this.style.background='transparent'">Post Property to Sell / Rent</div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Location -->
                <div class="cf-field">
                  <label class="cf-label" for="cf-location" style="font-size: 0.82rem; font-weight: 700; color: #333; display: block; margin-bottom: 6px;">Preferred District / Location</label>
                  <div class="cf-input-wrap" style="position: relative;">
                    <i class="ri-map-pin-2-line cf-icon" style="position: absolute; left: 14px; top: 50%; transform: translateY(-50%); color: #888;"></i>
                    <input type="text" id="cf-location" name="location" class="cf-input" placeholder="e.g. Thanjavur, Kumbakonam, Trichy, Chennai..." style="width: 100%; padding: 12px 14px 12px 42px; border-radius: 10px; border: 1px solid #d1d5db; font-size: 0.92rem; box-sizing: border-box;" />
                  </div>
                </div>

                <!-- Budget Pills -->
                <div class="cf-field">
                  <label class="cf-label" style="font-size: 0.82rem; font-weight: 700; color: #333; display: block; margin-bottom: 6px;">Target Budget Range</label>
                  <div class="cf-budget-pills" id="cf-budget-pills" style="display: flex; gap: 8px; flex-wrap: wrap;">
                    <button type="button" class="cf-budget-pill" data-value="under-50l" style="padding: 8px 14px; border-radius: 20px; border: 1px solid #d1d5db; background: #fff; font-size: 0.82rem; font-weight: 600; cursor: pointer;">Under ₹50L</button>
                    <button type="button" class="cf-budget-pill" data-value="50l-1cr" style="padding: 8px 14px; border-radius: 20px; border: 1px solid #d1d5db; background: #fff; font-size: 0.82rem; font-weight: 600; cursor: pointer;">₹50L – ₹1Cr</button>
                    <button type="button" class="cf-budget-pill" data-value="1cr-3cr" style="padding: 8px 14px; border-radius: 20px; border: 1px solid #d1d5db; background: #fff; font-size: 0.82rem; font-weight: 600; cursor: pointer;">₹1Cr – ₹3Cr</button>
                    <button type="button" class="cf-budget-pill" data-value="above-3cr" style="padding: 8px 14px; border-radius: 20px; border: 1px solid #d1d5db; background: #fff; font-size: 0.82rem; font-weight: 600; cursor: pointer;">Above ₹3Cr</button>
                  </div>
                  <input type="hidden" id="cf-budget" name="budget" value="" />
                </div>

                <!-- Message Textarea -->
                <div class="cf-field">
                  <label class="cf-label" for="cf-message" style="font-size: 0.82rem; font-weight: 700; color: #333; display: block; margin-bottom: 6px;">Your Message / Specific Requirements</label>
                  <div class="cf-input-wrap cf-textarea-wrap" style="position: relative;">
                    <i class="ri-chat-3-line cf-icon" style="position: absolute; left: 14px; top: 14px; color: #888;"></i>
                    <textarea id="cf-message" name="message" class="cf-input cf-textarea" placeholder="Provide any details regarding preferred land size, road width, legal verification..." rows="4" style="width: 100%; padding: 12px 14px 12px 42px; border-radius: 10px; border: 1px solid #d1d5db; font-size: 0.92rem; font-family: inherit; box-sizing: border-box;"></textarea>
                  </div>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="cf-submit" id="cf-submit-btn" style="background: var(--color-orange, #eb5e28); color: #fff; padding: 14px 28px; border-radius: 12px; border: none; font-size: 0.95rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 8px 20px rgba(235,94,40,0.25); transition: all 0.2s ease;">
                  <span class="cf-submit-text">Send Property Brief</span>
                  <i class="ri-arrow-right-line cf-submit-arrow"></i>
                </button>

                <!-- Success Alert -->
                <div class="cf-success" id="cf-success" style="display:none; background: #f0fff4; border: 1px solid #c6f6d5; padding: 14px; border-radius: 10px; align-items: center; gap: 12px;">
                  <i class="ri-checkbox-circle-fill" style="color: #38a169; font-size: 1.4rem; flex-shrink: 0;"></i>
                  <div>
                    <strong style="color: #22543d; font-size: 0.9rem;">Brief Received Successfully!</strong>
                    <p style="color: #2f855a; font-size: 0.82rem; margin-top: 2px;">Our senior property specialist will contact you within 24 hours.</p>
                  </div>
                </div>

              </form>
            </div>

            <!-- RIGHT: Official Office & Executive Team Panel -->
            <div class="contact-panel-col" id="contact-panel-col">
              <div class="contact-dark-panel">

                <span style="font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.12em; color: var(--color-orange, #eb5e28); font-weight: 700; display: block; margin-bottom: 6px;">
                  02 — DIRECT OFFICE & TEAM CONTACTS
                </span>
                <h3 class="contact-panel-heading" style="font-family: var(--font-serif, 'DM Serif Display', serif); font-size: 1.6rem; margin-bottom: 6px; color: #fff;">
                  Speak With Our Executive Desk
                </h3>
                <p class="contact-panel-subtext" style="font-size: 0.88rem; color: rgba(255,255,255,0.7); margin-bottom: 20px;">
                  Direct office address, executive phone support, and instant WhatsApp advisory.
                </p>

                <div style="height: 1px; background: rgba(255,255,255,0.1); margin-bottom: 20px;"></div>

                <!-- Office Address Card -->
                <div style="display: flex; gap: 14px; margin-bottom: 20px;">
                  <div style="width: 40px; height: 40px; border-radius: 10px; background: rgba(235,94,40,0.15); color: #eb5e28; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; flex-shrink: 0;">
                    <i class="ri-map-pin-2-fill"></i>
                  </div>
                  <div>
                    <div style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.08em; color: rgba(255,255,255,0.5); font-weight: 700; margin-bottom: 4px;">OFFICE ADDRESS</div>
                    <div style="font-size: 0.9rem; line-height: 1.4; color: #fff; font-weight: 600;">
                      Thanjai Property<br>
                      Flat No B1, 2nd Floor, Sivasakthi Apartment,<br>
                      Raja Nagar, Behind HDFC Bank,<br>
                      Near New Bus Stand, Thanjavur – 613005
                    </div>
                  </div>
                </div>

                <div style="height: 1px; background: rgba(255,255,255,0.1); margin-bottom: 20px;"></div>

                <!-- Key Executive Support Desk -->
                <div style="margin-bottom: 20px;">
                  <div style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.08em; color: rgba(255,255,255,0.5); font-weight: 700; margin-bottom: 12px;">
                    EXECUTIVE LEADERSHIP & HELP DESK
                  </div>

                  <div style="display: flex; flex-direction: column; gap: 12px;">
                    <!-- S. Vijayaraghavan: Managing Director -->
                    <div style="background: rgba(235,94,40,0.1); padding: 14px; border-radius: 14px; border: 1px solid rgba(235,94,40,0.3); display: flex; flex-direction: column; gap: 10px; max-width: 100%; box-sizing: border-box; overflow: hidden;">
                      <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px;">
                        <div>
                          <strong style="font-size: 1rem; color: #fff; display: block;">S. Vijayaraghavan</strong>
                          <span style="font-size: 0.78rem; color: #eb5e28; font-weight: 700;">Managing Director</span>
                        </div>
                        <a href="tel:+919578311506" style="background: #eb5e28; color: #fff; padding: 6px 12px; border-radius: 8px; font-size: 0.8rem; font-weight: 700; text-decoration: none; display: flex; align-items: center; gap: 4px; flex-shrink: 0;">
                          <i class="ri-phone-line"></i> +91 95783 11506
                        </a>
                      </div>

                      <!-- Priority Founder Email Box -->
                      <div style="background: rgba(0,0,0,0.3); padding: 10px 12px; border-radius: 8px; display: flex; align-items: center; justify-content: space-between; border: 1px solid rgba(235,94,40,0.2); flex-wrap: wrap; gap: 8px; max-width: 100%; box-sizing: border-box;">
                        <div style="display: flex; align-items: center; gap: 8px; min-width: 0; flex: 1 1 180px;">
                          <i class="ri-mail-star-line" style="color: #eb5e28; font-size: 1.1rem; flex-shrink: 0;"></i>
                          <div style="min-width: 0; overflow: hidden;">
                            <span style="font-size: 0.65rem; color: rgba(255,255,255,0.6); text-transform: uppercase; font-weight: 800; display: block;">DIRECT SUPPORT EMAIL</span>
                            <a href="https://mail.google.com/mail/?view=cm&fs=1&to=vijayaraghavan@thanjaiproperty.com" target="_blank" style="color: #fff; font-size: 0.8rem; font-weight: 700; text-decoration: none; word-break: break-all; overflow-wrap: anywhere; display: block;">
                              vijayaraghavan@thanjaiproperty.com
                            </a>
                          </div>
                        </div>
                        <a href="https://mail.google.com/mail/?view=cm&fs=1&to=vijayaraghavan@thanjaiproperty.com" target="_blank" style="background: rgba(255,255,255,0.15); color: #fff; padding: 4px 10px; border-radius: 6px; font-size: 0.75rem; font-weight: 700; text-decoration: none; flex-shrink: 0;">
                          Email
                        </a>
                      </div>
                    </div>

                    <!-- Radhakrishnan: Co-Partner -->
                    <div style="background: rgba(255,255,255,0.05); padding: 14px; border-radius: 14px; display: flex; align-items: center; justify-content: space-between; border: 1px solid rgba(255,255,255,0.08); flex-wrap: wrap; gap: 8px;">
                      <div>
                        <strong style="font-size: 0.95rem; color: #fff; display: block;">Radhakrishnan</strong>
                        <span style="font-size: 0.78rem; color: #38a169; font-weight: 700;">Co-Partner</span>
                      </div>
                      <a href="tel:+919585777772" style="background: rgba(255,255,255,0.15); color: #fff; padding: 6px 12px; border-radius: 8px; font-size: 0.8rem; font-weight: 700; text-decoration: none; display: flex; align-items: center; gap: 4px; flex-shrink: 0;">
                        <i class="ri-phone-line"></i> +91 95857 77772
                      </a>
                    </div>

                    <!-- Admin Desk -->
                    <div style="background: rgba(255,255,255,0.05); padding: 14px; border-radius: 14px; display: flex; align-items: center; justify-content: space-between; border: 1px solid rgba(255,255,255,0.08); flex-wrap: wrap; gap: 8px;">
                      <div>
                        <strong style="font-size: 0.95rem; color: #fff; display: block;">Admin</strong>
                        <span style="font-size: 0.78rem; color: rgba(255,255,255,0.6); font-weight: 700;">Admin</span>
                      </div>
                      <a href="tel:+919585598263" style="background: rgba(255,255,255,0.15); color: #fff; padding: 6px 12px; border-radius: 8px; font-size: 0.8rem; font-weight: 700; text-decoration: none; display: flex; align-items: center; gap: 4px; flex-shrink: 0;">
                        <i class="ri-phone-line"></i> +91 95855 98263
                      </a>
                    </div>
                  </div>
                </div>

                <!-- Direct WhatsApp Chat Button -->
                <a href="https://wa.me/919578311506?text=Hi%20Thanjai%20Property,%20I%20want%20to%20enquire%20about%20properties%20in%20Tamil%20Nadu" target="_blank" style="background: #25D366; color: #fff; padding: 14px 20px; border-radius: 12px; font-size: 0.95rem; font-weight: 700; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 10px; box-shadow: 0 8px 20px rgba(37,211,102,0.3); margin-bottom: 16px;">
                  <i class="ri-whatsapp-line" style="font-size: 1.3rem;"></i>
                  <span>Chat with WhatsApp Support</span>
                </a>

                <!-- Hours -->
                <div style="font-size: 0.8rem; color: rgba(255,255,255,0.6); text-align: center;">
                  <i class="ri-time-line" style="color: #eb5e28;"></i> Working Hours: Mon – Sun: 9:00 AM – 7:00 PM (Appointments Preferred)
                </div>

              </div>
            </div>

          </div>
        </div>
      </div>

      <!-- ═══════════════════════════════════════════════════════════════ -->
      <!-- SECTION 2 — OFFICIAL BANKING & TRUST VERIFICATION CREDENTIALS  -->
      <!-- ═══════════════════════════════════════════════════════════════ -->
      <div style="margin-top: 56px;">
        <div class="container">
          <div style="margin-bottom: 28px;">
            <span style="font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.12em; color: #eb5e28; font-weight: 700; display: block; margin-bottom: 6px;">
              03 — OFFICIAL BANK & PAYMENT DETAILS
            </span>
            <h2 style="font-family: var(--font-serif, 'DM Serif Display', serif); font-size: 2rem; color: #1a1a1a; margin-bottom: 6px;">
              Official Bank Accounts & Digital Pay
            </h2>
            <p style="font-size: 0.92rem; color: #666; max-width: 640px;">
              Verified accounts for booking token payments, legal Patta verification fees, and official property escrow deposits.
            </p>
          </div>

          <!-- Straight Line 4-Column Grid -->
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; align-items: stretch;">

            <!-- GPay / PhonePe Instant Card -->
            <div style="background: linear-gradient(135deg, #1a1a1a, #2D2721); color: #fff; border-radius: 16px; padding: 24px; box-shadow: 0 8px 24px rgba(0,0,0,0.08); border: 1px solid rgba(255,255,255,0.1); display: flex; flex-direction: column; justify-content: space-between; height: 100%;">
              <div>
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
                  <div style="display: flex; align-items: center; gap: 8px;">
                    <i class="ri-qr-code-line" style="font-size: 1.4rem; color: #eb5e28;"></i>
                    <strong style="font-size: 0.95rem; color: #fff;">Online / GPay / PhonePe</strong>
                  </div>
                  <span style="background: rgba(235,94,40,0.2); color: #eb5e28; font-size: 0.68rem; padding: 3px 8px; border-radius: 6px; font-weight: 800;">INSTANT</span>
                </div>
                <div style="font-size: 0.8rem; color: rgba(255,255,255,0.7); margin-bottom: 8px;">GPay & PhonePe Number:</div>
                <div style="background: rgba(255,255,255,0.08); padding: 12px 14px; border-radius: 10px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                  <span style="font-size: 1.1rem; font-weight: 800; letter-spacing: 0.05em; color: #fff;">9578311506</span>
                  <button class="copy-bank-btn" data-text="9578311506" style="background: #eb5e28; border: none; color: #fff; padding: 6px 12px; border-radius: 6px; font-size: 0.78rem; font-weight: 700; cursor: pointer;">
                    Copy
                  </button>
                </div>
              </div>
              <div style="font-size: 0.75rem; color: rgba(255,255,255,0.5); padding-top: 10px; border-top: 1px solid rgba(255,255,255,0.1);">
                A/C Holder: <strong>S. Vijayaraghavan</strong>
              </div>
            </div>

            <!-- Union Bank of India Card -->
            <div style="background: #ffffff; border: 1px solid #E7E0D8; border-radius: 16px; padding: 24px; box-shadow: 0 4px 16px rgba(0,0,0,0.02); display: flex; flex-direction: column; justify-content: space-between; height: 100%;">
              <div>
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
                  <strong style="font-size: 0.95rem; color: #1a1a1a; display: flex; align-items: center; gap: 8px;">
                    <i class="ri-bank-line" style="color: #0056b3;"></i> Union Bank of India
                  </strong>
                  <span style="font-size: 0.72rem; color: #777;">Cauvery Nagar</span>
                </div>
                <div style="font-size: 0.82rem; color: #555; display: flex; flex-direction: column; gap: 6px; margin-bottom: 14px;">
                  <div>Account Name: <strong>Thanjai Property</strong></div>
                  <div>Account No: <strong style="color: #1a1a1a;">510101000770751</strong></div>
                  <div>RTGS / IFSC: <strong style="color: #eb5e28;">UBIN0903728</strong></div>
                </div>
              </div>
              <div style="display: flex; gap: 8px; padding-top: 10px; border-top: 1px solid #f0f4f8;">
                <button class="copy-bank-btn" data-text="510101000770751" style="flex: 1; background: #f0f4f8; border: 1px solid #cbd5e0; padding: 8px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; cursor: pointer;">
                  Copy A/C No
                </button>
                <button class="copy-bank-btn" data-text="UBIN0903728" style="flex: 1; background: #f0f4f8; border: 1px solid #cbd5e0; padding: 8px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; cursor: pointer;">
                  Copy IFSC
                </button>
              </div>
            </div>

            <!-- State Bank of India (SBI) Card -->
            <div style="background: #ffffff; border: 1px solid #E7E0D8; border-radius: 16px; padding: 24px; box-shadow: 0 4px 16px rgba(0,0,0,0.02); display: flex; flex-direction: column; justify-content: space-between; height: 100%;">
              <div>
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
                  <strong style="font-size: 0.95rem; color: #1a1a1a; display: flex; align-items: center; gap: 8px;">
                    <i class="ri-bank-line" style="color: #28a745;"></i> State Bank of India
                  </strong>
                  <span style="font-size: 0.72rem; color: #777;">Karanthattangudi</span>
                </div>
                <div style="font-size: 0.82rem; color: #555; display: flex; flex-direction: column; gap: 6px; margin-bottom: 14px;">
                  <div>Account Name: <strong>Thanjai Property</strong></div>
                  <div>Account No: <strong style="color: #1a1a1a;">32946233761</strong></div>
                  <div>RTGS / IFSC: <strong style="color: #eb5e28;">SBIN0008178</strong></div>
                </div>
              </div>
              <div style="display: flex; gap: 8px; padding-top: 10px; border-top: 1px solid #f0f4f8;">
                <button class="copy-bank-btn" data-text="32946233761" style="flex: 1; background: #f0f4f8; border: 1px solid #cbd5e0; padding: 8px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; cursor: pointer;">
                  Copy A/C No
                </button>
                <button class="copy-bank-btn" data-text="SBIN0008178" style="flex: 1; background: #f0f4f8; border: 1px solid #cbd5e0; padding: 8px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; cursor: pointer;">
                  Copy IFSC
                </button>
              </div>
            </div>

            <!-- HDFC Bank Card -->
            <div style="background: #ffffff; border: 1px solid #E7E0D8; border-radius: 16px; padding: 24px; box-shadow: 0 4px 16px rgba(0,0,0,0.02); display: flex; flex-direction: column; justify-content: space-between; height: 100%;">
              <div>
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
                  <strong style="font-size: 0.95rem; color: #1a1a1a; display: flex; align-items: center; gap: 8px;">
                    <i class="ri-bank-line" style="color: #dc3545;"></i> HDFC Bank
                  </strong>
                  <span style="font-size: 0.72rem; color: #777;">New Bus Stand</span>
                </div>
                <div style="font-size: 0.82rem; color: #555; display: flex; flex-direction: column; gap: 6px; margin-bottom: 14px;">
                  <div>Account Name: <strong>Thanjai Property</strong></div>
                  <div>Account No: <strong style="color: #1a1a1a;">50200062317303</strong></div>
                  <div>RTGS / IFSC: <strong style="color: #eb5e28;">HDFC0009164</strong></div>
                </div>
              </div>
              <div style="display: flex; gap: 8px; padding-top: 10px; border-top: 1px solid #f0f4f8;">
                <button class="copy-bank-btn" data-text="50200062317303" style="flex: 1; background: #f0f4f8; border: 1px solid #cbd5e0; padding: 8px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; cursor: pointer;">
                  Copy A/C No
                </button>
                <button class="copy-bank-btn" data-text="HDFC0009164" style="flex: 1; background: #f0f4f8; border: 1px solid #cbd5e0; padding: 8px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; cursor: pointer;">
                  Copy IFSC
                </button>
              </div>
            </div>

          </div>
        </div>
      </div>

      <!-- ═══════════════════════════════════════════════════════════════ -->
      <!-- SECTION 3 — PREMIER INTERACTIVE MAP LOCATION SECTION             -->
      <!-- ═══════════════════════════════════════════════════════════════ -->
      <div style="margin-top: 56px;">
        <div class="container">
          <div style="margin-bottom: 24px; display: flex; justify-content: space-between; align-items: flex-end; flex-wrap: wrap; gap: 16px;">
            <div>
              <span style="font-size: 0.78rem; text-transform: uppercase; letter-spacing: 0.12em; color: #eb5e28; font-weight: 700; display: block; margin-bottom: 6px;">
                04 — VISIT OUR THANJAVUR HEADQUARTERS
              </span>
              <h2 style="font-family: var(--font-serif, 'DM Serif Display', serif); font-size: 2rem; color: #1a1a1a; margin-bottom: 4px;">
                📍 Our Location
              </h2>
              <p style="font-size: 0.92rem; color: #666;">
                Sivasakthi Apartment, Raja Nagar, Behind HDFC Bank, Near New Bus Stand, Thanjavur – 613005
              </p>
            </div>

            <a href="https://maps.google.com/?q=Sivasakthi+Apartment+Raja+Nagar+Thanjavur+613005" target="_blank" style="background: #1a1a1a; color: #fff; padding: 12px 24px; border-radius: 12px; font-size: 0.88rem; font-weight: 700; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; box-shadow: 0 4px 14px rgba(0,0,0,0.15);">
              <i class="ri-navigation-fill" style="color: #eb5e28;"></i> Get Directions on Map
            </a>
          </div>

          <!-- Premier Interactive Location Map Frame -->
          <div style="background: #ffffff; border-radius: 24px; padding: 12px; border: 1px solid #E7E0D8; box-shadow: 0 16px 40px rgba(0,0,0,0.06); position: relative; overflow: hidden; height: 420px;">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3916.140224163589!2d79.13038621480287!3d10.74100919234857!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3baabf9f5b66d489%3A0xc68297b69c4c7304!2sNew%20Bus%20Stand%2C%20Thanjavur!5e0!3m2!1sen!2sin!4v1691234567890"
              style="width: 100%; height: 100%; border: none; border-radius: 16px;"
              allowfullscreen=""
              loading="lazy"
              referrerpolicy="no-referrer-when-downgrade"
              title="Thanjavur Advisory Desk Headquarters"
            ></iframe>

            <!-- Location Overlay Badge -->
            <div style="position: absolute; bottom: 24px; left: 24px; background: rgba(42,24,8,0.92); backdrop-filter: blur(12px); color: #fff; padding: 14px 20px; border-radius: 14px; border: 1px solid rgba(255,255,255,0.15); display: flex; align-items: center; gap: 14px; box-shadow: 0 10px 30px rgba(0,0,0,0.3); max-width: 380px;">
              <div style="width: 12px; height: 12px; border-radius: 50%; background: #eb5e28; box-shadow: 0 0 0 4px rgba(235,94,40,0.4); flex-shrink: 0;"></div>
              <div>
                <strong style="font-size: 0.92rem; display: block; color: #fff;">Thanjavur Headquarters</strong>
                <span style="font-size: 0.78rem; color: rgba(255,255,255,0.7);">Sivasakthi Apt, Raja Nagar, New Bus Stand</span>
              </div>
            </div>
          </div>
        </div>
      </div>

    </section>
  `}function Ge(){let e=document.querySelectorAll(`.cf-budget-pill`),n=document.getElementById(`cf-budget`);e.forEach(t=>{t.addEventListener(`click`,()=>{e.forEach(e=>{e.style.background=`#fff`,e.style.color=`#333`,e.style.borderColor=`#d1d5db`}),t.style.background=`var(--color-orange, #eb5e28)`,t.style.color=`#fff`,t.style.borderColor=`var(--color-orange, #eb5e28)`,n&&(n.value=t.dataset.value)})});let r=document.getElementById(`custom-property-type`),i=document.getElementById(`custom-select-trigger`),a=document.querySelectorAll(`.custom-option`),o=document.getElementById(`cf-interest`),s=document.getElementById(`custom-select-text`);r&&i&&(i.addEventListener(`click`,e=>{e.stopPropagation();let t=r.querySelector(`.custom-select-options`);r.classList.toggle(`open`),t&&(t.style.display=r.classList.contains(`open`)?`block`:`none`)}),a.forEach(e=>{e.addEventListener(`click`,t=>{t.stopPropagation();let n=e.getAttribute(`data-value`),i=e.textContent;o&&(o.value=n),s&&(s.textContent=i,s.style.color=`#1a1a1a`,s.style.fontWeight=`600`),r.classList.remove(`open`);let a=r.querySelector(`.custom-select-options`);a&&(a.style.display=`none`)})}),document.addEventListener(`click`,()=>{r.classList.remove(`open`);let e=r.querySelector(`.custom-select-options`);e&&(e.style.display=`none`)})),document.querySelectorAll(`.copy-bank-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.text;t&&navigator.clipboard.writeText(t).then(()=>{let t=e.textContent;e.textContent=`Copied!`,e.style.background=`#38a169`,e.style.color=`#fff`,setTimeout(()=>{e.textContent=t,e.style.background=t.includes(`A/C`)||t.includes(`IFSC`)?`#f0f4f8`:`#eb5e28`,e.style.color=t.includes(`A/C`)||t.includes(`IFSC`)?`#333`:`#fff`},2e3)})})});let c=document.getElementById(`contact-form`),l=document.getElementById(`cf-submit-btn`),u=document.getElementById(`cf-success`);c?.addEventListener(`submit`,async r=>{r.preventDefault();let i=document.getElementById(`cf-name`)?.value.trim(),a=document.getElementById(`cf-phone`)?.value.trim(),d=document.getElementById(`cf-email`)?.value.trim()||``,f=document.getElementById(`cf-location`)?.value.trim()||`Thanjavur`,p=document.getElementById(`cf-message`)?.value.trim()||``;if(!i||!a){document.getElementById(`cf-name`)?.focus();return}l&&(l.disabled=!0,l.querySelector(`.cf-submit-text`).textContent=`Sending Property Brief...`);let m=a.replace(/\D/g,``),h=m.length===10?`+91${m}`:`+${m}`,g=`L-`+Math.floor(1e3+Math.random()*9e3),_=o?o.value:`General Enquiry`,v=n?n.value:`Any Budget`,y={id:g,name:i,phone:h,mobile:h,email:d,type:_,location:f,budget:v,source:`Contact Enquiry`,date:new Date().toISOString().split(`T`)[0],stage:`New Lead`,assignedTo:`Unassigned`,priority:`High`,timeline:[{type:`whatsapp_incoming`,date:new Date().toISOString(),message:`📩 Web Brief: ${_} in ${f} (${v}). Note: ${p||`No additional note`}`,note:p},{type:`whatsapp`,date:new Date().toISOString(),message:`🤖 Auto-sent WhatsApp Welcome Intro to ${i} (${h})`,note:`Campaign: initial_contact_intro`}]};try{let e=JSON.parse(localStorage.getItem(`thanjai_leads`))||[];e.unshift(y),localStorage.setItem(`thanjai_leads`,JSON.stringify(e)),window.dispatchEvent(new Event(`storage`))}catch(e){console.error(`Error saving lead to storage:`,e)}try{await t(`/leads`,{method:`POST`,body:JSON.stringify(y)})}catch{}try{await t(`/whatsapp_incoming`,{method:`POST`,body:JSON.stringify({from_phone:h,from_name:i,message:`[Website Contact Brief] ${_} in ${f} (${v}) - ${p}`,message_type:`text`})}),await t(`/whatsapp_logs`,{method:`POST`,body:JSON.stringify({id:`WA-${Date.now()}`,leadId:g,phone:h,sender:`Super Admin`,recipientName:i,message:`Hello ${i}, Thank you for your interest in Thanjai Property! We have received your requirement for ${_} in ${f}. Our property advisors will assist you shortly. Official Desk: +91 84899 96852.`,type:`outbound`})})}catch{}try{await t(`/send_whatsapp`,{method:`POST`,body:JSON.stringify({campaignName:`initial_contact_intro`,destination:h,userName:i,leadId:g,templateParams:[i,f,_,`our Executive Desk at +91 84899 96852`]})})}catch{}c.reset(),e.forEach(e=>{e.style.background=`#fff`,e.style.color=`#333`,e.style.borderColor=`#d1d5db`}),n&&(n.value=``),s&&(s.textContent=`Select requirement`,s.style.color=`#666`,s.style.fontWeight=`normal`),l&&(l.disabled=!1,l.querySelector(`.cf-submit-text`).textContent=`Send Property Brief`),u&&(u.style.display=`flex`,setTimeout(()=>{u.style.display=`none`},6e3))})}function Ke(){return`
    <div class="page-view view-enter contact-page" style="padding-top: 60px;">
      ${We()}
    </div>
  `}function qe(){Ge()}function Je(){return`
    <div class="view-enter terms-view" style="background: #f8fafc;">
      <!-- Dark Luxury Header -->
      <section style="background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%); padding: 140px 0 80px; color: white;">
        <div class="container">
          
          <div style="display: inline-flex; align-items: center; gap: 8px; color: #ff6b6b; font-size: 0.85rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 24px;">
            <i class="ri-scales-3-line"></i> LEGAL & POLICY
          </div>

          <h1 style="font-family: var(--font-primary, 'DM Serif Display', serif); font-size: 3rem; line-height: 1.2; margin-bottom: 24px; color: #ffffff;">
            Terms of Use & Policies
          </h1>

          <p style="font-size: 1.1rem; color: rgba(255, 255, 255, 0.7); line-height: 1.6; max-width: 800px; margin-bottom: 40px;">
            The rules that govern how you list, browse, and transact on Thanjai Property<br>
            — written plainly, so there are no surprises.
          </p>

          <div style="display: flex; flex-wrap: wrap; gap: 16px;">
            <div style="display: inline-flex; align-items: center; gap: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); padding: 8px 16px; border-radius: 30px; font-size: 0.9rem; color: rgba(255,255,255,0.8);">
              <i class="ri-government-line" style="color: #ff6b6b;"></i> Thanjai Property, Thanjavur
            </div>
            <div style="display: inline-flex; align-items: center; gap: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); padding: 8px 16px; border-radius: 30px; font-size: 0.9rem; color: rgba(255,255,255,0.8);">
              <i class="ri-refresh-line" style="color: #ff6b6b;"></i> Reviewed periodically
            </div>
            <div style="display: inline-flex; align-items: center; gap: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); padding: 8px 16px; border-radius: 30px; font-size: 0.9rem; color: rgba(255,255,255,0.8);">
              <i class="ri-mail-line" style="color: #ff6b6b;"></i> vijayaraghavan@thanjaiproperty.com
            </div>
          </div>
        </div>
      </section>

      <!-- Terms Content Section with Sidebar -->
      <section style="padding: 60px 0 100px;">
        <div class="container" style="display: grid; grid-template-columns: 300px 1fr; gap: 64px; align-items: start;">
          
          <!-- Sticky Sidebar -->
          <aside style="position: sticky; top: 120px; background: #ffffff; padding: 32px; border-radius: 16px; border: 1px solid #e2e8f0; box-shadow: 0 10px 30px rgba(0,0,0,0.03);">
            <h4 style="font-family: var(--font-primary, 'DM Serif Display', serif); font-size: 1.25rem; color: var(--color-dark, #0f172a); margin-bottom: 24px; border-bottom: 2px solid var(--color-orange, #eb5e28); padding-bottom: 12px; display: inline-block;">
              Quick Navigation
            </h4>
            <ul style="list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 16px; font-size: 0.95rem; font-weight: 500;">
              <li><a href="#term-agreement" class="term-nav-link">1. Agreement & Definitions</a></li>
              <li><a href="#term-fees" class="term-nav-link">2. Subscription Fees & Payment</a></li>
              <li><a href="#term-cancellation" class="term-nav-link">3. Cancellation</a></li>
              <li><a href="#term-prohibited" class="term-nav-link">4. Prohibited Actions</a></li>
              <li><a href="#term-security" class="term-nav-link">5. Confidentiality & Security</a></li>
              <li><a href="#term-termination" class="term-nav-link">6. Termination & Suspension</a></li>
              <li><a href="#term-disclaimer" class="term-nav-link">7. Disclaimer & Liability</a></li>
              <li><a href="#term-privacy" class="term-nav-link">8. Privacy Policy</a></li>
              <li><a href="#term-misc" class="term-nav-link">9. Miscellaneous</a></li>
            </ul>
          </aside>

          <!-- Main Content -->
          <div id="terms-scroll-container" style="background: #ffffff; padding: 48px; border-radius: 16px; border: 1px solid #e2e8f0; box-shadow: 0 10px 30px rgba(0,0,0,0.03); font-family: var(--font-secondary, 'Inter', sans-serif); color: #475569; line-height: 1.8; font-size: 1.05rem;">
            
            <p style="font-size: 1.15rem; color: #0f172a; font-weight: 500; margin-bottom: 40px; padding-bottom: 24px; border-bottom: 1px solid #e2e8f0;">
              Thanjai property Real Estate Land Promoters and Constructions in Thanjavur to buy sale and house land plot commercial industrial apartment. Unless otherwise specified, the capitalized words shall have the meanings as defined herein below:
            </p>

            <style>
              .term-nav-link {
                color: #475569;
                text-decoration: none;
                transition: all 0.2s ease;
                display: block;
              }
              .term-nav-link:hover {
                color: var(--color-orange, #eb5e28);
              }
              .term-nav-link.active-term-link {
                color: var(--color-orange, #eb5e28);
                font-weight: 700;
                transform: translateX(4px);
              }
              .term-heading {
                font-family: var(--font-primary, 'DM Serif Display', serif);
                color: var(--color-dark, #0f172a);
                font-size: 2rem;
                margin: 64px 0 24px;
                display: flex;
                align-items: center;
                gap: 16px;
              }
              .term-heading::before {
                content: '';
                display: block;
                width: 32px;
                height: 4px;
                background-color: var(--color-orange, #eb5e28);
                border-radius: 2px;
              }
              .term-para {
                margin-bottom: 24px;
              }
            </style>

            <h3 id="term-agreement" class="term-heading" style="margin-top: 0;">Agreement & Definitions</h3>
            <p class="term-para"><strong>Agreement:</strong> Shall mean and include the completed application form, its attachment(s) and the terms and conditions stated herein.</p>
            <p class="term-para"><strong>Date of Commencement:</strong> Is the date indicating the acceptance of the application by the Client to the service. It shall be specified by the company in its notice to the Client either through e-mail or conventional mail. Words referring to masculine include the feminine and the singular include the plural and vice versa as the context admits or requires; and Words importing persons includes individuals, bodies corporate and unincorporated.</p>
            <p class="term-para"><strong>Registration Data:</strong> Is the database of all the particulars and information supplied by the Client on initial application and subscription, including but without limiting to the Client's name, telephone number, mailing address, account and email address.</p>
            <p class="term-para"><strong>My Subscriptions:</strong> Contains time to time information and description of the Services for the Client provided by the Company in writing or contained in the website Thanjaiproperty.com</p>
            <p class="term-para"><strong>Date of Termination:</strong> Is the date of expiry mentioned in the notice or/and the letter of termination.</p>
            <p class="term-para"><strong>Changes:</strong> We may periodically change the Terms and the Site without notice, and you are responsible for checking these Terms periodically for revisions. All amended Terms become effective upon our posting to the Site, and any use of the site after such revisions have been posted signifies your consent to the changes.</p>
            <p class="term-para"><strong>Services:</strong> Service to the Client wishing to post their profile or listing for the purpose of sale/rental of their property, and for Client providing property services etc., and its Internet links. Service to the Client who wishes to receive advertisements and promotional messages on www.Thanjaiproperty.com and through emails.</p>
            <p class="term-para"><strong>Thanjaiproperty.com:</strong> Is defined as the Internet web site of the Company at Thanjavur.</p>

            <h3 id="term-fees" class="term-heading">Subscription Fees & Payment</h3>
            <p class="term-para"><strong>Subscription Fees:</strong> The applicable rate of the Subscription Fees for the Service provided shall be such as mentioned in the "My Subscriptions" page or as may be prescribed by the Company from time to time Liability for the Subscription Fees shall accrue from the Date of Commencement. All individual Client who access or make postings of information at Thanjaiproperty.com for the purpose of buying property shall be exempted from the application of this clause.</p>
            <p class="term-para"><strong>Payment:</strong> The Subscription Fees shall be paid by the Client on demand. In case the Client disputes the same for any reason whatsoever, he shall make the payment towards the Subscription Fees accrued subject to the decision of the Company on the dispute. In the event of Company's deciding the dispute in the Client's favour, the Company shall refund to the Client any excess amount paid by the Client free of interest. Any delay in the payment by the Client of any sums due under this Agreement, the Company shall have the right to charge interest on the outstanding amount from the date the payment became due until the date of final payment by the Client.</p>

            <h3 id="term-cancellation" class="term-heading">Cancellation</h3>
            <p class="term-para">Thanjaiproperty.com shall reserve the exclusive right to cancel any content whatsoever from being published or reflected on its website or in any other mode. The cancellation charges payable to the Client shall be at the applicable rates laid down in the cancellation and refund policy. For Premium listing packages, there shall be no cancellation or refund of orders booked / payments made via online payment options (except in the case of Cheque & Demand Draft). Cancellations requests for orders placed via cheque/demand draft can be made only before such payment is realized by Thanjaiproperty.com. Obligations of Client/Subscriber (Client) The accuracy of the Registration Data given to Thanjaiproperty.com on initial application for the Service shall be the sole responsibility of the Client. The Client will ensure compliance with all notices or instructions given by the Company from time to time to enable the use of the Service. The Client shall be solely responsible for all information retrieved, stored and transmitted through the Service by him. Any licenses or other rights as may be required for using the Service shall be obtained by the Client at his own cost. Client is responsible for all applicable taxes and for all costs that are incurred in using the Thanjaiproperty.com service.</p>

            <h3 id="term-prohibited" class="term-heading">Prohibited Actions</h3>
            <p class="term-para">Client is restrained from allowing any person other than the authorized person(s) named in the application form to use the Service. The Client undertakes not to resell or assign his/her rights or obligations under these Terms & Conditions. Client also agrees not to make any unauthorized commercial use of the Service. The Client shall use the Service only for the purpose for which it is subscribed. The Client shall comply with all applicable laws (and shall not contravene any applicable law) of India relating to the Services, including any regulation made pursuant thereto.</p>
            <p class="term-para">The Client shall not to print, download, duplicate or otherwise copy, delete, vary or amend or use any data or personal information posted by any Client on Thanjaiproperty.com except such data and information which is posted by the particular Client himself. The Client shall not share the Service with any person without the prior written approval of the Company. The Client shall not use the Service for any unlawful purpose including without limitation criminal purposes.</p>

            <h3 id="term-security" class="term-heading">Confidentiality & Security</h3>
            <p class="term-para">To protect the secrecy of his Client Identification and/or password the Client shall take all such measures as may be necessary (including but without limiting to changing his password from time to time and shall not reveal the same to any other person(s). Since a Client identification is necessary to access the Service; the Client shall use only his own Client Identification. It is agreed by the Client that he acquire s no rights to any mailbox number or/and the Client identification or/and circuit reference or/and any codes assigned to him by the Company.</p>
            <p class="term-para">The Company may at its sole discretion and without assigning any reason whatsoever at any time deactivate or/and suspend the Client's access to Thanjaiproperty.com and/or the Services (as the case may be) without notice to carry out system maintenance or/and upgrading or/and testing or/and repairs or/and other related work. Without prejudice to any other provisions of this Agreement, the Company shall not be liable for any loss or/and damage or/and costs or/and expense that the Client may suffer or incur, and no fees or/and charges payable by the Client to the Company shall be deducted or refunded or rebated, as a result of such deactivation or/and suspension.</p>

            <h3 id="term-termination" class="term-heading">Termination & Suspension</h3>
            <p class="term-para">Either party to this agreement may terminate this Agreement by giving prior notice of 30 days in writing. It shall be on the discretion of the Company that the period of notice of 30 days may be waived or a shorter period of notice may be accepted in writing from the Client. However, the Company irrespective of any clause above may terminate this Agreement with immediate effect, without prior notice to the Client and without assigning any reason/s whatsoever.</p>
            <p class="term-para">If any monies payable by the Client to the Company are not paid on the due date, the Company may without prejudice to any other rights or remedies that may be available to it suspend the Service provided to the Client. When the Service subscribed for is suspended, it shall be deemed to be terminated. The date shall be such as stipulated by the Company and the Client shall be liable for all the charges and fees incurred upto the date.</p>

            <h3 id="term-disclaimer" class="term-heading">Disclaimer & Liability</h3>
            <p class="term-para">The Client shall agree that use of the service e is at the Client's sole risk. The service is provided on an "as is" or/and on an "as available" basis. Thanjaiproperty.com expressly disclaims all warranties of any kind, whether express or implied, including, but not limited to the implied warranties of merchantability, fitness for a particular purpose and non-infringement. Thanjaiproperty.com makes no warranty that the service shall meet Client's requirements, that the service shall be uninterrupted or/and timely or/and secure or/and error free.</p>
            <p class="term-para">Client agrees that neither Thanjaiproperty.com nor any of its providers of information shall be liable for any direct or/and indirect or/and incidental or/and special or/and consequential or/and exemplary damages, resulting from the use or/and the inability to use the service or/and for cost of procurement of substitute goods or/and services or resulting from any goods or/and data or/and information or/and services purchased or/and obtained or/and messages received or/and transactions entered into through or/and from the service or/and resulting from unauthorized access to or/and alteration of Client's transmissions or/and data.</p>

            <h3 id="term-privacy" class="term-heading">Privacy Policy</h3>
            <p class="term-para">Thanjaiproperty.com respects the privacy of its Client and is committed to its protection Thanjaiproperty.com through its various advertising campaigns collects information about the Client. This information is voluntarily provided by the Client and is collected in the database of Thanjaiproperty.com. The information so collected in the database through these campaigns refers to the property details, email address and names of the Client. Thanjaiproperty.com uses third-party advertising companies to display/serve their ads on various other internet sites for reaching out to its prospective Client/buyers/sellers. The data collected is for the exclusive use of Thanjaiproperty.com and Thanjaiproperty.com reserves its right to allow access to its client for the purposes of purchase and disposing of properties only, and any unauthorized use or sharing of information by any third party shall invite appropriate legal action by Thanjaiproperty.com against the erring party, including indemnification for third party claims for damages.</p>

            <h3 id="term-misc" class="term-heading">Miscellaneous</h3>
            <p class="term-para">These Terms will be governed by and construed in accordance with the Indian laws, without giving effect to its conflict of laws provisions or your actual state or country of residence, and you agree to submit to personal jurisdiction in Thanjavur Only. You agree to exclude, in its entirety, the application to these Terms of the United Nations Convention on Contracts for the International Sale of Goods. You are responsible for compliance with applicable laws.</p>
            
            <div style="background: rgba(235, 94, 40, 0.05); border-left: 4px solid var(--color-orange, #eb5e28); padding: 32px; margin-top: 64px; border-radius: 4px;">
              <p style="margin: 0; font-family: var(--font-primary, 'DM Serif Display', serif); font-size: 1.5rem; color: #0f172a; margin-bottom: 12px;">Questions about these terms?</p>
              <p style="margin: 0; color: #475569; font-size: 1.1rem;">Write to <a href="mailto:vijayaraghavan@thanjaiproperty.com" style="color: var(--color-orange, #eb5e28); text-decoration: none; font-weight: 500;">vijayaraghavan@thanjaiproperty.com</a> or call <strong style="color: #0f172a;">+91 95783 11506</strong>.</p>
            </div>

          </div>
        </div>
      </section>
    </div>
  `}function Ye(){let e=document.querySelector(`.terms-view`);e&&(e.addEventListener(`copy`,e=>e.preventDefault()),e.addEventListener(`cut`,e=>e.preventDefault()),e.addEventListener(`contextmenu`,e=>e.preventDefault()));let t=document.querySelectorAll(`.terms-view aside a`);t.forEach(e=>{e.addEventListener(`click`,n=>{n.preventDefault(),t.forEach(e=>e.classList.remove(`active-term-link`)),e.classList.add(`active-term-link`);let r=e.getAttribute(`href`).substring(1),i=document.getElementById(r);i&&(i.scrollIntoView({behavior:`smooth`}),history.pushState(null,null,`#${r}`))})});let n=document.querySelectorAll(`.term-heading`),r=new IntersectionObserver(e=>{e.forEach(e=>{if(e.isIntersecting){let n=e.target.getAttribute(`id`);t.forEach(e=>{e.classList.remove(`active-term-link`),e.getAttribute(`href`)===`#${n}`&&e.classList.add(`active-term-link`)})}})},{root:null,rootMargin:`-80px 0px -70% 0px`,threshold:0});n.forEach(e=>{e.getAttribute(`id`)&&r.observe(e)})}function Xe(){return`
    <div class="view-enter privacy-view" style="background: #f8fafc;">
      <!-- Dark Luxury Header -->
      <section style="background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%); padding: 140px 0 80px; color: white;">
        <div class="container">
          
          <div style="display: inline-flex; align-items: center; gap: 8px; color: #ff6b6b; font-size: 0.85rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 24px;">
            <i class="ri-scales-3-line"></i> LEGAL & POLICY
          </div>

          <h1 style="font-family: var(--font-primary, 'DM Serif Display', serif); font-size: 3rem; line-height: 1.2; margin-bottom: 24px; color: #ffffff;">
            Privacy Policy
          </h1>

          <p style="font-size: 1.1rem; color: rgba(255, 255, 255, 0.7); line-height: 1.6; max-width: 800px; margin-bottom: 40px;">
            The rules that govern how you list, browse, and transact on Thanjai Property<br>
            — written plainly, so there are no surprises.
          </p>

          <div style="display: flex; flex-wrap: wrap; gap: 16px;">
            <div style="display: inline-flex; align-items: center; gap: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); padding: 8px 16px; border-radius: 30px; font-size: 0.9rem; color: rgba(255,255,255,0.8);">
              <i class="ri-government-line" style="color: #ff6b6b;"></i> Thanjai Property, Thanjavur
            </div>
            <div style="display: inline-flex; align-items: center; gap: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); padding: 8px 16px; border-radius: 30px; font-size: 0.9rem; color: rgba(255,255,255,0.8);">
              <i class="ri-refresh-line" style="color: #ff6b6b;"></i> Reviewed periodically
            </div>
            <div style="display: inline-flex; align-items: center; gap: 8px; background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1); padding: 8px 16px; border-radius: 30px; font-size: 0.9rem; color: rgba(255,255,255,0.8);">
              <i class="ri-mail-line" style="color: #ff6b6b;"></i> vijayaraghavan@thanjaiproperty.com
            </div>
          </div>
        </div>
      </section>

      <!-- Privacy Content Section with Sidebar -->
      <section style="padding: 60px 0 100px;">
        <div class="container" style="display: grid; grid-template-columns: 300px 1fr; gap: 64px; align-items: start;">
          
          <!-- Sticky Sidebar -->
          <aside style="position: sticky; top: 120px; background: #ffffff; padding: 32px; border-radius: 16px; border: 1px solid #e2e8f0; box-shadow: 0 10px 30px rgba(0,0,0,0.03);">
            <h4 style="font-family: var(--font-primary, 'DM Serif Display', serif); font-size: 1.25rem; color: var(--color-dark, #0f172a); margin-bottom: 24px; border-bottom: 2px solid var(--color-orange, #eb5e28); padding-bottom: 12px; display: inline-block;">
              Quick Navigation
            </h4>
            <ul style="list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 16px; font-size: 0.95rem; font-weight: 500;">
              <li><a href="#privacy-info" class="privacy-nav-link">1. Information Collection</a></li>
              <li><a href="#privacy-cookies" class="privacy-nav-link">2. Use of Cookies</a></li>
              <li><a href="#privacy-liability" class="privacy-nav-link">3. Limitation of Liability</a></li>
              <li><a href="#privacy-changes" class="privacy-nav-link">4. Notification of Changes</a></li>
            </ul>
          </aside>

          <!-- Main Content -->
          <div id="privacy-scroll-container" style="background: #ffffff; padding: 48px; border-radius: 16px; border: 1px solid #e2e8f0; box-shadow: 0 10px 30px rgba(0,0,0,0.03); font-family: var(--font-secondary, 'Inter', sans-serif); color: #475569; line-height: 1.8; font-size: 1.05rem;">
            
            <style>
              .privacy-nav-link {
                color: #475569;
                text-decoration: none;
                transition: all 0.2s ease;
                display: block;
              }
              .privacy-nav-link:hover {
                color: var(--color-orange, #eb5e28);
              }
              .privacy-nav-link.active-privacy-link {
                color: var(--color-orange, #eb5e28);
                font-weight: 700;
                transform: translateX(4px);
              }
              .privacy-heading {
                font-family: var(--font-primary, 'DM Serif Display', serif);
                color: var(--color-dark, #0f172a);
                font-size: 2rem;
                margin: 64px 0 24px;
                display: flex;
                align-items: center;
                gap: 16px;
              }
              .privacy-heading::before {
                content: '';
                display: block;
                width: 32px;
                height: 4px;
                background-color: var(--color-orange, #eb5e28);
                border-radius: 2px;
              }
              .privacy-para {
                margin-bottom: 24px;
              }
            </style>

            <h3 id="privacy-info" class="privacy-heading" style="margin-top: 0;">Information Collection</h3>
            <p class="privacy-para">In Thanjai Property's site we do not collect any personal information like email address or name. Thanjai Property's site provides information about the Product and Services offered by Thanjai Property's, Thanjavur. For more information of Products and Services we highly recommend to send email to vijayaraghavan@thanjaiproperty.com Upon the request we will use your email address to further communicate with you. We will not sell or share this information to any third party.</p>

            <h3 id="privacy-cookies" class="privacy-heading">Use of Cookies</h3>
            <p class="privacy-para">Cookies are used to measure the number of visits, page views, average time spent, relating to your use of Thanjai Property's site. We are not collecting any personal information through these cookies. We also recommend you to set your browser to notify you when you receive a cookie or to prevent cookies from being sent.</p>

            <h3 id="privacy-liability" class="privacy-heading">Limitation of Liability</h3>
            <p class="privacy-para">Thanjai Property's WILL NOT BE LIABLE FOR ANY LOST PROFITS, ANY DAMAGES, THAT ARISE OUT THIS WEBSITE OR ANY LINKED WEBSITE. THANJAI PROPERTY'S IS NOT RESPONSIBLE FOR THE PRIVACY PRACTIES OR THE CONTENT OF SUCH WEBSITES.</p>
            <p class="privacy-para">If you have any questions regarding this privacy statement of Thanjai Property's send an email to vijayaraghavan@thanjaiproperty.com</p>

            <h3 id="privacy-changes" class="privacy-heading">Notification of Changes</h3>
            <p class="privacy-para">Thanjai Property.com may modify this policy from time to time. Any amendment on privacy policy will be updated on our website time to time for your reference.</p>
            
            <div style="background: rgba(235, 94, 40, 0.05); border-left: 4px solid var(--color-orange, #eb5e28); padding: 32px; margin-top: 64px; border-radius: 4px;">
              <p style="margin: 0; font-family: var(--font-primary, 'DM Serif Display', serif); font-size: 1.5rem; color: #0f172a; margin-bottom: 12px;">Questions about these terms?</p>
              <p style="margin: 0; color: #475569; font-size: 1.1rem;">Write to <a href="mailto:vijayaraghavan@thanjaiproperty.com" style="color: var(--color-orange, #eb5e28); text-decoration: none; font-weight: 500;">vijayaraghavan@thanjaiproperty.com</a> or call <strong style="color: #0f172a;">+91 95783 11506</strong>.</p>
            </div>

          </div>
        </div>
      </section>
    </div>
  `}function Ze(){let e=document.querySelector(`.privacy-view`);e&&(e.addEventListener(`copy`,e=>e.preventDefault()),e.addEventListener(`cut`,e=>e.preventDefault()),e.addEventListener(`contextmenu`,e=>e.preventDefault()));let t=document.querySelectorAll(`.privacy-view aside a`);t.forEach(e=>{e.addEventListener(`click`,n=>{n.preventDefault(),t.forEach(e=>e.classList.remove(`active-privacy-link`)),e.classList.add(`active-privacy-link`);let r=e.getAttribute(`href`).substring(1),i=document.getElementById(r);i&&(i.scrollIntoView({behavior:`smooth`}),history.pushState(null,null,`#${r}`))})});let n=document.querySelectorAll(`.privacy-heading`),r=new IntersectionObserver(e=>{e.forEach(e=>{if(e.isIntersecting){let n=e.target.getAttribute(`id`);t.forEach(e=>{e.classList.remove(`active-privacy-link`),e.getAttribute(`href`)===`#${n}`&&e.classList.add(`active-privacy-link`)})}})},{root:null,rootMargin:`-80px 0px -70% 0px`,threshold:0});n.forEach(e=>{e.getAttribute(`id`)&&r.observe(e)})}var H=K(),U={keyword:``,type:`all`,location:`all`,purpose:`all`,budget:`all`,selectedPropertyId:null},W={category:`all`,keyword:``,selectedPostId:null},G={selectedPropertyId:null,isPostModalOpen:!1,scheduleModalData:null,isSavedOnlyView:!1};function K(){let e=window.location.pathname.toLowerCase().replace(/\/$/,``),t=window.location.hash.toLowerCase().replace(/^#\/?/,``);if(e.includes(`our-story`)||t===`our-story`)return`our-story`;if(e.includes(`find-your-property`)||e.includes(`find-you-property`)||e.includes(`discover-properties`)||e.includes(`discover`)||t===`find-your-property`||t===`discover-properties`||t===`discover`)return`discover`;if(t.startsWith(`blog/`)){let e=t.replace(`blog/`,``).trim();return e&&(W.selectedPostId=e),`blog`}if(e.startsWith(`/blog/`)||e.includes(`/blog/`)){let t=e.split(`/blog/`)[1]?.trim();return t&&(W.selectedPostId=t),`blog`}return e===`/blog`||t===`blog`||e.includes(`journal`)||t===`journal`?`blog`:e.includes(`contact-us`)||e.includes(`contact`)||t===`contact-us`||t===`contact`?`contact`:e.includes(`terms-of-use`)||e.includes(`terms`)||t===`terms-of-use`||t===`terms`||t.startsWith(`term-`)?`terms`:e.includes(`privacy-policy`)||e.includes(`privacy`)||t===`privacy-policy`||t===`privacy`||t.startsWith(`privacy-`)?`privacy`:`home`}function Qe(e){switch(e){case`our-story`:return`/our-story`;case`discover`:return`/find-your-property`;case`blog`:return W.selectedPostId?`/blog/${W.selectedPostId}`:`/blog`;case`contact`:return`/contact-us`;case`terms`:return`/terms-of-use`;case`privacy`:return`/privacy-policy`;default:return`/`}}function q(e){let t=`Thanjai Property | Buy, Sell & Rent Properties Across Tamil Nadu`,n=`Explore houses, villas, apartments, plots, agricultural land and commercial properties for sale or rent across Tamil Nadu. Search by location, property type and budget with Thanjai Property.`;switch(e){case`our-story`:t=`Our Story — Thanjai Property | 17+ Years of Real Estate Trust`,n=`Learn about Thanjai Property's history since 2009, legal Patta title assurance, and district plots presence across Tamil Nadu.`;break;case`discover`:t=`Find Your Property — Luxury Villas, Plots & Farmlands | Thanjai Property`,n=`Search and filter luxury villas, independent homes, DTCP layout plots, and Kaveri farm estates across Thanjavur, Trichy, Chennai, and Madurai.`;break;case`blog`:if(W.selectedPostId){let e=v(W.selectedPostId);if(e){t=e.metaTitle||`${e.title} | Thanjai Property`,n=e.metaDescription||e.excerpt||`Expert real estate articles, DTCP/RERA approval checklists, and legal verification guides.`;break}}t=`The Blog — Real Estate Guides & Insights | Thanjai Property`,n=`Expert real estate articles, DTCP/RERA approval checklists, Kaveri delta farmland guides, and architectural perspectives.`;break;case`contact`:t=`Contact Us — Thanjai Property Advisory Desk`,n=`Connect with our senior property advisors at Thanjavur Raja Nagar office or submit your private property brief.`;break;case`privacy`:t=`Privacy Policy — Thanjai Property`,n=`Privacy policy governing information collection, use of cookies, and limitations of liability on Thanjaiproperty.com`}document.title=t;let r=document.querySelector(`meta[name="description"]`);r&&r.setAttribute(`content`,n)}function J(e,t=!0){if(H=e,e!==`discover`&&(U.selectedPropertyId=null),e!==`blog`&&(W.selectedPostId=null),t){let t=Qe(e);t.startsWith(`/#`)?window.location.hash=t.replace(`/#`,``):window.history.pushState({route:e},``,t)}q(e),X(),window.scrollTo({top:0,behavior:`smooth`})}var Y=!1;function X(){let e=document.getElementById(`app`);if(!Y){e.innerHTML=`
      ${b(H,J)}
      <main style="min-height: 75vh; display: flex; flex-direction: column; justify-content: center; align-items: center; background: #faf8f5;">
         <i class="ri-loader-4-line" style="font-size: 3rem; color: #eb5e28; animation: spin 1s linear infinite;"></i>
         <div style="margin-top: 16px; font-size: 1.1rem; font-weight: 700; color: #4A5568; letter-spacing: 0.5px;">Loading Thanjai Property...</div>
         <style>@keyframes spin { to { transform: rotate(360deg); } }</style>
      </main>
      ${A()}
      ${j()}
    `;return}let t=s(),n=G.selectedPropertyId?t.find(e=>e.id===G.selectedPropertyId):null,r=``;switch(H){case`our-story`:r=je(()=>J(`discover`));break;case`discover`:r=Ne(U,e=>{U.selectedPropertyId=e,window.scrollTo({top:0,behavior:`smooth`}),X()},()=>J(`contact`));break;case`blog`:r=ze(W,e=>{W.selectedPostId=e,X()},()=>J(`contact`));break;case`contact`:r=Ke();break;case`terms`:r=Je();break;case`privacy`:r=Xe();break;default:r=`
        <main>
          ${re()}
          ${ce(t,Z,()=>J(`discover`))}
          ${ae($)}
          ${ue()}
          ${me()}
          ${ge()}
          ${ve(()=>J(`blog`),e=>Q(e))}
          ${be(()=>J(`contact`))}
        </main>
      `}switch(e.innerHTML=`
    ${b(H,J)}
    
    ${r}

    ${A()}
    ${j()}

    <!-- Dynamic Overlay Modals -->
    <div id="modal-slot">
      ${n?te(n):``}
      ${G.isPostModalOpen?Ce():``}
      ${G.scheduleModalData?Te(G.scheduleModalData):``}
    </div>
  `,ne(J,rt),document.getElementById(`nav-post-property-btn`)?.addEventListener(`click`,$),H){case`our-story`:Me(()=>J(`discover`));break;case`discover`:Re(U,e=>{U=e,X()},e=>{U.selectedPropertyId=e,window.scrollTo({top:0,behavior:`smooth`}),X()},()=>J(`contact`));break;case`blog`:Ue(W,e=>{W=e,X()},e=>{if(!e)W.selectedPostId=null;else{let t=v(e),n=t?t.slug||t.id:e;W.selectedPostId=n}J(`blog`)},()=>J(`contact`));break;case`contact`:qe();break;case`terms`:Ye();break;case`privacy`:Ze();break;default:ie(it),le(Z,()=>{U.selectedPropertyId=null,J(`discover`)}),oe($),de(at),he(ot),_e(),ye(()=>J(`blog`),e=>Q(e)),xe(()=>J(`contact`))}n&&ee(n,$e),G.isPostModalOpen&&we(et),G.scheduleModalData&&Ee(nt)}function Z(e){U.selectedPropertyId=e,J(`discover`)}function $e(){G.selectedPropertyId=null,X()}function Q(e){let t=v(e),n=t?t.slug||t.id:e;W.selectedPostId=n,J(`blog`)}function $(){i()?window.location.href=`/user-dashboard`:window.location.href=`/user-register`}function et(){G.isPostModalOpen=!1,X()}function tt(e={}){G.scheduleModalData=e,X()}function nt(){G.scheduleModalData=null,X()}function rt(){U.keyword=``,U.type=`all`,U.location=`all`,U.purpose=`all`,U.budget=`all`,J(`discover`),n(`Showing saved properties`,`ri-heart-fill`)}function it(e){U.purpose=e.purpose,U.location=e.location,U.type=e.type,U.budget=e.budget,U.selectedPropertyId=null,J(`discover`)}function at(e){U.location=e,U.selectedPropertyId=null,J(`discover`)}function ot(e){U.type=e,U.selectedPropertyId=null,J(`discover`)}window.addEventListener(`popstate`,()=>{H=K(),q(H),X()});async function st(){await Promise.all([f().catch(()=>{}),p().catch(()=>{}),m().catch(()=>{})]),r(),De(),Oe(),Se.init()}window.addEventListener(`popstate`,()=>{H=K(),q(H),X()}),window.addEventListener(`hashchange`,()=>{let e=K();e===`terms`&&H===`terms`&&window.location.hash.startsWith(`#term-`)||(H=e,q(H),X())}),window.addEventListener(`openPostPropertyModal`,()=>$()),window.addEventListener(`openScheduleModal`,e=>tt(e.detail)),window.addEventListener(`openEnquiryModal`,e=>{n(`Direct message sent to ${e.detail?.agentName||`Agent`}!`,`ri-send-plane-fill`)}),window.addEventListener(`favoritesUpdated`,e=>{let t=document.getElementById(`saved-count-badge`);t&&(t.textContent=e.detail.count)}),window.addEventListener(`propertiesUpdated`,()=>{X()}),window.addEventListener(`siteImagesUpdated`,()=>{X()}),window.addEventListener(`blogPostsUpdated`,()=>{X()}),window.addEventListener(`storage`,e=>{(e.key===`thanjai_properties`||e.key===`thanjai_blog_posts`)&&X()}),st().then(()=>{Y=!0,q(H),X()}).catch(e=>{console.error(`Critical error starting app:`,e),Y=!0,q(H),X()});