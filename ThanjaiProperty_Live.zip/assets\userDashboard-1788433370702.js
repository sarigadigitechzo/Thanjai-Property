import{c as e,f as t,g as n,h as r,i,o as a}from"./toast-1788433370702.js";import{f as o,o as s,r as c,t as l}from"./propertiesStore-1788433370702.js";var u=[],d=``,f=0,p=`free`,m=[{id:`INQ-101`,buyerName:`Senthil Kumar`,buyerRole:`Verified Buyer`,phone:`+91 98421 88921`,email:`senthil.k@gmail.com`,propertyTitle:`3BHK Luxury Villa with Garden & Car Parking`,propId:`TP-2001`,offeredPrice:`₹ 1.30 Crore`,visitDate:`20 Aug 2026 at 10:30 AM`,status:`Site Visit Requested`,message:`Interested in visiting the property on Sunday morning with family.`},{id:`INQ-102`,buyerName:`Dr. Rajan Saravanan`,buyerRole:`NRI Investor`,phone:`+91 94431 22841`,email:`dr.rajan.nri@yahoo.com`,propertyTitle:`Kaveri Riverfront Agricultural Farmland`,propId:`TP-2003`,offeredPrice:`₹ 45.00 Lakhs`,visitDate:`22 Aug 2026 at 04:00 PM`,status:`Offer Received`,message:`Looking for Kaveri water source land for organic farming project.`},{id:`INQ-103`,buyerName:`Priya Mahalingam`,buyerRole:`Individual Buyer`,phone:`+91 95857 33412`,email:`priya.m@outlook.com`,propertyTitle:`DTCP Approved Residential Plot in New Bus Stand`,propId:`TP-2002`,offeredPrice:`₹ 18.50 Lakhs`,visitDate:`21 Aug 2026 at 11:00 AM`,status:`New Inquiry`,message:`Requesting original Patta title copy and layout plan map.`}];function h(e,t=1e3,n=800,r=.75){return new Promise(i=>{if(!e||!e.type.startsWith(`image/`)){i(null);return}let a=new FileReader;a.onload=e=>{let a=new Image;a.onload=()=>{let e=a.width,o=a.height;e>t&&(o=Math.round(o*t/e),e=t),o>n&&(e=Math.round(e*n/o),o=n);let s=document.createElement(`canvas`);s.width=e,s.height=o,s.getContext(`2d`).drawImage(a,0,0,e,o),i(s.toDataURL(`image/jpeg`,r))},a.onerror=()=>i(e.target.result),a.src=e.target.result},a.onerror=()=>i(null),a.readAsDataURL(e)})}function g(){let b=document.getElementById(`user-dashboard-app`)||document.getElementById(`user-db-app`);if(!b)return;let w=a();if(!w){window.location.href=`login.html`;return}if(w.roleCode&&(w.roleCode.includes(`admin`)||w.roleCode.includes(`manager`)||w.roleCode.includes(`executive`)||w.roleCode.includes(`staff`))){window.location.href=`dashboard.html`;return}let T=w.fullName||w.name||(w.email?w.email.split(`@`)[0]:`Property Owner`),A=s().filter(e=>e.userId&&w.id&&e.userId===w.id||e.userEmail&&w.email&&e.userEmail.toLowerCase()===w.email.toLowerCase()||e.actualOwnerPhone===w.phone&&e.actualOwnerName===T?!0:!e.userId&&!e.userEmail&&e.ownerPhone===w.phone&&(e.listedBy===T||e.ownerName===T)),j=A.length,M=A.filter(e=>e.approvalStatus===`Pending Approval`||e.status===`Pending Approval`).length;A.filter(e=>e.approvalStatus===`Approved`||e.status===`Available`).length,b.innerHTML=`
    <div class="user-db-wrapper">
      
      <!-- SIDEBAR NAVIGATION -->
      <aside class="user-sidebar">
        <div class="user-sidebar-header">
          <div class="user-brand-pill">
            <img src="/thanjai-official-new.png" alt="Thanjai Property Logo" class="user-brand-logo" onerror="this.src='https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=200&q=80'" />
          </div>
        </div>

        <div class="user-profile-card">
          <div class="avatar-frame">
            <i class="ri-user-3-line avatar-icon"></i>
          </div>
          <h4 class="user-name">Hi! ${T}</h4>
          <span class="user-role-badge">${w.role||`Individual Owner`}</span>
        </div>

        <nav class="user-nav">
          <a href="index.html" class="user-nav-item nav-item" data-tab="home">
            <i class="ri-home-5-line"></i>
            <span>Home</span>
          </a>
          <a href="#" class="user-nav-item nav-item active" data-tab="my-properties">
            <i class="ri-building-4-line"></i>
            <span>My Properties (${j})</span>
          </a>
          <a href="#" class="user-nav-item nav-item" data-tab="post-property">
            <i class="ri-add-circle-line"></i>
            <span>Add New Property</span>
          </a>
          <a href="#" class="user-nav-item nav-item" data-tab="profile">
            <i class="ri-user-settings-line"></i>
            <span>Profile & Password</span>
          </a>

          <button id="user-logout-btn" class="user-nav-item logout-btn" style="margin-top: auto;">
            <i class="ri-logout-box-r-line"></i>
            <span>Logout</span>
          </button>
        </nav>
      </aside>

      <!-- MAIN CONTENT WORKSPACE -->
      <main class="user-main-area">
        
        <!-- HEADER TOPBAR -->
        <header class="user-top-bar">
          <div style="font-size: 0.88rem; color: #718096; font-weight: 600;">
            <span style="color: #1A202C; font-weight: 800;">Thanjai Property</span> / Client Portal Workspace
          </div>

          <div>
            <button class="post-prop-header-btn" id="header-post-property-btn">
              <i class="ri-add-line"></i> Add New Property
            </button>
          </div>
        </header>

        <!-- DYNAMIC CONTENT PANEL CONTAINER -->
        <div class="user-content-body" id="user-workspace-body">
          
          <!-- SUMMARY KPI CARDS -->
          <div class="user-kpi-grid">
            <div class="kpi-card" id="kpi-submitted-card" style="cursor: pointer;">
              <div class="kpi-card-inner">
                <div class="kpi-icon-box orange"><i class="ri-stack-line"></i></div>
                <div>
                  <h5 class="kpi-title">Total Submitted</h5>
                  <div class="kpi-val" id="kpi-submitted-count">${j} Properties</div>
                </div>
              </div>
              <div class="kpi-footer-link">Manage Properties &rsaquo;</div>
            </div>

            <div class="kpi-card">
              <div class="kpi-card-inner">
                <div class="kpi-icon-box blue"><i class="ri-time-line"></i></div>
                <div>
                  <h5 class="kpi-title">Awaiting Approval</h5>
                  <div class="kpi-val" id="kpi-pending-count">${M} Pending</div>
                </div>
              </div>
              <div class="kpi-footer-link">Pending Verification &rsaquo;</div>
            </div>
          </div>

          <!-- PROPERTIES INVENTORY TABLE PANEL -->
          <div class="user-data-panel">
            <div class="panel-header">
              <div>
                <h2 class="panel-title" id="panel-title-text">My Listed Properties</h2>
                <p class="panel-subtitle" id="panel-sub-text">Properties uploaded under your seller account with live approval status</p>
              </div>
            </div>

            <div class="panel-body" id="panel-body-content" style="width: 100%; box-sizing: border-box;">
              ${y(A)}
            </div>
          </div>

        </div>
      </main>

    </div>
  `;let N=document.getElementById(`user-notice-banner`),P=document.getElementById(`close-notice-btn`),F=()=>{N&&!N.classList.contains(`fade-out`)&&(N.classList.add(`fade-out`),setTimeout(()=>N.remove(),450))};P?.addEventListener(`click`,F),setTimeout(F,5e3),document.getElementById(`user-logout-btn`)?.addEventListener(`click`,()=>{t(),i(`Logged out successfully`,`ri-logout-box-r-line`),window.location.href=`login.html`});function I(e=null,t=`free`){let n=e?.adType||t||`free`;p=n;let r=document.getElementById(`panel-title-text`),i=document.getElementById(`panel-sub-text`),a=document.getElementById(`panel-body-content`);R.forEach(e=>e.classList.remove(`active`)),document.querySelector(`[data-tab="post-property"]`)?.classList.add(`active`),r&&(r.textContent=e?`Edit Property (${e.id})`:`Add New Property`),i&&(i.textContent=e?`Modify your property specs, price, location, or uploaded photos`:`Upload land, house, villa, or commercial property for review and publication`),a&&(a.innerHTML=E(e,n),H(e,n))}document.getElementById(`header-post-property-btn`)?.addEventListener(`click`,()=>{k(e=>{I(null,e)})}),document.getElementById(`kpi-submitted-card`)?.addEventListener(`click`,()=>{document.querySelector(`[data-tab="my-properties"]`)?.click()}),document.getElementById(`kpi-buyers-link`)?.addEventListener(`click`,()=>{document.querySelector(`[data-tab="buyers-list"]`)?.click()});let R=document.querySelectorAll(`.user-nav .nav-item`);function z(){let e=s().filter(e=>e.userId&&w.id&&e.userId===w.id||e.userEmail&&w.email&&e.userEmail.toLowerCase()===w.email.toLowerCase()||e.actualOwnerPhone===w.phone&&e.actualOwnerName===T?!0:!e.userId&&!e.userEmail&&e.ownerPhone===w.phone&&(e.listedBy===T||e.ownerName===T)),t=document.getElementById(`panel-title-text`),n=document.getElementById(`panel-sub-text`),r=document.getElementById(`panel-body-content`);t&&(t.textContent=`My Listed Properties`),n&&(n.textContent=`Properties uploaded under your seller account with live approval status`),r&&(r.innerHTML=y(e),B());let i=e.length,a=e.filter(e=>e.approvalStatus===`Pending Approval`||e.status===`Pending Approval`).length,o=document.getElementById(`kpi-submitted-count`),c=document.getElementById(`kpi-pending-count`);o&&(o.textContent=`${i} Properties`),c&&(c.textContent=`${a} Pending`);let l=document.getElementById(`sidebar-props-count`);l&&(l.textContent=i)}function B(){document.getElementById(`empty-post-btn`)?.addEventListener(`click`,()=>{k(e=>{I(null,e)})}),document.querySelectorAll(`.user-preview-prop-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.id;t&&(f=0,C(t))})}),document.querySelectorAll(`.user-edit-prop-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.id,n=s().find(e=>e.id===t);if(n){let e=document.getElementById(`panel-title-text`),r=document.getElementById(`panel-sub-text`),i=document.getElementById(`panel-body-content`);e&&(e.textContent=`Edit Property (${t})`),r&&(r.textContent=`Modify your property specs, price, location, or uploaded photos`),i&&(i.innerHTML=E(n,n.adType||`free`),H(n,n.adType||`free`))}})}),document.querySelectorAll(`.user-delete-prop-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.dataset.id;v(t,s().find(e=>e.id===t)?.title||``,()=>{c(t),i(`Property listing ${t} deleted successfully.`,`ri-delete-bin-line`),z()})})})}B(),R.forEach(e=>{e.addEventListener(`click`,t=>{let n=e.dataset.tab;if(n===`home`||e.getAttribute(`href`)===`index.html`){window.location.href=`index.html`;return}t.preventDefault(),R.forEach(e=>e.classList.remove(`active`)),e.classList.add(`active`),V(n)})});function V(t){let a=document.getElementById(`panel-title-text`),o=document.getElementById(`panel-sub-text`),s=document.getElementById(`panel-body-content`);t===`home`||t===`my-properties`?z():t===`post-property`?k(e=>{p=e,I(null,e)}):t===`buyers-list`?(a&&(a.textContent=`Buyers Inquiries & Lead Desk`),o&&(o.textContent=`Direct buyer leads, site visit requests, and offers submitted for your listings`),s&&(s.innerHTML=D(m))):t===`profile`&&(a&&(a.textContent=`Owner Profile & Password Settings`),o&&(o.textContent=`Manage your seller account details and login password`),s&&(s.innerHTML=`
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 24px; padding: 10px 0;">
            <!-- LEFT: Profile Details Form -->
            <div style="background: #ffffff; border: 1px solid #E2E8F0; border-radius: 16px; padding: 24px; box-shadow: 0 2px 10px rgba(0,0,0,0.02);">
              <h3 style="font-size: 1.1rem; font-weight: 800; color: #1A202C; margin-bottom: 6px; display: flex; align-items: center; gap: 8px;">
                <i class="ri-user-settings-line" style="color: #eb5e28;"></i> Personal Profile
              </h3>
              <p style="font-size: 0.85rem; color: #718096; margin-bottom: 20px;">Update your displayed name and contact phone number</p>

              <form id="owner-profile-form" onsubmit="return false;">
                <div style="margin-bottom: 16px;">
                  <label style="font-size: 0.82rem; font-weight: 700; color: #4A5568; display: block; margin-bottom: 6px;">FULL NAME</label>
                  <input type="text" id="profile-fullname-input" value="${T}" required style="width: 100%; padding: 10px 14px; border-radius: 8px; border: 1px solid #CBD5E0; background: #ffffff; font-size: 0.9rem; outline: none;" />
                </div>

                <div style="margin-bottom: 16px;">
                  <label style="font-size: 0.82rem; font-weight: 700; color: #4A5568; display: block; margin-bottom: 6px;">EMAIL ADDRESS (USERNAME)</label>
                  <input type="email" value="${w.email||``}" readonly style="width: 100%; padding: 10px 14px; border-radius: 8px; border: 1px solid #CBD5E0; background: #EDF2F7; font-size: 0.9rem; color: #718096;" />
                </div>

                <div style="margin-bottom: 16px;">
                  <label style="font-size: 0.82rem; font-weight: 700; color: #4A5568; display: block; margin-bottom: 6px;">PHONE NUMBER</label>
                  <input type="tel" id="profile-phone-input" value="${w.phone||``}" required maxlength="10" pattern="[0-9]{10}" oninput="this.value = this.value.replace(/[^0-9]/g, '')" style="width: 100%; padding: 10px 14px; border-radius: 8px; border: 1px solid #CBD5E0; background: #ffffff; font-size: 0.9rem; outline: none;" />
                </div>

                <div style="margin-bottom: 24px;">
                  <label style="font-size: 0.82rem; font-weight: 700; color: #4A5568; display: block; margin-bottom: 6px;">ACCOUNT ROLE</label>
                  <input type="text" value="${w.role||`Individual Owner`}" readonly style="width: 100%; padding: 10px 14px; border-radius: 8px; border: 1px solid #CBD5E0; background: #EDF2F7; font-size: 0.9rem; color: #718096;" />
                </div>

                <button type="submit" id="save-profile-btn" style="background: #eb5e28; color: #fff; border: none; padding: 10px 24px; border-radius: 8px; font-weight: 700; font-size: 0.9rem; cursor: pointer; box-shadow: 0 4px 12px rgba(235,94,40,0.25);">
                  <i class="ri-save-line"></i> Save Profile Details
                </button>
              </form>
            </div>

            <!-- RIGHT: Change / Set Password Form -->
            <div style="background: #ffffff; border: 1px solid #E2E8F0; border-radius: 16px; padding: 24px; box-shadow: 0 2px 10px rgba(0,0,0,0.02);">
              <h3 style="font-size: 1.1rem; font-weight: 800; color: #1A202C; margin-bottom: 6px; display: flex; align-items: center; gap: 8px;">
                <i class="ri-lock-password-line" style="color: #3182CE;"></i> Change Password
              </h3>
              <p style="font-size: 0.85rem; color: #718096; margin-bottom: 20px;">
                ${w.isTemporaryPassword?`⚠️ You are currently using a temporary password. Please set a permanent password.`:`Update your personal account login password`}
              </p>

              <form id="owner-password-form" onsubmit="return false;">
                <div style="margin-bottom: 16px;">
                  <label style="font-size: 0.82rem; font-weight: 700; color: #4A5568; display: block; margin-bottom: 6px;">NEW PASSWORD</label>
                  <input type="password" id="profile-new-password" required minlength="6" placeholder="Enter new password (min 6 chars)" style="width: 100%; padding: 10px 14px; border-radius: 8px; border: 1px solid #CBD5E0; background: #ffffff; font-size: 0.9rem; outline: none;" />
                </div>

                <div style="margin-bottom: 24px;">
                  <label style="font-size: 0.82rem; font-weight: 700; color: #4A5568; display: block; margin-bottom: 6px;">CONFIRM NEW PASSWORD</label>
                  <input type="password" id="profile-confirm-password" required minlength="6" placeholder="Confirm new password" style="width: 100%; padding: 10px 14px; border-radius: 8px; border: 1px solid #CBD5E0; background: #ffffff; font-size: 0.9rem; outline: none;" />
                </div>

                <button type="submit" id="save-password-btn" style="background: #3182CE; color: #fff; border: none; padding: 10px 24px; border-radius: 8px; font-weight: 700; font-size: 0.9rem; cursor: pointer; box-shadow: 0 4px 12px rgba(49,130,206,0.25);">
                  <i class="ri-shield-keyhole-line"></i> Update Password
                </button>
              </form>
            </div>
          </div>
        `,document.getElementById(`owner-profile-form`)?.addEventListener(`submit`,t=>{t.preventDefault();let n=document.getElementById(`profile-fullname-input`)?.value.trim(),a=document.getElementById(`profile-phone-input`)?.value.trim();if(!n||!a){i(`Please provide both Full Name and Phone Number.`,`ri-error-warning-line`);return}let o={...w,fullName:n,name:n,phone:a};r(o);let s=e(),c=s.findIndex(e=>e.email?.toLowerCase()===w.email?.toLowerCase()||e.id===w.id);c>=0&&(s[c]={...s[c],...o},localStorage.setItem(`thanjai_registered_users`,JSON.stringify(s))),i(`Profile details updated successfully!`,`ri-checkbox-circle-fill`),setTimeout(()=>{g()},300)}),document.getElementById(`owner-password-form`)?.addEventListener(`submit`,e=>{e.preventDefault();let t=document.getElementById(`profile-new-password`)?.value.trim(),r=document.getElementById(`profile-confirm-password`)?.value.trim();if(!t||t.length<6){i(`Password must be at least 6 characters.`,`ri-error-warning-line`);return}if(t!==r){i(`New Password and Confirm Password do not match.`,`ri-error-warning-line`);return}let a=n(w.email||w.id,t);a.success?(i(`Password updated successfully! You can now log in with your new password.`,`ri-checkbox-circle-fill`),setTimeout(()=>{g()},300)):i(a.message||`Failed to update password.`,`ri-error-warning-line`)})))}function H(e=null){let t=!!e,n=document.getElementById(`user-prop-type`),r=document.getElementById(`user-res-specs-box`),a=document.getElementById(`user-prop-img-url`),s=document.getElementById(`user-prop-img-files`),c=document.getElementById(`user-prop-video-file-input`),f=document.getElementById(`user-video-label-text`),m=document.getElementById(`user-geolocation-btn`),g=document.getElementById(`user-map-pinpoint-btn`);document.getElementById(`cancel-edit-btn`)?.addEventListener(`click`,()=>{document.querySelector(`[data-tab="my-properties"]`)?.click()}),n?.addEventListener(`input`,()=>{let e=(n.value||``).toLowerCase().trim(),t=[`house`,`villa`,`apartment`,`home`,`flat`,`duplex`,`townhouse`,`penthouse`,`building`,`room`,`bhk`,`residence`,`cottage`,`bungalow`,`rowhouse`,`manor`,`studio`].some(t=>e.includes(t));r&&(r.style.display=t?`block`:`none`)}),a?.addEventListener(`input`,()=>{let e=a.value.trim();e&&!u.includes(e)&&(u.unshift(e),u=[...new Set(u)],x())}),s?.addEventListener(`change`,async e=>{let t=Array.from(e.target.files);if(!(!t||t.length===0)){i(`Compressing ${t.length} photo(s)...`,`ri-loader-4-line`);for(let e of t){if(!e.type.startsWith(`image/`))continue;let t=await h(e,1e3,800,.75);t&&u.push(t)}u=[...new Set(u)],x(),i(`${t.length} HD photo(s) added to property!`,`ri-image-add-line`)}}),S(),c?.addEventListener(`change`,e=>{let t=e.target.files[0];if(t){let e=new FileReader;e.onload=e=>{d=e.target.result,f&&(f.textContent=`Video Uploaded (${t.name})`),i(`Video file attached successfully!`,`ri-video-upload-line`)},e.readAsDataURL(t)}}),m?.addEventListener(`click`,()=>{navigator.geolocation&&navigator.geolocation.getCurrentPosition(e=>{let t=e.coords.latitude.toFixed(6),n=e.coords.longitude.toFixed(6),r=document.getElementById(`user-prop-latitude`),a=document.getElementById(`user-prop-longitude`);r&&(r.value=t),a&&(a.value=n);let o=document.getElementById(`user-location-badge`),s=document.getElementById(`user-location-badge-text`);o&&(o.style.display=`inline-flex`),s&&(s.textContent=`Location Pinpoint Captured: Lat ${t}, Lng ${n}`),i(`Location captured: Lat ${t}, Lng ${n}`,`ri-map-pin-user-fill`)},()=>{i(`Geolocation permission denied or unavailable.`,`ri-error-warning-line`)})}),g?.addEventListener(`click`,()=>{let e=document.getElementById(`user-prop-latitude`),t=document.getElementById(`user-prop-longitude`);O(e?.value||`10.786999`,t?.value||`79.137827`,(n,r)=>{e&&(e.value=n),t&&(t.value=r);let a=document.getElementById(`user-location-badge`),o=document.getElementById(`user-location-badge-text`);a&&(a.style.display=`inline-flex`),o&&(o.textContent=`Location Pinpoint Captured: Lat ${n}, Lng ${r}`),i(`Map location saved: Lat ${n}, Lng ${r}`,`ri-compass-3-fill`)})}),document.getElementById(`change-adtype-btn`)?.addEventListener(`click`,()=>{k(t=>{I(e,t)})});let v=document.getElementById(`client-post-prop-form`);document.getElementById(`user-submit-prop-btn`)?.addEventListener(`click`,()=>{v&&!v.checkValidity()&&i(`Please fill out all required fields marked with * (Scroll up to see)`,`ri-error-warning-line`)}),v?.addEventListener(`submit`,n=>{n.preventDefault();let r=document.getElementById(`user-prop-title`).value,a=document.getElementById(`user-prop-type`).value,s=document.getElementById(`user-prop-category`).value,c=document.getElementById(`user-prop-area`)?.value.trim()||``,f=document.getElementById(`user-prop-road`)?.value||``,m=document.getElementById(`user-prop-taluk`)?.value.trim()||`Thanjavur`,h=document.getElementById(`user-prop-district`)?.value.trim()||`Thanjavur`,g=document.getElementById(`user-prop-facing`)?.value.trim()||``,v=document.getElementById(`user-prop-size`).value,y=document.getElementById(`user-prop-builtup-size`)?.value.trim()||``,b=parseInt(document.getElementById(`user-prop-bedrooms`)?.value||0),x=parseInt(document.getElementById(`user-prop-bathrooms`)?.value||0),S=document.getElementById(`user-prop-floor`)?.value.trim(),C=document.getElementById(`user-prop-furnishing`)?.value,E=parseFloat(document.getElementById(`user-prop-price`).value)||0,D=document.getElementById(`user-prop-img-url`).value,O=document.getElementById(`user-prop-videolink`).value||d,k=document.getElementById(`user-prop-latitude`)?.value||`10.786999`,A=document.getElementById(`user-prop-longitude`)?.value||`79.137827`,j=document.getElementById(`user-prop-desc`).value,M=[c,f&&f!==`Other / Outside Road`?f:``,m,h].filter(Boolean),N=M.length>0?[...new Set(M)].join(`, `):c||h||``,P=Array.from(document.querySelectorAll(`.user-feature-chk:checked`)).map(e=>e.value),F=[...u];D&&!F.includes(D)&&F.unshift(D);let I=[...new Set(F.filter(Boolean))];I.length===0&&I.push(`/default-property.jpg`);let R=a.toLowerCase().trim(),z=[`house`,`villa`,`apartment`,`home`,`flat`,`duplex`,`townhouse`,`penthouse`,`building`,`room`,`bhk`,`residence`,`cottage`,`bungalow`,`rowhouse`,`manor`,`studio`].some(e=>R.includes(e)),B=p||e?.adType||`free`,V=T,H=w.phone,U=T;B===`free`&&(V=`Thanjai Property`,H=`+91 84899 96852`,U=`Thanjai Property`);let W={title:r,type:a,purpose:s===`Rent`?`rent`:`buy`,category:s===`Rent`?`Rent`:`Sale`,categoryRaw:s,district:h,taluk:m,road:f,area:c,location:N,facing:g,address:g||c,size:v,builtUpArea:z&&y?y:y||``,posterRole:w.role||`Individual Owner`,bedrooms:z?b:null,bathrooms:z?x:null,floor:S||null,furnishing:C,price:E,images:I,videoUrl:O,latitude:k,longitude:A,description:j||`${r} located at ${N}.`,features:P.length>0?P:[`Patta Title Verified`,`24/7 Security`],adType:B,actualOwnerName:T,actualOwnerPhone:w.phone,ownerName:V,ownerPhone:w.phone||H,inquiryPhone:`8489996852`,listedBy:U,userId:w.id,userEmail:w.email,approvalStatus:t&&e.approvalStatus||`Pending Approval`,status:t&&e.status||`Pending Approval`};if(t)o(e.id,W),i(`Property ${e.id} updated successfully!`,`ri-checkbox-circle-fill`),setTimeout(()=>_(`Property ${e.id} updated successfully!`),100);else{let e=l(W);i(`Property ${e.id} submitted for Admin Approval!`,`ri-time-line`),setTimeout(()=>_(`New property ${e.id} submitted! Sent to Admin for Approval.`),100)}u=[],d=``,document.querySelector(`[data-tab="my-properties"]`)?.click()})}}function _(e){let t=document.getElementById(`user-workspace-body`);if(!t)return;document.getElementById(`user-action-notice-banner`)?.remove();let n=document.createElement(`div`);n.id=`user-action-notice-banner`,n.className=`notice-banner-box`,n.style.cssText=`
    background: #E6FFFA; border: 1px solid #B2F5EA; color: #234E52; border-radius: 12px;
    padding: 14px 20px; font-size: 0.9rem; font-weight: 700; margin-bottom: 24px; display: flex; align-items: center; justify-content: space-between; gap: 12px;
  `,n.innerHTML=`
    <div style="display: flex; align-items: center; gap: 8px;">
      <i class="ri-checkbox-circle-fill" style="color: #38A169; font-size: 1.2rem;"></i>
      <span>Notice: ${e}</span>
    </div>
    <div style="display: flex; align-items: center; gap: 8px;">
      <span style="background: #38A169; color: #fff; font-size: 0.72rem; font-weight: 800; padding: 4px 10px; border-radius: 12px;">VERIFIED LIVE</span>
      <button id="close-action-notice-btn" title="Dismiss notice" style="background: none; border: none; color: #234E52; font-size: 1.2rem; cursor: pointer; display: flex; align-items: center; justify-content: center; padding: 2px;">
        <i class="ri-close-line"></i>
      </button>
    </div>
  `,t.insertBefore(n,t.firstElementChild);let r=()=>{n&&!n.classList.contains(`fade-out`)&&(n.classList.add(`fade-out`),setTimeout(()=>n.remove(),450))};document.getElementById(`close-action-notice-btn`)?.addEventListener(`click`,r),setTimeout(r,4e3)}function v(e,t,n){document.getElementById(`user-custom-confirm-overlay`)?.remove();let r=document.createElement(`div`);r.id=`user-custom-confirm-overlay`,r.style.cssText=`
    position: fixed !important; top: 0 !important; left: 0 !important; right: 0 !important; bottom: 0 !important;
    width: 100vw !important; height: 100vh !important; z-index: 999999 !important;
    background: rgba(15, 23, 42, 0.75) !important; backdrop-filter: blur(6px) !important;
    display: flex !important; align-items: center !important; justify-content: center !important;
    padding: 20px !important; box-sizing: border-box !important; margin: 0 !important;
  `,r.innerHTML=`
    <div style="
      background: #ffffff; width: 100%; max-width: 440px; border-radius: 20px;
      padding: 32px 28px 24px; box-shadow: 0 20px 40px rgba(0,0,0,0.3); text-align: center;
      box-sizing: border-box; border: 1px solid #E2E8F0;
    ">
      <div style="
        width: 60px; height: 60px; border-radius: 50%; background: #FFF5F5;
        border: 2px solid #FED7D7; color: #E52E3D; display: flex; align-items: center;
        justify-content: center; font-size: 1.8rem; margin: 0 auto 20px;
      ">
        <i class="ri-delete-bin-line"></i>
      </div>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #1A202C; margin: 0 0 8px 0;">Delete Property Listing?</h3>
      
      <p style="font-size: 0.9rem; color: #718096; line-height: 1.5; margin: 0 0 20px 0;">
        Are you sure you want to permanently delete <strong style="color: #E52E3D;">${e}</strong> (${t||`this listing`})? This action cannot be undone.
      </p>

      <div style="display: flex; gap: 12px; justify-content: center;">
        <button id="cancel-user-delete-btn" style="
          flex: 1; padding: 12px 18px; border-radius: 12px; border: 1px solid #CBD5E0;
          background: #EDF2F7; color: #4A5568; font-weight: 700; font-size: 0.9rem; cursor: pointer;
        ">Cancel</button>
        <button id="confirm-user-delete-btn" style="
          flex: 1; padding: 12px 18px; border-radius: 12px; border: none;
          background: #E52E3D; color: #ffffff; font-weight: 700; font-size: 0.9rem; cursor: pointer;
          box-shadow: 0 4px 12px rgba(229, 46, 61, 0.3);
        ">Yes, Delete</button>
      </div>
    </div>
  `,document.body.appendChild(r);let i=()=>r.remove();document.getElementById(`cancel-user-delete-btn`)?.addEventListener(`click`,i),document.getElementById(`confirm-user-delete-btn`)?.addEventListener(`click`,()=>{i(),n()}),r.addEventListener(`click`,e=>{e.target===r&&i()})}function y(e){return e.length===0?`
      <div style="padding: 48px; text-align: center; color: #718096;">
        <i class="ri-building-line" style="font-size: 3rem; color: #eb5e28; margin-bottom: 12px; display: block;"></i>
        <h3 style="font-size: 1.1rem; color: #1A202C; margin-bottom: 6px;">No Properties Uploaded Yet</h3>
        <p style="font-size: 0.9rem; margin-bottom: 20px;">Upload your land or house to reach verified buyers across Tamil Nadu.</p>
        <button class="post-prop-header-btn" id="empty-post-btn">
          <i class="ri-add-line"></i> Add New Property
        </button>
      </div>
    `:`
    <div class="table-responsive">
      <table class="user-table">
        <thead>
          <tr>
            <th>Property ID</th>
            <th>Title</th>
            <th>Type</th>
            <th>Location</th>
            <th>Expected Price</th>
            <th>Approval Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${e.map(e=>{let t=e.approvalStatus===`Pending Approval`||e.status===`Pending Approval`,n=e.approvalStatus===`Approved`||e.status===`Available`,r=e.approvalStatus===`Rejected`;return`
              <tr>
                <td style="font-weight: 700; color: #eb5e28;">${e.id}</td>
                <td style="font-weight: 700;">${e.title}</td>
                <td>${e.type||`Property`}</td>
                <td>${e.location||`Thanjavur`}</td>
                <td style="font-weight: 700; color: #2b6cb0;">${e.priceFormatted||`₹ `+(e.price||0).toLocaleString(`en-IN`)}</td>
                <td>
                  ${t?`
                    <span style="background: #FEEBC8; color: #C05621; font-weight: 800; padding: 4px 10px; border-radius: 6px; font-size: 0.8rem; display: inline-flex; align-items: center; gap: 4px;">
                      <i class="ri-time-line"></i> Pending Admin Approval
                    </span>
                  `:n?`
                    <span style="background: #E6FFFA; color: #234E52; font-weight: 800; padding: 4px 10px; border-radius: 6px; font-size: 0.8rem; display: inline-flex; align-items: center; gap: 4px;">
                      <i class="ri-checkbox-circle-fill" style="color: #38A169;"></i> Approved & Published Live
                    </span>
                  `:`
                    <div style="display: flex; flex-direction: column; gap: 4px;">
                      <span style="background: #FED7D7; color: #9B2C2C; font-weight: 800; padding: 4px 10px; border-radius: 6px; font-size: 0.8rem; display: inline-flex; align-items: center; gap: 4px;">
                        <i class="ri-close-circle-fill"></i> ${r?`Submission Rejected`:e.status}
                      </span>
                      ${e.rejectionReason?`
                        <span style="font-size: 0.76rem; color: #E52E3D; font-weight: 600; line-height: 1.3;">
                          Reason: ${e.rejectionReason}
                        </span>
                      `:``}
                    </div>
                  `}
                </td>
                <td>
                  <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                    <button class="user-preview-prop-btn" data-id="${e.id}" title="Preview property details" style="
                      background: #F7FAFC; color: #4A5568; border: 1px solid #CBD5E0; padding: 6px 12px;
                      border-radius: 8px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 4px;
                    ">
                      <i class="ri-eye-line" style="color: #eb5e28;"></i> Preview
                    </button>

                    <button class="user-edit-prop-btn" data-id="${e.id}" style="
                      background: rgba(49,130,206,0.12); color: #3182ce; border: none; padding: 6px 12px;
                      border-radius: 8px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 4px;
                    ">
                      <i class="ri-pencil-line"></i> Edit
                    </button>

                    <button class="user-delete-prop-btn" data-id="${e.id}" style="
                      background: rgba(229,46,61,0.12); color: #E52E3D; border: none; padding: 6px 12px;
                      border-radius: 8px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 4px;
                    ">
                      <i class="ri-delete-bin-line"></i> Delete
                    </button>
                  </div>
                </td>
              </tr>
            `}).join(``)}
        </tbody>
      </table>
    </div>
  `}function b(){return!u||u.length===0?``:u.map((e,t)=>`
    <div style="position: relative; width: 90px; height: 90px; border-radius: 10px; overflow: hidden; border: 1px solid #CBD5E0; flex-shrink: 0; background: #111;">
      <img src="${e}" style="width:100%; height:100%; object-fit:cover;" />
      <button type="button" class="delete-user-img-btn" data-index="${t}" title="Remove photo" style="
        position: absolute; top: 4px; right: 4px; width: 24px; height: 24px; border-radius: 50%;
        background: rgba(229, 62, 62, 0.95); color: #ffffff; border: none; font-size: 0.85rem;
        display: flex; align-items: center; justify-content: center; cursor: pointer; box-shadow: 0 2px 6px rgba(0,0,0,0.3);
      ">
        <i class="ri-close-line"></i>
      </button>
    </div>
  `).join(``)}function x(){let e=document.getElementById(`user-uploaded-preview-grid`);e&&(e.innerHTML=b(),S())}function S(){document.querySelectorAll(`.delete-user-img-btn`).forEach(e=>{e.addEventListener(`click`,t=>{t.preventDefault();let n=parseInt(e.dataset.index,10);!isNaN(n)&&n>=0&&n<u.length&&(u.splice(n,1),x(),i(`Photo removed`,`ri-delete-bin-line`))})})}function C(e){document.getElementById(`user-prop-modal-overlay`)?.remove();let t=s().find(t=>t.id===e);if(!t)return;let n=document.createElement(`div`);n.innerHTML=w(t);let r=n.firstElementChild;r&&(document.body.appendChild(r),T(e))}function w(e){if(!e)return``;let t=Array.isArray(e.images)?e.images.filter(Boolean):[],n=[...new Set(t)],r=n.length>0?n:[`/default-property.jpg`],i=e.status||e.availability||`Available`,a=[];if(e.videoUrl){let t=!1,n=e.videoUrl;if(e.videoUrl.includes(`youtube.com`)||e.videoUrl.includes(`youtu.be`)){let r=e.videoUrl.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))([\w-]{11})/);r&&r[1]&&(n=`https://www.youtube.com/embed/${r[1]}?autoplay=0`,t=!0)}else(e.videoUrl.includes(`facebook.com`)||e.videoUrl.includes(`fb.watch`)||e.videoUrl.includes(`fb.com`))&&(n=`https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(e.videoUrl)}&show_text=0&width=560&autoplay=0`,t=!0);a.push({type:`video`,url:n,rawUrl:e.videoUrl,isEmbeddable:t,title:`Property Video Tour`,thumb:r[0]})}r.forEach((e,t)=>{a.push({type:`image`,url:e,title:`Photo ${t+1}`,thumb:e})});let o=a.length;f>=o&&(f=0);let s=a[f]||a[0],c=``;return c=s.type===`video`?s.isEmbeddable?`<iframe src="${s.url}" style="width: 100%; height: 100%; border: none;" allowfullscreen></iframe>`:`<video src="${s.rawUrl}" controls autoplay style="width: 100%; height: 100%; object-fit: contain; background: #000;"></video>`:`<img src="${s.url}" alt="${e.title}" style="width: 100%; height: 100%; object-fit: cover;" />`,`
    <div id="user-prop-modal-overlay" style="
      position: fixed !important; top: 0 !important; left: 0 !important; right: 0 !important; bottom: 0 !important;
      width: 100vw !important; height: 100vh !important; z-index: 999999 !important;
      background: rgba(15, 23, 42, 0.82) !important; backdrop-filter: blur(8px) !important;
      display: flex !important; align-items: center !important; justify-content: center !important;
      padding: 24px !important; box-sizing: border-box !important; margin: 0 !important;
    ">
      <div style="
        background: #ffffff; width: 100%; max-width: 920px; max-height: 90vh; border-radius: 24px;
        overflow: hidden; box-shadow: 0 25px 60px rgba(0,0,0,0.5); border: 1px solid #e2e8f0; display: flex; flex-direction: column;
      ">
        
        <!-- Modal Top Bar -->
        <div style="padding: 18px 28px; background: #faf8f5; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; flex-shrink: 0;">
          <div>
            <span style="font-size: 0.75rem; font-weight: 800; color: #eb5e28; letter-spacing: 0.08em; text-transform: uppercase;">
              PROPERTY PREVIEW • ID: ${e.id}
            </span>
            <h3 style="font-size: 1.3rem; font-weight: 800; color: #1a202c; margin: 2px 0 0 0;">${e.title}</h3>
          </div>

          <button id="close-user-prop-preview-btn" style="background: #ffffff; border: 1px solid #cbd5e0; color: #4a5568; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; cursor: pointer;">
            <i class="ri-close-line"></i>
          </button>
        </div>

        <!-- Scrollable Modal Body -->
        <div style="padding: 24px 28px; overflow-y: auto; display: flex; flex-direction: column; gap: 24px; flex: 1;">
          
          <!-- HERO MEDIA VIEWPORT -->
          <div style="width: 100%;">
            <div style="width: 100%; height: 380px; border-radius: 16px; overflow: hidden; background: #f0f4f8; position: relative; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
              ${c}

              <!-- Counter Badge -->
              <div style="position: absolute; top: 16px; left: 16px; background: rgba(0,0,0,0.75); color: #ffffff; font-size: 0.8rem; font-weight: 700; padding: 6px 14px; border-radius: 20px; backdrop-filter: blur(4px); display: flex; align-items: center; gap: 6px; z-index: 10;">
                <i class="${s.type===`video`?`ri-video-line`:`ri-image-line`}" style="color: #eb5e28;"></i>
                <span>${s.type===`video`?`Video Tour`:`Photo ${f+ +!e.videoUrl} of ${o-+!!e.videoUrl}`}</span>
              </div>

              <!-- Status Badge -->
              <span style="position: absolute; top: 16px; right: 16px; background: #eb5e28; color: #fff; font-size: 0.78rem; font-weight: 800; padding: 6px 14px; border-radius: 20px; z-index: 10;">
                ${i.toUpperCase()}
              </span>

              <!-- Carousel Navigation Arrows -->
              ${o>1?`
                <button id="user-prev-preview-media-btn" title="Previous photo" style="
                  position: absolute; left: 16px; top: 50%; transform: translateY(-50%); width: 44px; height: 44px; border-radius: 50%;
                  background: rgba(0,0,0,0.65); color: #ffffff; border: 1px solid rgba(255,255,255,0.3); font-size: 1.4rem;
                  display: flex; align-items: center; justify-content: center; cursor: pointer; backdrop-filter: blur(6px); z-index: 10;
                ">
                  <i class="ri-arrow-left-s-line"></i>
                </button>

                <button id="user-next-preview-media-btn" title="Next photo" style="
                  position: absolute; right: 16px; top: 50%; transform: translateY(-50%); width: 44px; height: 44px; border-radius: 50%;
                  background: rgba(0,0,0,0.65); color: #ffffff; border: 1px solid rgba(255,255,255,0.3); font-size: 1.4rem;
                  display: flex; align-items: center; justify-content: center; cursor: pointer; backdrop-filter: blur(6px); z-index: 10;
                ">
                  <i class="ri-arrow-right-s-line"></i>
                </button>
              `:``}
            </div>

            <!-- Horizontal Thumbnail Carousel -->
            ${o>1?`
              <div style="display: flex; gap: 12px; overflow-x: auto; padding: 14px 4px 6px 4px; margin-top: 12px; scrollbar-width: thin; scrollbar-color: #eb5e28 #edf2f7;">
                ${a.map((e,t)=>{let n=t===f;return`
                    <div class="user-preview-thumb-card" data-index="${t}" style="
                      position: relative; flex-shrink: 0; width: 110px; height: 74px; border-radius: 10px; overflow: hidden;
                      cursor: pointer; transition: all 0.25s ease; border: ${n?`3px solid #eb5e28`:`2px solid #e2e8f0`};
                      box-shadow: ${n?`0 4px 14px rgba(235,94,40,0.35)`:`0 2px 6px rgba(0,0,0,0.06)`};
                      opacity: ${n?`1`:`0.75`}; transform: ${n?`scale(1.02)`:`scale(1)`};
                    ">
                      <img src="${e.thumb}" style="width: 100%; height: 100%; object-fit: cover;" />
                      ${e.type===`video`?`
                        <div style="position: absolute; inset: 0; background: rgba(0,0,0,0.45); display: flex; align-items: center; justify-content: center; color: #fff; font-size: 1.5rem;">
                          <i class="ri-play-circle-fill" style="color: #eb5e28;"></i>
                        </div>
                      `:``}
                    </div>
                  `}).join(``)}
              </div>
            `:``}
          </div>

          <!-- Specs Grid -->
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; background: #faf8f5; padding: 20px; border-radius: 14px; border: 1px solid #e2e8f0;">
            <div>
              <span style="font-size: 0.75rem; font-weight: 800; color: #718096; display: block;">EXPECTED PRICE</span>
              <div style="font-size: 1.3rem; font-weight: 800; color: #eb5e28;">${e.priceFormatted||`₹ `+(e.price||0).toLocaleString(`en-IN`)}</div>
            </div>
            <div>
              <span style="font-size: 0.75rem; font-weight: 800; color: #718096; display: block;">TYPE & PURPOSE</span>
              <div style="font-size: 0.95rem; font-weight: 700; color: #1a202c;">${e.type||`Property`} • ${e.categoryRaw||`Sale`}</div>
            </div>
            <div>
              <span style="font-size: 0.75rem; font-weight: 800; color: #718096; display: block;">LOCATION</span>
              <div style="font-size: 0.95rem; font-weight: 700; color: #1a202c;">${e.location||e.district}</div>
            </div>
            <div>
              <span style="font-size: 0.75rem; font-weight: 800; color: #718096; display: block;">AREA SIZE</span>
              <div style="font-size: 0.95rem; font-weight: 700; color: #1a202c;">${e.size||`N/A`}</div>
            </div>
            ${e.bedrooms?`
              <div>
                <span style="font-size: 0.75rem; font-weight: 800; color: #718096; display: block;">BEDROOMS / BATHROOMS</span>
                <div style="font-size: 0.95rem; font-weight: 700; color: #1a202c;">${e.bedrooms} Bed • ${e.bathrooms||0} Bath</div>
              </div>
            `:``}
          </div>

          <!-- Description -->
          <div>
            <h4 style="font-size: 0.85rem; font-weight: 800; color: #4A5568; text-transform: uppercase; margin-bottom: 8px;">PROPERTY DESCRIPTION</h4>
            <p style="font-size: 0.92rem; color: #4A5568; line-height: 1.6;">${e.description||`${e.title} located at ${e.location}.`}</p>
          </div>

        </div>

        <!-- Modal Footer -->
        <div style="padding: 18px 28px; background: #faf8f5; border-top: 1px solid #e2e8f0; display: flex; justify-content: flex-end; gap: 12px; flex-shrink: 0;">
          <button id="modal-user-edit-btn" data-id="${e.id}" style="background: #3182CE; color: #fff; border: none; padding: 10px 24px; border-radius: 10px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 6px;">
            <i class="ri-pencil-line"></i> Edit Property Details
          </button>
          <button id="modal-user-close-btn" style="background: #ffffff; border: 1px solid #cbd5e0; color: #4a5568; padding: 10px 24px; border-radius: 10px; font-weight: 700; cursor: pointer;">
            Close Preview
          </button>
        </div>

      </div>
    </div>
  `}function T(e){let t=document.getElementById(`close-user-prop-preview-btn`),n=document.getElementById(`modal-user-close-btn`),r=document.getElementById(`modal-user-edit-btn`),i=document.getElementById(`user-prev-preview-media-btn`),a=document.getElementById(`user-next-preview-media-btn`),o=()=>{document.getElementById(`user-prop-modal-overlay`)?.remove()};t?.addEventListener(`click`,o),n?.addEventListener(`click`,o),r?.addEventListener(`click`,()=>{o();let t=document.querySelector(`.user-edit-prop-btn[data-id="${e}"]`);t&&t.click()}),i?.addEventListener(`click`,t=>{t.stopPropagation();let n=s().find(t=>t.id===e),r=(n?.images?.length||1)+ +!!n?.videoUrl;f=(f-1+r)%r,C(e)}),a?.addEventListener(`click`,t=>{t.stopPropagation();let n=s().find(t=>t.id===e),r=(n?.images?.length||1)+ +!!n?.videoUrl;f=(f+1)%r,C(e)}),document.querySelectorAll(`.user-preview-thumb-card`).forEach(t=>{t.addEventListener(`click`,()=>{let n=parseInt(t.dataset.index,10);isNaN(n)||(f=n,C(e))})})}function E(e=null,t=`free`){let n=!!e,r=e?.adType||t||`free`;u=e?.images?[...e.images]:[],d=e?.videoUrl||``;let i=(e?.type||``).toLowerCase().trim(),a=[`house`,`villa`,`apartment`,`home`,`flat`,`duplex`,`townhouse`,`penthouse`,`building`,`room`,`bhk`,`residence`,`cottage`,`bungalow`,`rowhouse`,`manor`,`studio`].some(e=>i.includes(e));return`
    <div style="background: #FAF8F5; border: 1px solid #E7E0D8; border-radius: 16px; padding: 32px; width: 100%; max-width: 980px; margin: 0 auto; box-sizing: border-box;">
      <div style="margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid #E2E8F0; display: flex; justify-content: space-between; align-items: center;">
        <div>
          <span style="font-size: 0.78rem; font-weight: 800; color: #eb5e28; letter-spacing: 0.08em; text-transform: uppercase;">
            ${n?`EDITING PROPERTY ID: ${e.id}`:`PROPERTIES INVENTORY SUBMISSION FORM`}
          </span>
          <h3 style="font-size: 1.5rem; font-weight: 800; color: #1A202C; margin-top: 4px;">
            ${n?`Edit Property (${e.id})`:`Add New Property`}
          </h3>
        </div>

        ${n?`
          <button id="cancel-edit-btn" style="background: #FFF; border: 1px solid #CBD5E0; color: #4A5568; padding: 8px 16px; border-radius: 8px; font-weight: 700; cursor: pointer;">
            <i class="ri-arrow-left-line"></i> Cancel Edit
          </button>
        `:``}
      </div>

      <!-- AD TYPE ACTIVE BANNER -->
      ${r===`free`?`
        <div style="background: #EBF8FF; border: 1px solid #BEE3F8; border-left: 5px solid #3182CE; padding: 14px 18px; border-radius: 12px; margin-bottom: 24px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px;">
          <div style="display: flex; align-items: center; gap: 12px;">
            <div style="width: 38px; height: 38px; border-radius: 50%; background: rgba(49,130,206,0.15); color: #3182CE; display: flex; align-items: center; justify-content: center; font-size: 1.25rem; flex-shrink: 0;">
              <i class="ri-checkbox-circle-fill"></i>
            </div>
            <div>
              <div style="display: flex; align-items: center; gap: 8px;">
                <strong style="color: #1A202C; font-size: 0.95rem;">Selected Plan: FREE LISTING (Thanjai Property Managed)</strong>
                <span style="font-size: 0.72rem; font-weight: 800; background: rgba(49,130,206,0.15); color: #3182CE; padding: 2px 8px; border-radius: 6px;">FREE LISTING</span>
              </div>
              <span style="font-size: 0.82rem; color: #718096; display: block; margin-top: 2px;">
                All buyer inquiries are routed to Thanjai Property (<strong style="color: #3182CE;">+91 84899 96852</strong>) • Property commission / percentage is applicable on deal closure.
              </span>
            </div>
          </div>
          ${n?``:`
            <button type="button" id="change-adtype-btn" style="background: #ffffff; border: 1px solid #CBD5E0; color: #4A5568; padding: 8px 16px; border-radius: 8px; font-size: 0.82rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 6px;">
              <i class="ri-refresh-line"></i> Change Plan
            </button>
          `}
        </div>
      `:`
        <div style="background: #EBF8FF; border: 1px solid #BEE3F8; border-left: 5px solid #3182CE; padding: 14px 18px; border-radius: 12px; margin-bottom: 24px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px;">
          <div style="display: flex; align-items: center; gap: 12px;">
            <div style="width: 38px; height: 38px; border-radius: 50%; background: rgba(49,130,206,0.15); color: #3182CE; display: flex; align-items: center; justify-content: center; font-size: 1.25rem; flex-shrink: 0;">
              <i class="ri-checkbox-circle-fill"></i>
            </div>
            <div>
              <div style="display: flex; align-items: center; gap: 8px;">
                <strong style="color: #1A202C; font-size: 0.95rem;">Selected Plan: PAID LISTING (Direct Owner Listing)</strong>
                <span style="font-size: 0.72rem; font-weight: 800; background: rgba(49,130,206,0.15); color: #3182CE; padding: 2px 8px; border-radius: 6px;">PAID LISTING</span>
              </div>
              <span style="font-size: 0.82rem; color: #718096; display: block; margin-top: 2px;">
                Direct buyer inquiries will be sent to your Owner Dashboard & phone • <strong style="color: #3182CE;">0% Commission</strong> (Zero Brokerage).
              </span>
            </div>
          </div>
          ${n?``:`
            <button type="button" id="change-adtype-btn" style="background: #ffffff; border: 1px solid #CBD5E0; color: #4A5568; padding: 8px 16px; border-radius: 8px; font-size: 0.82rem; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 6px;">
              <i class="ri-refresh-line"></i> Change Plan
            </button>
          `}
        </div>
      `}

      <form id="client-post-prop-form" style="display: flex; flex-direction: column; gap: 28px;">
        
        <!-- SECTION 1: BASICS -->
        <div>
          <h4 style="font-size: 0.85rem; font-weight: 800; text-transform: uppercase; color: #4A5568; letter-spacing: 0.08em; margin-bottom: 16px;">
            1. PROPERTY BASICS & LOCATION
          </h4>

          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 18px;">
            <div style="grid-column: 1 / -1;">
              <label style="font-size: 0.82rem; font-weight: 800; color: #4A5568; display: block; margin-bottom: 6px;">Title *</label>
              <input type="text" id="user-prop-title" required value="${e?.title||``}" placeholder="e.g. 3BHK Luxury Villa with Garden & Car Parking" style="width: 100%; padding: 12px 14px; font-size: 0.95rem; border-radius: 10px; border: 1px solid #CBD5E0; box-sizing: border-box;" />
            </div>

            <div>
              <label style="font-size: 0.82rem; font-weight: 800; color: #4A5568; display: block; margin-bottom: 6px;">Property Type (Text Input) *</label>
              <input type="text" id="user-prop-type" required value="${e?.type||``}" placeholder="e.g. Villa, House, Apartment, Land, Plot..." style="width: 100%; padding: 12px 14px; font-size: 0.95rem; border-radius: 10px; border: 1px solid #CBD5E0; box-sizing: border-box;" />
            </div>

            <div>
              <label style="font-size: 0.82rem; font-weight: 800; color: #4A5568; display: block; margin-bottom: 6px;">Category / Purpose *</label>
              <select id="user-prop-category" required style="width: 100%; padding: 12px 14px; font-size: 0.95rem; border-radius: 10px; border: 1px solid #CBD5E0; background: #fff; box-sizing: border-box;">
                <option value="" disabled ${e?.categoryRaw?``:`selected`}>-- Select Category --</option>
                <option value="Sale" ${e?.categoryRaw===`Sale`||e?.purpose===`buy`?`selected`:``}>Sale (Buy)</option>
                <option value="Rent" ${e?.categoryRaw===`Rent`||e?.purpose===`rent`?`selected`:``}>Rent</option>
                <option value="Lease" ${e?.categoryRaw===`Lease`?`selected`:``}>Lease</option>
              </select>
            </div>

            <div>
              <label style="font-size: 0.82rem; font-weight: 800; color: #4A5568; display: block; margin-bottom: 6px;">Area / Locality *</label>
              <input type="text" id="user-prop-area" required value="${e?.area||e?.location||``}" placeholder="e.g. Sundaram Nagar, Medical College Area" style="width: 100%; padding: 12px 14px; font-size: 0.95rem; border-radius: 10px; border: 1px solid #CBD5E0; box-sizing: border-box;" />
            </div>

            <div>
              <label style="font-size: 0.82rem; font-weight: 800; color: #4A5568; display: block; margin-bottom: 6px;">Road / Prime Corridor</label>
              <select id="user-prop-road" style="width: 100%; padding: 12px 14px; font-size: 0.95rem; border-radius: 10px; border: 1px solid #CBD5E0; background: #fff; box-sizing: border-box;">
                <option value="" ${e?.road?``:`selected`}>-- Select Road Corridor (Optional) --</option>
                <option value="Medical College Road" ${e?.road===`Medical College Road`?`selected`:``}>Medical College Road</option>
                <option value="Trichy Road" ${e?.road===`Trichy Road`?`selected`:``}>Trichy Road</option>
                <option value="Pudukkottai Road" ${e?.road===`Pudukkottai Road`?`selected`:``}>Pudukkottai Road</option>
                <option value="Madhakottai Road" ${e?.road===`Madhakottai Road`?`selected`:``}>Madhakottai Road</option>
                <option value="Nanjikottai Road" ${e?.road===`Nanjikottai Road`?`selected`:``}>Nanjikottai Road</option>
                <option value="Villar Road" ${e?.road===`Villar Road`?`selected`:``}>Villar Road</option>
                <option value="Pattukottai Bypass" ${e?.road===`Pattukottai Bypass`?`selected`:``}>Pattukottai Bypass</option>
                <option value="Mariyamman Kovil Road" ${e?.road===`Mariyamman Kovil Road`?`selected`:``}>Mariyamman Kovil Road</option>
                <option value="Srinivasapuram" ${e?.road===`Srinivasapuram`?`selected`:``}>Srinivasapuram</option>
                <option value="Reddipalayam Road" ${e?.road===`Reddipalayam Road`?`selected`:``}>Reddipalayam Road</option>
                <option value="Kumbakonam Bypass" ${e?.road===`Kumbakonam Bypass`?`selected`:``}>Kumbakonam Bypass</option>
                <option value="Other / Outside Road" ${e?.road===`Other / Outside Road`?`selected`:``}>Other / Outside Road</option>
              </select>
            </div>

            <div>
              <label style="font-size: 0.82rem; font-weight: 800; color: #4A5568; display: block; margin-bottom: 6px;">Taluk</label>
              <input type="text" id="user-prop-taluk" value="${e?.taluk||``}" placeholder="e.g. Thanjavur, Kumbakonam" style="width: 100%; padding: 12px 14px; font-size: 0.95rem; border-radius: 10px; border: 1px solid #CBD5E0; box-sizing: border-box;" />
            </div>

            <div>
              <label style="font-size: 0.82rem; font-weight: 800; color: #4A5568; display: block; margin-bottom: 6px;">District</label>
              <input type="text" id="user-prop-district" value="${e?.district||``}" placeholder="e.g. Thanjavur, Trichy, Madurai" style="width: 100%; padding: 12px 14px; font-size: 0.95rem; border-radius: 10px; border: 1px solid #CBD5E0; box-sizing: border-box;" />
            </div>

            <div>
              <label style="font-size: 0.82rem; font-weight: 800; color: #4A5568; display: block; margin-bottom: 6px;">Facing</label>
              <input type="text" id="user-prop-facing" value="${e?.facing||e?.address||``}" placeholder="e.g. East, North, North-East" style="width: 100%; padding: 12px 14px; font-size: 0.95rem; border-radius: 10px; border: 1px solid #CBD5E0; box-sizing: border-box;" />
            </div>
          </div>
        </div>

        <!-- SECTION 2: SPECS & PRICING -->
        <div>
          <h4 style="font-size: 0.85rem; font-weight: 800; text-transform: uppercase; color: #4A5568; letter-spacing: 0.08em; margin-bottom: 16px;">
            2. SPECS, DIMENSIONS & PRICING
          </h4>

          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 18px;">
            <div>
              <label style="font-size: 0.82rem; font-weight: 800; color: #4A5568; display: block; margin-bottom: 6px;">Total Size / Area *</label>
              <input type="text" id="user-prop-size" required value="${e?.size||``}" placeholder="e.g. 2,400 sq.ft or 4.5 Cents" style="width: 100%; padding: 12px 14px; font-size: 0.95rem; border-radius: 10px; border: 1px solid #CBD5E0; box-sizing: border-box;" />
            </div>

            <div>
              <label style="font-size: 0.82rem; font-weight: 800; color: #4A5568; display: block; margin-bottom: 6px;">Expected Price (INR ₹) *</label>
              <input type="number" id="user-prop-price" required value="${e?.price||``}" placeholder="e.g. 13500000" style="width: 100%; padding: 12px 14px; font-size: 0.95rem; border-radius: 10px; border: 1px solid #CBD5E0; box-sizing: border-box;" />
            </div>
          </div>

          <!-- DYNAMIC RESIDENTIAL STRUCTURE SPECS -->
          <div id="user-res-specs-box" style="margin-top: 18px; display: ${a?`block`:`none`}; background: #FFF; padding: 20px; border-radius: 12px; border: 1px dashed #CBD5E0;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px;">
              <div>
                <label style="font-size: 0.82rem; font-weight: 800; color: #4A5568; display: block; margin-bottom: 6px;">Bedrooms</label>
                <input type="number" id="user-prop-bedrooms" value="${e?.bedrooms||``}" placeholder="e.g. 3" style="width: 100%; padding: 10px 12px; font-size: 0.9rem; border-radius: 8px; border: 1px solid #CBD5E0; box-sizing: border-box;" />
              </div>

              <div>
                <label style="font-size: 0.82rem; font-weight: 800; color: #4A5568; display: block; margin-bottom: 6px;">Bathrooms</label>
                <input type="number" id="user-prop-bathrooms" value="${e?.bathrooms||``}" placeholder="e.g. 3" style="width: 100%; padding: 10px 12px; font-size: 0.9rem; border-radius: 8px; border: 1px solid #CBD5E0; box-sizing: border-box;" />
              </div>

              <div>
                <label style="font-size: 0.82rem; font-weight: 800; color: #4A5568; display: block; margin-bottom: 6px;">Built-up Area (Sq.Ft)</label>
                <input type="text" id="user-prop-builtup-size" value="${e?.builtUpArea||``}" placeholder="e.g. 1850 or 1,850 Sq.Ft" style="width: 100%; padding: 10px 12px; font-size: 0.9rem; border-radius: 8px; border: 1px solid #CBD5E0; box-sizing: border-box;" />
              </div>

              <div>
                <label style="font-size: 0.82rem; font-weight: 800; color: #4A5568; display: block; margin-bottom: 6px;">Floor Number (Optional)</label>
                <input type="text" id="user-prop-floor" value="${e?.floor||``}" placeholder="e.g. 2nd Floor (Optional)" style="width: 100%; padding: 10px 12px; font-size: 0.9rem; border-radius: 8px; border: 1px solid #CBD5E0; box-sizing: border-box;" />
              </div>

              <div>
                <label style="font-size: 0.82rem; font-weight: 800; color: #4A5568; display: block; margin-bottom: 6px;">Furnishing Status</label>
                <select id="user-prop-furnishing" style="width: 100%; padding: 10px 12px; font-size: 0.9rem; border-radius: 8px; border: 1px solid #CBD5E0; background: #fff; box-sizing: border-box;">
                  <option value="Not specified" ${e?.furnishing===`Not specified`?`selected`:``}>Not specified</option>
                  <option value="Fully Furnished" ${e?.furnishing===`Fully Furnished`?`selected`:``}>Fully Furnished</option>
                  <option value="Semi-Furnished" ${e?.furnishing===`Semi-Furnished`?`selected`:``}>Semi-Furnished</option>
                  <option value="Unfurnished" ${e?.furnishing===`Unfurnished`?`selected`:``}>Unfurnished</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <!-- SECTION 3: PROPERTY PHOTOS & GALLERY -->
        <div>
          <h4 style="font-size: 0.85rem; font-weight: 800; text-transform: uppercase; color: #4A5568; letter-spacing: 0.08em; margin-bottom: 16px;">
            3. PROPERTY PHOTOS & GALLERY
          </h4>
          
          <div style="display: flex; flex-direction: column; gap: 14px;">
            <div>
              <label style="font-size: 0.82rem; font-weight: 700; color: #4A5568; display: block; margin-bottom: 6px;">Photo Image URL</label>
              <input type="url" id="user-prop-img-url" value="${e?.images&&e.images[0]?e.images[0]:``}" placeholder="https://images.unsplash.com/photo-..." style="width: 100%; padding: 12px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #CBD5E0; box-sizing: border-box;" />
            </div>

            <div>
              <label style="font-size: 0.82rem; font-weight: 700; color: #4A5568; display: block; margin-bottom: 6px;">Or Upload Photo Files</label>
              <input type="file" id="user-prop-img-files" accept="image/*" multiple style="width: 100%; padding: 10px 14px; font-size: 0.88rem; border-radius: 10px; border: 1px solid #CBD5E0; background: #fff; box-sizing: border-box;" />
            </div>

            <div id="user-uploaded-preview-grid" style="display: flex; gap: 12px; flex-wrap: wrap; margin-top: 10px;">
              ${b()}
            </div>
          </div>
        </div>

        <!-- SECTION 4: VIDEO & LOCATION PINPOINT MAP -->
        <div>
          <h4 style="font-size: 0.85rem; font-weight: 800; text-transform: uppercase; color: #4A5568; letter-spacing: 0.08em; margin-bottom: 16px;">
            4. VIDEO & LOCATION PINPOINT MAP
          </h4>

          <input type="hidden" id="user-prop-latitude" value="${e?.latitude||`10.786999`}" />
          <input type="hidden" id="user-prop-longitude" value="${e?.longitude||`79.137827`}" />

          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 18px;">
            <div>
              <label style="font-size: 0.82rem; font-weight: 700; color: #4A5568; display: block; margin-bottom: 6px;">YouTube Video Link</label>
              <input type="url" id="user-prop-videolink" value="${e?.videoUrl||``}" placeholder="https://youtube.com/watch?v=..." style="width: 100%; padding: 11px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #CBD5E0; box-sizing: border-box;" />
            </div>

            <div>
              <label style="font-size: 0.82rem; font-weight: 700; color: #4A5568; display: block; margin-bottom: 6px;">Upload Video File</label>
              <label style="display: flex; align-items: center; gap: 8px; padding: 10px 16px; border-radius: 10px; background: #fff; border: 1px dashed #CBD5E0; color: #4A5568; font-weight: 700; font-size: 0.88rem; cursor: pointer; height: 44px; box-sizing: border-box;">
                <i class="ri-video-upload-line" style="color: #eb5e28; font-size: 1.2rem;"></i>
                <span id="user-video-label-text">${e?.videoUrl?`Video Attached`:`Upload Video (.mp4)`}</span>
                <input type="file" id="user-prop-video-file-input" accept="video/*" style="display: none;" />
              </label>
            </div>
          </div>

          <div style="display: flex; gap: 12px; margin-top: 16px; flex-wrap: wrap; align-items: center;">
            <button type="button" id="user-geolocation-btn" style="background: #fff; border: 1px solid #CBD5E0; color: #2D3748; padding: 10px 18px; border-radius: 10px; font-weight: 700; font-size: 0.88rem; cursor: pointer; display: inline-flex; align-items: center; gap: 6px;">
              <i class="ri-map-pin-user-fill" style="color: #eb5e28;"></i> Use my current location
            </button>

            <button type="button" id="user-map-pinpoint-btn" style="background: #fff; border: 1px solid #CBD5E0; color: #2D3748; padding: 10px 18px; border-radius: 10px; font-weight: 700; font-size: 0.88rem; cursor: pointer; display: inline-flex; align-items: center; gap: 6px;">
              <i class="ri-compass-3-fill" style="color: #3182CE;"></i> Select Location on Interactive Map
            </button>
          </div>

          <div id="user-location-badge" style="margin-top: 12px; font-size: 0.85rem; font-weight: 700; color: #2B6CB0; display: ${e?.latitude?`inline-flex`:`none`}; align-items: center; gap: 6px; background: #EBF8FF; padding: 8px 14px; border-radius: 8px; border: 1px solid #BEE3F8;">
            <i class="ri-map-pin-2-fill" style="color: #eb5e28;"></i>
            <span id="user-location-badge-text">Location Pinpoint Captured: Lat ${e?.latitude||`10.786999`}, Lng ${e?.longitude||`79.137827`}</span>
          </div>
        </div>

        <!-- SECTION 5: DESCRIPTION & LEGAL AMENITIES -->
        <div>
          <h4 style="font-size: 0.85rem; font-weight: 800; text-transform: uppercase; color: #4A5568; letter-spacing: 0.08em; margin-bottom: 16px;">
            5. DESCRIPTION & LEGAL AMENITIES
          </h4>

          <div style="display: flex; flex-direction: column; gap: 16px;">
            <div>
              <label style="font-size: 0.82rem; font-weight: 700; color: #4A5568; display: block; margin-bottom: 6px;">Detailed Property Description</label>
              <textarea id="user-prop-desc" rows="4" style="width: 100%; padding: 12px 14px; font-size: 0.92rem; border-radius: 10px; border: 1px solid #CBD5E0; box-sizing: border-box;" placeholder="Describe water availability, road width, legal Patta title status, nearby landmarks...">${e?.description||``}</textarea>
            </div>

            <div>
              <label style="font-size: 0.82rem; font-weight: 700; color: #4A5568; display: block; margin-bottom: 8px;">Key Amenities & Legal Assurances</label>
              <div style="display: flex; gap: 14px; flex-wrap: wrap; font-size: 0.88rem; font-weight: 600; color: #4A5568;">
                <label><input type="checkbox" class="user-feature-chk" value="Clear Patta Title Verified" checked /> Clear Patta Title Verified</label>
                <label><input type="checkbox" class="user-feature-chk" value="24/7 Water Supply" checked /> 24/7 Water Supply</label>
                <label><input type="checkbox" class="user-feature-chk" value="Tar Road Frontage" /> Tar Road Frontage</label>
                <label><input type="checkbox" class="user-feature-chk" value="Gated Community" /> Gated Community</label>
                <label><input type="checkbox" class="user-feature-chk" value="Ready for Construction" /> Ready for Construction</label>
              </div>
            </div>
          </div>
        </div>

        <!-- SUBMIT ACTION BUTTON -->
        <div style="border-top: 1px solid #E2E8F0; padding-top: 24px; display: flex; justify-content: flex-end; gap: 12px;">
          <button type="submit" id="user-submit-prop-btn" style="background: #eb5e28; color: #fff; border: none; padding: 12px 32px; border-radius: 10px; font-weight: 800; font-size: 0.95rem; cursor: pointer; box-shadow: 0 4px 14px rgba(235,94,40,0.35);">
            <i class="ri-send-plane-fill"></i> ${n?`Save & Update Property`:`Submit & Publish Listing`}
          </button>
        </div>

      </form>
    </div>
  `}function D(e){return`
    <div class="table-responsive">
      <table class="user-table">
        <thead>
          <tr>
            <th>Inquiry ID</th>
            <th>Buyer Name & Role</th>
            <th>Property Interested</th>
            <th>Contact Info</th>
            <th>Offered Price / Visit</th>
            <th>Status</th>
            <th>Direct Actions</th>
          </tr>
        </thead>
        <tbody>
          ${e.map(e=>`
            <tr>
              <td style="font-weight: 700; color: #eb5e28;">${e.id}</td>
              <td>
                <div style="font-weight: 700; color: #1A202C;">${e.buyerName}</div>
                <span style="font-size: 0.78rem; background: #EDF2F7; color: #4A5568; padding: 2px 8px; border-radius: 4px; font-weight: 600;">${e.buyerRole}</span>
              </td>
              <td>
                <div style="font-weight: 700; color: #2B6CB0; font-size: 0.9rem;">${e.propertyTitle}</div>
                <span style="font-size: 0.78rem; color: #718096;">ID: ${e.propId}</span>
              </td>
              <td>
                <div style="font-size: 0.88rem; font-weight: 600;">${e.phone}</div>
                <div style="font-size: 0.8rem; color: #718096;">${e.email}</div>
              </td>
              <td>
                <div style="font-weight: 800; color: #eb5e28;">${e.offeredPrice}</div>
                <div style="font-size: 0.78rem; color: #718096;"><i class="ri-calendar-line"></i> ${e.visitDate}</div>
              </td>
              <td>
                <span style="background: #EBF8FF; color: #2B6CB0; font-weight: 800; padding: 4px 10px; border-radius: 6px; font-size: 0.8rem; display: inline-flex; align-items: center; gap: 4px;">
                  <i class="ri-checkbox-circle-line"></i> ${e.status}
                </span>
              </td>
              <td>
                <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                  <a href="https://wa.me/91${e.phone.replace(/[^0-9]/g,``)}?text=Hello%20${encodeURIComponent(e.buyerName)},%20regarding%20your%20inquiry%20for%20${encodeURIComponent(e.propertyTitle)}" target="_blank" style="background: #25D366; color: #fff; text-decoration: none; padding: 6px 12px; border-radius: 6px; font-weight: 700; font-size: 0.8rem; display: inline-flex; align-items: center; gap: 4px;">
                    <i class="ri-whatsapp-line"></i> Chat
                  </a>
                  <a href="tel:${e.phone}" style="background: #3182CE; color: #fff; text-decoration: none; padding: 6px 12px; border-radius: 6px; font-weight: 700; font-size: 0.8rem; display: inline-flex; align-items: center; gap: 4px;">
                    <i class="ri-phone-line"></i> Call
                  </a>
                </div>
              </td>
            </tr>
          `).join(``)}
        </tbody>
      </table>
    </div>
  `}function O(e,t,n){document.getElementById(`user-leaflet-map-modal-overlay`)?.remove();let r=parseFloat(e)||10.786999,i=parseFloat(t)||79.137827,a=r,o=i,s=document.createElement(`div`);s.id=`user-leaflet-map-modal-overlay`,s.style.cssText=`
    position: fixed !important; top: 0 !important; left: 0 !important; right: 0 !important; bottom: 0 !important;
    width: 100vw !important; height: 100vh !important; z-index: 9999999 !important;
    background: rgba(15, 23, 42, 0.8) !important; backdrop-filter: blur(8px) !important;
    display: flex !important; align-items: center !important; justify-content: center !important;
    padding: 24px !important; box-sizing: border-box !important; margin: 0 !important;
  `,s.innerHTML=`
    <div style="
      background: #ffffff; width: 100%; max-width: 820px; border-radius: 20px;
      overflow: hidden; box-shadow: 0 24px 50px rgba(0,0,0,0.35); border: 1px solid #E2E8F0;
      display: flex; flex-direction: column; animation: pageFadeIn 0.25s ease;
    ">
      <!-- HEADER -->
      <div style="
        padding: 16px 24px; background: #2B3648; color: #ffffff; display: flex;
        align-items: center; justify-content: space-between;
      ">
        <div style="display: flex; align-items: center; gap: 10px;">
          <i class="ri-compass-3-fill" style="color: #eb5e28; font-size: 1.4rem;"></i>
          <div>
            <h3 style="font-size: 1.1rem; font-weight: 800; color: #ffffff; margin: 0;">Interactive Location Pinpoint</h3>
            <span style="font-size: 0.78rem; color: #A0AEC0;">Click anywhere on the map or drag the pin to set property GPS location</span>
          </div>
        </div>

        <button id="close-user-map-modal-btn" style="
          background: rgba(255,255,255,0.12); border: none; color: #ffffff; width: 34px; height: 34px;
          border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; cursor: pointer;
        ">
          <i class="ri-close-line"></i>
        </button>
      </div>

      <!-- MAP CONTAINER -->
      <div style="position: relative; width: 100%; height: 420px; background: #EDF2F7;">
        <div id="user-leaflet-map-canvas" style="width: 100%; height: 100%;"></div>
        <div style="
          position: absolute; bottom: 16px; left: 16px; background: rgba(255,255,255,0.92);
          padding: 8px 14px; border-radius: 20px; font-size: 0.8rem; font-weight: 700; color: #1A202C;
          box-shadow: 0 4px 12px rgba(0,0,0,0.15); z-index: 1000; display: flex; align-items: center; gap: 6px;
        ">
          <i class="ri-map-pin-2-fill" style="color: #eb5e28;"></i>
          <span id="user-modal-coords-text">Lat: ${a.toFixed(6)}, Lng: ${o.toFixed(6)}</span>
        </div>
      </div>

      <!-- FOOTER -->
      <div style="padding: 16px 24px; background: #ffffff; border-top: 1px solid #E2E8F0; display: flex; justify-content: space-between; align-items: center;">
        <span style="font-size: 0.82rem; color: #718096; font-weight: 600;">
          <i class="ri-information-line"></i> Exact location helps buyers locate your property on map search.
        </span>

        <div style="display: flex; gap: 12px;">
          <button id="cancel-user-map-btn" style="
            padding: 10px 18px; border-radius: 10px; border: 1px solid #CBD5E0; background: #ffffff;
            color: #4A5568; font-weight: 700; font-size: 0.88rem; cursor: pointer;
          ">Cancel</button>

          <button id="confirm-user-map-btn" style="
            padding: 10px 22px; border-radius: 10px; border: none; background: #eb5e28;
            color: #ffffff; font-weight: 700; font-size: 0.88rem; cursor: pointer;
            box-shadow: 0 4px 12px rgba(235,94,40,0.25);
          ">Confirm Location</button>
        </div>
      </div>
    </div>
  `,document.body.appendChild(s);let c=()=>s.remove();document.getElementById(`close-user-map-modal-btn`)?.addEventListener(`click`,c),document.getElementById(`cancel-user-map-btn`)?.addEventListener(`click`,c),s.addEventListener(`click`,e=>{e.target===s&&c()}),setTimeout(()=>{if(typeof L<`u`){let e=L.map(`user-leaflet-map-canvas`).setView([r,i],14);L.tileLayer(`https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png`,{attribution:`&copy; OpenStreetMap contributors`}).addTo(e);let t=L.marker([r,i],{draggable:!0}).addTo(e);function s(e,t){a=e,o=t;let n=document.getElementById(`user-modal-coords-text`);n&&(n.textContent=`Lat: ${e.toFixed(6)}, Lng: ${t.toFixed(6)}`)}t.on(`dragend`,function(e){let n=t.getLatLng();s(n.lat,n.lng)}),e.on(`click`,function(e){t.setLatLng(e.latlng),s(e.latlng.lat,e.latlng.lng)}),document.getElementById(`confirm-user-map-btn`)?.addEventListener(`click`,()=>{c(),n(a.toFixed(6),o.toFixed(6))})}else document.getElementById(`confirm-user-map-btn`)?.addEventListener(`click`,()=>{c(),n(a.toFixed(6),o.toFixed(6))})},100)}function k(e){document.getElementById(`user-adtype-modal-overlay`)?.remove();let t=document.createElement(`div`);t.id=`user-adtype-modal-overlay`,t.style.cssText=`
    position: fixed !important; top: 0 !important; left: 0 !important; right: 0 !important; bottom: 0 !important;
    width: 100vw !important; height: 100vh !important; z-index: 999999 !important;
    background: rgba(15, 23, 42, 0.8) !important; backdrop-filter: blur(8px) !important;
    display: flex !important; align-items: center !important; justify-content: center !important;
    padding: 24px !important; box-sizing: border-box !important; margin: 0 !important;
  `,t.innerHTML=`
    <div style="
      background: #ffffff; width: 100%; max-width: 800px; max-height: calc(100vh - 48px);
      border-radius: 20px; overflow-y: auto; box-shadow: 0 25px 60px rgba(0,0,0,0.3);
      border: 1px solid #E2E8F0; display: flex; flex-direction: column; animation: pageFadeIn 0.25s ease;
      margin: auto;
    ">
      <!-- HEADER -->
      <div style="
        padding: 18px 24px 14px 24px; background: linear-gradient(135deg, #1A202C 0%, #2D3748 100%);
        color: #ffffff; display: flex; align-items: center; justify-content: space-between; flex-shrink: 0;
      ">
        <div>
          <span style="font-size: 0.74rem; font-weight: 800; color: #3182CE; letter-spacing: 0.1em; text-transform: uppercase;">STEP 1 OF 2 — CHOOSE LISTING PACKAGE</span>
          <h2 style="font-size: 1.3rem; font-weight: 800; color: #ffffff; margin: 3px 0 0 0;">Select Your Property Listing Package</h2>
        </div>

        <button id="close-adtype-modal-btn" style="
          background: rgba(255,255,255,0.12); border: none; color: #ffffff; width: 32px; height: 32px;
          border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.15rem; cursor: pointer;
        ">
          <i class="ri-close-line"></i>
        </button>
      </div>

      <!-- CARDS COMPARISON GRID -->
      <div style="padding: 20px 24px; background: #FAF8F5; display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 18px;">
        
        <!-- CARD 1: FREE LISTING -->
        <div class="ad-type-choice-card" style="
          background: #ffffff; border-radius: 14px; padding: 20px 18px; border: 2px solid #3182CE;
          box-shadow: 0 8px 20px rgba(49,130,206,0.06); display: flex; flex-direction: column; justify-content: space-between;
          position: relative; transition: all 0.25s ease;
        ">
          <div>
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
              <span class="badge" style="background: rgba(49,130,206,0.12); color: #3182CE; font-size: 0.74rem; font-weight: 800; padding: 3px 10px; border-radius: 20px;">
                FREE LISTING
              </span>
            </div>

            <h3 style="font-size: 1.2rem; font-weight: 800; color: #1A202C; margin: 0 0 6px 0;">Free Listing</h3>
            <p style="font-size: 0.82rem; color: #718096; line-height: 1.45; margin: 0 0 14px 0;">
              Zero upfront ad cost. Thanjai Property manages all buyer inquiries, property marketing, and client site visits for you.
            </p>

            <div style="display: flex; flex-direction: column; gap: 9px; margin-bottom: 18px; font-size: 0.83rem; color: #4A5568;">
              <div style="display: flex; align-items: flex-start; gap: 8px;">
                <i class="ri-checkbox-circle-fill" style="color: #3182CE; font-size: 1rem; flex-shrink: 0; margin-top: 1px;"></i>
                <span><strong>Ad Cost:</strong> Free (₹0 Upfront Cost)</span>
              </div>
              <div style="display: flex; align-items: flex-start; gap: 8px;">
                <i class="ri-checkbox-circle-fill" style="color: #3182CE; font-size: 1rem; flex-shrink: 0; margin-top: 1px;"></i>
                <span><strong>Deal Commission:</strong> Commission percentage applicable on deal closure</span>
              </div>
              <div style="display: flex; align-items: flex-start; gap: 8px;">
                <i class="ri-checkbox-circle-fill" style="color: #3182CE; font-size: 1rem; flex-shrink: 0; margin-top: 1px;"></i>
                <span><strong>Inquiries:</strong> Handled directly by Thanjai Property advisory team</span>
              </div>
              <div style="display: flex; align-items: flex-start; gap: 8px;">
                <i class="ri-checkbox-circle-fill" style="color: #3182CE; font-size: 1rem; flex-shrink: 0; margin-top: 1px;"></i>
                <span><strong>Public Contact:</strong> Thanjai Property (<strong style="color: #3182CE;">+91 84899 96852</strong>)</span>
              </div>
            </div>
          </div>

          <button id="choose-free-ad-btn" style="
            width: 100%; padding: 11px; border-radius: 10px; border: 2px solid #3182CE;
            background: #ffffff; color: #3182CE; font-weight: 800; font-size: 0.9rem; cursor: pointer;
            display: flex; align-items: center; justify-content: center; gap: 6px; transition: all 0.2s;
          " onmouseover="this.style.background='#3182CE'; this.style.color='#ffffff';" onmouseout="this.style.background='#ffffff'; this.style.color='#3182CE';">
            <span>Proceed with Free Listing</span>
            <i class="ri-arrow-right-line"></i>
          </button>
        </div>

        <!-- CARD 2: PAID LISTING -->
        <div class="ad-type-choice-card" style="
          background: #ffffff; border-radius: 14px; padding: 20px 18px; border: 2px solid #3182CE;
          box-shadow: 0 8px 20px rgba(49,130,206,0.06); display: flex; flex-direction: column; justify-content: space-between;
          position: relative; transition: all 0.25s ease;
        ">
          <div>
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
              <span class="badge" style="background: rgba(49,130,206,0.12); color: #3182CE; font-size: 0.74rem; font-weight: 800; padding: 3px 10px; border-radius: 20px;">
                PAID LISTING
              </span>
            </div>

            <h3 style="font-size: 1.2rem; font-weight: 800; color: #1A202C; margin: 0 0 6px 0;">Paid Listing</h3>
            <p style="font-size: 0.82rem; color: #718096; line-height: 1.45; margin: 0 0 14px 0;">
              Direct buyer calls and messages sent straight to you with 0% deal commission and verified direct owner visibility.
            </p>

            <div style="display: flex; flex-direction: column; gap: 9px; margin-bottom: 18px; font-size: 0.83rem; color: #4A5568;">
              <div style="display: flex; align-items: flex-start; gap: 8px;">
                <i class="ri-checkbox-circle-fill" style="color: #3182CE; font-size: 1rem; flex-shrink: 0; margin-top: 1px;"></i>
                <span><strong>Ad Cost:</strong> Paid Listing Plan</span>
              </div>
              <div style="display: flex; align-items: flex-start; gap: 8px;">
                <i class="ri-checkbox-circle-fill" style="color: #3182CE; font-size: 1rem; flex-shrink: 0; margin-top: 1px;"></i>
                <span><strong>Deal Commission:</strong> <strong style="color: #3182CE;">0% Commission</strong> (Zero Brokerage)</span>
              </div>
              <div style="display: flex; align-items: flex-start; gap: 8px;">
                <i class="ri-checkbox-circle-fill" style="color: #3182CE; font-size: 1rem; flex-shrink: 0; margin-top: 1px;"></i>
                <span><strong>Inquiries:</strong> Direct buyer leads sent to your Dashboard & phone</span>
              </div>
              <div style="display: flex; align-items: flex-start; gap: 8px;">
                <i class="ri-checkbox-circle-fill" style="color: #3182CE; font-size: 1rem; flex-shrink: 0; margin-top: 1px;"></i>
                <span><strong>Public Contact:</strong> Direct Owner Name & Contact details</span>
              </div>
            </div>
          </div>

          <button id="choose-paid-ad-btn" style="
            width: 100%; padding: 11px; border-radius: 10px; border: 2px solid #3182CE;
            background: #3182CE; color: #ffffff; font-weight: 800; font-size: 0.9rem; cursor: pointer;
            display: flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 4px 12px rgba(49,130,206,0.25); transition: all 0.2s;
          " onmouseover="this.style.background='#2B6CB0'; this.style.borderColor='#2B6CB0';" onmouseout="this.style.background='#3182CE'; this.style.borderColor='#3182CE';">
            <span>Proceed with Paid Listing</span>
            <i class="ri-arrow-right-line"></i>
          </button>
        </div>

      </div>

      <!-- FOOTER NOTE -->
      <div style="padding: 12px 24px; background: #ffffff; border-top: 1px solid #E2E8F0; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; flex-shrink: 0;">
        <span style="font-size: 0.78rem; color: #718096;">
          <i class="ri-shield-check-line" style="color: #3182CE;"></i> All listings are verified and approved by Thanjai Property administration before going live.
        </span>
        <button id="cancel-adtype-modal-btn" style="background: none; border: none; color: #718096; font-size: 0.82rem; font-weight: 700; cursor: pointer;">
          Cancel
        </button>
      </div>
    </div>
  `,document.body.appendChild(t);let n=()=>t.remove();document.getElementById(`close-adtype-modal-btn`)?.addEventListener(`click`,n),document.getElementById(`cancel-adtype-modal-btn`)?.addEventListener(`click`,n),t.addEventListener(`click`,e=>{e.target===t&&n()}),document.getElementById(`choose-free-ad-btn`)?.addEventListener(`click`,()=>{n(),e(`free`)}),document.getElementById(`choose-paid-ad-btn`)?.addEventListener(`click`,()=>{n(),e(`paid`)})}document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,g):g();